package tw.chris.guessMyDraw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import javax.swing.JFrame;

import tw.chris.guessMyDraw.Member;
import tw.chris.guessMyDraw.BCrypt;

public class checkAccount {
	
	static Member login(String account,String passwd, Connection conn) 
			throws Exception {
		String sql = "SELECT * FROM member WHERE account = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, account);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			String hashPasswd = rs.getString("passwd");
			if(BCrypt.checkpw(passwd, hashPasswd)) {
			Member member = new Member(rs.getInt("id"), rs.getString("account"), rs.getString("realname"));
			return member;
			}else {
				return null;
			}
		}else {
			return null;
		}
	}
	static final String sqlCheckAccount = "SELECT account FROM member WHERE account = ?";	
	static final String sqlAppendAccount = "INSERT INTO member (account,passwd) VALUES (?,?)";	
	static PreparedStatement checkStatement, appendStatement;
	
	public static int m1(String account,String passwd) {		
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");

		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/eeit48", prop);
			checkStatement = conn.prepareStatement(sqlCheckAccount);
			appendStatement = conn.prepareStatement(sqlAppendAccount);
		
			if (!isDataRepeat(account)) {
				if (appendData(account, passwd)) {
					System.out.println("Success");
					return 1;
				}else {
					System.out.println("E2");
					return 0;
				}
			}else {
				System.out.println("E1");
				return 0;
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return 0;

	}
	
	public static boolean isDataRepeat(String account)  throws Exception {
		checkStatement.setString(1, account);
		ResultSet rs = checkStatement.executeQuery();
		return rs.next();
	}
	
	public static boolean appendData(String account,String passwd)
			throws Exception {
		appendStatement.setString(1, account);
		appendStatement.setString(2,BCrypt.hashpw(passwd, BCrypt.gensalt()) );
		int n = appendStatement.executeUpdate();
		
		return n != 0;
	}
	
}
