package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class playRoomNew extends JFrame implements ActionListener {
	
	private JButton leaveRoom;
	private JTextField chat,answer;
	private JTextArea chatArea,answerArea;
	private	String chatareaText,oldchat = "";
	int rId;
	
	public playRoomNew(String roomId) {
		rId = Integer.parseInt(roomId);
		leaveRoom = new JButton("離開遊戲");
		chat = new JTextField(20);
		answer = new JTextField(20);
		chatArea = new JTextArea(10,10);
		JScrollPane jsp = new JScrollPane(chatArea);
		answerArea = new JTextArea(10,10);
		
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");
		Timer T1 = new Timer();
		TimerTask loadChar = new TimerTask(){
			@Override
			public void run() {
				try {
					Connection conn = DriverManager.getConnection(
							"jdbc:mysql://localhost:3306/eeit48", prop);
					String sql2 = "SELECT * FROM partyroom WHERE roomId = ?";
					PreparedStatement pstmt = conn.prepareStatement(sql2);
					pstmt.setInt(1,rId);
					pstmt.execute();
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						chatareaText = rs.getString("roomChat");
						if(chatareaText.compareTo(oldchat) !=0) {
						chatArea.append(chatareaText + "\n");
						oldchat= chatareaText;
						}
					}
				}catch (Exception e2) {
					System.out.println(e2.toString());
				}
		}};
		T1.schedule(loadChar,0,1*1000);
		
		
		setSize(800, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		JPanel playerArea = new JPanel(); 
		playerArea.setPreferredSize(new Dimension(100,560));
		playerArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		
        signApp myDraw = new signApp(rId);
//        myDraw.setPreferredSize(new Dimension(600,400));
        myDraw.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
         
        answerArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        answer.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        chatArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        chat.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        
        JPanel toolBar = new JPanel(new BorderLayout());
        JPanel ansBar = new JPanel(new BorderLayout());
        JPanel chatBar = new JPanel(new BorderLayout());
        ansBar.add(answerArea,BorderLayout.CENTER);
        ansBar.add(answer,BorderLayout.SOUTH);
        chatBar.add(jsp,BorderLayout.CENTER);
        chatBar.add(chat,BorderLayout.SOUTH);
        toolBar.add(ansBar,BorderLayout.WEST);
        toolBar.add(chatBar,BorderLayout.CENTER);
        
        add(playerArea,BorderLayout.WEST);
        add(myDraw,BorderLayout.CENTER);
        add(toolBar,BorderLayout.SOUTH);
        
        chat.addActionListener(this);
        
		setVisible(true);
	}

	public static void main(String[] args) {
//		new playRoomNew("2");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String chatText = chat.getText();
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/eeit48", prop);
				
			String sql = "UPDATE partyroom SET roomChat = ? WHERE roomId = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, chatText);	
			ps.setInt(2, rId);
			ps.execute();
			chat.setText("");
		} catch (Exception e1) {
			System.out.println(e1.toString());
		}
	}
}
