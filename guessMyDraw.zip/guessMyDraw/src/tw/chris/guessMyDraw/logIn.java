package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import tw.chris.guessMyDraw.Member;

public class logIn extends JFrame implements ActionListener {

	private JButton login,create;
	private JLabel	account,password,startImage;
	private JTextField acIn,pwIn;
	private String loginAc,loginPw;  
	
	public logIn() {
		
		login = new JButton("登入");
		create = new JButton("註冊");
		account = new JLabel("帳號:");
		password = new JLabel("密碼:");
		ImageIcon icon = new ImageIcon("./dir1/123456.jpg");
		Image image = icon.getImage(); 
		Image newimg = image.getScaledInstance(300,150,java.awt.Image.SCALE_SMOOTH);  
		icon = new ImageIcon(newimg);
		startImage = new JLabel(icon);
		acIn = new JTextField(20);
		pwIn = new JTextField(20);
		
		setLayout(new BorderLayout());
		add(startImage, BorderLayout.CENTER);
		JPanel textIn = new JPanel(new BorderLayout());
		JPanel p1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		p1.add(account);
		p1.add(acIn);
		p1.add(login);
		JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		p2.add(password);
		p2.add(pwIn);
		p2.add(create);
		textIn.add(p1,BorderLayout.NORTH);
		textIn.add(p2,BorderLayout.CENTER);
		add(textIn, BorderLayout.SOUTH);
		
		acIn.addActionListener(this);
		pwIn.addActionListener(this);
		login.addActionListener(this);
		
		setLocationRelativeTo(null);
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		addEventListener();
	}
	
	public static void main(String[] args) {
		logIn loginPage = new logIn();
	}
	
	private void addEventListener() {
		create.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				loginAc = acIn.getText();
				loginPw = pwIn.getText();
				int check = checkAccount.m1(loginAc,loginPw);
				if(check == 1) {
				dispose();
				new createOK();
				}else {
					new createFalse();
				}
			}
		});
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		loginAc = acIn.getText();
		loginPw = pwIn.getText();
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/eeit48", prop);
			Member member = checkAccount.login(loginAc, loginPw, conn);
			if (member != null) {
				System.out.println("Welcome, " + member.getRealname());
				new chooseRoom(); 
				this.setVisible(false);
			}else {
				System.out.println("get out here");
			}
		} catch (Exception e1) {
			System.out.println(e1.toString());
		}
	}

}
