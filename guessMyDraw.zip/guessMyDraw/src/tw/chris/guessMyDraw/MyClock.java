package tw.chris.guessMyDraw;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;

public class MyClock extends JLabel {
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //格式須注意
	private Timer timer;
	public MyClock() {
		timer = new Timer();
		timer.schedule(new ClockTask(),0,1000);
		
		
		
//		Date now = new Date();
//		Calendar cal = Calendar.getInstance();	//用方法建出一個實體
//		int year = cal.get(Calendar.YEAR);
//		int month = cal.get(Calendar.MONTH) + 1;
//		int day = cal.get(Calendar.DAY_OF_MONTH);
//		int hour = cal.get(Calendar.HOUR_OF_DAY);
//		int miunte = cal.get(Calendar.MINUTE);
//		int second = cal.get(Calendar.SECOND);
//		setText(String.format("%04d-%02d-%02d"+""+"%02d:%02d:%02d", year, month, day,hour,miunte,second));
	}
	
	private class ClockTask extends TimerTask{

		@Override
		public void run() {
			setText(sdf.format(new Date()));
		}
		
	}
	
}
