package tw.chris.guessMyDraw;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Properties;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class MyDrawer extends JPanel {	
	private LinkedList<LinkedList<HashMap<String, Integer>>> lines,recycler;
	int i = 0,rId;
	public MyDrawer(int rId) {
		this.rId = rId;
		setBackground(Color.yellow);
		MyMouseListenerV3 ListenerV3 = new MyMouseListenerV3();	
		addMouseListener(ListenerV3);
		addMouseMotionListener(ListenerV3);
		
		lines = new LinkedList<>();
		recycler = new LinkedList<>();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);		
		
		Graphics2D g2d = (Graphics2D)g;
		g2d.setStroke(new BasicStroke(3));
		g2d.setColor(Color.blue);
		for (LinkedList<HashMap<String, Integer>> line : lines) {
			for (int i=1;i<line.size();i++) {
				HashMap<String , Integer> p0 = line.get(i-1);
				HashMap<String , Integer> p1 = line.get(i);
				g2d.drawLine(p0.get("x"), p0.get("y"), 
						p1.get("x"), p1.get("y"));
			}
		}
		
	}


class MyMouseListenerV3 extends MouseAdapter{
	
	@Override
	public void mousePressed(MouseEvent e) {
		HashMap<String,Integer> point = new HashMap<>();
		point.put("x", e.getX());point.put("y", e.getY());
		LinkedList<HashMap<String, Integer>> line = new LinkedList<>();
		line.add(point);
		lines.add(line);
		recycler.clear();
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		HashMap<String,Integer> point = new HashMap<>();
		point.put("x", e.getX());point.put("y", e.getY());
		lines.getLast().add(point);
		repaint();
	}
	
}
public void clear() {
	lines.clear();
	repaint();
} 
public void undo() {
	if (lines.size() > 0) {
		recycler.add(lines.removeLast());
		repaint();
	}
}

public void redo() {
	if (recycler.size() > 0) {
		lines.add(recycler.removeLast());
		repaint();
		}
	}

public void saveImage(){
	BufferedImage img = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
	Graphics2D g2d = img.createGraphics();
	paint(g2d);
	i++;
	File dir = new File("./dirDraw");
	if (!dir.exists()) {
		System.out.println("create dirDraw");
		dir.mkdirs();
	}
	try {
		ImageIO.write(img, "jpeg", new File("./dirDraw/myDraw" + i + ".jpg"));
	} catch (IOException e) {
		System.out.println(e.toString());
		}	
}
	
	public void savelines() {
		File dir = new File("./dirDraw");
		if (!dir.exists()) {
			System.out.println("create dirDraw");
			dir.mkdirs();
		}
		
		try (FileOutputStream fout = new FileOutputStream("./dirDraw/lines.chris");
				ObjectOutputStream oout = new ObjectOutputStream(fout)) {
			oout.writeObject(lines);
			oout.flush();
//			System.out.println("ok1");
		} catch (Exception e) {
			System.out.println(e.toString());
			}
		
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");

		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/eeit48", prop);
			
			FileInputStream fin = new FileInputStream("./dirDraw/lines.chris");	
			String sql = "UPDATE partyroom SET roomDraw = ? WHERE roomId = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setObject(1, fin);	
			ps.setInt(2, rId);
			ps.execute();
//			fin.close();
//			System.out.println("ok2");
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
}
	
	public void loadlines() {
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");

		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/eeit48", prop);		
			String sql = "SELECT * FROM partyroom WHERE roomId = ? ";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,rId);
			ResultSet rs = ps.executeQuery();
			rs.next();
			
//			while (rs.next()) {
			InputStream in = rs.getBinaryStream("roomDraw");
			ObjectInputStream oin = new ObjectInputStream(in);		
			lines = (LinkedList<LinkedList<HashMap<String, Integer>>>)oin.readObject();
			repaint();
//				}
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
}
