package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import tw.chris.guessMyDraw.MyDrawer;

public class signApp extends JPanel implements ActionListener {
private	JButton clear,undo,redo,save;
private MyDrawer MyDrawer;
private MyClock MyClock;
	
	public signApp(int rId) {
		
		setLayout(new BorderLayout());
		clear = new JButton("Clear");
		undo = new JButton("Undo");
		redo = new JButton("Redo");
		save = new JButton("Save");
		MyClock = new MyClock();
				
		JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
		top.add(clear);top.add(undo);top.add(redo);top.add(save);
		top.add(MyClock);
		add(top,BorderLayout.NORTH);
		
		MyDrawer = new MyDrawer(rId);
		add(MyDrawer,BorderLayout.CENTER);
		
		Timer T1 = new Timer();
		TimerTask u1 = new TimerTask(){
			@Override
			public void run() {
			MyDrawer.savelines();
		}};
		TimerTask l1 = new TimerTask(){
			@Override
			public void run() {
			MyDrawer.loadlines();
		}};
		T1.schedule(u1,0,1*100);
		T1.schedule(l1,1,1*100);
	
		setSize(600,400);
//		setVisible(true);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		addEventListener();
	}

	private void addEventListener() {
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyDrawer.clear();
			}
		});
		undo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyDrawer.undo();
			}
		});
		redo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyDrawer.redo();
			}
		});
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				MyDrawer.saveImage();
			}
		});		
	}

	public static void main(String[] args) {
		
//		new signApp();
	}
	public void actionPerformed(ActionEvent e) {
	
	}	
}

