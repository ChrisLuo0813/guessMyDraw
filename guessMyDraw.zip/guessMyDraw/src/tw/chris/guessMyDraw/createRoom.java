package tw.chris.guessMyDraw;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class createRoom {

	public static void main(String[] args) {
		
		 JFrame jFrame = new JFrame();
	     String getMessage1 = JOptionPane.showInputDialog(jFrame, "請輸入房名");
	     String getMessage2 = JOptionPane.showInputDialog(jFrame, "請輸入房間主題");	 	        
	     JOptionPane.showMessageDialog(jFrame, "你的房間名稱: "+getMessage1);
	     JOptionPane.showMessageDialog(jFrame, "你的房間主題: "+getMessage2);
	     
	     int result = JOptionPane.showConfirmDialog(jFrame, "Press any button to close the dialog.");
	     int res=JOptionPane
	    			.showConfirmDialog(jFrame, "是否創立房間", "新增房間", JOptionPane.YES_NO_OPTION);  
	     System.out.println(res);
	}	
}
