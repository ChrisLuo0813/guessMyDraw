package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class createOK extends JFrame implements ActionListener {
	
	private JButton gotoRoom;
	private JLabel	msg;
	
	
	
	public createOK() {
		gotoRoom = new JButton("確定");
		msg = new JLabel("恭喜老爺賀喜夫人，帳號創建成功，請點擊確定前往大廳",JLabel.CENTER);
		setLayout(new BorderLayout());
		add(msg,BorderLayout.CENTER);
		add(gotoRoom,BorderLayout.SOUTH);
		gotoRoom.addActionListener(this);
		
		setLocationRelativeTo(null);
		setSize(400, 200);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		dispose();
		new chooseRoom(); 
	}

}
