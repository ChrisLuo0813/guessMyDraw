package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class chooseRoom extends JFrame implements ActionListener {

	private JButton checkRoom,createRoom;
	private JLabel	roomId,roomName,roomPw,roomClass;
	private JTextField roomSearch;
	private String rSearch;
	private JScrollPane rooms;
	private String drid,drname,drclass,drpw;
	
	
	public chooseRoom() {
		checkRoom = new JButton("確認");
		createRoom = new JButton("新建房間");
		roomSearch = new JTextField(20);
		
		JPanel north = new JPanel();
		JPanel east = new JPanel();
		JPanel west = new JPanel();
		north.setPreferredSize(new Dimension(800,30));
		east.setPreferredSize(new Dimension(30,600));
		west.setPreferredSize(new Dimension(30,600));
		
		JPanel p0 = new JPanel(new FlowLayout(FlowLayout.LEADING));
		p0.setPreferredSize(new Dimension(600,600));
		
		Properties prop = new Properties();
		prop.put("user", "root");
		prop.put("password", "root");
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/eeit48", prop);
			String sql = "SELECT * FROM partyroom";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {	
				String roomId = rs.getString("roomId");
				String roomName = rs.getString("roomName");
				String roomClass = rs.getString("roomClass");	
				String roomPw = rs.getString("roomPw");
				p0.add(new drawRoom(roomId,roomName,roomClass,roomPw));
				
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		rooms = new JScrollPane(p0);
		
		JPanel tool = new JPanel(new FlowLayout(FlowLayout.CENTER));
		tool.add(roomSearch);
		tool.add(checkRoom);
		tool.add(createRoom);
		
		setLayout(new BorderLayout());
		add(rooms,BorderLayout.CENTER);
		add(tool,BorderLayout.SOUTH);
		add(north,BorderLayout.NORTH);
		add(east,BorderLayout.EAST);
		add(west,BorderLayout.WEST);
		
		setLocationRelativeTo(null);
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		addEventListener();
	}
	
	public static void main(String[] args) {
		new chooseRoom();
	}
	
	private class drawRoom extends JPanel {
		
			public drawRoom(String drId,String drName,String drClass,String drPw)  {
				drid = drId;
				drname = drName;
				drclass = drClass;
				drpw = drPw;
				setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
				setBorder(BorderFactory.createRaisedBevelBorder());
				setPreferredSize(new Dimension(200,200));
				setBackground(Color.blue);
				JLabel	jid = new JLabel(drId);
				JLabel	jdrN = new JLabel(drName);
				JLabel	jdrC = new JLabel(drClass);
				JLabel	jdrP = new JLabel(drPw);
				jid.setFont(new java.awt.Font("Dialog", 1, 30));
				jdrN.setFont(new java.awt.Font("Dialog", 1, 30));
				jdrC.setFont(new java.awt.Font("Dialog", 1, 30));
				jdrP.setFont(new java.awt.Font("Dialog", 1, 30));
				add(jid);
				add(jdrN);
				add(jdrC);
				add(jdrP);
				addMouseListener(new MouseAdapter() {

					@Override
					public void mouseClicked(MouseEvent e) {
//						System.out.println(drid + "_" + drname + "_" + drclass);
						super.mouseClicked(e);
					}
					
				});
		}
	} 

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}	
	private void addEventListener() {
		checkRoom.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new playRoomNew(drid);
				dispose();
			}
		});
		createRoom.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame jFrame = new JFrame();
			     String getMessage1 = JOptionPane.showInputDialog(jFrame, "請輸入房名");
			     String getMessage2 = JOptionPane.showInputDialog(jFrame, "請輸入房間主題");	 	        
			     JOptionPane.showMessageDialog(jFrame, "你的房間名稱: "+getMessage1);
			     JOptionPane.showMessageDialog(jFrame, "你的房間主題: "+getMessage2);
			     
//			     int result = JOptionPane.showConfirmDialog(jFrame, "Press any button to close the dialog.");
			     int res=JOptionPane
			    			.showConfirmDialog(jFrame, "是否創立房間", "新增房間", JOptionPane.YES_NO_OPTION);  
			     if(res == 0) {
			    	 try {
			 			Properties prop = new Properties();
			 			prop.put("user", "root");
			 			prop.put("password", "root");
			 			
			 			Connection conn = DriverManager.getConnection(
			 					"jdbc:mysql://localhost:3306/eeit48",prop);
			 			
			 			String sql = "INSERT INTO  partyroom(roomName,roomClass) VALUES (?,?)";
			 			PreparedStatement pstmt = conn.prepareStatement(sql);
			 			pstmt.setString(1, getMessage1);
			 			pstmt.setString(2, getMessage2);
			 			int n = pstmt.executeUpdate();
			 			System.out.println("OK");
			 			dispose();
			 			new chooseRoom(); 
			 			
			 		} catch (SQLException e2) {
			 			System.out.println(e2.toString());
			 		}
			     }
			}
		});
		
	}
}


// https://ithelp.ithome.com.tw/articles/10273232