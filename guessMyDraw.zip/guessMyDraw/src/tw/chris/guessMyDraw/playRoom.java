package tw.chris.guessMyDraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class playRoom extends JFrame implements ActionListener {
	
	private JButton leaveRoom;
	private JLabel	roomId;
	private JTextField chat,answer;
	private JTextArea chatArea,answerArea;
	
	public playRoom() {
		leaveRoom = new JButton("離開遊戲");
		roomId = new JLabel("ABC123");
		chat = new JTextField(20);
		answer = new JTextField(20);
		chatArea = new JTextArea();
		answerArea = new JTextArea();
		
		setSize(800, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridBagLayout());
		
		JPanel playerArea = new JPanel(); 
		playerArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		playerArea.setPreferredSize(new Dimension(100,560));
		GridBagConstraints c0 = new GridBagConstraints();
		c0.gridx = 20;
		c0.gridy = 20;
		c0.gridwidth = 100;
        c0.gridheight = 560;
//        c0.weightx = 0;
//        c0.weighty = 0;
        c0.fill = GridBagConstraints.BOTH;
//        c0.anchor = GridBagConstraints.WEST;
        add(playerArea, c0);
		
        signApp myDraw = new signApp(1);
        myDraw.setPreferredSize(new Dimension(600,400));
        myDraw.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		GridBagConstraints c1 = new GridBagConstraints();
		c1.gridx = 180;
		c1.gridy = 20;
		c1.gridwidth = 600;
        c1.gridheight = 400;
        c1.insets = new Insets(20,20,20,20);
        c1.fill = GridBagConstraints.BOTH;
        add(myDraw, c1);
         
        answerArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		GridBagConstraints c2 = new GridBagConstraints();
		c2.gridx = 180;
		c2.gridy = 440;
		c2.gridwidth = 280;
        c2.gridheight = 120;
        c2.insets = new Insets(0,20,0,20);
        c2.fill = GridBagConstraints.BOTH;
        add(answerArea, c2);
		
        answer.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        GridBagConstraints c3 = new GridBagConstraints();
		c3.gridx = 180;
		c3.gridy = 560;
		c3.gridwidth = 280;
        c3.gridheight = 20;
        c3.insets = new Insets(0,20,0,20);
        c3.fill = GridBagConstraints.BOTH;
        add(answer, c3);
        
        chatArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		GridBagConstraints c4 = new GridBagConstraints();
		c4.gridx = 480;
		c4.gridy = 440;
		c4.gridwidth = 280;
        c4.gridheight = 120;
        c4.insets = new Insets(0,20,0,20);
        c4.fill = GridBagConstraints.BOTH;
        add(chatArea, c4);
		
        chat.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        GridBagConstraints c5 = new GridBagConstraints();
		c5.gridx = 480;
		c5.gridy = 560;
		c5.gridwidth = 280;
        c5.gridheight = 20;
        c5.insets = new Insets(0,20,0,20);
        c5.fill = GridBagConstraints.BOTH;
        add(chat, c5);
        
        
        
        
		setVisible(true);
	}

	public static void main(String[] args) {
		new playRoom();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
