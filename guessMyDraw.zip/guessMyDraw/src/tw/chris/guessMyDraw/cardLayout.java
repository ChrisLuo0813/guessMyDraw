package tw.chris.guessMyDraw;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class cardLayout extends JFrame implements ActionListener {
    JFrame frame;
    Panel p1, p2;
    CardLayout card;
    Button next, previous, first, last, show;    

	public static void main(String[] args) {
		new cardLayout();
	}
	
	public cardLayout() {
        Frame frame = new JFrame("AWTDemo");
        frame.setSize(400, 200);
         
        p1 = new Panel();
        card = new CardLayout();
        p1.setLayout(card);
        p1.add(new Label("1"), "one");
        p1.add(new Label("2"), "two");
        p1.add(new Label("3"), "three");
        p1.add(new Label("4"), "four");
        p1.add(new Label("5"), "five");
         
        p2 = new Panel();
        p2.setLayout(new FlowLayout());
        next = new Button("NEXT");
        next.setActionCommand("next");
        next.addActionListener(this);
        previous = new Button("PREVIOUS");
        previous.setActionCommand("previous");
        previous.addActionListener(this);
        first = new Button("FIRST");
        first.setActionCommand("first");
        first.addActionListener(this);
        last = new Button("LAST");
        last.setActionCommand("last");
        last.addActionListener(this);
        show = new Button("SHOW");
        show.setActionCommand("show");
        show.addActionListener(this);
        p2.add(next);
        p2.add(previous);
        p2.add(first);
        p2.add(last);
        p2.add(show);
         
        frame.add(p1, BorderLayout.CENTER);
        frame.add(p2, BorderLayout.SOUTH);
        frame.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		 String cmd = e.getActionCommand();
	        if (cmd == "next") {
	            card.next(p1);
	        }
	        if (cmd == "previous") {
	            card.previous(p1);
	        }
	        if (cmd == "first") {
	            card.first(p1);
	        }
	        if (cmd == "last") {
	            card.last(p1);
	        }
	        if (cmd == "show") {
	            card.show(p1, "three");
	        }
	}

}
	
//	https://pydoing.blogspot.com/2012/06/java-api-cardlayout.html
//  https://tw-hkt.blogspot.com/2019/05/java-gridbaglayout.html
//  https://pydoing.blogspot.com/2011/05/java-gridbaglayout.html