-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- 主機： localhost:3306
-- 產生時間： 2022-08-19 07:06:07
-- 伺服器版本： 5.7.24
-- PHP 版本： 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫: `chris`
--
CREATE DATABASE IF NOT EXISTS `chris` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `chris`;

-- --------------------------------------------------------

--
-- 資料表結構 `t1`
--

CREATE TABLE `t1` (
  `f1` varchar(4) DEFAULT NULL,
  `f2` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- 資料庫: `eeit48`
--
CREATE DATABASE IF NOT EXISTS `eeit48` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `eeit48`;

-- --------------------------------------------------------

--
-- 資料表結構 `class`
--

CREATE TABLE `class` (
  `classId` int(10) NOT NULL,
  `roomClass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `class`
--

INSERT INTO `class` (`classId`, `roomClass`) VALUES
(1, '動漫人物'),
(7, '中國偉人'),
(8, '七龍珠'),
(9, '名偵探柯南');

-- --------------------------------------------------------

--
-- 資料表結構 `cust`
--

CREATE TABLE `cust` (
  `id` int(10) UNSIGNED NOT NULL,
  `cname` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `birthday` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `cust`
--

INSERT INTO `cust` (`id`, `cname`, `tel`, `birthday`) VALUES
(6, 'chris', '987654567', '1999-01-04'),
(8, 'brad', '789', '1999-01-04'),
(9, 'brad', '789', '1999-01-04'),
(10, 'brad', '789', '1999-01-04'),
(11, 'brad', '789', '1999-01-04'),
(12, 'abcde', '123456789', '2020-01-07'),
(13, 'paul', '5559555', '1951-05-04'),
(14, 'paul', '5559555', '1951-05-04'),
(15, 'paul', '5559555', '1951-05-04'),
(16, 'paul', '5559555', '1951-05-04'),
(17, 'paul', '5559555', '1951-05-04'),
(18, 'Eric', '333', '1999-02-03'),
(19, 'paul', '5559555', '1951-05-04'),
(20, 'paul', '5559555', '1951-05-04');

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

CREATE TABLE `member` (
  `id` int(10) UNSIGNED NOT NULL,
  `account` varchar(100) NOT NULL,
  `passwd` varchar(256) NOT NULL,
  `realname` varchar(100) DEFAULT NULL,
  `icon` blob,
  `student` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `member`
--

INSERT INTO `member` (`id`, `account`, `passwd`, `realname`, `icon`, `student`) VALUES
(1, 'chris', '$2a$10$ZWlG7JwO6nCVVWwzFsmkcu170xOi05tXoxbp0evQbKG6yMQ9b0xfC', 'ChrisOK', 0x89504e470d0a1a0a0000000d4948445200000040000000400806000000aa6971de000000017352474200aece1ce90000000467414d410000b18f0bfc61050000000970485973000017110000171101ca26f33f0000127549444154785eed5b7b705cd579fff6bd927657b22d5bb2246459b6e307b6710b311883c10e94646a32532698ba1d7052322e696dd3326981e97488c7434cc609842690d4268184b4a181040692821f60546ce21abf6dfc946c3dac872d5b8fd54afbdeedf73bf77ed2d9ddbb92fcfaabfe667e3af79e7bcfbde7f73bdff9cee3aee8ba5db7eb76ddfe3f9bcd4cafa94522912fa452a9db1c0ec75c3e9d964ea72b6d36db584e0b18c4d7c29c5e8c46a3ad6bbefd1fa7f6ed6b3f68b3bb771dddbfb6de78c2b5b36b220093b1f7f4f4dce5743a97f1e952bbdd5ec5848d8ba681b80e264f2ffc682bbdf3de31b2d99d64b339f82e5bb38dec7f48a5e9379fef7daa8ecfd346e9ab67575580cece4e3f1359e972b9fe8e5bbb16a475e806d2a150881289043c80defdc321fad92f8f90ddeee67b5900bb832b6737ef86d91b289d7a29eab16f3a5ab72a64665eb15d1501b66fdfee2d2d2d5de376bb9fe4561fcbe409e096cf1020994c2ac22c90ba5e5454a452582c16a32ddb0ed0eb6f1ca1d676c3036c3608802ac24b922c8a0ba25c8cc582eb439dc91fd7d73f1e5585afc0ae5880ad5bb7dee3f57a7feaf178a6307912803cc88138c881acdfefa7c2c242d5faf90c5de1f7ffbd9f5eff4d0b05fbbc9c3324402a1557b0b31089f8c0c964bcf7b183bb9fdcae0a5ea65db6002fbef8a267c284091b98fc2a266fe3d6572d2b0280384418376e1c95959599a50cc3b5e10c02f5f4f4d2cf5f3f48dbeae2ec390e4aa513dc0320408ccf23944a46398da603fee80f577db3e6a965cb96c5cce297649725c033cf3c53515252f2764141c17c9fcf478140b122ed7239291e8fabd6aeaeaece217e3976e05023fd686313b5757814798378989209467280bbd400d554d9feb8f21b331e58ba746987596cd476c9023cfbecb3331ace843777f7daabfb076cd4dd33405ddd41ae589245b0d3dd8b6ea417363c9ad3ca23b57a3e83370c0c84e9a73f3f44db77d899307b0093067123ede7ee10a2f9b78c69fcf69abbef9b356bd649b3e8a84c0fb3231a939f75e458f4e34ff724ab8f9f4a504b6b9cfa420e261e20a7ab885bc841b36656aa4a0bc4f43c3ddfcab2ef2b2c2ca07ffcfbf9b4f2112fb95ddcb51c1e865bc502c1aedd1d35efbcf7791d8f443354a151daa89be5b9e79eab3e511fff74cf015b25619c36b54ba7530c1eca92ec9ea928fdfab5afd3942995832daeb7fca57a812e941cbff5f66efab0ae952657fbc9e7f3523245140c86a9bdbd9b1a9bdae87bebbeda326d5ad5428e3d2daac00836aa1a6dd8b0a1a8b935fee9cedd9eb9693294e731c9b8c802a8e8cc7db3aac24d3ffbc932e2d89023c0a5921713e2921e3f7182c6978ea7d2d271fcde947a2e82ada03718a4606fef011e6d165656560ea842c3d8a8ba40776fec27fb0e17cdb53b02e472172bb8dd250aeadc852ee0a739b32b8847045559540ea920fb7c34b07a06822e022e864be4410001aca4b89878749a77fefcf99755c60836a200ebd6ad7be8f0b1c287a3717e3193045997226ec2c52380db1060eeec725549a9b87e2ce7723c12f295f32a81d9ef2d4c4480074e9e3c79c5ce9d3bbfa63286b16105e0e16e6c739bfbdfdacf43f52226091158002582e109e2016e8f8fa6d6fa7868c284c5209e0d2123c7f9907daf0eb43e522b4319314cb8e6cc99f3e36030586a6659dab0022492ee678e1c2f9c80a8eb701490c3596888c02d6e78005adfcf79453465f2780e0708842925c26885182de49968e514af8e442c1d6272ceddb18c2768df37b32d2daf00ebd7afaf3975daf1582c8e6186031f0f3b0e87975ba0805b9cbb82120113209f12a7aad2c3a5d26aae2f95d5914d463fd731f2bd209a4b1ec0758bbc87395edca84859585e017a82897faa6f74b88d458900ab3488e1556e6f90f7aa51c15730a0fa1e2a9c4f04012a6a950fe4bb86671a889b5ea08b62205b041cb3d97976fab4226561960270df2f3977debe229134332c8c5f611ec16c1c9cfa5810979a0a0f55365388ecf3d142ca2145f4c7224b279e0ddc9b95b78c478589666533cc5280fefefee5695b4111c678acc20631b81809f3f4b34f010b935bfea4806a6e7012bf4409204085754184840e2169754d87fe3c78805e4e88eae759a98b457bc4a497619602b0fb2cf71561f181cd0a4016211163fecd73ef78ac972a2746e93b4f8ea3d5df2ca0db17dca47ce2d4a9fa4101aca0939163ab6b7abe00cb6aec11c00b842c80fbf5f33c586eb0cbb49ce9d9134f3c51cad1b3c3e599ec78ebdd56a3af73a447e0537d9e478240a0881e595e4db7dd9ca6de9e6e3503c3f084494aa8bf9f0e1e3c4453a7d42a57456be13ad26c5819faaea4d28f250560bc0457ef03f00e40de81148663799694e5f39a8a8a8a2695695a8e07f0b0b198057054561470ab738b9b4b4facbe1289102dbcd547ebffb59ca6569fa30b9de75519bc14400bf97829fca5258be9ecd9569ea30755dea5022d2cd0cf0f1f69a14f769e54de90ed2d48adf2f46bf5f5ed0b54853533f6a3345bb468d14a8ee6b795141751734b987a7b23ac265171c04b8f7f6b0eddfe451b2f4f7b14616901494508283f7dfa177899dccd225d50d7d102166e9903a9aca0f34288367f584f9b5efd8c366f6ba25d9f9da6da9a31545e1650f59556462a305b5b3d4fde8b74eb47879ab76e7e6b8b2a605a8e008b172f7e8a05a8c1ee8ec75348478fb7d38d33cbe989553751a117410febfe4cf71380bca4b8af6cc2042a1933861acf342a97449e0e10d48f05d1689cf61deca437df69a0fffa5d239d6a885334ee55cf40373c70b09eee5c3899bba52383b40e3c535279fe8e4f4f4477eef8fd2f4caaca720458b264c97a9e46fa3095acaa184b7d7d617a78f94c7e8931fc589197969773bd2f62713485e3c1c58b5dd4cd1e81caea640570d5d6b601daf6f179facfdfb6d3de8331eaee71f21358b894b10596e6809c4e73404cb8a9b3f322fde9bc8a41014404a4425a07def1c98e13eebd9f6d7e5e55ccb40c0156af5eede14006016c10a0b4b4846ea8f432a92177d7813c9db808014004012a555e5ecede50421d1d1d14098707fb665f28467bf6f7d2bb1f74d3879fc4a8adc3c515767119903526229880d90777890d6b690d524db58f4ac7150edbf2425e09b0f3a4a3ebc2dc1782c15d09f3319941d0eff79732119b108208f178febd461093548e61fab1182a12f0fbe98e850b69ead469d4d412a15fffb6839e7ff9226df9d8419d17032c1c88336916cdc1536eb500532854a38f024fbb312b45faab378e5028141e0c929148c432158423b1b8d3df3bc1ac92b20c01b8df17e9ade8e0164e260db7ca8658f6b19ccb7136204445c5443ad1e0a6332d253cb5f671bed1da58731884b1fa3457a00c833c2fc69834a6e1987ec31b2e76a7e8fdad0d8a683ef2720d08f5c762b65481113d4dcb1e06edbaeb3a1d1000b3c05c22d2dfaca05f13d7d4af039128021888a71429a395992caf2c87880b79a3e51d4e83bcda1334bf206dddde4ce73bfb29ccdd2a1f4480603095f07a7c082c83962100f7e98c2f2d4ea783030e2a9959798110d34966e7e5433862ece68090410e2ecfcb6d9087080a2679b43e0342191ba2b2298a06b2d37bef9fb124ae63606020120cda3cbc8a8d9bf494650bd023e4000439042b2b025680b7e869f6351de108b7bc5a5962afc1685983a8e90926b0fc965677d8337783d5a7328e07070f9fa7c6e63e9014b283a9e07463573fd9dc63136947d0a4ab2c4380a79f7eba872b1b964ac3d2bcfe96732b0859abd40a728dbba721801201303c61d00bcc96b7c33b708dc9db1c43dbe06a696e2ed1f9026df9a83983342fe8068ff111b6b9253a96054bc5c6179c53c44ccb8e0169aee019a92c8208bef68c86d070f7e8c0708434ca838bfa02cc6eac48291186769e940728f2667fc73d8ab4101760c8b5536353905ace8638b64479680d71c01be02ee4a6b2f289545b5bcb33d924161f6df51f647e50cd1600953b221585a26e9ec848e5ad2063ac10cbcecb86dc138b61b410024821842182b43ec82b37377f2f2084516d218e89128078523d6932dd72f3cdb4e8ce3be98e3b1652556505f587faa8a9a9898afd884d89237c7386e508c07d7f37fa3d00d7915d1e1d5684b2f3874334860f9e6ab8671b22800c45125e01d70651fdba79ac1231e32134637a19cd9d5da19e8f1967477b3b757575292f0630832c09c477ab9b35cb1180575f7522404f4f8ffad0994dc08a30eed7cff301f745c2985c198196fff0315a0740578238bc0a4da1d2c630696ccc30f83edccb27e68e9451de61b7f1747d9e7ab6207b65896170d6d4e8c75c28c37204e0c9d03e2ed821859c3c23b4220b0c77ac9feb407e3812e77acb4e13365c0ce2eaf39ab9e9a2c0c76a3386afc964c9102a53947b16d7504579917abe4e5a0773e9a9a828dc69d21cb41c01d6ae5d9be24afece2cc4fd305700811092e3d122ca1110a4b1b8d1779c0cf2d87fc0ae53bf71ac44c03516416dc9e96224696c899beeff4aed2071d45923ad8058c6d7df666e39f3fa1c01604ce897527860a01f5ec12f4be710c9471c9501f25d8b730c90fd45839cb9dd86bd46f5b91be44d2fc810213628821282c5fbab07a7721830462c9d38480b301472fe26935e86e52c87613b76ec685db060c1fdbc1ea838d719a6034792545de55422a87e6b9a9c4b9e7e0e60681448dcc071249aa08ffee702575c829c2acd65e0da7c8fea16206988235f9e93a650927febcd2574d7c20983ad0f64134720e7e3ff7de9a597be63be28c32c3d00c60ffb3e1eb0e38f213a72ccc6eb73045c6353c3aa85256f34b011084aab8bdb9baecf1e908417a81471c0045f471711418a7949b3f4cb15398425056432c4ef5c67d2ca314b0f80dd77df7d479b9a430f1caf4f95c155cf5dc08f9b5c543511eb7b04a0cc96ce3ecf867800d0df1fa240c04eeded411e12e10188e678861114d5c687ea1e880d663751ad0ec1b03112a5871faa62116c392daf9307987cdda64d9bfec560956b7905a8abab4b4752f34f321fb59f8e0a747679a9afdf4993aae03843e4f2911688eb2366a092e34ac7d3ec99e5f467f754536d0d8ff7a9308fd97d5c59e8c0dec163b6eae3e2fa8abc881065b72fe6f2858ab8f477235e6592e7eb717eef5fecdfbf3f63faab9b3ea5b0b4a9b3d7bc61b7b91e924588c7534ae5e50574ef22a2a2428ccb46d7904d147d3f01302630c63de1708426d54c522f8520100e865f98d9b96c734b2f9da8efa743873ba9fd5c9abd031bac46b437825e9c6a27b9e9a10726b2989963bd082122a05bf2f3bf3b5cebc3461660deeaf114b71de2696ab91d8b119b4b7d182df205e8ce5b535ca1a1478024902d002ae8f707a81253536e19dda4db0870bfcfef57c43a3b07588818b5b5f773da4b89d800ddbbb88cef4966c41d90170f400a8f63dbcb33c2dbdf7cf3cdfc5b5a6c230a00ab9db56a89dd66dfc21ee0502b319eaa6285e6768fa19aea142d9cef245f516e3cc5783f66cc1876f9526e3da3d25626e4c52ba4db08e059188a93bc32ede9eeca202fad0fe0dc7c56373ff68bdcfa0dc61bf2dba80480d5cefcd6e376bbf387d884b0b11718a943fd56002e3c7d4a9a6e9ceea6f2322f0b64e7e9a983039d5f550c84c43b00dd84bc10d72102c8642b505c42ed6dad2a4fc80338c6fde6f3b0e1f9e74c3e63ff3f9f8d5a00d894198f7d8f97b0ff6cacce184c52edd6f22a0e2bb8924092bef6557c32cf8c073af9e104101140d04a007c6338dd709af386266042dc34049547376edcf8aa713ab2e51d05acacfbc29e6d25e3e6f9b9a6b71b8b12b8ac317c61888a44ed34615c84bc1e1ee9cd4a033a896c0811ddadf563405a3ac502755dec525e85b2104c333e4dafe196df689e8fca2e490058f7857d5b8ac7de146601bec4afe449812e0486ba18958d1ffa65b81574d23a74d23ac4cd11e5e151b158e68fc4997882f1b7afbcf2cabf9b59a3b64bea02ba4d9efee8fdec70bfe01a8de1b8cfaecd4190dddbed72d29797b8c9eb357e122f5d405298a4d28248e1ca4875f7973cdde2f1047b00eb6f1ac7d92e8f9bfe9addfe0333eb92ecb20580d5ce5a594da9f86be9b47db191833e6ee7498a93a6d51618394c5687e4c17401740c67f854174f24a98be3fc85eee4b68ecec4df347cfedaa87e156a6557248069b6458bfff21bf1b8f7bb3d416759249ae621d146f7de1d18247a350cba9c3ae34cd79f7170b7a3b66422fad4c9cf7ff02b5c32eeb83cbb6a357cf0c1077d814060f540d8fd0fa101c704ac1ed50f9bd9f5afc440bca3d3410d4d45148e14b473d6f3ae64ffcb7bf7ae1df167b0a3b1abd744a6ad58b1c25b5858b8cce3f17c9dc9dfc55e6017d7be1431b069dadc9a607893b1846fbbcb55f46a2c78c35b478f5ede3f46e4b3ab2e806e6bd6ace19564ea2b1c0c97b000b772609b0a41d03564aea01b86f4739db1545b47e2d4d9d6e8ae74daf391cd5bf27efd81f59de62d57ddaea900d9b672e5ca421e066b59882a1ef6c6725681f97f4461f68ede3d87fa9b1a8e15349c3dfbc25098bf6ed7ed1a1ad1ff01e61dcf347f746fc10000000049454e44ae426082, 0xaced00057372001674772e63687269732e7574696c732e53747564656e747a21f85e4ac7394f0200044900026368490003656e674900046d6174684c00046e616d657400124c6a6176612f6c616e672f537472696e673b78700000001e0000003c0000005a740005546f6d6d79),
(3, 'Ting', '$2a$10$/aO6XUy3k4mmthKIyihLOuIagneoOXQtG4rR0XkA9bEz.5Ya6waA.', 'ChrisOK', NULL, NULL),
(5, 'Yahoo', '$2a$10$YoI98W65nlhFVdoFY4OHRuHDPzqYtNju8bNpGPuM7MgMIv2vLRGBO', 'two Yahoo', NULL, NULL),
(6, 'Amy', '$2a$10$JMM22hROIof3RzzPnCPULunQSvIotbrGTPpHBbQzFCn8ac8IuJtB6', 'dddfrww', NULL, NULL),
(7, 'Xman', '$2a$10$qNtDooYKUUgodEI0z9aqK.VnQYDSAmeRPlOIFhJ0xbcN0YCAcJR0u', 'abcdefg', NULL, NULL),
(8, 'test110', '1111000', 'abcdeff', NULL, NULL),
(9, '123456', '$2a$10$O25zwcCxAMlSJ.blTpn9lu6.2WS0hRGfHuRCsJLairbEfCO/zLony', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `partyroom`
--

CREATE TABLE `partyroom` (
  `roomId` int(10) UNSIGNED NOT NULL,
  `roomName` varchar(100) NOT NULL,
  `player` tinyint(10) UNSIGNED DEFAULT NULL,
  `victoryScore` int(10) UNSIGNED DEFAULT NULL,
  `roomPw` varchar(10) DEFAULT NULL,
  `roomDraw` blob,
  `roomClass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `partyroom`
--

INSERT INTO `partyroom` (`roomId`, `roomName`, `player`, `victoryScore`, `roomPw`, `roomDraw`, `roomClass`) VALUES
(1, '來畫畫吧', NULL, NULL, NULL, NULL, '動漫人物'),
(2, '突然好想畫畫', NULL, NULL, NULL, NULL, '中國偉人'),
(3, '熱血一下啊', NULL, NULL, NULL, NULL, '七龍珠');

-- --------------------------------------------------------

--
-- 資料表結構 `souvenir`
--

CREATE TABLE `souvenir` (
  `id` int(10) UNSIGNED NOT NULL,
  `sname` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `lng` double NOT NULL,
  `lat` double NOT NULL,
  `picurl` varchar(10000) NOT NULL,
  `addr` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `souvenir`
--

INSERT INTO `souvenir` (`id`, `sname`, `tel`, `lng`, `lat`, `picurl`, `addr`) VALUES
(1, '銅鑼杭菊美人茶', '(037) 981-531 #18', 120.788222, 24.487964, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161106.jpg', '苗栗縣銅鑼鄉永樂路22號'),
(2, '曬幸福-阿婆的手造品', '(037) 881-700', 120.769475, 24.3892633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161215.jpg', '苗栗縣三義鄉龍騰村外庄10號'),
(3, '柴之燒炭焙-龍眼乾禮盒', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163803.jpg', '南投縣中寮鄉永平村永平路186號'),
(4, '台灣原生種土-肉桂手工皂', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163842.jpg', '南投縣中寮鄉永平村永平路186號'),
(5, '喜諾巴萊-小米醇酒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172014.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(6, '夢谷咖啡禮盒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172056.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(7, '蔥小子系列零嘴', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170055.jpg', '宜蘭縣三星鄉中山路 31 號'),
(8, '凍橄梅梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027094908.jpg', '南投縣水里鄉民生路362號'),
(9, '水里真梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095134.jpg', '南投縣水里鄉民生路362號'),
(10, '日日青春曲-蜂蜜梅精果日日青春曲─蜂蜜梅精果', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095339.jpg', '南投縣水里鄉民生路362號'),
(11, '四珍凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110331.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(12, '三星上將梨果醬', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170919.jpg', '宜蘭縣三星鄉中山路 31 號'),
(13, '三金-凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110428.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(14, '茶鄉米香', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110510.jpg', '南投縣竹山鎮下橫街38號'),
(15, '大地果實幸福禮盒', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110553.jpg', '南投縣竹山鎮下橫街38號'),
(16, '半路店梅子味噌禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027111847.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(17, '信義風情禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112141.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(18, '歡囍幸福婚宴酒禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112308.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(19, '愛旦-台灣梅禮盒組愛旦台灣梅禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112906.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(20, '台灣農夫禮盒', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113057.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(21, '日月潭幸福飲', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113145.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(22, '南投茶宴禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113228.jpg', '南投縣南投市文昌街 45 號'),
(23, '南投茶經禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113338.jpg', '南投縣南投市文昌街 45 號'),
(24, '南投梅宴禮盒-梅好時刻', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113430.jpg', '南投縣南投市文昌街 45 號'),
(25, '南投梅宴-黃梅酥', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113505.jpg', '南投縣南投市文昌街 45 號'),
(26, '南投冰工廠', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113557.jpg', '南投縣南投市文昌街 45 號'),
(27, '花點心呷好醋禮盒', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027143911.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(28, '美人腿湯麵', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144128.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(29, '花．心 下午茶組花．心午茶組', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144436.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(30, '錦歡喜禮盒', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144520.jpg', '南投縣草屯鎮碧山路190號'),
(31, '吉荔糕', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144559.jpg', '南投縣草屯鎮碧山路190號'),
(32, '五結好禮-稻米禮盒', '(039) 503-190', 121.797628, 24.6855829, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023171325.jpg', '宜蘭縣五結鄉五結村五結中路23號'),
(33, '菇鄉香酥禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144641.jpg', '南投縣魚池鄉魚池街 439 號'),
(34, '日月潭典藏茶包', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144725.jpg', '南投縣魚池鄉魚池街 439 號'),
(35, '菇菇茶集禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144825.jpg', '南投縣魚池鄉魚池街 439 號'),
(36, '日月潭茶之捲禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144911.jpg', '南投縣魚池鄉魚池街 439 號'),
(37, '貴妃枇杷、宋媽媽葡萄', '(049) 245-1079', 120.851505, 23.9959569, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145410.jpg', '南投縣國姓鄉昌榮巷 55-12 號'),
(38, '幸福雪酪', '(049) 227-3797', 120.674956, 23.865896, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145455.jpg', '南投縣名間鄉田仔村田仔巷16-8號'),
(39, '柚香米酥', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160402.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(40, '柚惑魔棒柚香米棒', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160631.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(41, '手工日曬蕎麥麵', '(04) 896-1191', 120.369817, 23.8961344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160727.jpg', '彰化縣二林鎮南光里儒林路二段260號'),
(42, '大城土豆麥酥', '(04) 894-4565 #307', 120.321886, 23.853374, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161038.jpg', '彰化縣大城鄉東城村南平路256號'),
(43, '美春姐古早味雞精阿春姐古早味雞精', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161123.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(44, '阿春姐荔枝酥餅', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161214.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(45, '蘭花精緻小禮盆', '(04) 852-7335 #338', 120.558709, 23.9968785, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161309.jpg', '彰化縣大村鄉中山路三段137號'),
(46, '米樂禮禮盒', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161548.jpg', '彰化縣田中鎮南北街80號'),
(47, '穀意禮', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161920.jpg', '彰化縣田中鎮南北街80號'),
(48, '柚子蜜茶', '(04) 879-2696', 120.631006, 23.8077098, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162336.jpg', '彰化縣二水鄉惠民村山腳路一段2號'),
(49, '富貴良緣禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162803.jpg', '彰化縣社頭鄉社斗路一段360號'),
(50, '八樂鮮果禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163017.jpg', '彰化縣社頭鄉社斗路一段360號'),
(51, '美荔三寶', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163315.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(52, '美春姐-龍情荔意', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172228.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(53, '龍花吉祥', '(04) 776-3651', 120.4366, 24.0650184, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172358.jpg', '彰化縣鹿港鎮建國路7號'),
(54, '芭樂玄米茶', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172500.jpg', '彰化縣田中鎮興工路509號'),
(55, '陽光芭樂果乾陽光芭樂乾', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172545.jpg', '彰化縣田中鎮興工路509號'),
(56, '蜂蜜桂圓茶', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172851.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(57, '風之鄉系列產品-黃金番薯燒-抹燒', '(04) 758-5048', 120.479966, 24.128633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173142.jpg', '彰化縣線西鄉德興村德興路1號'),
(58, '溪州黑鑽紫黑米溪州紫黑米系列-貢米禮盒', '(04) 889-5610', 120.494963, 23.8515366, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173315.jpg', '彰化縣溪州鄉溪州村中央路三段324號'),
(59, '禾樂幸福米禮盒', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173414.jpg', '台中市大甲區中山路一段372號'),
(60, '大安好酒禮盒', '(04) 2671-0909', 120.589175, 24.3493938, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094245.jpg', '台中市大安區中庄里中松路 91 號'),
(61, '棗茶兒-金棗濃糖果汁', '(03) 960-5388 #212', 121.729009, 24.632506, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180703.jpg', '宜蘭縣冬山鄉梅山路168號'),
(62, '建國百年頭等倉米寶島雙星伴手禮', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094428.jpg', '台中市西區向上路1段95號'),
(63, '幸福穗稻伴手米禮盒頭等倉-幸福穗稻伴手米禮盒', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094539.jpg', '台中市西區向上路1段95號'),
(64, '咱的后里', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094623.jpg', '台中市后里區民生路268號'),
(65, '稻囍', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094706.jpg', '台中市后里區民生路268號'),
(66, '好神祈福米', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094910.jpg', '台中市后里區民生路268號'),
(67, '心有所薯', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028095028.jpg', '台中市后里區民生路268號'),
(68, '黃金活力地瓜餐包', '(04) 2662-3111 #263', 120.558948, 24.236049, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113413.jpg', '台中市沙鹿區沙田路131號'),
(69, '韭讚の麵', '(04) 2623-2101 #216', 120.574757, 24.2668384, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113935.jpg', '台中市清水區中山路94號'),
(70, '杏鮑菇系列產品菇饌的美味', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114201.jpg', '台中市新社區中和街四段226號'),
(71, '菇賞禮盒', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114412.jpg', '台中市新社區中和街四段226號'),
(72, '將軍花翎百年紀念酒', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115407.jpg', '台中市霧峰區中正村四德路 10 號'),
(73, '峰田小町', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115542.jpg', '台中市霧峰區中正村四德路 10 號'),
(74, '台農鮮奶酪', '(04) 2687-2724', 120.626962, 24.3258733, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115701.jpg', '台中市外埔區水美里二崁路700號'),
(75, '香草醋系列香草系列產品', '(05) 662-4999', 120.387665, 23.6751521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115756.jpg', '雲林縣土庫鎮新建路6-5號'),
(76, '咖啡戀禮盒', '(05) 582-1009', 120.55524, 23.624105, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028120059.jpg', '雲林縣古坑鄉永光村光昌12號'),
(77, '好米伴名醬禮盒', '(05) 586-3621', 120.45463, 23.8003737, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133246.jpg', '雲林縣西螺鎮延平路353號'),
(78, '鵝樂-鵝翅、鵝腳', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133332.jpg', '雲林縣東勢鄉東南村民生路56號'),
(79, '東勢鵝肉美食系列產品', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133824.jpg', '雲林縣東勢鄉東南村民生路56號'),
(80, '食在愛餡-蔥米捲', '(03) 977-2222', 121.849467, 24.9071472, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180904.jpg', '宜蘭縣頭城鎮更新路125號'),
(81, '莿桐說的蒜-蒜泥厲害', '(05) 584-6161 #37', 120.502638, 23.7569732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134216.jpg', '雲林縣莿桐鄉中正路54號'),
(82, '嘿讚幸運餅', '(05) 773-0640', 120.304049, 23.5688563, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134301.jpg', '雲林縣北港鎮中正路20號'),
(83, '杏鮑菇脆片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134742.jpg', '嘉義縣東石鄉港墘村60號'),
(84, '杏福菇菇片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134844.jpg', '嘉義縣東石鄉港墘村60號'),
(85, '柴燒土窯福圓', '(06)686-3635', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145647.jpg', '台南市東山區南勢里一鄰6-2號'),
(86, '牧草茶飲伴手禮-四喜牧草茶飲', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145748.jpg', '台南市新營區民治路5號'),
(87, '台灣鯛魚鬆、魚脯台灣鯛-魚鬆、魚脯禮盒', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150036.jpg', '台南市新營區民治路5號'),
(88, '玉井烘焙情人果', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150309.jpg', '台南市玉井區中正路139號'),
(89, '酸酸甜甜-約定手禮', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150353.jpg', '台南市玉井區中正路139號'),
(90, '回味玉井', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150429.bmp', '台南市玉井區中正路139號'),
(91, '玉井鮮芒果多千層蛋糕熱情小子-芒果多千層', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150513.jpg', '台南市玉井區中正路139號'),
(92, '龜山朝日-金棗酒', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181133.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(93, '國產優質胡麻油', '(06) 592-2121', 120.254157, 23.1115672, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150705.jpg', '台南市安定區安定里58號'),
(94, '芝麻喜事禮盒', '(06) 795-5217', 120.204536, 23.12337, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150807.jpg', '台南市西港區文化路 2 號'),
(95, '玉井之門水果乾系列', '(06) 577-3260', 120.49912, 23.0517371, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152343.jpg', '台南市南化區小崙里57-3號'),
(96, '原燒黑糖香', '(06) 577-1516 #8', 120.476416, 23.043118, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028151330.jpg', '台南市南化區(村)128號'),
(97, '酒粕櫻花蝦XO醬', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181233.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(98, '大膽不敵-牛蒡蔘', '(06) 794-2201 #241、\n(06) 794-2127', 120.16326, 23.2018481, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152551.jpg', '台南市將軍區忠興里189號'),
(99, '好了梅！梅果小舖', '(07) 380-0170', 120.53455, 23.1859399, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153838.jpg', '台南市楠西區香蕉山53-1號'),
(100, '柚之寶淨白系列', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153959.jpg', '台南市麻豆區興國路 58 號'),
(101, '文旦柚茶', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154211.jpg', '台南市麻豆區興國路 58 號'),
(102, '旺來伯-稻香鳳梨酥', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154350.jpg', '台南市善化區中山路 242 號'),
(103, '善緣女兒禮', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154445.jpg', '台南市善化區中山路 242 號'),
(104, '新纖貨-鳳梨乾', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154605.jpg', '台南市新化區信義路450號'),
(105, '大目降胡麻系列-胡麻油大目降胡麻清油', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154841.jpg', '台南市新化區信義路450號'),
(106, '毛豆麵', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154946.jpg', '台南市新市區復興路 1-1 號'),
(107, '純南瓜粉', '(03) 938-3918', 121.808861, 24.7277051, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181345.jpg', '宜蘭縣壯圍鄉新南路107-7號'),
(108, '冷凍毛豆莢', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155038.jpg', '台南市新市區復興路 1-1 號'),
(109, '逗呷禮盒-新市好濃味', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155148.jpg', '台南市新市區復興路 1-1 號'),
(110, '竹好炭伴手禮', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170734.jpg', '台南市龍崎區崎頂里7鄰223號'),
(111, '龍崎湛炭', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170810.jpg', '台南市龍崎區崎頂里7鄰223號'),
(112, '真空綠竹筍', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170950.jpg', '台南市關廟區中正路963號'),
(113, '關廟鳳梨麵', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171132.jpg', '台南市關廟區中正路963號'),
(114, '金棗健康家族', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181428.jpg', '宜蘭縣礁溪鄉興農路127號'),
(115, '農情鳳禮鳳梨酥+鳳梨乾禮盒', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171453.jpg', '台南市關廟區中正路963號'),
(116, '鹽水番茄米餅系列鹽水區農會番茄米餅', '(06) 652-5071', 120.265784, 23.319378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171646.jpg', '台南市鹽水區西門路21號'),
(117, '手作果干', '(06) 594-1555', 120.390406, 23.0068316, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171805.jpg', '台南市新化區大坑里82號'),
(118, '玉荷甘果', '(07) 656-5101 #109', 120.440828, 22.7126936, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171940.jpg', '高雄市大樹區大坑里大坑路108-18號'),
(119, '幸福廚房', '(07) 675-4123', 120.580547, 23.0735195, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172315.jpg', '高雄市甲仙區新興路9號'),
(120, '福花茶王', '(07) 638-1188', 120.401191, 22.8633474, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172422.jpg', '高雄市田寮區新興村崗南路 4-1號'),
(121, '真愛吉緣訂婚禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181532.jpg', '宜蘭縣礁溪鄉興農路127號'),
(122, '台園膠原蛋白美人凍禮盒', '(07) 643-2763', 120.398438, 22.4826554, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172628.jpg', '高雄市林園區漁港路2號'),
(123, '幸福蕉點', '(07) 661-6377', 120.482137, 22.8850276, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172853.jpg', '高雄市旗山區復新街32號'),
(124, '花嫁-濃情陶米禮盒', '(07) 683-3309', 120.541406, 22.902171, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173111.jpg', '高雄市美濃區泰安里中正路一段1號'),
(125, '大樹張媽媽桑椹系列產品', '(07) 656-4569', 120.405633, 22.7289906, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173301.jpg', '高雄市大樹區興田里(路)116-1號'),
(126, '戀戀蚵仔寮-幸福伴手禮盒 (野生烏魚子禮盒)', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180654.jpg', '高雄市梓官區漁港二路32號'),
(127, '戀戀蚵仔寮-極饌御宴禮盒', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/292 戀戀蚵仔寮-極饌御宴禮盒_20111020 (原始檔).jpg', '高雄市梓官區漁港二路32號'),
(128, '蒲燒鰻', '(07) 699-5528', 120.208939, 22.9081774, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180757.jpg', '高雄市湖內區中正路二段158號'),
(129, '溫泉米粉', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026094940.jpg', '宜蘭縣礁溪鄉興農路127號'),
(130, '虱想起禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180845.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(131, '「思慕‧魚」系列-雙寶組合禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180919.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(132, '鳳梨發酵醋', '(07) 656-4569', 120.447989, 22.7466957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112037.jpg', '高雄市大樹區興田里興田路116-1號'),
(133, '芒果冰淇淋', '(08) 876-1075', 120.660721, 22.2639534, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112256.jpg', '屏東縣枋山鄉枋山村國中路1號'),
(134, '無添加芒果乾', '(08) 876-1075', 120.66072, 22.263642, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112334.jpg', '屏東縣枋山鄉枋山村國中路3號'),
(135, '果然好味', '(08) 877-1111 #207', 120.690609, 22.1910849, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112410.jpg', '屏東縣枋山鄉善餘村德隆路25-1號'),
(136, '旗魚鬆', '(08) 832-8064', 120.442814, 22.4675985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112451.jpg', '屏東縣東港鎮新生三路175號'),
(137, '湯戀組合禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095110.jpg', '宜蘭縣礁溪鄉興農路127號'),
(138, '枋寮鈣多情-芒果鱙仔魚', '(08) 878-8203', 120.607044, 22.3447209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112649.jpg', '屏東縣枋寮鄉保生村(路)437號'),
(139, '稻鴨香伴手禮', '(08) 796-7301', 120.610959, 22.7951794, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112750.jpg', '屏東縣高樹鄉泰山村產業路329號'),
(140, '鶉園鵪鶉元氣蛋捲', '(08) 783-1592', 120.625259, 22.612133, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112827.jpg', '屏東縣萬巒鄉萬金村營區路1巷10號'),
(141, '溫泉糙米茶', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095201.jpg', '宜蘭縣礁溪鄉興農路127號'),
(142, '1. 洛神養生果凍、2. 水果酒禮盒、3. 原汁禮盒', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113004.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(143, '釋迦、洛神休閒食品', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113111.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(144, '洛神元氣餅', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113147.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(145, '養生香椿茶', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113357.jpg', '台東縣台東市更生北路118號'),
(146, '台東有機竹香咖啡禮盒', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113435.jpg', '台東縣台東市更生北路118號'),
(147, '果子狸咖啡', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113817.jpg', '台東縣台東市更生北路118號'),
(148, '鹿鳴枇杷梅', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113851.jpg', '台東縣台東市更生北路118號'),
(149, '山海紅鑽', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114002.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(150, '臺灣臺東好茶', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114111.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(151, '洛神花軟Q糖', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114153.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(152, '布農小米酒 davuz', '(089) 561-211 #9', 121.083538, 22.9158013, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114228.jpg', '台東縣延平鄉桃源村11鄰191號'),
(153, '台11線牛肉乾', '(089) 871-848', 121.378469, 23.1031521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114931.jpg', '台東縣成功鎮新生路55號'),
(154, '池農養生米麩', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114457.jpg', '台東縣池上鄉中山路302號'),
(155, '南澳椴木香菇伴手禮盒', '(03) 990-6423', 121.831706, 24.6404134, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113523.jpg', '宜蘭縣蘇澳鎮龍德里福德路156號'),
(156, '米鄉-紫米餅', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141359.jpg', '台東縣池上鄉中山路302號'),
(157, '池農米蛋捲', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141435.jpg', '台東縣池上鄉中山路302號'),
(158, '池上米餅禮盒', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141509.jpg', '台東縣池上鄉中山路302號'),
(159, '米戀茶緣禮盒', '(089) 550-772', 121.135994, 22.9116099, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141620.jpg', '台東縣鹿野鄉鹿野村中華路二段 25 號'),
(160, '玉溪好米', '(03) 888-2040', 121.32868, 23.3804975, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141712.jpg', '花蓮縣玉里鎮大禺里166-13號'),
(161, '當歸心圓夢情禮盒', '(03) 888-3965', 121.31628, 23.325412, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142112.jpg', '花蓮縣玉里鎮大同路24號'),
(162, '富麗養生粥', '(03) 882-1991', 121.296967, 23.1838646, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142335.jpg', '花蓮縣富里鄉羅山村9鄰東湖6號'),
(163, '牛奶系列天然沐浴用品', '(03) 877-2666 #1181', 121.456414, 23.8037226, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142515.jpg', '花蓮縣鳳林鎮永福街20號'),
(164, '瑞穗柚花茶', '(03) 887-1044', 121.381484, 23.496431, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142603.jpg', '花蓮縣瑞穗鄉中山路一段128號'),
(165, '茶籽油禮盒', '(02) 2783-6121 #13', 121.61299, 25.0551711, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026134158.jpg', '台北市南港區南港路一段173號'),
(166, '伊糯千金', '(03) 865-6888', 121.502628, 23.8423111, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142751.jpg', '花蓮縣壽豐鄉豐文路105號'),
(167, '花蓮鰹干貝XO醬', '(03) 823-6071', 121.638531, 24.0062297, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029143002.jpg', '花蓮縣花蓮市港濱路37號'),
(168, '健康要裝蒜-健康調味禮盒', '(082) 322-376', 118.320407, 24.4329217, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150448.jpg', '金門縣金城鎮民生路6號'),
(169, '醋老爺健康日記', '(03) 922-5226', 121.708869, 24.7460167, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150532.jpg', '宜蘭縣員山鄉茄苳路3號'),
(170, '戀戀大湖', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150702.jpg', '苗栗縣大湖鄉富興村八寮灣34-7號'),
(171, '柚香和風沾醬', '(02) 2610-2996 #250', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113736.jpg', '新北市八里區中山路二段 366 號'),
(172, '紅棗干', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150901.jpg', '苗栗縣公館鄉館東村大同路266號'),
(173, '炭晶蛋捲', '(037) 540-039', 120.875905, 24.6356209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151000.jpg', '苗栗縣造橋鄉造橋村錦成東路8-5號'),
(174, '柚鄉餅、副總統餅 (東閔餅)', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151259.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(175, '紫香御品-香芋片', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029161829.jpg', '台中市大甲區中山路一段372號'),
(176, '楊媽媽菓子工坊-米麩金饌鳳梨酥', '(06) 687-1929', 120.357963, 23.3632139, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029162155.jpg', '台南市後壁區後壁里99號'),
(177, '三峽茶鄉、袋袋相傳禮盒', '(02) 8674-1780', 121.376189, 24.933545, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113824.jpg', '新北市三峽區長泰街96號'),
(178, '棗紅公館蜜餞系列', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163826.jpg', '苗栗縣公館鄉館東村大同路266號'),
(179, '鳥兒歡唱-養生禮盒組', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163903.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(180, '花蓮珍饌-肉乾與肉條系列', '(03) 888-3501、\n(03) 888-9158、\n0928-875-148', 121.320723, 23.3270702, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164109.jpg', '花蓮縣玉里鎮城南五街27號'),
(181, '燒仙草禮盒', '035875288、035872010', 121.165311, 24.8058508, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164316.jpg', '新竹縣關西鎮北山里高橋坑10鄰6號'),
(182, '平溪原生種山藥', '(02) 2495-1052', 121.739325, 25.0254039, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113912.jpg', '新北市平溪區嶺腳里中華街15號'),
(183, '臻品禮饌', '(02) 2638-1005 #212', 121.567138, 25.2908277, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113950.jpg', '新北市石門區(村)中央路2號'),
(184, '陳年包種老茶', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114113.jpg', '新北市坪林區坪林村坪林街103號'),
(185, '包種美人雙饗泡', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114207.jpg', '新北市坪林區坪林村坪林街103號'),
(186, '三好禮', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114243.jpg', '新北市坪林區坪林村坪林街103號'),
(187, '金紅藷', '(02) 2498-1100 #5', 121.636655, 25.2225054, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114320.jpg', '新北市金山區中山路267號'),
(188, '金舞滂米', '(03) 379-1881 #203', 121.258777, 25.0047037, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114536.jpg', '桃園市蘆竹區龍安街二段968號'),
(189, '向日葵花茶', '(03) 498-1221 #107', 121.139732, 25.010732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114659.jpg', '桃園市觀音區大同里中山路二段833號'),
(190, '客家擂茶', '(03) 580-3448', 121.055152, 24.700446, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114805.jpg', '新竹縣北埔鄉北埔街94號'),
(191, '手工蔬食蕃茄麵', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114837.jpg', '新竹縣芎林鄉文昌街120號'),
(192, '瓊福滿溢', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114912.jpg', '新竹縣芎林鄉文昌街120號'),
(193, '柿餅加工系列產品-柿糬', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115430.jpg', '新竹縣新埔鎮楊新路一段322號'),
(194, '客家柚子茶', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115632.jpg', '新竹縣新埔鎮楊新路一段322號'),
(195, '台北珍情土肉桂伴手禮組', '(02) 2707-0612 #242', 121.543272, 25.0337719, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023165917.jpg', '台北市大安區復興南路一段390號14樓'),
(196, '彩油四季-苦茶油', '(037) 872-001 #47', 120.772363, 24.4146177, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153407.jpg', '苗栗縣三義鄉中正路80號'),
(197, '擂茶香柚酥禮盒', '(037) 832-077', 120.956137, 24.6535081, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153504.jpg', '苗栗縣三灣鄉中正路176號'),
(198, '草莓大福', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153547.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(199, '草莓蜜果子', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153650.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(200, '紅運高棗', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153804.jpg', '苗栗縣公館鄉館東村大同路266號'),
(201, '幸福禮盒', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153838.jpg', '苗栗縣公館鄉館東村大同路266號'),
(202, '好采福', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154016.jpg', '苗栗縣公館鄉館東村大同路266號'),
(203, '1. 甘薯湯圓、2. 甘薯筍 (菜) 包', '(037) 921-718', 120.810083, 24.5506389, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154228.jpg', '苗栗縣西湖鄉三湖村4鄰71號'),
(204, '待客以鱒-醃鱒', '(037) 824-156', 121.001136, 24.6055422, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154300.jpg', '苗栗縣南庄鄉東村中正路195號'),
(205, '菜乾禮盒組', '(037) 879-393', 120.751328, 24.406434, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154656.jpg', '苗栗縣三義鄉廣盛村廣盛9-27號'),
(206, '藺草禮盒組藺草手工藝品-草蓆、草帽', '(037) 741-319', 120.65256, 24.4426396, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155303.jpg', '苗栗縣苑裡鎮為公路65號'),
(207, '飛牛烤布丁禮盒', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155336.jpg', '苗栗縣通霄鎮南和里166號'),
(208, '飛牛牧場原野-酪農餅乾', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155750.jpg', '苗栗縣通霄鎮南和里166號'),
(209, '飛牛甜心蛋糕', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160558.jpg', '苗栗縣通霄鎮南和里166號'),
(210, '百變薑餅人-提著幸福去旅行', '(037) 951-530', 120.832666, 24.3804378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160657.jpg', '苗栗縣大湖鄉栗林村薑麻園9鄰6號'),
(211, '福桂滿堂禮', '(037) 931-340、\n(037) 931-306', 120.921605, 24.5409581, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161023.jpg', '苗栗縣獅潭鄉新店村125號'),
(212, '銅鑼杭菊美人茶', '(037) 981-531 #18', 120.788222, 24.487964, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161106.jpg', '苗栗縣銅鑼鄉永樂路22號'),
(213, '曬幸福-阿婆的手造品', '(037) 881-700', 120.769475, 24.3892633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161215.jpg', '苗栗縣三義鄉龍騰村外庄10號'),
(214, '柴之燒炭焙-龍眼乾禮盒', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163803.jpg', '南投縣中寮鄉永平村永平路186號'),
(215, '台灣原生種土-肉桂手工皂', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163842.jpg', '南投縣中寮鄉永平村永平路186號'),
(216, '喜諾巴萊-小米醇酒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172014.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(217, '夢谷咖啡禮盒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172056.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(218, '蔥小子系列零嘴', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170055.jpg', '宜蘭縣三星鄉中山路 31 號'),
(219, '凍橄梅梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027094908.jpg', '南投縣水里鄉民生路362號'),
(220, '水里真梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095134.jpg', '南投縣水里鄉民生路362號'),
(221, '日日青春曲-蜂蜜梅精果日日青春曲─蜂蜜梅精果', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095339.jpg', '南投縣水里鄉民生路362號'),
(222, '四珍凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110331.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(223, '三星上將梨果醬', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170919.jpg', '宜蘭縣三星鄉中山路 31 號'),
(224, '三金-凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110428.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(225, '茶鄉米香', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110510.jpg', '南投縣竹山鎮下橫街38號'),
(226, '大地果實幸福禮盒', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110553.jpg', '南投縣竹山鎮下橫街38號'),
(227, '半路店梅子味噌禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027111847.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(228, '信義風情禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112141.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(229, '歡囍幸福婚宴酒禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112308.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(230, '愛旦-台灣梅禮盒組愛旦台灣梅禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112906.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(231, '台灣農夫禮盒', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113057.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(232, '日月潭幸福飲', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113145.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(233, '南投茶宴禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113228.jpg', '南投縣南投市文昌街 45 號'),
(234, '南投茶經禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113338.jpg', '南投縣南投市文昌街 45 號'),
(235, '南投梅宴禮盒-梅好時刻', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113430.jpg', '南投縣南投市文昌街 45 號'),
(236, '南投梅宴-黃梅酥', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113505.jpg', '南投縣南投市文昌街 45 號'),
(237, '南投冰工廠', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113557.jpg', '南投縣南投市文昌街 45 號'),
(238, '花點心呷好醋禮盒', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027143911.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(239, '美人腿湯麵', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144128.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(240, '花．心 下午茶組花．心午茶組', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144436.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(241, '錦歡喜禮盒', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144520.jpg', '南投縣草屯鎮碧山路190號'),
(242, '吉荔糕', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144559.jpg', '南投縣草屯鎮碧山路190號'),
(243, '五結好禮-稻米禮盒', '(039) 503-190', 121.797628, 24.6855829, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023171325.jpg', '宜蘭縣五結鄉五結村五結中路23號'),
(244, '菇鄉香酥禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144641.jpg', '南投縣魚池鄉魚池街 439 號'),
(245, '日月潭典藏茶包', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144725.jpg', '南投縣魚池鄉魚池街 439 號'),
(246, '菇菇茶集禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144825.jpg', '南投縣魚池鄉魚池街 439 號'),
(247, '日月潭茶之捲禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144911.jpg', '南投縣魚池鄉魚池街 439 號'),
(248, '貴妃枇杷、宋媽媽葡萄', '(049) 245-1079', 120.851505, 23.9959569, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145410.jpg', '南投縣國姓鄉昌榮巷 55-12 號'),
(249, '幸福雪酪', '(049) 227-3797', 120.674956, 23.865896, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145455.jpg', '南投縣名間鄉田仔村田仔巷16-8號'),
(250, '柚香米酥', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160402.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(251, '柚惑魔棒柚香米棒', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160631.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(252, '手工日曬蕎麥麵', '(04) 896-1191', 120.369817, 23.8961344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160727.jpg', '彰化縣二林鎮南光里儒林路二段260號'),
(253, '大城土豆麥酥', '(04) 894-4565 #307', 120.321886, 23.853374, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161038.jpg', '彰化縣大城鄉東城村南平路256號'),
(254, '美春姐古早味雞精阿春姐古早味雞精', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161123.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(255, '阿春姐荔枝酥餅', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161214.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(256, '蘭花精緻小禮盆', '(04) 852-7335 #338', 120.558709, 23.9968785, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161309.jpg', '彰化縣大村鄉中山路三段137號'),
(257, '米樂禮禮盒', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161548.jpg', '彰化縣田中鎮南北街80號'),
(258, '穀意禮', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161920.jpg', '彰化縣田中鎮南北街80號'),
(259, '柚子蜜茶', '(04) 879-2696', 120.631006, 23.8077098, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162336.jpg', '彰化縣二水鄉惠民村山腳路一段2號'),
(260, '富貴良緣禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162803.jpg', '彰化縣社頭鄉社斗路一段360號'),
(261, '八樂鮮果禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163017.jpg', '彰化縣社頭鄉社斗路一段360號'),
(262, '美荔三寶', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163315.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(263, '美春姐-龍情荔意', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172228.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(264, '龍花吉祥', '(04) 776-3651', 120.4366, 24.0650184, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172358.jpg', '彰化縣鹿港鎮建國路7號'),
(265, '芭樂玄米茶', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172500.jpg', '彰化縣田中鎮興工路509號'),
(266, '陽光芭樂果乾陽光芭樂乾', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172545.jpg', '彰化縣田中鎮興工路509號'),
(267, '蜂蜜桂圓茶', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172851.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(268, '風之鄉系列產品-黃金番薯燒-抹燒', '(04) 758-5048', 120.479966, 24.128633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173142.jpg', '彰化縣線西鄉德興村德興路1號'),
(269, '溪州黑鑽紫黑米溪州紫黑米系列-貢米禮盒', '(04) 889-5610', 120.494963, 23.8515366, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173315.jpg', '彰化縣溪州鄉溪州村中央路三段324號'),
(270, '禾樂幸福米禮盒', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173414.jpg', '台中市大甲區中山路一段372號'),
(271, '大安好酒禮盒', '(04) 2671-0909', 120.589175, 24.3493938, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094245.jpg', '台中市大安區中庄里中松路 91 號'),
(272, '棗茶兒-金棗濃糖果汁', '(03) 960-5388 #212', 121.729009, 24.632506, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180703.jpg', '宜蘭縣冬山鄉梅山路168號'),
(273, '建國百年頭等倉米寶島雙星伴手禮', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094428.jpg', '台中市西區向上路1段95號'),
(274, '幸福穗稻伴手米禮盒頭等倉-幸福穗稻伴手米禮盒', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094539.jpg', '台中市西區向上路1段95號'),
(275, '咱的后里', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094623.jpg', '台中市后里區民生路268號'),
(276, '稻囍', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094706.jpg', '台中市后里區民生路268號'),
(277, '好神祈福米', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094910.jpg', '台中市后里區民生路268號'),
(278, '心有所薯', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028095028.jpg', '台中市后里區民生路268號'),
(279, '黃金活力地瓜餐包', '(04) 2662-3111 #263', 120.558948, 24.236049, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113413.jpg', '台中市沙鹿區沙田路131號'),
(280, '韭讚の麵', '(04) 2623-2101 #216', 120.574757, 24.2668384, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113935.jpg', '台中市清水區中山路94號'),
(281, '杏鮑菇系列產品菇饌的美味', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114201.jpg', '台中市新社區中和街四段226號'),
(282, '菇賞禮盒', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114412.jpg', '台中市新社區中和街四段226號'),
(283, '將軍花翎百年紀念酒', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115407.jpg', '台中市霧峰區中正村四德路 10 號'),
(284, '峰田小町', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115542.jpg', '台中市霧峰區中正村四德路 10 號'),
(285, '台農鮮奶酪', '(04) 2687-2724', 120.626962, 24.3258733, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115701.jpg', '台中市外埔區水美里二崁路700號'),
(286, '香草醋系列香草系列產品', '(05) 662-4999', 120.387665, 23.6751521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115756.jpg', '雲林縣土庫鎮新建路6-5號'),
(287, '咖啡戀禮盒', '(05) 582-1009', 120.55524, 23.624105, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028120059.jpg', '雲林縣古坑鄉永光村光昌12號'),
(288, '好米伴名醬禮盒', '(05) 586-3621', 120.45463, 23.8003737, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133246.jpg', '雲林縣西螺鎮延平路353號'),
(289, '鵝樂-鵝翅、鵝腳', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133332.jpg', '雲林縣東勢鄉東南村民生路56號'),
(290, '東勢鵝肉美食系列產品', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133824.jpg', '雲林縣東勢鄉東南村民生路56號'),
(291, '食在愛餡-蔥米捲', '(03) 977-2222', 121.849467, 24.9071472, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180904.jpg', '宜蘭縣頭城鎮更新路125號'),
(292, '莿桐說的蒜-蒜泥厲害', '(05) 584-6161 #37', 120.502638, 23.7569732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134216.jpg', '雲林縣莿桐鄉中正路54號'),
(293, '嘿讚幸運餅', '(05) 773-0640', 120.304049, 23.5688563, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134301.jpg', '雲林縣北港鎮中正路20號'),
(294, '杏鮑菇脆片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134742.jpg', '嘉義縣東石鄉港墘村60號'),
(295, '杏福菇菇片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134844.jpg', '嘉義縣東石鄉港墘村60號'),
(296, '柴燒土窯福圓', '(06)686-3635', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145647.jpg', '台南市東山區南勢里一鄰6-2號'),
(297, '牧草茶飲伴手禮-四喜牧草茶飲', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145748.jpg', '台南市新營區民治路5號'),
(298, '台灣鯛魚鬆、魚脯台灣鯛-魚鬆、魚脯禮盒', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150036.jpg', '台南市新營區民治路5號'),
(299, '玉井烘焙情人果', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150309.jpg', '台南市玉井區中正路139號'),
(300, '酸酸甜甜-約定手禮', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150353.jpg', '台南市玉井區中正路139號'),
(301, '回味玉井', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150429.bmp', '台南市玉井區中正路139號'),
(302, '玉井鮮芒果多千層蛋糕熱情小子-芒果多千層', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150513.jpg', '台南市玉井區中正路139號'),
(303, '龜山朝日-金棗酒', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181133.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(304, '國產優質胡麻油', '(06) 592-2121', 120.254157, 23.1115672, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150705.jpg', '台南市安定區安定里58號'),
(305, '芝麻喜事禮盒', '(06) 795-5217', 120.204536, 23.12337, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150807.jpg', '台南市西港區文化路 2 號'),
(306, '玉井之門水果乾系列', '(06) 577-3260', 120.49912, 23.0517371, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152343.jpg', '台南市南化區小崙里57-3號'),
(307, '原燒黑糖香', '(06) 577-1516 #8', 120.476416, 23.043118, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028151330.jpg', '台南市南化區(村)128號'),
(308, '酒粕櫻花蝦XO醬', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181233.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(309, '大膽不敵-牛蒡蔘', '(06) 794-2201 #241、\n(06) 794-2127', 120.16326, 23.2018481, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152551.jpg', '台南市將軍區忠興里189號'),
(310, '好了梅！梅果小舖', '(07) 380-0170', 120.53455, 23.1859399, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153838.jpg', '台南市楠西區香蕉山53-1號'),
(311, '柚之寶淨白系列', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153959.jpg', '台南市麻豆區興國路 58 號'),
(312, '文旦柚茶', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154211.jpg', '台南市麻豆區興國路 58 號'),
(313, '旺來伯-稻香鳳梨酥', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154350.jpg', '台南市善化區中山路 242 號'),
(314, '善緣女兒禮', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154445.jpg', '台南市善化區中山路 242 號'),
(315, '新纖貨-鳳梨乾', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154605.jpg', '台南市新化區信義路450號'),
(316, '大目降胡麻系列-胡麻油大目降胡麻清油', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154841.jpg', '台南市新化區信義路450號'),
(317, '毛豆麵', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154946.jpg', '台南市新市區復興路 1-1 號'),
(318, '純南瓜粉', '(03) 938-3918', 121.808861, 24.7277051, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181345.jpg', '宜蘭縣壯圍鄉新南路107-7號');
INSERT INTO `souvenir` (`id`, `sname`, `tel`, `lng`, `lat`, `picurl`, `addr`) VALUES
(319, '冷凍毛豆莢', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155038.jpg', '台南市新市區復興路 1-1 號'),
(320, '逗呷禮盒-新市好濃味', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155148.jpg', '台南市新市區復興路 1-1 號'),
(321, '竹好炭伴手禮', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170734.jpg', '台南市龍崎區崎頂里7鄰223號'),
(322, '龍崎湛炭', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170810.jpg', '台南市龍崎區崎頂里7鄰223號'),
(323, '真空綠竹筍', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170950.jpg', '台南市關廟區中正路963號'),
(324, '關廟鳳梨麵', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171132.jpg', '台南市關廟區中正路963號'),
(325, '金棗健康家族', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181428.jpg', '宜蘭縣礁溪鄉興農路127號'),
(326, '農情鳳禮鳳梨酥+鳳梨乾禮盒', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171453.jpg', '台南市關廟區中正路963號'),
(327, '鹽水番茄米餅系列鹽水區農會番茄米餅', '(06) 652-5071', 120.265784, 23.319378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171646.jpg', '台南市鹽水區西門路21號'),
(328, '手作果干', '(06) 594-1555', 120.390406, 23.0068316, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171805.jpg', '台南市新化區大坑里82號'),
(329, '玉荷甘果', '(07) 656-5101 #109', 120.440828, 22.7126936, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171940.jpg', '高雄市大樹區大坑里大坑路108-18號'),
(330, '幸福廚房', '(07) 675-4123', 120.580547, 23.0735195, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172315.jpg', '高雄市甲仙區新興路9號'),
(331, '福花茶王', '(07) 638-1188', 120.401191, 22.8633474, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172422.jpg', '高雄市田寮區新興村崗南路 4-1號'),
(332, '真愛吉緣訂婚禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181532.jpg', '宜蘭縣礁溪鄉興農路127號'),
(333, '台園膠原蛋白美人凍禮盒', '(07) 643-2763', 120.398438, 22.4826554, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172628.jpg', '高雄市林園區漁港路2號'),
(334, '幸福蕉點', '(07) 661-6377', 120.482137, 22.8850276, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172853.jpg', '高雄市旗山區復新街32號'),
(335, '花嫁-濃情陶米禮盒', '(07) 683-3309', 120.541406, 22.902171, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173111.jpg', '高雄市美濃區泰安里中正路一段1號'),
(336, '大樹張媽媽桑椹系列產品', '(07) 656-4569', 120.405633, 22.7289906, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173301.jpg', '高雄市大樹區興田里(路)116-1號'),
(337, '戀戀蚵仔寮-幸福伴手禮盒 (野生烏魚子禮盒)', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180654.jpg', '高雄市梓官區漁港二路32號'),
(338, '戀戀蚵仔寮-極饌御宴禮盒', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/292 戀戀蚵仔寮-極饌御宴禮盒_20111020 (原始檔).jpg', '高雄市梓官區漁港二路32號'),
(339, '蒲燒鰻', '(07) 699-5528', 120.208939, 22.9081774, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180757.jpg', '高雄市湖內區中正路二段158號'),
(340, '溫泉米粉', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026094940.jpg', '宜蘭縣礁溪鄉興農路127號'),
(341, '虱想起禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180845.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(342, '「思慕‧魚」系列-雙寶組合禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180919.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(343, '鳳梨發酵醋', '(07) 656-4569', 120.447989, 22.7466957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112037.jpg', '高雄市大樹區興田里興田路116-1號'),
(344, '芒果冰淇淋', '(08) 876-1075', 120.660721, 22.2639534, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112256.jpg', '屏東縣枋山鄉枋山村國中路1號'),
(345, '無添加芒果乾', '(08) 876-1075', 120.66072, 22.263642, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112334.jpg', '屏東縣枋山鄉枋山村國中路3號'),
(346, '果然好味', '(08) 877-1111 #207', 120.690609, 22.1910849, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112410.jpg', '屏東縣枋山鄉善餘村德隆路25-1號'),
(347, '旗魚鬆', '(08) 832-8064', 120.442814, 22.4675985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112451.jpg', '屏東縣東港鎮新生三路175號'),
(348, '湯戀組合禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095110.jpg', '宜蘭縣礁溪鄉興農路127號'),
(349, '枋寮鈣多情-芒果鱙仔魚', '(08) 878-8203', 120.607044, 22.3447209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112649.jpg', '屏東縣枋寮鄉保生村(路)437號'),
(350, '稻鴨香伴手禮', '(08) 796-7301', 120.610959, 22.7951794, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112750.jpg', '屏東縣高樹鄉泰山村產業路329號'),
(351, '鶉園鵪鶉元氣蛋捲', '(08) 783-1592', 120.625259, 22.612133, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112827.jpg', '屏東縣萬巒鄉萬金村營區路1巷10號'),
(352, '溫泉糙米茶', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095201.jpg', '宜蘭縣礁溪鄉興農路127號'),
(353, '1. 洛神養生果凍、2. 水果酒禮盒、3. 原汁禮盒', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113004.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(354, '釋迦、洛神休閒食品', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113111.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(355, '洛神元氣餅', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113147.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(356, '養生香椿茶', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113357.jpg', '台東縣台東市更生北路118號'),
(357, '台東有機竹香咖啡禮盒', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113435.jpg', '台東縣台東市更生北路118號'),
(358, '果子狸咖啡', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113817.jpg', '台東縣台東市更生北路118號'),
(359, '鹿鳴枇杷梅', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113851.jpg', '台東縣台東市更生北路118號'),
(360, '山海紅鑽', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114002.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(361, '臺灣臺東好茶', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114111.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(362, '洛神花軟Q糖', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114153.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(363, '布農小米酒 davuz', '(089) 561-211 #9', 121.083538, 22.9158013, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114228.jpg', '台東縣延平鄉桃源村11鄰191號'),
(364, '台11線牛肉乾', '(089) 871-848', 121.378469, 23.1031521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114931.jpg', '台東縣成功鎮新生路55號'),
(365, '池農養生米麩', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114457.jpg', '台東縣池上鄉中山路302號'),
(366, '南澳椴木香菇伴手禮盒', '(03) 990-6423', 121.831706, 24.6404134, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113523.jpg', '宜蘭縣蘇澳鎮龍德里福德路156號'),
(367, '米鄉-紫米餅', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141359.jpg', '台東縣池上鄉中山路302號'),
(368, '池農米蛋捲', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141435.jpg', '台東縣池上鄉中山路302號'),
(369, '池上米餅禮盒', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141509.jpg', '台東縣池上鄉中山路302號'),
(370, '米戀茶緣禮盒', '(089) 550-772', 121.135994, 22.9116099, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141620.jpg', '台東縣鹿野鄉鹿野村中華路二段 25 號'),
(371, '玉溪好米', '(03) 888-2040', 121.32868, 23.3804975, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141712.jpg', '花蓮縣玉里鎮大禺里166-13號'),
(372, '當歸心圓夢情禮盒', '(03) 888-3965', 121.31628, 23.325412, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142112.jpg', '花蓮縣玉里鎮大同路24號'),
(373, '富麗養生粥', '(03) 882-1991', 121.296967, 23.1838646, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142335.jpg', '花蓮縣富里鄉羅山村9鄰東湖6號'),
(374, '牛奶系列天然沐浴用品', '(03) 877-2666 #1181', 121.456414, 23.8037226, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142515.jpg', '花蓮縣鳳林鎮永福街20號'),
(375, '瑞穗柚花茶', '(03) 887-1044', 121.381484, 23.496431, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142603.jpg', '花蓮縣瑞穗鄉中山路一段128號'),
(376, '茶籽油禮盒', '(02) 2783-6121 #13', 121.61299, 25.0551711, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026134158.jpg', '台北市南港區南港路一段173號'),
(377, '伊糯千金', '(03) 865-6888', 121.502628, 23.8423111, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142751.jpg', '花蓮縣壽豐鄉豐文路105號'),
(378, '花蓮鰹干貝XO醬', '(03) 823-6071', 121.638531, 24.0062297, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029143002.jpg', '花蓮縣花蓮市港濱路37號'),
(379, '健康要裝蒜-健康調味禮盒', '(082) 322-376', 118.320407, 24.4329217, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150448.jpg', '金門縣金城鎮民生路6號'),
(380, '醋老爺健康日記', '(03) 922-5226', 121.708869, 24.7460167, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150532.jpg', '宜蘭縣員山鄉茄苳路3號'),
(381, '戀戀大湖', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150702.jpg', '苗栗縣大湖鄉富興村八寮灣34-7號'),
(382, '柚香和風沾醬', '(02) 2610-2996 #250', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113736.jpg', '新北市八里區中山路二段 366 號'),
(383, '紅棗干', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150901.jpg', '苗栗縣公館鄉館東村大同路266號'),
(384, '炭晶蛋捲', '(037) 540-039', 120.875905, 24.6356209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151000.jpg', '苗栗縣造橋鄉造橋村錦成東路8-5號'),
(385, '柚鄉餅、副總統餅 (東閔餅)', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151259.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(386, '紫香御品-香芋片', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029161829.jpg', '台中市大甲區中山路一段372號'),
(387, '楊媽媽菓子工坊-米麩金饌鳳梨酥', '(06) 687-1929', 120.357963, 23.3632139, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029162155.jpg', '台南市後壁區後壁里99號'),
(388, '三峽茶鄉、袋袋相傳禮盒', '(02) 8674-1780', 121.376189, 24.933545, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113824.jpg', '新北市三峽區長泰街96號'),
(389, '棗紅公館蜜餞系列', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163826.jpg', '苗栗縣公館鄉館東村大同路266號'),
(390, '鳥兒歡唱-養生禮盒組', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163903.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(391, '花蓮珍饌-肉乾與肉條系列', '(03) 888-3501、\n(03) 888-9158、\n0928-875-148', 121.320723, 23.3270702, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164109.jpg', '花蓮縣玉里鎮城南五街27號'),
(392, '燒仙草禮盒', '035875288、035872010', 121.165311, 24.8058508, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164316.jpg', '新竹縣關西鎮北山里高橋坑10鄰6號'),
(393, '平溪原生種山藥', '(02) 2495-1052', 121.739325, 25.0254039, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113912.jpg', '新北市平溪區嶺腳里中華街15號'),
(394, '臻品禮饌', '(02) 2638-1005 #212', 121.567138, 25.2908277, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113950.jpg', '新北市石門區(村)中央路2號'),
(395, '陳年包種老茶', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114113.jpg', '新北市坪林區坪林村坪林街103號'),
(396, '包種美人雙饗泡', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114207.jpg', '新北市坪林區坪林村坪林街103號'),
(397, '三好禮', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114243.jpg', '新北市坪林區坪林村坪林街103號'),
(398, '金紅藷', '(02) 2498-1100 #5', 121.636655, 25.2225054, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114320.jpg', '新北市金山區中山路267號'),
(399, '金舞滂米', '(03) 379-1881 #203', 121.258777, 25.0047037, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114536.jpg', '桃園市蘆竹區龍安街二段968號'),
(400, '向日葵花茶', '(03) 498-1221 #107', 121.139732, 25.010732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114659.jpg', '桃園市觀音區大同里中山路二段833號'),
(401, '客家擂茶', '(03) 580-3448', 121.055152, 24.700446, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114805.jpg', '新竹縣北埔鄉北埔街94號'),
(402, '手工蔬食蕃茄麵', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114837.jpg', '新竹縣芎林鄉文昌街120號'),
(403, '瓊福滿溢', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114912.jpg', '新竹縣芎林鄉文昌街120號'),
(404, '柿餅加工系列產品-柿糬', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115430.jpg', '新竹縣新埔鎮楊新路一段322號'),
(405, '客家柚子茶', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115632.jpg', '新竹縣新埔鎮楊新路一段322號'),
(406, '台北珍情土肉桂伴手禮組', '(02) 2707-0612 #242', 121.543272, 25.0337719, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023165917.jpg', '台北市大安區復興南路一段390號14樓'),
(407, '彩油四季-苦茶油', '(037) 872-001 #47', 120.772363, 24.4146177, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153407.jpg', '苗栗縣三義鄉中正路80號'),
(408, '擂茶香柚酥禮盒', '(037) 832-077', 120.956137, 24.6535081, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153504.jpg', '苗栗縣三灣鄉中正路176號'),
(409, '草莓大福', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153547.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(410, '草莓蜜果子', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153650.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(411, '紅運高棗', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153804.jpg', '苗栗縣公館鄉館東村大同路266號'),
(412, '幸福禮盒', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153838.jpg', '苗栗縣公館鄉館東村大同路266號'),
(413, '好采福', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154016.jpg', '苗栗縣公館鄉館東村大同路266號'),
(414, '1. 甘薯湯圓、2. 甘薯筍 (菜) 包', '(037) 921-718', 120.810083, 24.5506389, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154228.jpg', '苗栗縣西湖鄉三湖村4鄰71號'),
(415, '待客以鱒-醃鱒', '(037) 824-156', 121.001136, 24.6055422, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154300.jpg', '苗栗縣南庄鄉東村中正路195號'),
(416, '菜乾禮盒組', '(037) 879-393', 120.751328, 24.406434, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154656.jpg', '苗栗縣三義鄉廣盛村廣盛9-27號'),
(417, '藺草禮盒組藺草手工藝品-草蓆、草帽', '(037) 741-319', 120.65256, 24.4426396, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155303.jpg', '苗栗縣苑裡鎮為公路65號'),
(418, '飛牛烤布丁禮盒', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155336.jpg', '苗栗縣通霄鎮南和里166號'),
(419, '飛牛牧場原野-酪農餅乾', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155750.jpg', '苗栗縣通霄鎮南和里166號'),
(420, '飛牛甜心蛋糕', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160558.jpg', '苗栗縣通霄鎮南和里166號'),
(421, '百變薑餅人-提著幸福去旅行', '(037) 951-530', 120.832666, 24.3804378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160657.jpg', '苗栗縣大湖鄉栗林村薑麻園9鄰6號'),
(422, '福桂滿堂禮', '(037) 931-340、\n(037) 931-306', 120.921605, 24.5409581, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161023.jpg', '苗栗縣獅潭鄉新店村125號'),
(423, '銅鑼杭菊美人茶', '(037) 981-531 #18', 120.788222, 24.487964, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161106.jpg', '苗栗縣銅鑼鄉永樂路22號'),
(424, '曬幸福-阿婆的手造品', '(037) 881-700', 120.769475, 24.3892633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161215.jpg', '苗栗縣三義鄉龍騰村外庄10號'),
(425, '柴之燒炭焙-龍眼乾禮盒', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163803.jpg', '南投縣中寮鄉永平村永平路186號'),
(426, '台灣原生種土-肉桂手工皂', '(049) 269-3934', 120.767809, 23.8787397, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026163842.jpg', '南投縣中寮鄉永平村永平路186號'),
(427, '喜諾巴萊-小米醇酒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172014.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(428, '夢谷咖啡禮盒', '(049) 292-0480 #12', 121.088911, 24.004799, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026172056.jpg', '南投縣仁愛鄉南豐村中正路80-3號'),
(429, '蔥小子系列零嘴', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170055.jpg', '宜蘭縣三星鄉中山路 31 號'),
(430, '凍橄梅梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027094908.jpg', '南投縣水里鄉民生路362號'),
(431, '水里真梅', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095134.jpg', '南投縣水里鄉民生路362號'),
(432, '日日青春曲-蜂蜜梅精果日日青春曲─蜂蜜梅精果', '(049) 277-2101 #315', 120.8541, 23.8171797, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027095339.jpg', '南投縣水里鄉民生路362號'),
(433, '四珍凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110331.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(434, '三星上將梨果醬', '(03) 989-3170 #78', 121.652284, 24.6679321, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023170919.jpg', '宜蘭縣三星鄉中山路 31 號'),
(435, '三金-凍頂茶禮盒', '(049) 275-2215', 120.735456, 23.7643532, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110428.jpg', '南投縣鹿谷鄉初鄉村中正路三段293號'),
(436, '茶鄉米香', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110510.jpg', '南投縣竹山鎮下橫街38號'),
(437, '大地果實幸福禮盒', '(049) 264-4077 #332', 120.68463, 23.756698, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027110553.jpg', '南投縣竹山鎮下橫街38號'),
(438, '半路店梅子味噌禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027111847.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(439, '信義風情禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112141.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(440, '歡囍幸福婚宴酒禮盒', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112308.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(441, '愛旦-台灣梅禮盒組愛旦台灣梅禮盒組', '(049) 279-1949', 120.861791, 23.688701, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027112906.jpg', '南投縣信義鄉明德村新開巷 11 號'),
(442, '台灣農夫禮盒', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113057.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(443, '日月潭幸福飲', '(04) 9289-7169', 120.942481, 23.8976522, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113145.jpg', '南投縣魚池鄉東池村福興巷13-12號'),
(444, '南投茶宴禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113228.jpg', '南投縣南投市文昌街 45 號'),
(445, '南投茶經禮盒', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113338.jpg', '南投縣南投市文昌街 45 號'),
(446, '南投梅宴禮盒-梅好時刻', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113430.jpg', '南投縣南投市文昌街 45 號'),
(447, '南投梅宴-黃梅酥', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113505.jpg', '南投縣南投市文昌街 45 號'),
(448, '南投冰工廠', '(049) 225-1170', 120.687753, 23.9073655, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027113557.jpg', '南投縣南投市文昌街 45 號'),
(449, '花點心呷好醋禮盒', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027143911.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(450, '美人腿湯麵', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144128.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(451, '花．心 下午茶組花．心午茶組', '(049) 242-3828', 120.964167, 23.963721, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144436.jpg', '南投縣埔里鎮清新里西安路一段6號'),
(452, '錦歡喜禮盒', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144520.jpg', '南投縣草屯鎮碧山路190號'),
(453, '吉荔糕', '(049) 233-0633', 120.682201, 23.978165, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144559.jpg', '南投縣草屯鎮碧山路190號'),
(454, '五結好禮-稻米禮盒', '(039) 503-190', 121.797628, 24.6855829, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023171325.jpg', '宜蘭縣五結鄉五結村五結中路23號'),
(455, '菇鄉香酥禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144641.jpg', '南投縣魚池鄉魚池街 439 號'),
(456, '日月潭典藏茶包', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144725.jpg', '南投縣魚池鄉魚池街 439 號'),
(457, '菇菇茶集禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144825.jpg', '南投縣魚池鄉魚池街 439 號'),
(458, '日月潭茶之捲禮盒', '(049) 289-8453', 120.935039, 23.8961886, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027144911.jpg', '南投縣魚池鄉魚池街 439 號'),
(459, '貴妃枇杷、宋媽媽葡萄', '(049) 245-1079', 120.851505, 23.9959569, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145410.jpg', '南投縣國姓鄉昌榮巷 55-12 號'),
(460, '幸福雪酪', '(049) 227-3797', 120.674956, 23.865896, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027145455.jpg', '南投縣名間鄉田仔村田仔巷16-8號'),
(461, '柚香米酥', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160402.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(462, '柚惑魔棒柚香米棒', '(04) 879-2112', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160631.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(463, '手工日曬蕎麥麵', '(04) 896-1191', 120.369817, 23.8961344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027160727.jpg', '彰化縣二林鎮南光里儒林路二段260號'),
(464, '大城土豆麥酥', '(04) 894-4565 #307', 120.321886, 23.853374, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161038.jpg', '彰化縣大城鄉東城村南平路256號'),
(465, '美春姐古早味雞精阿春姐古早味雞精', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161123.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(466, '阿春姐荔枝酥餅', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161214.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(467, '蘭花精緻小禮盆', '(04) 852-7335 #338', 120.558709, 23.9968785, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161309.jpg', '彰化縣大村鄉中山路三段137號'),
(468, '米樂禮禮盒', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161548.jpg', '彰化縣田中鎮南北街80號'),
(469, '穀意禮', '(04) 874-9211 #335', 120.586382, 23.8596621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027161920.jpg', '彰化縣田中鎮南北街80號'),
(470, '柚子蜜茶', '(04) 879-2696', 120.631006, 23.8077098, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162336.jpg', '彰化縣二水鄉惠民村山腳路一段2號'),
(471, '富貴良緣禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027162803.jpg', '彰化縣社頭鄉社斗路一段360號'),
(472, '八樂鮮果禮盒', '(04) 873-5437', 120.584708, 23.896825, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163017.jpg', '彰化縣社頭鄉社斗路一段360號'),
(473, '美荔三寶', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027163315.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(474, '美春姐-龍情荔意', '(049) 252-4362', 120.621062, 24.0371467, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172228.jpg', '彰化縣芬園鄉彰南路五段451巷36號'),
(475, '龍花吉祥', '(04) 776-3651', 120.4366, 24.0650184, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172358.jpg', '彰化縣鹿港鎮建國路7號'),
(476, '芭樂玄米茶', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172500.jpg', '彰化縣田中鎮興工路509號'),
(477, '陽光芭樂果乾陽光芭樂乾', '(04) 875-2376', 120.591207, 23.8566985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172545.jpg', '彰化縣田中鎮興工路509號'),
(478, '蜂蜜桂圓茶', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027172851.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(479, '風之鄉系列產品-黃金番薯燒-抹燒', '(04) 758-5048', 120.479966, 24.128633, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173142.jpg', '彰化縣線西鄉德興村德興路1號'),
(480, '溪州黑鑽紫黑米溪州紫黑米系列-貢米禮盒', '(04) 889-5610', 120.494963, 23.8515366, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173315.jpg', '彰化縣溪州鄉溪州村中央路三段324號'),
(481, '禾樂幸福米禮盒', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151027173414.jpg', '台中市大甲區中山路一段372號'),
(482, '大安好酒禮盒', '(04) 2671-0909', 120.589175, 24.3493938, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094245.jpg', '台中市大安區中庄里中松路 91 號'),
(483, '棗茶兒-金棗濃糖果汁', '(03) 960-5388 #212', 121.729009, 24.632506, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180703.jpg', '宜蘭縣冬山鄉梅山路168號'),
(484, '建國百年頭等倉米寶島雙星伴手禮', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094428.jpg', '台中市西區向上路1段95號'),
(485, '幸福穗稻伴手米禮盒頭等倉-幸福穗稻伴手米禮盒', '(04) 2302-8390', 120.663284, 24.1465595, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094539.jpg', '台中市西區向上路1段95號'),
(486, '咱的后里', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094623.jpg', '台中市后里區民生路268號'),
(487, '稻囍', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094706.jpg', '台中市后里區民生路268號'),
(488, '好神祈福米', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028094910.jpg', '台中市后里區民生路268號'),
(489, '心有所薯', '(04) 2556-5116 #217', 120.712628, 24.3066984, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028095028.jpg', '台中市后里區民生路268號'),
(490, '黃金活力地瓜餐包', '(04) 2662-3111 #263', 120.558948, 24.236049, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113413.jpg', '台中市沙鹿區沙田路131號'),
(491, '韭讚の麵', '(04) 2623-2101 #216', 120.574757, 24.2668384, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028113935.jpg', '台中市清水區中山路94號'),
(492, '杏鮑菇系列產品菇饌的美味', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114201.jpg', '台中市新社區中和街四段226號'),
(493, '菇賞禮盒', '(04) 2582-1836、\n(04) 2581-1511', 120.808227, 24.2436761, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028114412.jpg', '台中市新社區中和街四段226號'),
(494, '將軍花翎百年紀念酒', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115407.jpg', '台中市霧峰區中正村四德路 10 號'),
(495, '峰田小町', '(04) 2339-5372', 120.734995, 24.0442951, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115542.jpg', '台中市霧峰區中正村四德路 10 號'),
(496, '台農鮮奶酪', '(04) 2687-2724', 120.626962, 24.3258733, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115701.jpg', '台中市外埔區水美里二崁路700號'),
(497, '香草醋系列香草系列產品', '(05) 662-4999', 120.387665, 23.6751521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028115756.jpg', '雲林縣土庫鎮新建路6-5號'),
(498, '咖啡戀禮盒', '(05) 582-1009', 120.55524, 23.624105, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028120059.jpg', '雲林縣古坑鄉永光村光昌12號'),
(499, '好米伴名醬禮盒', '(05) 586-3621', 120.45463, 23.8003737, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133246.jpg', '雲林縣西螺鎮延平路353號'),
(500, '鵝樂-鵝翅、鵝腳', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133332.jpg', '雲林縣東勢鄉東南村民生路56號'),
(501, '東勢鵝肉美食系列產品', '(05) 699-2245 #124', 120.253822, 23.675807, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028133824.jpg', '雲林縣東勢鄉東南村民生路56號'),
(502, '食在愛餡-蔥米捲', '(03) 977-2222', 121.849467, 24.9071472, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023180904.jpg', '宜蘭縣頭城鎮更新路125號'),
(503, '莿桐說的蒜-蒜泥厲害', '(05) 584-6161 #37', 120.502638, 23.7569732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134216.jpg', '雲林縣莿桐鄉中正路54號'),
(504, '嘿讚幸運餅', '(05) 773-0640', 120.304049, 23.5688563, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134301.jpg', '雲林縣北港鎮中正路20號'),
(505, '杏鮑菇脆片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134742.jpg', '嘉義縣東石鄉港墘村60號'),
(506, '杏福菇菇片', '(05) 379-9174 #120', 120.212323, 23.459957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028134844.jpg', '嘉義縣東石鄉港墘村60號'),
(507, '柴燒土窯福圓', '(06)686-3635', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145647.jpg', '台南市東山區南勢里一鄰6-2號'),
(508, '牧草茶飲伴手禮-四喜牧草茶飲', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028145748.jpg', '台南市新營區民治路5號'),
(509, '台灣鯛魚鬆、魚脯台灣鯛-魚鬆、魚脯禮盒', '(06) 632-4151', 120.320843, 23.3108819, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150036.jpg', '台南市新營區民治路5號'),
(510, '玉井烘焙情人果', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150309.jpg', '台南市玉井區中正路139號'),
(511, '酸酸甜甜-約定手禮', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150353.jpg', '台南市玉井區中正路139號'),
(512, '回味玉井', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150429.bmp', '台南市玉井區中正路139號'),
(513, '玉井鮮芒果多千層蛋糕熱情小子-芒果多千層', '(06) 574-8551', 120.485224, 23.1768678, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150513.jpg', '台南市玉井區中正路139號'),
(514, '龜山朝日-金棗酒', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181133.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(515, '國產優質胡麻油', '(06) 592-2121', 120.254157, 23.1115672, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150705.jpg', '台南市安定區安定里58號'),
(516, '芝麻喜事禮盒', '(06) 795-5217', 120.204536, 23.12337, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028150807.jpg', '台南市西港區文化路 2 號'),
(517, '玉井之門水果乾系列', '(06) 577-3260', 120.49912, 23.0517371, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152343.jpg', '台南市南化區小崙里57-3號'),
(518, '原燒黑糖香', '(06) 577-1516 #8', 120.476416, 23.043118, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028151330.jpg', '台南市南化區(村)128號'),
(519, '酒粕櫻花蝦XO醬', '(039) 778-555', 121.862429, 24.9036307, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181233.jpg', '宜蘭縣頭城鎮更新路126-50號'),
(520, '大膽不敵-牛蒡蔘', '(06) 794-2201 #241、\n(06) 794-2127', 120.16326, 23.2018481, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028152551.jpg', '台南市將軍區忠興里189號'),
(521, '好了梅！梅果小舖', '(07) 380-0170', 120.53455, 23.1859399, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153838.jpg', '台南市楠西區香蕉山53-1號'),
(522, '柚之寶淨白系列', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028153959.jpg', '台南市麻豆區興國路 58 號'),
(523, '文旦柚茶', '(06) 572-2277', 120.246536, 23.176068, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154211.jpg', '台南市麻豆區興國路 58 號'),
(524, '旺來伯-稻香鳳梨酥', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154350.jpg', '台南市善化區中山路 242 號'),
(525, '善緣女兒禮', '(06) 583-6111 #218', 120.297647, 23.132757, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154445.jpg', '台南市善化區中山路 242 號'),
(526, '新纖貨-鳳梨乾', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154605.jpg', '台南市新化區信義路450號'),
(527, '大目降胡麻系列-胡麻油大目降胡麻清油', '(06) 590-2400 #227', 120.301965, 23.0345014, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154841.jpg', '台南市新化區信義路450號'),
(528, '毛豆麵', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028154946.jpg', '台南市新市區復興路 1-1 號'),
(529, '純南瓜粉', '(03) 938-3918', 121.808861, 24.7277051, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181345.jpg', '宜蘭縣壯圍鄉新南路107-7號'),
(530, '冷凍毛豆莢', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155038.jpg', '台南市新市區復興路 1-1 號'),
(531, '逗呷禮盒-新市好濃味', '(06) 589-9888 #207', 120.295499, 23.0792847, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028155148.jpg', '台南市新市區復興路 1-1 號'),
(532, '竹好炭伴手禮', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170734.jpg', '台南市龍崎區崎頂里7鄰223號'),
(533, '龍崎湛炭', '(06) 594-1114 #31', 120.383901, 22.9688808, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170810.jpg', '台南市龍崎區崎頂里7鄰223號'),
(534, '真空綠竹筍', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028170950.jpg', '台南市關廟區中正路963號'),
(535, '關廟鳳梨麵', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171132.jpg', '台南市關廟區中正路963號'),
(536, '金棗健康家族', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181428.jpg', '宜蘭縣礁溪鄉興農路127號'),
(537, '農情鳳禮鳳梨酥+鳳梨乾禮盒', '(06) 595-2352 #43', 120.32842, 22.9624947, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171453.jpg', '台南市關廟區中正路963號'),
(538, '鹽水番茄米餅系列鹽水區農會番茄米餅', '(06) 652-5071', 120.265784, 23.319378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171646.jpg', '台南市鹽水區西門路21號'),
(539, '手作果干', '(06) 594-1555', 120.390406, 23.0068316, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171805.jpg', '台南市新化區大坑里82號'),
(540, '玉荷甘果', '(07) 656-5101 #109', 120.440828, 22.7126936, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028171940.jpg', '高雄市大樹區大坑里大坑路108-18號'),
(541, '幸福廚房', '(07) 675-4123', 120.580547, 23.0735195, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172315.jpg', '高雄市甲仙區新興路9號'),
(542, '福花茶王', '(07) 638-1188', 120.401191, 22.8633474, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172422.jpg', '高雄市田寮區新興村崗南路 4-1號'),
(543, '真愛吉緣訂婚禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023181532.jpg', '宜蘭縣礁溪鄉興農路127號'),
(544, '台園膠原蛋白美人凍禮盒', '(07) 643-2763', 120.398438, 22.4826554, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172628.jpg', '高雄市林園區漁港路2號'),
(545, '幸福蕉點', '(07) 661-6377', 120.482137, 22.8850276, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028172853.jpg', '高雄市旗山區復新街32號'),
(546, '花嫁-濃情陶米禮盒', '(07) 683-3309', 120.541406, 22.902171, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173111.jpg', '高雄市美濃區泰安里中正路一段1號'),
(547, '大樹張媽媽桑椹系列產品', '(07) 656-4569', 120.405633, 22.7289906, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028173301.jpg', '高雄市大樹區興田里(路)116-1號'),
(548, '戀戀蚵仔寮-幸福伴手禮盒 (野生烏魚子禮盒)', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180654.jpg', '高雄市梓官區漁港二路32號'),
(549, '戀戀蚵仔寮-極饌御宴禮盒', '(07) 617-6110', 120.256825, 22.7258567, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/292 戀戀蚵仔寮-極饌御宴禮盒_20111020 (原始檔).jpg', '高雄市梓官區漁港二路32號'),
(550, '蒲燒鰻', '(07) 699-5528', 120.208939, 22.9081774, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180757.jpg', '高雄市湖內區中正路二段158號'),
(551, '溫泉米粉', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026094940.jpg', '宜蘭縣礁溪鄉興農路127號'),
(552, '虱想起禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180845.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(553, '「思慕‧魚」系列-雙寶組合禮盒', '(07) 617-7063', 120.235443, 22.7637416, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151028180919.jpg', '高雄市彌陀區南寮里漁港一街60號'),
(554, '鳳梨發酵醋', '(07) 656-4569', 120.447989, 22.7466957, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112037.jpg', '高雄市大樹區興田里興田路116-1號'),
(555, '芒果冰淇淋', '(08) 876-1075', 120.660721, 22.2639534, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112256.jpg', '屏東縣枋山鄉枋山村國中路1號'),
(556, '無添加芒果乾', '(08) 876-1075', 120.66072, 22.263642, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112334.jpg', '屏東縣枋山鄉枋山村國中路3號'),
(557, '果然好味', '(08) 877-1111 #207', 120.690609, 22.1910849, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112410.jpg', '屏東縣枋山鄉善餘村德隆路25-1號'),
(558, '旗魚鬆', '(08) 832-8064', 120.442814, 22.4675985, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112451.jpg', '屏東縣東港鎮新生三路175號'),
(559, '湯戀組合禮盒', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095110.jpg', '宜蘭縣礁溪鄉興農路127號'),
(560, '枋寮鈣多情-芒果鱙仔魚', '(08) 878-8203', 120.607044, 22.3447209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112649.jpg', '屏東縣枋寮鄉保生村(路)437號'),
(561, '稻鴨香伴手禮', '(08) 796-7301', 120.610959, 22.7951794, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112750.jpg', '屏東縣高樹鄉泰山村產業路329號'),
(562, '鶉園鵪鶉元氣蛋捲', '(08) 783-1592', 120.625259, 22.612133, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029112827.jpg', '屏東縣萬巒鄉萬金村營區路1巷10號'),
(563, '溫泉糙米茶', '(03) 988-2924', 121.775228, 24.8190818, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026095201.jpg', '宜蘭縣礁溪鄉興農路127號'),
(564, '1. 洛神養生果凍、2. 水果酒禮盒、3. 原汁禮盒', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113004.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(565, '釋迦、洛神休閒食品', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113111.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(566, '洛神元氣餅', '(089) 781-531', 120.998081, 22.6018231, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113147.jpg', '台東縣太麻里鄉泰和村曙光街2號'),
(567, '養生香椿茶', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113357.jpg', '台東縣台東市更生北路118號'),
(568, '台東有機竹香咖啡禮盒', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113435.jpg', '台東縣台東市更生北路118號'),
(569, '果子狸咖啡', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113817.jpg', '台東縣台東市更生北路118號'),
(570, '鹿鳴枇杷梅', '(089) 513-035', 121.124906, 22.778972, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029113851.jpg', '台東縣台東市更生北路118號'),
(571, '山海紅鑽', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114002.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(572, '臺灣臺東好茶', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114111.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(573, '洛神花軟Q糖', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114153.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(574, '布農小米酒 davuz', '(089) 561-211 #9', 121.083538, 22.9158013, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114228.jpg', '台東縣延平鄉桃源村11鄰191號'),
(575, '台11線牛肉乾', '(089) 871-848', 121.378469, 23.1031521, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114931.jpg', '台東縣成功鎮新生路55號'),
(576, '池農養生米麩', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029114457.jpg', '台東縣池上鄉中山路302號'),
(577, '南澳椴木香菇伴手禮盒', '(03) 990-6423', 121.831706, 24.6404134, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113523.jpg', '宜蘭縣蘇澳鎮龍德里福德路156號'),
(578, '米鄉-紫米餅', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141359.jpg', '台東縣池上鄉中山路302號'),
(579, '池農米蛋捲', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141435.jpg', '台東縣池上鄉中山路302號'),
(580, '池上米餅禮盒', '(089 862-203', 121.21929, 23.1250621, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141509.jpg', '台東縣池上鄉中山路302號'),
(581, '米戀茶緣禮盒', '(089) 550-772', 121.135994, 22.9116099, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141620.jpg', '台東縣鹿野鄉鹿野村中華路二段 25 號'),
(582, '玉溪好米', '(03) 888-2040', 121.32868, 23.3804975, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029141712.jpg', '花蓮縣玉里鎮大禺里166-13號'),
(583, '當歸心圓夢情禮盒', '(03) 888-3965', 121.31628, 23.325412, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142112.jpg', '花蓮縣玉里鎮大同路24號'),
(584, '富麗養生粥', '(03) 882-1991', 121.296967, 23.1838646, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142335.jpg', '花蓮縣富里鄉羅山村9鄰東湖6號'),
(585, '牛奶系列天然沐浴用品', '(03) 877-2666 #1181', 121.456414, 23.8037226, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142515.jpg', '花蓮縣鳳林鎮永福街20號'),
(586, '瑞穗柚花茶', '(03) 887-1044', 121.381484, 23.496431, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142603.jpg', '花蓮縣瑞穗鄉中山路一段128號'),
(587, '茶籽油禮盒', '(02) 2783-6121 #13', 121.61299, 25.0551711, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026134158.jpg', '台北市南港區南港路一段173號'),
(588, '伊糯千金', '(03) 865-6888', 121.502628, 23.8423111, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029142751.jpg', '花蓮縣壽豐鄉豐文路105號'),
(589, '花蓮鰹干貝XO醬', '(03) 823-6071', 121.638531, 24.0062297, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029143002.jpg', '花蓮縣花蓮市港濱路37號'),
(590, '健康要裝蒜-健康調味禮盒', '(082) 322-376', 118.320407, 24.4329217, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150448.jpg', '金門縣金城鎮民生路6號'),
(591, '醋老爺健康日記', '(03) 922-5226', 121.708869, 24.7460167, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150532.jpg', '宜蘭縣員山鄉茄苳路3號'),
(592, '戀戀大湖', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150702.jpg', '苗栗縣大湖鄉富興村八寮灣34-7號'),
(593, '柚香和風沾醬', '(02) 2610-2996 #250', 120.988108, 24.778289, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113736.jpg', '新北市八里區中山路二段 366 號'),
(594, '紅棗干', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029150901.jpg', '苗栗縣公館鄉館東村大同路266號'),
(595, '炭晶蛋捲', '(037) 540-039', 120.875905, 24.6356209, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151000.jpg', '苗栗縣造橋鄉造橋村錦成東路8-5號'),
(596, '柚鄉餅、副總統餅 (東閔餅)', '(04) 879-0100 #141', 120.616152, 23.810138, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029151259.jpg', '彰化縣二水鄉聖化村員集路三段678號'),
(597, '紫香御品-香芋片', '(04) 2686-7926', 120.615858, 24.334949, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029161829.jpg', '台中市大甲區中山路一段372號'),
(598, '楊媽媽菓子工坊-米麩金饌鳳梨酥', '(06) 687-1929', 120.357963, 23.3632139, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029162155.jpg', '台南市後壁區後壁里99號'),
(599, '三峽茶鄉、袋袋相傳禮盒', '(02) 8674-1780', 121.376189, 24.933545, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113824.jpg', '新北市三峽區長泰街96號'),
(600, '棗紅公館蜜餞系列', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163826.jpg', '苗栗縣公館鄉館東村大同路266號'),
(601, '鳥兒歡唱-養生禮盒組', '(089) 513-111 #15', 121.022134, 22.6955793, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029163903.jpg', '台東縣卑南鄉溫泉村溫泉路 388 號'),
(602, '花蓮珍饌-肉乾與肉條系列', '(03) 888-3501、\n(03) 888-9158、\n0928-875-148', 121.320723, 23.3270702, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164109.jpg', '花蓮縣玉里鎮城南五街27號'),
(603, '燒仙草禮盒', '035875288、035872010', 121.165311, 24.8058508, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151029164316.jpg', '新竹縣關西鎮北山里高橋坑10鄰6號'),
(604, '平溪原生種山藥', '(02) 2495-1052', 121.739325, 25.0254039, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113912.jpg', '新北市平溪區嶺腳里中華街15號'),
(605, '臻品禮饌', '(02) 2638-1005 #212', 121.567138, 25.2908277, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026113950.jpg', '新北市石門區(村)中央路2號'),
(606, '陳年包種老茶', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114113.jpg', '新北市坪林區坪林村坪林街103號'),
(607, '包種美人雙饗泡', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114207.jpg', '新北市坪林區坪林村坪林街103號'),
(608, '三好禮', '(02) 2665-7227 #28', 121.710761, 24.9350844, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114243.jpg', '新北市坪林區坪林村坪林街103號'),
(609, '金紅藷', '(02) 2498-1100 #5', 121.636655, 25.2225054, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114320.jpg', '新北市金山區中山路267號'),
(610, '金舞滂米', '(03) 379-1881 #203', 121.258777, 25.0047037, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114536.jpg', '桃園市蘆竹區龍安街二段968號'),
(611, '向日葵花茶', '(03) 498-1221 #107', 121.139732, 25.010732, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114659.jpg', '桃園市觀音區大同里中山路二段833號'),
(612, '客家擂茶', '(03) 580-3448', 121.055152, 24.700446, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114805.jpg', '新竹縣北埔鄉北埔街94號'),
(613, '手工蔬食蕃茄麵', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114837.jpg', '新竹縣芎林鄉文昌街120號'),
(614, '瓊福滿溢', '(03) 592-1173 #34', 121.080427, 24.7742887, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026114912.jpg', '新竹縣芎林鄉文昌街120號'),
(615, '柿餅加工系列產品-柿糬', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115430.jpg', '新竹縣新埔鎮楊新路一段322號'),
(616, '客家柚子茶', '(03) 588-2002 #124', 121.088394, 24.8312961, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026115632.jpg', '新竹縣新埔鎮楊新路一段322號'),
(617, '台北珍情土肉桂伴手禮組', '(02) 2707-0612 #242', 121.543272, 25.0337719, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151023165917.jpg', '台北市大安區復興南路一段390號14樓'),
(618, '彩油四季-苦茶油', '(037) 872-001 #47', 120.772363, 24.4146177, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153407.jpg', '苗栗縣三義鄉中正路80號'),
(619, '擂茶香柚酥禮盒', '(037) 832-077', 120.956137, 24.6535081, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153504.jpg', '苗栗縣三灣鄉中正路176號'),
(620, '草莓大福', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153547.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(621, '草莓蜜果子', '(037) 994-986', 120.876103, 24.4402288, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153650.jpg', '苗栗縣大湖鄉富興村八寮灣2-4號'),
(622, '紅運高棗', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153804.jpg', '苗栗縣公館鄉館東村大同路266號'),
(623, '幸福禮盒', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026153838.jpg', '苗栗縣公館鄉館東村大同路266號'),
(624, '好采福', '(037) 233-908', 120.827364, 24.5046407, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154016.jpg', '苗栗縣公館鄉館東村大同路266號'),
(625, '1. 甘薯湯圓、2. 甘薯筍 (菜) 包', '(037) 921-718', 120.810083, 24.5506389, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154228.jpg', '苗栗縣西湖鄉三湖村4鄰71號'),
(626, '待客以鱒-醃鱒', '(037) 824-156', 121.001136, 24.6055422, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154300.jpg', '苗栗縣南庄鄉東村中正路195號'),
(627, '菜乾禮盒組', '(037) 879-393', 120.751328, 24.406434, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026154656.jpg', '苗栗縣三義鄉廣盛村廣盛9-27號'),
(628, '藺草禮盒組藺草手工藝品-草蓆、草帽', '(037) 741-319', 120.65256, 24.4426396, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155303.jpg', '苗栗縣苑裡鎮為公路65號'),
(629, '飛牛烤布丁禮盒', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155336.jpg', '苗栗縣通霄鎮南和里166號'),
(630, '飛牛牧場原野-酪農餅乾', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026155750.jpg', '苗栗縣通霄鎮南和里166號'),
(631, '飛牛甜心蛋糕', '(037) 783-588', 120.740641, 24.4422344, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160558.jpg', '苗栗縣通霄鎮南和里166號'),
(632, '百變薑餅人-提著幸福去旅行', '(037) 951-530', 120.832666, 24.3804378, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026160657.jpg', '苗栗縣大湖鄉栗林村薑麻園9鄰6號'),
(633, '福桂滿堂禮', '(037) 931-340、\n(037) 931-306', 120.921605, 24.5409581, 'https://ezgo.coa.gov.tw/Uploads/opendata/BuyItem/APPLY_D/20151026161023.jpg', '苗栗縣獅潭鄉新店村125號');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`roomClass`),
  ADD UNIQUE KEY `classId` (`classId`) USING BTREE;

--
-- 資料表索引 `cust`
--
ALTER TABLE `cust`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account` (`account`);

--
-- 資料表索引 `partyroom`
--
ALTER TABLE `partyroom`
  ADD PRIMARY KEY (`roomId`),
  ADD KEY `roomClass` (`roomClass`);

--
-- 資料表索引 `souvenir`
--
ALTER TABLE `souvenir`
  ADD PRIMARY KEY (`id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `class`
--
ALTER TABLE `class`
  MODIFY `classId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `cust`
--
ALTER TABLE `cust`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `member`
--
ALTER TABLE `member`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `partyroom`
--
ALTER TABLE `partyroom`
  MODIFY `roomId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `souvenir`
--
ALTER TABLE `souvenir`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=634;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `partyroom`
--
ALTER TABLE `partyroom`
  ADD CONSTRAINT `partyroom_ibfk_1` FOREIGN KEY (`roomClass`) REFERENCES `class` (`roomClass`);
--
-- 資料庫: `java`
--
CREATE DATABASE IF NOT EXISTS `java` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
USE `java`;

-- --------------------------------------------------------

--
-- 資料表結構 `blog`
--

CREATE TABLE `blog` (
  `Id` int(11) NOT NULL,
  `Articleid` int(11) DEFAULT NULL,
  `Nickname` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `Retime` datetime DEFAULT NULL,
  `Reply` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `blog`
--

INSERT INTO `blog` (`Id`, `Articleid`, `Nickname`, `Retime`, `Reply`) VALUES
(1, 1, 'Crystal', '2011-05-01 00:00:00', 'very good'),
(2, 1, 'Babe', '2011-05-01 00:00:00', 'donot know'),
(3, 1, 'Dave', '2011-05-01 00:00:00', 'bull shit');

-- --------------------------------------------------------

--
-- 資料表結構 `customer`
--

CREATE TABLE `customer` (
  `custid` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `password` varbinary(50) DEFAULT NULL,
  `email` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `birth` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `customer`
--

INSERT INTO `customer` (`custid`, `password`, `email`, `birth`) VALUES
('Alex', 0x41, 'alex@lab.com', '2001-07-20'),
('Babe', 0x42, 'babe@lab.com', '2003-03-20'),
('Carol', 0x43, 'carol@lab.com', '2001-09-11'),
('Dave', 0x44, 'dave@lab.com', '2001-01-20'),
('Ellen', 0x45, 'ellen@lab.com', '1970-01-01');

-- --------------------------------------------------------

--
-- 資料表結構 `dept`
--

CREATE TABLE `dept` (
  `deptid` int(11) NOT NULL,
  `deptname` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `dept`
--

INSERT INTO `dept` (`deptid`, `deptname`) VALUES
(10, 'Java'),
(20, 'Delphi'),
(30, 'Visual Basic'),
(50, 'hahahahahahahaha');

-- --------------------------------------------------------

--
-- 資料表結構 `detail`
--

CREATE TABLE `detail` (
  `photoid` int(11) NOT NULL,
  `photo` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- 資料表結構 `emp`
--

CREATE TABLE `emp` (
  `empid` int(11) NOT NULL,
  `empname` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `sex` char(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `photo` longblob,
  `deptid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `emp`
--

INSERT INTO `emp` (`empid`, `empname`, `salary`, `sex`, `photo`, `deptid`) VALUES
(1, 'Samuel', 10, 'M', NULL, 10),
(2, 'Crystal', 100, 'F', NULL, 30),
(3, 'Sammy', 1000, 'M', NULL, 10),
(4, 'Momo', 10000, 'M', NULL, 20);

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `price` float DEFAULT NULL,
  `make` date DEFAULT NULL,
  `expire` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `make`, `expire`) VALUES
(1, 'Coca Cola', 20, '2007-01-01', 365),
(2, 'Milk Tea', 15, '2007-02-14', 150),
(3, 'Easy Coffee', 10, '2007-10-01', 200),
(4, 'Coffee Square', 15, '2007-02-20', 100),
(5, 'Cookie', 25, '2007-03-27', 45),
(6, 'Prince Noodle', 5, '2007-04-02', 365),
(7, 'Chicken Noodle', 20, '2006-10-30', 300),
(8, 'Qwi-Qwi', 20, '2007-02-28', 200),
(9, 'Ice Pop', 15, '2007-05-30', 150),
(10, 'HotDog', 25, '2007-04-30', 1);

-- --------------------------------------------------------

--
-- 資料表結構 `proj`
--

CREATE TABLE `proj` (
  `projid` int(11) NOT NULL,
  `projname` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `proj`
--

INSERT INTO `proj` (`projid`, `projname`) VALUES
(100, 'Online Shopping'),
(200, 'Mobile Banking');

-- --------------------------------------------------------

--
-- 資料表結構 `projemp`
--

CREATE TABLE `projemp` (
  `projid` int(11) NOT NULL,
  `empid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 傾印資料表的資料 `projemp`
--

INSERT INTO `projemp` (`projid`, `empid`) VALUES
(100, 1),
(100, 2),
(200, 3),
(100, 4),
(200, 4);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`Id`);

--
-- 資料表索引 `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`custid`);

--
-- 資料表索引 `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`deptid`);

--
-- 資料表索引 `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`photoid`);

--
-- 資料表索引 `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`empid`),
  ADD KEY `FK_EMP_DEPT_DEPTID` (`deptid`);

--
-- 資料表索引 `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `proj`
--
ALTER TABLE `proj`
  ADD PRIMARY KEY (`projid`);

--
-- 資料表索引 `projemp`
--
ALTER TABLE `projemp`
  ADD PRIMARY KEY (`projid`,`empid`),
  ADD KEY `FK_PROJEMP_EMP_EMPID` (`empid`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `blog`
--
ALTER TABLE `blog`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `emp`
--
ALTER TABLE `emp`
  MODIFY `empid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `detail`
--
ALTER TABLE `detail`
  ADD CONSTRAINT `FK_DETAIL_PRODUCT_PHOTOID` FOREIGN KEY (`photoid`) REFERENCES `product` (`id`);

--
-- 資料表的限制式 `emp`
--
ALTER TABLE `emp`
  ADD CONSTRAINT `FK_EMP_DEPT_DEPTID` FOREIGN KEY (`deptid`) REFERENCES `dept` (`deptid`);

--
-- 資料表的限制式 `projemp`
--
ALTER TABLE `projemp`
  ADD CONSTRAINT `FK_PROJEMP_EMP_EMPID` FOREIGN KEY (`empid`) REFERENCES `emp` (`empid`),
  ADD CONSTRAINT `FK_PROJEMP_PROJ_PROJID` FOREIGN KEY (`projid`) REFERENCES `proj` (`projid`);
--
-- 資料庫: `lab`
--
CREATE DATABASE IF NOT EXISTS `lab` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `lab`;

-- --------------------------------------------------------

--
-- 資料表結構 `lab007`
--

CREATE TABLE `lab007` (
  `CatID` int(11) NOT NULL,
  `MyDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab007`
--

INSERT INTO `lab007` (`CatID`, `MyDate`) VALUES
(1, '2022-07-07 11:12:23'),
(2, '2022-07-07 11:12:23');

-- --------------------------------------------------------

--
-- 資料表結構 `lab06`
--

CREATE TABLE `lab06` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(5) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `CreateDate` datetime DEFAULT NULL,
  `UpdateDate` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab06`
--

INSERT INTO `lab06` (`ProductID`, `ProductName`, `Price`, `CreateDate`, `UpdateDate`) VALUES
(123, '口罩', 199, NULL, '2022-07-04 15:22:30'),
(124, NULL, 100, NULL, '2022-07-04 15:22:30'),
(125, NULL, 100, NULL, '2022-07-04 15:22:30'),
(501, NULL, NULL, '2022-07-04 15:25:46', '2022-07-04 15:25:46');

-- --------------------------------------------------------

--
-- 資料表結構 `lab07`
--

CREATE TABLE `lab07` (
  `CategoryID` int(11) NOT NULL,
  `AvgPrice` decimal(5,2) DEFAULT NULL,
  `Memo` varchar(50) DEFAULT NULL,
  `UpdateDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab07`
--

INSERT INTO `lab07` (`CategoryID`, `AvgPrice`, `Memo`, `UpdateDate`) VALUES
(2, '23.06', NULL, '2022-07-05 09:40:38'),
(3, '25.16', NULL, '2022-07-05 09:40:38'),
(4, '28.73', NULL, '2022-07-05 09:40:38'),
(5, '20.25', NULL, '2022-07-05 09:40:38'),
(6, '54.01', NULL, '2022-07-05 09:40:38'),
(7, '32.37', NULL, '2022-07-05 09:40:38'),
(8, '20.68', NULL, '2022-07-05 09:40:38');

-- --------------------------------------------------------

--
-- 資料表結構 `lab24`
--

CREATE TABLE `lab24` (
  `ID` int(11) NOT NULL,
  `MobilePhone` varchar(10) DEFAULT NULL,
  `HomePhone` varchar(10) DEFAULT NULL,
  `OfficePhone` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab24`
--

INSERT INTO `lab24` (`ID`, `MobilePhone`, `HomePhone`, `OfficePhone`) VALUES
(1, 'M1', 'H1', 'O1'),
(2, NULL, 'H2', 'O2'),
(3, 'M3', NULL, 'O3'),
(4, 'M4', 'H4', NULL),
(5, NULL, NULL, 'O5'),
(6, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `lab301`
--

CREATE TABLE `lab301` (
  `ProductID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab301`
--

INSERT INTO `lab301` (`ProductID`) VALUES
(1),
(2),
(3);

-- --------------------------------------------------------

--
-- 資料表結構 `lab302`
--

CREATE TABLE `lab302` (
  `OrderID` char(1) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab302`
--

INSERT INTO `lab302` (`OrderID`, `ProductID`) VALUES
('A', 1),
('B', 98),
('C', 99);

-- --------------------------------------------------------

--
-- 資料表結構 `lab_employee`
--

CREATE TABLE `lab_employee` (
  `EmployeeID` int(11) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(10) NOT NULL,
  `Title` varchar(30) DEFAULT NULL,
  `TitleOfCourtesy` varchar(25) DEFAULT NULL,
  `BirthDate` datetime DEFAULT NULL,
  `HireDate` datetime DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(15) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(15) DEFAULT NULL,
  `HomePhone` varchar(24) DEFAULT NULL,
  `Extension` varchar(4) DEFAULT NULL,
  `Notes` mediumtext NOT NULL,
  `ReportsTo` int(11) DEFAULT NULL,
  `PhotoPath` varchar(255) DEFAULT NULL,
  `Salary` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `lab_employee`
--

INSERT INTO `lab_employee` (`EmployeeID`, `LastName`, `FirstName`, `Title`, `TitleOfCourtesy`, `BirthDate`, `HireDate`, `Address`, `City`, `Region`, `PostalCode`, `Country`, `HomePhone`, `Extension`, `Notes`, `ReportsTo`, `PhotoPath`, `Salary`) VALUES
(1, 'Davolio', 'Nancy', 'Sales Representative', 'Ms.', '1948-12-08 00:00:00', '1992-05-01 00:00:00', '507 - 20th Ave. E.Apt. 2A', 'Seattle', 'WA', '98122', 'USA', '(206) 555-9857', '5467', 'Education includes a BA in psychology from Colorado State University in 1970.  She also completed \"The Art of the Cold Call.\"  Nancy is a member of Toastmasters International.', 2, 'http://accweb/emmployees/davolio.bmp', 2954.55),
(2, 'Fuller', 'Andrew', 'Vice President, Sales', 'Dr.', '1952-02-19 00:00:00', '1992-08-14 00:00:00', '908 W. Capital Way', 'Tacoma', 'WA', '98401', 'USA', '(206) 555-9482', '3457', 'Andrew received his BTS commercial in 1974 and a Ph.D. in international marketing from the University of Dallas in 1981.  He is fluent in French and Italian and reads German.  He joined the company as a sales representative, was promoted to sales manager in January 1992 and to vice president of sales in March 1993.  Andrew is a member of the Sales Management Roundtable, the Seattle Chamber of Commerce, and the Pacific Rim Importers Association.', NULL, 'http://accweb/emmployees/fuller.bmp', 2254.49),
(3, 'Leverling', 'Janet', 'Sales Representative', 'Ms.', '1963-08-30 00:00:00', '1992-04-01 00:00:00', '722 Moss Bay Blvd.', 'Kirkland', 'WA', '98033', 'USA', '(206) 555-3412', '3355', 'Janet has a BS degree in chemistry from Boston College (1984).  She has also completed a certificate program in food retailing management.  Janet was hired as a sales associate in 1991 and promoted to sales representative in February 1992.', 2, 'http://accweb/emmployees/leverling.bmp', 3119.15),
(4, 'Peacock', 'Margaret', 'Sales Representative', 'Mrs.', '1937-09-19 00:00:00', '1993-05-03 00:00:00', '4110 Old Redmond Rd.', 'Redmond', 'WA', '98052', 'USA', '(206) 555-8122', '5176', 'Margaret holds a BA in English literature from Concordia College (1958) and an MA from the American Institute of Culinary Arts (1966).  She was assigned to the London office temporarily from July through November 1992.', 2, 'http://accweb/emmployees/peacock.bmp', 1861.08),
(5, 'Buchanan', 'Steven', 'Sales Manager', 'Mr.', '1955-03-04 00:00:00', '1993-10-17 00:00:00', '14 Garrett Hill', 'London', NULL, 'SW1 8JR', 'UK', '(71) 555-4848', '3453', 'Steven Buchanan graduated from St. Andrews University, Scotland, with a BSC degree in 1976.  Upon joining the company as a sales representative in 1992, he spent 6 months in an orientation program at the Seattle office and then returned to his permanent post in London.  He was promoted to sales manager in March 1993.  Mr. Buchanan has completed the courses \"Successful Telemarketing\" and \"International Sales Management.\"  He is fluent in French.', 2, 'http://accweb/emmployees/buchanan.bmp', 1744.21),
(6, 'Suyama', 'Michael', 'Sales Representative', 'Mr.', '1963-07-02 00:00:00', '1993-10-17 00:00:00', 'Coventry House\r\nMiner Rd.', 'London', NULL, 'EC2 7JR', 'UK', '(71) 555-7773', '428', 'Michael is a graduate of Sussex University (MA, economics, 1983) and the University of California at Los Angeles (MBA, marketing, 1986).  He has also taken the courses \"Multi-Cultural Selling\" and \"Time Management for the Sales Professional.\"  He is fluent in Japanese and can read and write French, Portuguese, and Spanish.', 5, 'http://accweb/emmployees/davolio.bmp', 2004.07),
(7, 'King', 'Robert', 'Sales Representative', 'Mr.', '1960-05-29 00:00:00', '1994-01-02 00:00:00', 'Edgeham Hollow\r\nWinchester Way', 'London', NULL, 'RG1 9SP', 'UK', '(71) 555-5598', '465', 'Robert King served in the Peace Corps and traveled extensively before completing his degree in English at the University of Michigan in 1992, the year he joined the company.  After completing a course entitled \"Selling in Europe,\" he was transferred to the London office in March 1993.', 5, 'http://accweb/emmployees/davolio.bmp', 1991.55),
(8, 'Callahan', 'Laura', 'Inside Sales Coordinator', 'Ms.', '1958-01-09 00:00:00', '1994-03-05 00:00:00', '4726 - 11th Ave. N.E.', 'Seattle', 'WA', '98105', 'USA', '(206) 555-1189', '2344', 'Laura received a BA in psychology from the University of Washington.  She has also completed a course in business French.  She reads and writes French.', 2, 'http://accweb/emmployees/davolio.bmp', 2100.5),
(9, 'Dodsworth', 'Anne', 'Sales Representative', 'Ms.', '1966-01-27 00:00:00', '1994-11-15 00:00:00', '7 Houndstooth Rd.', 'London', NULL, 'WG2 7LT', 'UK', '(71) 555-4444', '452', 'Anne has a BA degree in English from St. Lawrence College.  She is fluent in French and German.', 5, 'http://accweb/emmployees/davolio.bmp', 2333.33);

-- --------------------------------------------------------

--
-- 資料表結構 `shop`
--

CREATE TABLE `shop` (
  `Store_Code` char(1) NOT NULL,
  `Store_Name` varchar(20) DEFAULT '皮卡丘',
  `Store_Address` varchar(255) DEFAULT NULL,
  `Store_Phone` varchar(10) DEFAULT NULL,
  `Store_Capital` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `shop`
--

INSERT INTO `shop` (`Store_Code`, `Store_Name`, `Store_Address`, `Store_Phone`, `Store_Capital`) VALUES
('E', '皮卡丘', NULL, NULL, -999);

-- --------------------------------------------------------

--
-- 資料表結構 `shop_employee`
--

CREATE TABLE `shop_employee` (
  `Employee_ID` int(11) NOT NULL,
  `Employee_Name` varchar(20) NOT NULL,
  `Employee_Phone` varchar(10) NOT NULL,
  `Store_Code` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `lab06`
--
ALTER TABLE `lab06`
  ADD PRIMARY KEY (`ProductID`);

--
-- 資料表索引 `lab07`
--
ALTER TABLE `lab07`
  ADD PRIMARY KEY (`CategoryID`);

--
-- 資料表索引 `lab24`
--
ALTER TABLE `lab24`
  ADD PRIMARY KEY (`ID`);

--
-- 資料表索引 `lab_employee`
--
ALTER TABLE `lab_employee`
  ADD PRIMARY KEY (`EmployeeID`),
  ADD KEY `LastName` (`LastName`),
  ADD KEY `PostalCode` (`PostalCode`),
  ADD KEY `FK_Employees_Employees` (`ReportsTo`);

--
-- 資料表索引 `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`Store_Code`);

--
-- 資料表索引 `shop_employee`
--
ALTER TABLE `shop_employee`
  ADD PRIMARY KEY (`Employee_ID`),
  ADD UNIQUE KEY `Employee_Phone` (`Employee_Phone`),
  ADD KEY `Store_Code` (`Store_Code`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `lab06`
--
ALTER TABLE `lab06`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=502;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `lab07`
--
ALTER TABLE `lab07`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `lab24`
--
ALTER TABLE `lab24`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `lab_employee`
--
ALTER TABLE `lab_employee`
  MODIFY `EmployeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `shop_employee`
--
ALTER TABLE `shop_employee`
  ADD CONSTRAINT `shop_employee_ibfk_1` FOREIGN KEY (`Store_Code`) REFERENCES `shop` (`Store_Code`);
--
-- 資料庫: `netflix`
--
CREATE DATABASE IF NOT EXISTS `netflix` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `netflix`;

-- --------------------------------------------------------

--
-- 資料表結構 `album`
--

CREATE TABLE `album` (
  `AlbumID` int(11) NOT NULL,
  `AlbumName` varchar(30) DEFAULT NULL,
  `AlbumPicture` blob,
  `Age` tinyint(2) DEFAULT NULL,
  `AlbumType` varchar(10) DEFAULT NULL,
  `AlbumText` varchar(100) DEFAULT NULL,
  `Star` varchar(10) DEFAULT NULL,
  `Suthor` varchar(10) DEFAULT NULL,
  `filmReview` varchar(100) DEFAULT NULL,
  `SeasonID` int(11) DEFAULT NULL,
  `SeasonText` varchar(100) DEFAULT NULL,
  `AlbumCreateTime` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `album`
--

INSERT INTO `album` (`AlbumID`, `AlbumName`, `AlbumPicture`, `Age`, `AlbumType`, `AlbumText`, `Star`, `Suthor`, `filmReview`, `SeasonID`, `SeasonText`, `AlbumCreateTime`) VALUES
(0, '怪奇物語', NULL, 16, '恐怖節目', '鎮上一名小男孩不知去向後，謎樣的秘密實驗、恐怖的超自然力量，以及一位詭異的小女孩，也跟著浮出檯面。', '薇諾娜·瑞德', '達菲兄弟', '這部懷舊影集師法 80 年代的科幻恐怖經典，已榮獲數十項艾美獎提名肯定，包括三度提名最佳戲劇類影集。', 0, '印第安那州的霍金斯鎮接連上演離奇事件，一名年輕男孩忽然失蹤，也因此讓一名擁有超能力的年輕女孩曝光。', NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `netflixindex`
--

CREATE TABLE `netflixindex` (
  `AlbumClassID` int(11) NOT NULL,
  `AlbumClassTitle` varchar(10) NOT NULL,
  `AlbumType` varchar(10) DEFAULT NULL,
  `AlbumID` int(11) NOT NULL,
  `AlbumName` varchar(30) NOT NULL,
  `AlbumPhoto` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `netflixindex`
--

INSERT INTO `netflixindex` (`AlbumClassID`, `AlbumClassTitle`, `AlbumType`, `AlbumID`, `AlbumName`, `AlbumPhoto`) VALUES
(0, '熱門選擇', '恐怖節目', 0, '怪奇物語', NULL),
(1, '熱門選擇', '恐怖節目', 1, '怪奇物語', NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `video`
--

CREATE TABLE `video` (
  `VideoID` int(11) NOT NULL,
  `VideoTitle` varchar(30) DEFAULT NULL,
  `VideoTime` tinyint(4) DEFAULT NULL,
  `VideoText` varchar(100) DEFAULT NULL,
  `Actor` varchar(10) DEFAULT NULL,
  `VideoFile` longblob,
  `SeasonID` int(11) DEFAULT NULL,
  `VideoSID` int(11) DEFAULT NULL,
  `AlbumID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `video`
--

INSERT INTO `video` (`VideoID`, `VideoTitle`, `VideoTime`, `VideoText`, `Actor`, `VideoFile`, `SeasonID`, `VideoSID`, `AlbumID`) VALUES
(0, '第 1 集。第 1 章：威爾·拜爾斯消失了', 49, '年輕的威爾從友人住處返家，途中卻目睹一番恐怖景象；不遠處的政府實驗室也暗藏不可告人的秘密。', '薇諾娜·瑞德', NULL, 0, 1, 0),
(1, '第 1 集。第 1 章：威爾·拜爾斯消失了', 49, '年輕的威爾從友人住處返家，途中卻目睹一番恐怖景象；不遠處的政府實驗室也暗藏不可告人的秘密。', '薇諾娜·瑞德', NULL, 0, 1, 0);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- 資料表索引 `netflixindex`
--
ALTER TABLE `netflixindex`
  ADD PRIMARY KEY (`AlbumClassID`),
  ADD UNIQUE KEY `AlbumID` (`AlbumID`);

--
-- 資料表索引 `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`VideoID`),
  ADD KEY `AlbumID` (`AlbumID`);

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`AlbumID`) REFERENCES `album` (`AlbumID`);
--
-- 資料庫: `northwind`
--
CREATE DATABASE IF NOT EXISTS `northwind` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `northwind`;

-- --------------------------------------------------------

--
-- 資料表結構 `categories`
--

CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(15) NOT NULL,
  `Description` mediumtext,
  `Picture` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(1, 'Beverages', 'Soft drinks, coffees, teas, beers, and ales', 0x46464438464645303030313034413436343934363030303130323030303036343030363430303030464645433030313134343735363336423739303030313030303430303030303035303030303046464545303032363431363436463632363530303634433030303030303030313033303031353034303330363041304430303030304136333030303031304538303030303139463430303030323741344646444230303834303030323032303230323032303230323032303230323033303230323032303330343033303230323033303430353034303430343034303430353036303530353035303530353035303630363037303730383037303730363039303930413041303930393043304330433043304330433043304330433043304330433043304330433031303330333033303530343035303930363036303930443042303930423044304630453045304530453046304630433043304330433043304630463043304330433043304330433046304330433043304330433043304330433043304330433043304330433043304330433043304330433043304330433043304330433043304346464332303031313038303036453030414630333031313130303032313130313033313130314646433430304538303030303031303430333031303130303030303030303030303030303030303030303035303330343036303730303032303830313039303130303032303330313031303130303030303030303030303030303030303030303032303330303031303430353036303731303030303130343031303330333034303130333034303330303030303030303030303130303032303330343131313031323035323032313133333132323134303633303332323331353431333332353037323433343136313130303032303030333035303530343037303430383037303130303030303030303031303230303131303332313331343131323034353137313232333231333130363138313035393141313432353236323233313432304331373233333330463042314531383239324232333444314631413243324432343339333234313230303030303530333034303330313030303030303030303030303030303030303030333030313131323132303430333131303530313232323431303233323631313330313030303230323032303130333033303530313031303030303030303030303031303031313231333134313531363131303731383139314131423132304630433144314531333046314646444130303043303330313030303231313033313130303030303145433345363644453636434530444442344644343736433639454146304241334443344441463246443230454237434344363831453934384241444235333937344143343641323137384635353344453732383041353638333236463736453132343439343636314634423430454236463539433931333536383543333837353546414241394338394344463642323637453045443144444532314344414632453436433441333846443837324545313641443534323739414238354534313443414337423244433039333735444142353442353037443137463635433643393332344636453635344339333234433933433933444239353244333634364444334534413646313934383731463435354643423344324143353535383034394233303842313042453838464133424543333930343645423234433933323443393332344339333234384532444635424436433936453935384431363038303732363335343846314442354345313738383531423739364139443038314536313543313946453836464234383735413837373630413930464232363439413044423531363436333336424138423237353039454643384330434135454431333436383434303836323542304343434631303332334331324135433735313143313832443645364635374134424441463337353032324436323441433543344136433235314435334531343844373037314430423338323633443045373246364539314333453737463344454241303138374138333936464634453143333539433636373834454246314233304534413043373344394431464546463030393331413142313832443637343433343443374431304431333634304337373139323038303845443435413445414536394632394545323936394445314146334230384231343735334130373131434134393542314639334230463844433432363842453930463739433538433844383541423133304335353142303834443136363932394336323143413144394533374136463645324641324536444536464230303141394339313531304235443945434337353141423639353842363131313335433745314543304535424641414645383545354133303942304230433434423135344334323844423831453042304431384443354430453735363042443743454645353744464437353744453632444146363045423737424441463732353933333441453641383835363533323930464137464542334536323039304334433234363936443432383832323941323835413944313132323142313737453131454244423432453046343134334632374438384342443039333332313239313830423541314133303934383438393039424230363744354146354446314336454238314531363935364441343445414530333846343339323339333638353134363041443241383745353741413132394437353441334138433033364232343639364137363834313932423333463836393431363133344433433645444346343545313443303245314336433336323238353431463443463630433632394535364133443931383934453641453546413534333946444144393634424238394431383436383543454145384639453731434236304343444130444539453646363446413446394630433835424444323833333741413637303831313331364138383244414532453837444444333538424139344545304546414443434544413339444341423435443331354534413438344442324438453444373244454546393845443445424638423144373136393035414438423441434238354543303139333930393439383142324241453437453337413238463637444332313744363841363145453342333044324542434241353645423639323646423338393245444443334646464441303030383031303130303031303530324534454242413441463343344431333441333632364631423741443535464233463335323744363338304534363737443241444635384537363746414444453845343643414344333938363933433746324246354245333339463135444233384144434231434331333633373137323733433830364438303942333631343743383631343543433444423944434245363443303532443041393339314335443034443633313833454344463544383345433943373346464436354636333634394337464630304142423930463939313434443836334433393839394235423839453332333743334336464132424230333945324345343334344239353233384244414633393737394434393237363634434630424343443742334631373343374639324230314639353932394631454635434435323330344146413136413437394533454538344641333739344144423130394632453133363530353739344532304235304438464333364544334333363039324243363938354145364346373633383839394545353830363943453542434146314232343332333939423533444139393636443537323246304230414543443532333734353536354638464537383634393142323935424442443035433032373445443041453732333134324442424341424143394136434444304643463939443343313436313844424238303435434335333845334535313244304641443441394643303730313241394645393444393437324643314444453041314532323939373131313836423637374532343845464342313236463330443444453536414146453536423237463246353032393745433135443841434644384137393134393636343934433544434442453434463142433446313534424531443745344146464332383246464441324536453942394642423232334339354237323646333133423142354546353842304438463932453441424146423046333337333933373535363838394242393539314642384632384244334134344539344137434139443232444339384131314446393033453445353435413644364144434346324433353937344232423943353537414630434434344231443233333743423544463037333132423537324145384134393630324437333742324233464443393133443344333933393338323031343444353544414530423944374643344536374543314338333538444235333937423839443241443937353439394634453142314337454643424645343742384237434333384245344332463342304142324337313931453134383133444135364332384231313632304335313337424236314142313431463638413844423135423936394535373441463339343530454533443536453742313435313442333238324643463536344534373934313732323046323143444534414542354136324234443546323442354436413933323538383432303833354438413538384231434538443036323633353534383234384531453441324632443545344638453644393845434435393642424439383132424532333044394233353444344237334331323537374336374637323636343931423943453639364234363530384339354534334534423735433439313533364341433532353636333846433531383735373836353332343436333743353533373238413038393842444632334443443045364436423331424534423335444135354345313332464242433744383335463935444432343336454634313732314130444143453245384133324245304245444237463834374545384238393839393043414332314543373646364339424439333331394244394641343432303939323539313831334633424132364642343239323433424245433735363741393736304534383538384644414539323145353645353139363645354142344331444646303039463732414633463035353545373944414541364537373930394334344546373336343245364438364645453437323738444436413344453232463638444242384338434445443735333742354336313142323336453043464441333937304436344443444336464231374541464631423731423345453036433332343738444135373845423935453241413943433835363433353432344342323144384136464436454332334538373745354245373433373646454446314439453945433532364335333041444531453633364643393933464541433542393746433843453739343546453531374639333433463934343444464337304441374646464441303030383031303230303031303530323742353031444338354533323431463633353037454433394434413244434539334641334235433232333430344144453734433243363846364545343631373034323135384434454145313930463141454544333141363346334343433435383537384341443835313034324341434144433346313137363133304539394430423732413438463042364538314334323046434137303042304232423344353934453931363732394245393935384433323842444142333141444231393436423832394630393641373233323634394433373935424437393137393131393531373132423141333744314131343846444131463639433531324532423042364144413530444331303739323236373045414332433243364131314634324543303936343246324431413644443330423242464134433342413344343735363045463232423332413633374130423742324332463435333331363131314638303034303631334341393538343343373438303831343445383538333537333136313631363341314131343844454345363837303733344235304542334431383538353834343635363130363230334130394332443830413244334131323832434539423530433745343935423832453443334446434134324632303542394142373335373934323333313539343045343745333734394444453330384237304237324341454342423232353635333431373144424438374531454441353846443433443041454342444142444142444142444142444141314336394646444130303038303130333030303130353032304544373241394437463931323343364336434634443932423143333037343631344339343834374435314541433243363939353944324135413330333942434134343433463935364531434544433734314142374133314639444133353045433734363335323846453236423332384237314130363635364430313634323141363136443042364139363543323043324236413244353845394441393931323043433237413642353137453938343138453545333741433344373930383445394242343531414336424231373844373844373838413131323131383141313545413545413138423739384539423533364233343246313035453230384336313138313835354638343330423037344535363536353637353241333139323139423944354530304434303638344637354541384231373231314636314638303641463241313241394334394144443543333242334444363534414330463645433230454445423141363531323534363332413942383339383841314142384132333437423337414631363938343045393935394538324543393835443837343645333142413139394232303242324233393030413237353637373437303334303531443332423338353935423931334138463436384341363539324434443931423936413642373039433136313137303042434638344544433544443237414141424644414436413933463439383141453032423930383336353038423235324245333339333641423032334439333836334143313539453838453346364333323634304637304438423035363543423245343332423641373944383042464246453145454242414139464137464142333344373642334137464646444130303038303130323032303633463032424339444536343435413435384335353231384437423636423639333630393931333641433234373542384330433043304331464335344136423746464644413030303830313033303230363346303241323730383142443530374538364131424331454641373530464243423230373331443642394431454435313845363231313445373231393433364336453832324437393230373431444336363943384541314437323633353130414138334538374430394636354436344345343939323945444646303046464441303030383031303130313036334630324146323133463936443630444431393138394136373244393331303537413634314636393541454445304331413141354130373245373941333335393942373445323933453944363541444434344139363946333541313538444143344545383531413134434435374343463444443444363641354144324536413446333438354332353141303232383744334539334343353535333544343141444343303139324435353946313038344138383636384532364137423735344541323646343639423534344445413237313442434439343345394643443341344235333433414434364535363936363439413334443438463038413042414137354142414131344434364132413238393036373937313130333743304638314530394543423330383543463530303245363433374543383945363839303330433041343931374441423244444430423345353137344546394636363641393431313938354233393437463641393635423239343439353432383138303846413341393533413135363942373533344435454643414444453336343034344434453941413230394634394333423539334545324236343532414445364445363134444538414230333531363931363636333243323644323834413439363235333132353144424536354138374535413341354141433743313443373937353141393633443244333532343731444531303033443935353243433834374342313843453145353738384245453832423332423346363835383631313844423932443545453342363244313143313743344537363643333144343946304144413045313637453845383739333533363936394139424136413743453146453135333941394431464533323236374242374636454333304334304530414443424246313843463442343935344343354144393043413338413930354445453946463030323833324433423334424444323142464134393846393934354430364436353233423244313139374438433434314539393339393739453942413934373142443541343746343243394136363535364636463532444341394242363946443742413141394432303732303643434435304441434543444343454337313236323638363632313931374536443635313336413642454346374239423934364638463932423941373841394539443346464430384343374638343437313641374133353046333335303539314645363643434430374141454635394244393737363236373132454332363835374139344246303331313034364233344539353941463135393345354434463132413234374334343232453839454135343636453741373531373930454339383343354541384142353145374435324134414136333339343731463035353445343746444631364631373743354632464231363939343539433530374144353032384637303546313931333836383842393632413336323138343534443036383941353937464243443538464641464530344638434641413134363542313445363134433939384344454631394633333737393842344335414531333743363544343535343731313845463536333143314138413934453744463034453837434331354645313738413941394435323030384344393535423334433136433235314635324636424244414230343644313239433334353844333142323345363243363230433745373138423641393330373241313342323038413437413633424132364544333236303435343641354644453641394641334134314631313143444531313441394633334346334435364335394344453631393831303142303244423630434142313132443936343438454131383046343437453742374136323435393836433945333035413935353034414445413643333133354346444639344345334342464342454144343645393036324543393737313430303330313245433646423137464439313145354641373645354433323141443233463137463934334541353835413031433832304244343742344632414530303736424436413637333535304236413243454336454642363341363242363339413443323545424236324633344443364338393536353135303644423843373936364144344439333242453942413034424337423142463432434341423939433046393642444631413441414637353744324232323943333341354132313334453943414138333334413046364144343542353645413934463036354439313541424539324137353539344635363936323742443043363737453342373842424533324634363838393630434231353138304338414132373635434136373743373445414438454243324542313938333443364438364531334538454442413245464230413245303444413631313638384532423042334642444533314136333245324135353738354244374637343445413545343046423132383339353841383731433532333743333734393044343238423939383042453044344138383935453736334144363133333637374446363435334135343638374432413443423536343542393845313830383046393436373145444442303534353542304445323432324134443831413836353238324235453932443439354639383542314635334133314638453846463030383435413244433632453843413743334543363741433732414237453532314246374333464330343338463038423034394146353344463139324141434236314330454538344344434239383636394543383334414138333235364237424334304132453636383438393337433244303639443442303839433244414330333139333635424534364638303843393933323543413430394338444133333745463835303133323935453636394345374438363332423542423231384535463938413338344533313342393542303832433243303730313037324641344330413445323634353831423634333533333741393934363637333934364343363034393034463639423632364537333038363433373330323046384335364632434435394339354139423131343242394241434442304634373531343833343846313233303831463436364437333235413243373144383138464446304146354634454634333535413431393642303731434341333130373138463246443431333343463437324236463130393946344432443632383041364238364230463834334144354432443544354239453541373443374541363045393745394436394433333632393743443531383644434143313631373442344634373444304143423345423239413933393934354439373139454438424241343832433041364437463143323241324532433834353837463639383639433033453938373037303343334242303831424130434630384344423246383643383537333338393344393346354636303344393234433246333033353831374534443639344141304637383545304330344139434539373133374341313634363630333046444231353238414437374539353336324130304438304337464634373936363937353843443633334244323535363937453234393437313739303241394638324244363146454538454144304632353239353435434446353135374436323731433345353541374233393442413941394644363443363531353035303446373639303039464232333335343632363139383238303136463236314132343739344334433733324332434630313132383641323345353843373643333634453234343934444637433442314442443833444541383732324641323730434537443831333837463245463333413241444131414542323641413237333539453331393639353531354538314533443336413035413139344545383946373542303542333039423435463136443746463030343938464346364645353845303636364630393436433835413639363933454145463835413632434136324339453342453141333841354533443936354431433346373431434443443843334645324533444430444542384232313333374244433142453436324146353543383443413733364546343432444233453046424343303135324335394643383645464334343139364342363338343133424532433533454138423945334442384239453345373246303633313545354639393242374630463637464644413030303830313031303330313346323137313442353146423344344336373332364342454631423833343532343135393033413041423239424444324233353642333545373730453345313038354138423445443436414643343334383037393836464437394538423935353535424439324639384242413733453241414139374443314635314534333337423437463132443944334142343043333131414246424135313343343736384538303631304146383345364537393932314636393936424239373141363936334434343930333844414341313639463438313643414536443446463236303939344430453335303441383633384142334430434532424139363430313935463633343435384134423341383731363134374341414233444331443637313531353842454633303436393830353436304541343636313935433136384332344139303541393233363831353142434438463242313533353538424638383546443046353833343741424341313733374332463938363037383541464245303436413038433342413537384232354643434135414142363937433437434143424235433736373730443143434338383442334538373433434536313630444443443436433936334443413042364337393346333044464437453639453446463942394538353139433746373334304530463834344232373332434536373636384536353533443243443535463431333443413832334632353241374332323537423833333434443333374543323237343046464534343930303641394630313246344331453739393544303136314339464335343234384142434134453930303046304436374645323631313138423635434433454445384537423637453733323541423442323843433344373744333033413441353030323936323642433835454333303439444133323937353931463142454632383744443741424532463446414342433139364437324630414532363737343934444343303944454337444331393538413330343544453042453544463330434233453330373035363141444544454339373033413937304330453635354430443042303936363642463232353633353735444646353037453345304533463436384446373333393332463141464143454342353345354531384242333443314346353733394343303744414246443938334541333135364641423330464430444443433446444146323245364437323446323738413844334331374132323934414144444541303930334338364139463043443935314434353542353843313537463332383038463038374443413833353634373734344430374337313336463635394330333935374343323833393635454538424630334631333046453431324230363545353232323935464132413934463046434233453844354239454636313333433533343843433430393635414233303144423332313945314243453545304537444541313636423339453535423437423632393246433636363541303339363238384437343632374542423635383234423630334643413541354131434545363442453230423336373037434132463130413732314536333737364444413743343434363737463236324433433137303844413239344243464235464530393535433733443145443235423245393735393635463438343139343833343541433346363433413736303843353530363836323430444435433536303132443135453341423244374344454243344430303935313444443535443230343433363335363733394532353446343146463030463139374246344145453838464430384342443937343131443233464233463832373238333733304238393630374430354238414434453734453044324630354638434342344635454443384437453641424536353334454441434141354232434146393937344443333842393936433644343130453944313834344444434533383232423732364331364244393838323132413237303433303545443037334334304132343131373638303036374238374244303334313242393039344230354341333431313630374437324538394243453632393143333439463638414633464137413845374434333541443431423638454537324136394535383733384437373636383034443430434537383441414233453932433242434335303734353943343035303042354330313031384137433138303734443645334135343443383030453433364537413937393037343536373144423146444141313931323638324444354231413230303742333634464245364135333330453834434146363030374536303336453136353743374234423433463030323046313735303136324436334341373730323338313631433742433646354632334644433535443232424231443332434532314443303936353234424533334630323039394244343342374644344245364345394534453446393145343939333942393243383736413633463145453436353939353234423239424237363742393245313439454341423345463443323045443837414231453344434136333031343235464137383031454534424139373538393444303332464544383935304643453732364437314133453344323038383136384236324636393241303945324536344441443146344344373938323337413739424535433633313134383542373243303243424535384538343638444346324333374334434536424446394145374536324435304241453446454135463938354244384233444535333544344531354537434331313745394430413834453544374436344330464346373136433131354336344537464438313745414331383137384234453746463030353243453038383135414344344637304343393138383246334442463233463639364244384533323336423544423333304532424543314441353846383936384536393846463030303232393338313145373531443335344239313831344431434246333339454539323137303732463435454245443242424539363836434444313646443242433443354345334630344545354437424135443336414646374233313630463035374445353538463730384131363832414637393541433533353132374331413635313533344534393637323138453941393739383046393043374530444544303041424130423537303036423041443237384243394533384532324436384344463230324645423245393833454432384141373039314635373137423546323331363735394430464431373238344532393938414534443932353332414242303233444531464441354142314335353242453234444143383544423641423045383133363337384431453633333439443745303939303342464337393934363537463730454136323333303036424331313034333937334544323938443833374535453643383330313232344331374332363139393146374336463137333031353544333743443933463431393832313442443334373730323734383831343441354243304632363444434236414536413944393943324344333035304530423537393330433635354235413046334633313645353544393946454137333133433132464442464630304238303332424335383146393943434146323632333432373244453943414636394239334546393045443739394336444533463034443335463043323533374333333337324539353332424635343745363034453035374444433339394441454139333644334532373244354642303743354335443934423235453339363934303238443043463843304343463131323739394541374546383945433536463834353345443432334334464337464139374646394246423945444642363245304246343843434133393141463845363642443535333945464637444343444346464644413030303830313032303330313346323134434341334431363030384538413938353844454534413442463545443733303832344332313530424641373544343231423939373731334431343935303444343433313332433130374541433635463431383233353139343934434544303935324246353537413733464132423632463846343538463031303832313043374643383232434236313141434235383943413334333438384345344130363839423141343645444538464343463338354135464538423233323436453541344335384331304137413234384444423135463439423234313333313943453838424530463435413441323739434143344335453344333839323241384534383337343436413336364342463730373046343841443738343235343935314634413935454242454243393938343046413638303945393541383531453831313245443133364638383237464330374436303943354634304634323033364634424342383441393632324645413744343031383830353545413338464132304138313146343146343130383043433535343542324135463732434346414236394538314538463539393634353442453131314146343241353636413235343344373039373241323543323932393239303631373732444443313235464137364136413634343746383838343332374135393137413337413236443938363938463445374433393846414230363546413235424334363945443045304330393636433333463644383146464139443032333743344341354335364131453834363543323331323535374131323937413230414145323544423231373831394545393744413034363642313032374538384641313339464430433441343736344632393545393534353444374131443145394646464441303030383031303330333031334632314335453937303830344637394536354646383430373133313233313330433536354233443638363636353945393239413641303733303745383344313145384246353245353045353845453542314233453230353531424633313931364446354442443038423145383441383435344139353146463944394641323044434139354538413935453834313133464532393134454135343643423838364437464231453239343834303331463439453431313536423731454245383542463435343142313138343636443035333832333332413045373030383734434137363445303231304542373244364442393541383434313935453235413545313045444634454337413133304335433741334436443445314130374334353938324439333732343332453532393235374138433230463430383146443131344139303141323531453841363733393938383137353142433137443335304634323546454136333935423244434535303741443038353438434434413737313537333431323542323131374538374130433344313731373130433632443643434333433943364644453131443131363344314634343939343933363944433035344232373834414630434246343137393732453543443437413437443744394443423437443143394539324432463631324533443044454133373043363244463331323531313543424634354244353539303030393735393937413743443336314136363043453342384643303431423232414631314644413736393931363331353042363232323546304538383331383444344443443230374135344139353035454432304239323545444443303441363637453533323639424544323630444642363544303634354346424341384132353833393343343233303633453937303344343741334237453132453730433635304343343934344133383945323936454531303536343537463437383938384333374539393834333136393341433530324434354631324643344246313246433442363243364635314239464646444130303043303330313030303231313033313130303030313030394343453845334633303744314530324434303345304543383546464433383942323034393238313146454137343742363030303030303041303441444641343541373430313242413835374630443638334342384241363845464343354431353234313246433931443533453741304543434446394336363631304232394233463932453646303831433545394432464330343442354544323435313145374238373243393833434131424246334132353844373735353034303738383044343937433635453639433333313438364331463533424245454337413937374444343137353646464644413030303830313031303330313346313041463342414332424343343042434238344342434537443437304232354144383031414132333543433843364235414136353541384434393636444344303130323433334431304633333332453733383135324134324434424242304138434233433530434432414532454433453233363836363735433430364342413144363935303136363037453837363346343937463446344243333137443439433335424234433133324632413942343136363934413937313446353545463841444441413530453233423838303534414530313938324530304246314645393636364143343643373536343333363034324234463443413844463236344430324232443343314434364143354338344330423735343032383330363344453241443235364338433041423333444545453336423841344330353434324141324334364341424343373142413241383734353830303338304443414431343239343538394435344136433944423734433734443242383731383339303842463941413042363243394337303642334139374343453042323544354430314344313033344341383735373732443444384436344134313836423743354538334144434544354137374135363338374139434646344246363132313536423934323232343239343045383045303043313039434646303033314634413041303142363042453535303739363231313641364543333844443338343831324545354636323437353139393137383432364533313138433141434237443546333531313646323042364433393342384341364144363130344331333537353446383831344237323533383931423241383133384242393933303532454333364636364245463145353035324138424432354430323242353735393333304342303033393238454637413742343634384446304131344234444435393844454131413235344146443135453935444641324330393030304239383331354541364634443235364139373642374343353930373434373831383538394435353931374241364331343131303143324534463739343331303543373139433245393539353833413237363835343037323045393132373633314233434139313545443337343045313542453933303636304341343030303441303338443933304239414433314133433234303843413135383545303032453239324544423345373843313246344339413445394341353338334646313443303045343243353838324143354145434236383845353639453936354144303141434245433531343433394437383145434531314134374445323743333039313930443633333431344438413236333841323837463244453944333933424436353338393141454544313542463639424538384631344338383341423941453139334646303036364135393438444638433731333238313938414332324634463243413831303845333043363432384441333442364431373345433438393433393544364330353634324438433733303134453043353539313635413635414331333833324541433341383739303441423330463232343230453538353534323342343239354638413834384244383531314635393635354445334436414233354130304241454145303438343736353631363342354643354341363144363231354238323836463943453839344642394233393236313333463133304541413242433137463145453230303741334234343242324437334234343330333432323844373336303335463134364437353730343435383735343241424530333332424533324632383733343835423135424645344442444436463846393841353941453031454142443934453741383244334538354339344336373546413434443845343243414539373033393338384244463944333245393731363235304639374238353032453932384130373430394442463036363230453545334531344533414644444343394234394643373044373939393544303835363046363844344139463733463442414346383831353636443841393342433935304441303734443946393835353037453038464343333542383035384131433637354437353033413131443635313239423541363538463730304144424243423938443731433130424545434430303938453833463630303339383735343231303435314435423635313034374130303231443046454533433036363231453130354332364543444435394330443133304345424530373941424339414636383538344331443130303146363332453931313735424439343241313837314245343935363245333842384135323533433337324236343233303835354330393535333144343230383933413134304132414431303735364341433545303646353536444643344237333538323535343443434632433131413733413839344442303937413341423641323841424241453233383733324532393935344232454133374337433637463838383830453137383331374346303130423631344132393730314241453642463131433139413637443343383141314141443136434330303532443042374345444442303536434143313743354133313742304235423330333142344343303139333843434232384133383731324136374638303030303532423438384337433834303630463739344342453946333242423538354144423343443538304537364332314238453139433245463345463732433730434532323534454639433838444135353039304145333043343338434334414536333041373333343843344132364442304437313543453431364135353036344130363536363943393033433232303338374230303041454633364537453232324131423735344342353944353742343434414335384339353246303038343730443941423330453632333036314136423934413139333831333033363033333343304136353430453644343432384143363844343237384236443431343139303833363644364145323731344630443030444230354332393544434234303135334338353539313933444136313245434135304341414635353035353845453231463131314144304130443233433332433134433733313338304630353846324234463736383939423333313942324131303343413144423733343433323041304444313938443936383832303638444234353239424232384138374635363241354144343241373337433043434136383045423941374630313633463144433735313934414642423146333532453131433842423637444541323932374431354141453030323346413036363033313134303333413636314131323934323139413131383041434530454145434233383243313832444133453131463231353739303537333330364543434533413232334536363139333544453139424534383236444636364430383839433337413039304232443431433031353442363939433537444530414139353741424131443344433633433944383235303334384535433342334534454132454246374230343243334137314546324543353237344442334545334544304136434431434130443631374439464434303441343644304434333235313032313232333541443937373444374133394446424435383936453246393146313636334541393834414235343831463038434445344345323343373146453339384531334245344433344336433935303033323431373344393630303031354546343536443246323932444333353335363135364142303146303235463531333538454345383937423134304634433531443330323634323641313638393445334239343931303244394130414341384639353531433038354546303031323634414130313141303733394241423934393132303133314541324538333642354334423541304332443434454632444235434343443346394239373842393039373845453343423634353943383533313444463339393832324341303035453541424245363339454635444536313444453238323236423042313444323843383434423432323546313036454232383039393238303339414438383545353030434130434536444337443044433030373131324534303443414245323645313632433937313330373338333543353433454338384636383546363636363845314531353246423030344145313739433539324530333233413835353833344444363832334433324638384345383530303030353338313145463731313430353442443833434238363931303336453735303935394539303931313139373637333734414133353533393339334230333241324232453246373830383732373831383143344136313841363446353738433239323834313538414531383642343244443339343135374634343843324545323030444531314236443532384435453246303437313642333435414436393139393543463732423036343943463832343135324533353746384131413638423330443630453146364545303141313245424339363046423744453731363546343934354541353430333832463236334445303932324137333035313330463646463730424138323033384145343545343239333131333933303134464433334632343435373232443945434134353234353131453935444134324445343042333839353043353841303134434430413342333541364142433134464139333534333431443842423730433441383830313243313435303431413037333039373030384131303833363831413635423338453936434432414246353845334243304436324638304346413431423941303642373032314241353832444142323432453035453539433433363330333939384439353545433832444342303244413243324436463739434334333043353338383442384342343442433937413835433944353445303344423841374536424638383737443042313336424246383339323530393531314534443142373842394243434231394337323645413535363834443638453135433838433244353532443439343645444246424541454530423035424645443433354139394131394539463838413834323532373632333738413734343530313732413631373532423531454537464536343034364333424330393432454135353933383031313831353642443332423339413034393535353646364441443143373144363231323635423430324244434141424536333738394431334544354643413030424633323046443645353743384638353546373837433035414233384546333637454431344534314439354639393842443341303833394139433042353831443930414336353130424336353645414138443442463333344339354633333946413442414239374643323142423938394446324445444345423331453141463546374542373334333732463337314631354435343739394234433242343642423645414130324430363732383330354531313739424541303644353744424643343238423442363137444544374445464343333632323842363431313136333036373034313242343136323936333131433539313037344439463039443442363933364234373245323332353337423544373744434236313137393138424533363946373936313839433244313542363145434341454443333231434231443246463030363235333544323539424644303944434446424141414234423938373843333046313738394439373737384637394646444130303038303130323033303133463130343431443039423233353535363236303541304546393844434533463645453134364633363541424236313037343643374633303443433345384634433239383738313445433430443137423937384631323935383333303043423132453933323632353844413546334538454133383141343337333030454332353943313030313839364445323030313539444337413241433235303443323042373530333530443437313144433935363531324136374346413439303939384133373241333131423635333233463431353241323543304139453545383533343837414141323639393435344530374337444339443746433444393233453232373532434334434431434532384637383746433438424532354234383834433432433336433630313333344636464636334439353745353843333643323639383236313434333142453432393846324337304341453346374546323939453145374638373333313641324135393932353746343235423630393832304234423344313137453735443441393442394343464532313032354344444233303030434443353445334246374634363645383841463131433730464243394643313046323938323633453630423631393433304445434334454334463043413738333333343034463032344239423633303635444244343437334536334135453930333243423342313431393432353742433545394343354139374532333638424330463243313638424138393042393942433432333039344343344334433236323042353238323730323241384145363543314434414444453230393030383242373638343439353533324343463237324133373837453843423645444130303430433444413534413839313242443330323043443931313938434136323244354642344131323334313645453030383135314433373135304439303331343441423938323435313744464237393934443541443843453731393632323235334539344435433733383935453941383044354341433639313145343334434546363635373637414331353331433741303845413239393245353038313533363343384631303233354138443043343444443042463432373438463834343534433442383245453145323045434538384245443636304136413739373532383037434630433731413430393734423935303534443645363233383141443130413432313535314135343631363641363031323031313133323844323931344545333943333034424439314333304435354530374638394231374342464239393238353632354534353733354638383033353938334338423032453132424445353236424535323244423341334145363039383331344442434641353534323543413038314634463433334334333839363130383342394438323836353339464332353146353139344238313846453330353435374644323337363744453831464630304141363034413145303841353642314238343044424631314439313245354239383446393936414138373331323334344337303641333443434237303843393733373143364434433331413032324343424243433231344632383037304446413234383641323633414141464143443344364437394634423731333335424542443141453635354137384331343737353136323639433346424343303534313645353935444246333045343746333343394639383736464536323537303946373837324535464337413746464441303030383031303330333031334631303243323333313641313146304332343538414539453534314530373936353444303844303535334246413637414631323842344132384332353141374233433341424336373238453334393446433741453031443330314130453634373143443343373838394234443542314530393731393431453631324145353234423430313841393532303838323841384136333341304138373635444533433931363033373438424638434237303535453841323830374439374445364432344237443731313044343137303141394245363234333041393545383046443043364337464345463542413846413232434337333631334344323533423837393432333038333131343035453632314646313746323441383131343330323334354342464331434345393746374641333434363732414633464534364632303441323444463741304230363142463738324541423933353044304233444638393531353931303044363232354337453831334132364642313144313046393746383937454442444337373546313338363244314443343941464446383341334441353937314238424330324336454338373937373538323332393141323044423135303041374133364431364341384245394239453332373132413737323635314342303031383941433733383133314431324130414232463330343346323832453044464234443330393634413233463530443639463438353638314237413235414531303837354538424332423342453234314238413839373046383630384536373730323837434637304334424138303044323544353932323037383939303843343543304643454131433442423334463435304133303643383135313543313937353143413845363030444632323443413043414533444131363238433733333139314338353545313841314631314646443131314643304337424630433334443132394645464536323637313031303938343142363731343133364634393042384339363139463138374334444338363033393230353632354132344237324443424238343733353239303231424241454132374242354637454131363035304536323935454642393733393934373241413541464242333638333231304232313837413132313938333431424144433132463338464143444139334538334642393642423343414439453439374142303841424343303845434138313737314642423936343435444138414232414236344238313535383046324144303743434536323538383130334435434237373031353941383538444342433731393635353833333034413942333346343831363534343239444639393742433235333146353942373943304646303032344341453046394346423433354142393838323943423838363330383342363631383337354436323642463144334334343635343732454135323143343437323545334546324332304136304334373239423443433442393246343741363131453930383037364645383843414234463543333031324141313439303332453033374146433446423041323446413333303841394535323142413145443845434146394146433435453842373932464536314130434535343432424535383538383830373332414333333338333533303245373232354146334138443234364146383842353037353030454244423838363032384439333944313035353845323232433534373032414643434630374542303730303845453536324437303941443838464431423938383037413138453737313342434144314434413642313837353842324138413939384543454145363137434445343938423436323731373146463030463532464330464237463731374433454134354634464139304530323237303537433232463937464233464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(2, 'Condiments', 'Sweet and savory sauces, relishes, spreads, and seasonings', 0x46464438464645303030313034413436343934363030303130323030303036343030363430303030464645433030313134343735363336423739303030313030303430303030303034433030303046464545303032363431363436463632363530303634433030303030303030313033303031353034303330363041304430303030304144413030303031344546303030303230324330303030324634384646444230303834303030333032303230323032303230333032303230333034303330323033303430353034303330333034303530363035303530353035303530363038303630373036303630373036303830383039303930413039303930383043304330433043304330433044304430443044304430463046304630463046304630463046304630463031303330333033303630363036304230383038304231313044304230443131313430463046304630463134313130463046304630463046313131313046304630463046304630463131304630463046304630463046304630463046304630463046304630463046304630463046304630463046304630463046304630463046304646464332303031313038303036453030414630333031313130303032313130313033313130314646433430304532303030303031303530313031303130303030303030303030303030303030303030303035303330343036303730383032303130303031303030323033303130313031303030303030303030303030303030303030303030323033303030313034303530363037313030303031303430323031303330343032303230323032303330303030303030303031303030323033303431313035313031323133303632303231333131343431303733303233333231353232323533333234313731313030303230313032303430343033303330393035303830333030303030303030303130323033303031313231333131323034343135313232313336313731333239313432303531303831413142314331353237323233313432304531463133333234463044313632383242324332343331353533333430363132303030323031303230353035303030303030303030303030303030303030303034303131303130303231313032303330363032323530333135313032313231333031303030333030303230323031303330353031303130313030303030303030303130303131323133313431313035313631373138313931323046304131423143314431453146314646444130303043303330313030303231313033313130303030303137334332463442374237353738393538384137324631383136353130443638463335343634323243313635383230464242364337353237343930323638383536434431363446363945354244333234423733414231373034333332454137333243434545463042313837313344333642434543373944433736323735443841354438354233373533383544313139314441454342443542373534313741323839414544373934303041354436433631364633354541313836374430423144324437353736464138463238354634453743463743354634333737373537383938353638363332443541333531434435393635443338304232434142373233374543314545413833314441463733443242424133353542424632314542423935394637373532324538363142373744323739414641344346334335463433363937343739353842454633333430413434413939333237373232423735323343423146414339454435333136433441354235423844344536414331443930424632444541313141384244443543354541334342433946364532464134434435433446343436314538383437343738393438384332463945433436384237323333383231334538423245414130314136464539303841363038374430453835423833333646414646303043434641343441343231424232444533453946434137443733453933333346313744313431454341453245393732363835393841303237343839433530363132353433433136343333394230443041314535364538344136373845444136423745424536303831433342394331333343313633393641384345424537334337363743393543324634443541363930373244304437304443313441363945374431313242453544424530384339393536413733394430324441394536313738423932373631364244364437314344454344343743394636323046323734394235433038453532434434353938444535363641453946323138333135434444354145304242444132434142463243333939394133453242364435324239414138444145334533393645393135463643393144453737374539354633334634323537314231303735423934353743333141364134433546373637414546443037384234353831433130373036313646324135423842384632354241423132353030394242333232433442353136433133314634324337333444303545344245413143384442343744324533354444344538363138433042463641413333454442433035343741363930363037313633453544344234304144323544344245353133393545384443363035393544324446363531453532354339463444353845334634444534303644413037443131363741313645353644323138344535314343303937374237463944363630373138333744374434334339353742343544383542413133324235304641344337353133343137453845443543373839463942464130433343463733373335414330343137363635323939444643434139323631443039383944423545413345363139394144443134373846443242434241464135464235303830394538334344323536313430313644384241354432374538373344413732334438353741424543384437413744413046303839313335424634363832393939413433333935383945384245364639443042343043363537333037393239434338393130453833434632453042434346443838313038443534343233373842364142343331324138334530464430413246443443384535364446324532353630353332453835413843424533423533424245303642413845343043333832413434413942333035343231443635383836363341423945363735373335384146344536314337444341433334353641453746323642464633444634314146394242394435324438313333423235393343394135433544334434333746464644413030303830313031303030313035303238364530393046384434334441443537394336443736353736363233414446374132384542314233414531303433464630304145433838343536364442424542443544384543364435353142353939393532433537344544423538423933433937453036353646413935373546304543353933334131464434423633333441343837423332333632303130364130303246314141374437363533454135444434433541443638384635444642303645343833433938334330353235443941373436444145393844434436383945394438414232344634453641363736414344413543393436424145374641453936443435353636424435363934324541423642354642313845433434444644353046384446423244394537464438423732313635304341443535344641353435354438354232384132463037353745343045374342424432434645434637373133443044373332394443384138454237413144333746423737343930333543353838433936413834434542383638434231344446363142343142363544354636333235454239354246344544344539413936363636434233374643313630324430443546423737463839413435453246363435414435454432313331364441343744373835334131313143353043324637343544463944443536384342363141464439423634384343333343324444343535413741463945303634373844363433334435383630414237453531324543413338363341374533443535424136463034393633383839324333443243363631424533443437453944314532344638463141444138443736443346363737384546443344434239453542324245434333333433354439304244303331333434413939364636353733353632343331423632373644423531323538424232343639463637424539394137443843423146364134393946313331443237383933424239384643454145393337363337463937394636444235393638384643363336443446434437433746434233433641434638453541453936333632454243303835444441374337333139314639383230413137323144384241394335423644384344354538343135363532364234373343443035364438364243373845453936434546333739334433373746414636373846454245424145453639324241364545413834303939424641304535304442414436333842373742413142374545334136373638423636454435364332304246343736443533433937463537354338434438383243353339413944353932373743333533454435433941423836443944364543363945414635443645443438364443434341423334353744414439314441314437454646433944363833343134464337413845444237353144303636433343414534374239464232444335383737464442424343464233444135333744364632383742314435374344314336394344364543344331313242433437374644324141354639363235363544413944424336454644374445334136353933463538444538443746463336444434353542363945324642324433434232434235413644373437414242314230393334424641433544363231443635374436443241374244463230384235433237423645423933363141433746354233424543333233433332434230413833423536313541443346443544383145373234314631464630303241454135313539304634314539393333463244423332423533333641453641454636383333364643413242443730454439454333374637373737373139413544343433363236423446393542303836374439374332343438454543423236454539464239314634343434334430363335443546433833343632343844454432443343454233433841463642443531463242443744393531444538394531393731413433414533303242444237383631353646374431424346454241363439364545463937444537434642323639454342363639383341394239434335343834344337393836433534344436464630303636414536393930354236414531454444433431463542363545393841433444304138423637423437424645393739303441363544314446344438323538314646414343384641444534453431444333434646364236353330434533324638453330314233344136334234443335314644373033354444453032343634423744424442383743393037464441363136313631363136313533413533444642314133463137413541453634393446323243443330443537414143373233374635444342463542363145363730343934463731463635443242394344304636343732373644434539344136343944433845413131444138363739393838334641363144383541434337423033463645444636303245433245434145443232313738374539334539353538364245313141423231364441413932453337444230313043444138444431413142364632364133303643423539373541453633314145454433354232443736323733324139364437454439363534393232363533313330363246423646454345464446374342304636313145434146454234374135333935344544394237414146463030433931374639304638423944424543463937383831463344374545373546454246393336453735354244363642354236464630304233323038373538374241373642414133374141323938443445414344383045464539313237464644413030303830313032303030313035303235313846363733423836394341304545303934313637303332313734324337424136413039444633434436364630353337453331433734414539453345353134373138364237444241393745374632443430374243424645354343344443304530374336374431454338414337303541383043413233383646304646303039453242423732373938434642323042323839453143394135374535433438343745344132394141353736314243433043433045304138434531313538353834373830424137444436343135443242304241433731323742423338383539393345383039413536333932423038323642383634423533384630373143334442454344414544304241393831374438364131363541394146303739363845303342393733393637443831463637333332343730443544314334443345313139313735383544443039413141353734313432363732304445343835393431454244393734383435413841314632423038313532434638344632344146433631313641453832394334423533363743384634313145394542354436313139313339443935333143333634303831463732434341433742393641453834453539463730353046343146353135313743443937363544463238333744463039454244384631324237383730344446453045413544433434413831334246433832453945304643333744393735323931333933393337443539353945304132413032413636464643433337314331304230383834463038384530413045354434424139373532434630344631443238423530303942454341444335443432333737313834303934453446303732343245444133454236413143334433353339343641343044454135463846363435304341334630313746464441303030383031303330303031303530324332393846424631384645333346304446384536434242443930323944463237463937463131374638463332424232353034454639334542314542363045364333463033383041363145453746393633364535464343454643394536353645343746323631333045314643344346433046344339314641463145393632363342444642454537324544343835374432373934363842443341323730453446304638424435394634393241423534454235314433303137363030354442354430423030413744303645344641304237323843324241304641433835353239393741384533304431433930383835443346433338343632354441323834323941433044353536334542373831384635313546394635363344323141414346433641453243333338324230424533443033463837303832304144414136334641423930374443414331453437413331454130383242343344423541464343343841363935393539344333433830423042304230423042314339373245454136334638373742384437434644304637324341434630443039424342374436353342383846453446433335344638353531434645393343314341364641334646464441303030383031303230323036334630323131383532303344383242333241423835374431354234323733323032343637303346314430464644413030303830313033303230363346303231313035314235444435423045463835433736303538333738323137453835384146354539384243384643453334334646464441303030383031303130313036334630324433383639333438464630304639383939334543464232423731463030443834333145383839353043414545373136304332463937324134393634323143464134433739353838463736393532333844443633393044463531463441394341433339443234454232383344434239303844443244363134383030363539383844344535443836393646433338353433424136383842433744414232323730324142374238313645354544413839363439433431333734454136323045383232443836373937324336424234453632344445433741383435413138423642353144354435433035413842323436343441354332333142383344363837353641314636363737413332434642393132383137343537363535384630374635373241374438433330393331433732363944423636373533353836323046334337324132463335444532444332343839313445303143463045393631433138314138463030383030463435463536414434373342384144444543384642384330443343343733343632424543333641423043303536373539443345454346413633434246313337433938423737323231384143424342433141423643413332313041374641364237324430423935364241393035344438453042364135444434383533423937424438363637433444373730334143363739374243303730313745353441323434353931393643304339434330413837423642444445453630363345324236333641464432364339424239413331393633424442414336323734314537453538443433334544353342454330414239424635303330444644454642373931313542454445374539383436453833353446304545303336303843373142313146443844373746423036363839413335423642303044463541454142314432343131383742323932354441343546393532343834343435303733433734453737433343364144424435393534413338363845344231343331363934323936463636353546413644323944394444433941353334393336384137303341314144394635363233443934423031373236323530314133303744333830453137414638393038304445313131413639463644364545433046463030334534464635314145333646393330323646353143324446434346353439463838464338363333453936354235343245333245433846413136423737423944454230393346333942413134453341343634334332383230303436303246374135354245313746363545414431453431414441423944314445323539373645434543424437383741373841394145463839453244413446303044373043414441463433333033393531443843333241343542363930394538423035423641453643324437423744353541343442323138453333413530323132343343344341353431314645364333453741314234444343383839323436383136344442454130344141453541373243454336383446314445333536303742383041453031424433373242433642423533433932313442354631463438323444433635354243444234364141333544424639384245393631383846313036433730333531333441434241453137393232444333413142384246414638373046423642453235463130323243384632323434383746303042394641454134393842304243384335424441364635454131454441434645394135323731384131454136463942323146324532373141454339463534343441314632333838414443433643353537373131344345384538433338414231313436463135453436423639353343364533334131334334453146413431334530373935313938464632373233374636443745394134454144423843363233364634393143413932313539434334393742413033453932444341424238444236384430344333313535424442434634393032393946373041344636464632363434453344423642333242304244364542373039323031333243374443314238393331364643444434393930463246413641364441454533463337373533433544433841444139414536323736313844464432364336423737423635324437394133443530323931413744334541324243454443324135444537373032324339464343373531454133433037334134393742363632394535364241444244304342393932333945333530324337383442333435414443464638453646454542443538433841433142313535423046373738353545463039423631413644384632453735374243373837383745464130434541413236394241394234384531454546443146423032323934444130444346343133433942444441344638453232393342304446363133363946373636303346444333454441304336454431383338364143373031433239384139443243433444443046384632414431333345384239433039433835333243373233314430343035323344323431333939413534384433353641313835443738394131313444373342343832434141443746423343413946363544424335433334304441383944303141453436304132463532364337363732443945353041363734383733463233373135444136423342333245383234444145453033363443303631453535423639354530454443313141353845393031334633383742443844314444363935353532313944414543303635433835343131424142354442413436413237324246384434363137443442303832333837413444354332433642463734444346304535383531323632303546454635463341343831413230353537414535333836304246424632464439364236363345424139334530394631434542444332413838453533393136423741363431453346364437364237303946393444383644423732413246314341334337454542373331353742444534364342433238413931384441433238333943423931433846394441423438453832463732414337433339353437423344443646334641363636333332433330464146353943333533463935423041464436364434333435463043373530443239354635414630454232374543413946364633424136453232443146463030423043333533433537453443334336383745413941343843323931413634303730443434463333434542463444423332323539433741323537453839333535433844333632364336444345423731423244433243354443444231353344443137433534384435414143303044353541433544413335364335423132303733434542463431423643303135454445414341433338394130464243393443383738383237343846454646303041364246324530343345334130374442343742373045384245373642304145413235364246324134304446323631364246383537364331453945333531454532463638434634433945354345424634374631333435394636443230463742313036394237424646434533464541423646394645393543384545414645313339333744374537344430364532333638423732424541384444344142374345304435463444453334423642453139443144423233313438443645433442374241333844313832314242393037344535364242363535444344463937444336464531423234374232363138324145364244433237324337463835324545413442324242454145463439314145393536423944353642304236353531453936334444443537443036453435423231413641334443454439364337324232384332453338373835304638363644444135454432333735434144383437313237394633463041354441454446413941444639393242363634443637383943413843354233343332434236433543444634383334334236353137454630423635343446374430394642424134384230414433423938464537314337434142354635353936413635324531414431423539384536333043454143453744394632384638364545354231464638353846313146373641453844383732413130464335463639314345424333354138333646323339384133424146383345454237314630464443333239354539363045423633433244323033463544373733453146463134383443453744344346423730303131434143303931463435373443394232393737444144424633434541314135314231453931413445323045354341394236464242444245453635343931424133373037313834394536454339414245433335324339323330373731413041414137344538333742353835364445314638354544413639463641363335423938393039433436323439323246364246443135314342463144393141303843313332313839314241434541333742314642413344424633353245444645313638393145434133463438344342434546433743454234324635344537443239463639463041464436364544434541433735323933443242453030353642384234453846374145333144323739443244423531364245323730344333453741424636454342384541313537314435364530303133384434394237394130423435333632313333354232463838453337413845333845464630304635463334384141353646384438453746423137313831313931413544414643343141443245343932394339424345423046393330363335373537333536393937353046304144364642363838334631464341313746414142344544453232433436343542303135314543384246343438444538354331364434434631384232413245393535413936373636443443373342463042443134363435423245303136414543313742333241463438424446314633313430324138393738324631334537344134464139333142343633343930303043454246324631454131444331434243364532384136334443423641324239384145433543354436453835373246394138434231324442373041333033463742433241434438314644383038344637363031454539434337393141303139424236464630303735463041424139424639353738443633463544313244323035313536384241434633453135423844463442363232313430414245364646303043324246343136443542373835324543413044424138384139323533313930433142344231353338384645443741343043343333333144343335373839464132414343413734414238363635423538383545313935313644363734343836453037303532373838424436413536373933423631383445383330324238363930443531383531363844393539354235394630433346373531444242364132433945394244384446324332423530423938454438443641354341443533343633443337423846394631464441464341393139334338443243333136453143423331423031343434423334383633453641374638353641463542374638423341443332323935364631414446363541423543374635314144434246353833444344323441453536434144343030423539424137434639354233413535443137463737314345393643304130433838354531433838413330313530444443323339463342463835304538323932384232413345333841384637344144323645463643464141323138303838453044364630434546344331393839323834463536314337323631454441364435333632453032303532334445423730313741323046414139424630414645443245443736434241413536464133433444303742373737373237333934464630304237393535414437313536423633354132343145354642414237374231363644344232413037343346383045334635443439423946463030383636353037303032453739443341463439384545303836323330464533343231363241363435333644354334463935314436433235423142324139453242453734413434393632413245333532453545303044333735383536384631304134304434373143414643363843314437363732303733353036464630303544373646343641343542453139393242453134373536424544314634354644353838433537324143373242363335324545333142333143334338363146324537353946433832373735464541453630313946433037303146323543303037434344354446344539413241303241324446413743463835343142463345383433443536453242393146413238364644303737303434383546304336463139313844414242434134303838453746383942393841353733374244443841334442413330453338443136313944423331373337323338394238313436343844383132413744303743333146363141464434414130433246414437334232443144313146413938444330454133373139304231413637454439334336334238303644454330323834383035433042423335424433413733423146314136353638463445443835424238453045374543463937303346324332323633363837423842414346383545413533374535363134424537463233364132303042373141364430444442394333324538323331303730433343324241374433374145444546453242364343314645384535323435443930463836373835314646303041423930334543314631423130373432334533383244463331343030464534314236413636433833354231464132383330303137373642314146373130363443423745334645354133443241433939384537364246413638373539343532434436423042444138313031374232423938463735384643443935364242364139394233384437304433434231434235354141434236364242373533304531354646444130303038303130313033303133463231323232393635373646463030313045464144354245463846453034323738343042353637343338443535463337463639434131434235373641374439433533463939343435303646454431374239433244443432424644303134373632334241444437423835344645374236413333373331454436333937443431393638353639453537424636344145434344313433423531374143323934443935313238433439434446443233443436324530433733443442344544353030303837373134383237313038363034443144413732304430463931373530364641444136463635344138424630343333304437344334423032423645433632414135373535414233394333413332374135353637443643374642393632324435374445464631303242374232413139353738463730394136424637454535433842333446453637453046454643353030314634304544433833433744364536323737463441383635334242303131434136433631313342373945424530453037424238374539384433424543303233383545343044343244323545423744323039333031334236433832433334423338443936373939444138373530394330363543314144353335454432423841304442343946433038334131383430344442384541453845364231433043303135384334383339334538423133343737313734323945323531434330423035384541384546363042323645324434314433394144384635324343423635323133304646353237424535324443303538313837314532454241464630303732334330423539324146423443304539413932423235443437424545313644443843363231334631314332353333463931374631433744424336383632393046433935333535433443463935304139323734373045424443454232413736354136423546453441444144383342383541324236383741324341383139354331423037314432424242343642443434373330384345434642353937464434313135353941413239433230423945373745353238373544314433313044323642453043413934443542343334343934444634354139363546413944453839343541434244414246313430333833423033413333364539323042303136444235393936343634353336353337383430413535433045323732344135423639303839413039384530443346343735324443313731453239374641463136383330453943364343383537444146433346383844393741374141383545303233454246464142464146333531374335434339364445433646463030363138434134424142323342303737303931353635373134354542354542423342393941413234453542314146433432333441354642303946303937423736463138363644384637433331413832443645454142463542463339334535323837314241434135464339373443363835414137393734343633443943373434323638354441343239364544353032384142423845323141333639453330323945343732423739394434373932333732384442383346393737353239313544324544454339303436443744383937363632364346363039363936433745323732304642344442364437454341374441314536383045453334334243454531333143383430443244423537433339393639384344423542414536463345353243353142383846384246423744353743454533303943444344313645424545453744453035363030393843324146423136374234383746303435313541464335463638313335453534423338324641374535383333393544323531303535464245313239433443363436304236454537443232453234303046384231413341394141304538433036434330333441303739324639364536424641343336394344374433424233353232304241313332423930363446374437423936463932464234323434433546344441453632353236433230444231373832384234333935464245344234343043333542324437323646353239383242344133333541334135364534313441433532463835464346443038333034444538393545383545303543424342343736383545394542384238434241454544453837384133363936323030313437314536413836353644324132363743334639383135454131353244334641434645314539393632353745313434374543374534463635394231323744353035453446374545453046423030334437423830304336414435393837354339353730394434433743413143413832334634334639383044343931393738333830453544343545463841383235343034453431364339343741453046413943464333454141433030303745454346413543363637313239414442453131413743464532323336343535383433413033323730384133323830433339363331393342364334364236333130423635414433443144423932383238303132363934464339434646423342413738303242463432354337373445383946314345453744383130444435454541373338314632354331414545424131444643373843333639433333423431423637304245424544304638393538374233464433393843364243423134314531463834453933344534383844354544384331434433443037433335443335333041423835304641333146453232423446453839313730353741444546383944424335433532454346443742464243363433453139303730313137354439364638463442413336344142364332433843463234334139453732313836414244353737313134423435423642464138464130464432453231424133373131413743393743353743433044423838343343414133433946344539443442413131454342424442454137443345424439374431373143394243324434414537393641314437303242463037424242444642344431313541393437444344464633453630303439463244393035444333314137344146363943343336364645303230464134453343354537383543424145424331433745313946393833453944374532313837434237323231313142384431424636444137433839303045333041433944323944343633353034453032384142373646444544324234423441354644303035313638423344423341383341453444354133423744313036383744393333433736393233373037433845444641323733413036344238413136424535344136303832314334373238364138384538353733313639333030334241433744394637363646444342424435373937464145443244434233313544303830443046323338373243454432303338444338363035383536333145324241363343443441333539303535323032434441334538364331383044384241424232443042443745443038414241313739433146433345453343363742433841413239413238454239433944434444454542303137463939394334444635313843413237353536314338393043383837353831453833443146453138313136424639394632433331413542454438443830323743444333324246424639353744453536393031423442444244443930463430314130334642313646463030353136343935314341314142354444314545313532303034354635343134374633463131454242324543433744354344463846433443433430433441463242363030363546413143394546463030413831323134343330364346433443423833353731413545304439433143354630343136394130454330384441444141414534324535414444353445314133343036434132413938304642323834463832414233423844444538323545324138463437313941413445303330314442464339343633453038423146303646423444453146423331383635424646463030433046304332433530464230393334434330334336323843413730323946454335364545464331334632363637363231443830393644354643343131463841313434444644343138453243434338464331383844443642463132423235314336413532384235434244424343344430453442353631463442463139353939324636423731463136453543464542324445453534353344373930383934393043333936454331324631364641354536333537374233373335324138433041343145414246383934414536334437314246434531333230463131354335433246343636463833304638363043313838354131463331464434324431344244374143333444323137413934463938334144444545313537463736314242433443333531303337343544354346434433344236423345414441364341304644323737324144443844423946364435343639384245344131344131434441364241374645433632393944373244383945463345414239393432303039423634413841424333464630304338323441353338303546354531323935464534423034344432314443423441333541304633393036323232313942333430454238353342463346314430373933383030333931414536373045434339374242423142324141313545373737374532334641334339424143314642304544334130383244414243453244463038334137463345453145414641324137444538393745424537323037464635343744413838453838393831423530434545413434393430373135463541424135393132463131433438463736463536454646433846384342353730454142394638464446343046323837383036314430363538394546453232454536433243424237423935374446443939343942314542414236464641414233454631434336384631333945353632374645323234303245304433393543453146334437423936363334324331324130454236333638414532353835453835414444313243434639314643304645303844424342313144324337463731314146463030453235333335304545303335423746444446393935383545363744313846413346433630433831313645373430374343313032353039354642393544333331413032394543453346334142334539333435303431313544324237413336303844433943303530453338303732323735393445353230343437423137373044413145434344344534384146363733444333344537423442434530413739304533463941394333313333353232424131354242354639323539353342443532393744343539463930423831384430424130314234414642314439423932454544433832384232393537384638453232333430323031374531354130393836464630304230444631423345463133423946434331443136354130304432354136443537374643343236433730363936414244384337353835393033423339303344413042343539353542373744343341364131304139344235353533423843363642363846443344464532353835354236413842333534313139374338464132334542383238323132313441383943393539453938374235394345353435303243444646453230313437333438414142374241354639354642393630463637453342324146374545463641453146433432303142434638344446354436373330323846423539423141414531363339333744434133344630333043354134394234414342374235443444344643304341464330434533394541434532374646444130303038303130323033303133463231363531313542453339313245434630343443313038324338383833384535384342384636413632324643313246374333374530444336463838303235413541343045344341423045313243463934413045433431433441363238444642464433323834413733434246304635453336324442433545463339393731313542363533433437313139383539444443353736463033464131393937343544343042333934304241393435434137353345363839443235363444363231353836463233443936414639374634313839364137303835413538363238444638413043343735423934364438304541363743344235304442453046443445364537344331304342423632343137314334353744344441373330323631393245384236354344434534413936443530353845423130324541323237304346384246323742453046384130393942344543344641324642394239433738413937303032373445333234344239384337383036353543343331363830373830463031343945443936424330394636383139373233364130463936303433433945334245353036393032353143343230343630334446323646454232424335423046313032323636363331453237383143463634444335324335434333393141354535314535374530373842393745324643304333443345413535413343384530373333383833313734383543433743314337434446383438393132413232303235463342343536424633323935314231333837433136384145413938323031304346304533324535434246313731414336444641324436313831463746303043443937393930394132364430443943423531374541383436354543304632324436303535433631453633464139373334434138413943313842413841394236334139373835434438343231453339434234323532373346314243453639333246453631373646354531373943443031313645453746464441303030383031303330333031334632314531324339333232433746343939424536424337313331444333313632434146433937333445334532464634313036354638454243414346463137433345324444463231334345354645383235433531463234363735353238324244373835464432324132464641313745364131464132453332383038373836374441374338463834374333303233453138374538303836413534433233324446463030343131394443374541323346413135333141433132453841423330453742334231303439433642433034353132373631313343353441384345334530463034423233413943453738443438443237363838383233444639324336313437414132313133434434413834344244394230463132393530454345413637383333393741434644304639423843344230314533433137463243304133394238343031453245373532463231313536433732444434313846384146313545313532413534304631333041433146363946324131313745303131374633314337434437383146443031453037363241464131313937453141333531424143383339324243313235344146304146443232333936354244344145334437393530433630423739303343314333433146323932353441413232304245303838343536374337463646323832333533424132324135433230323331463243334337384231393746303244304442453632364234334546333746443946433635313733463137393137453346464441303030433033303130303032313130333131303030303130464337414144333436394330374431443135353539323031413441463642323543374437373641383933354430443538393335384541353046433344313631363234373030354532434230374443463633393046313943443346453345324636374230454538333231413533443536443433394531394538313736434342413942413038463635314631324545373139363431453642374638363745394445433244383332383833413145463234413238343544324137454330413731383846323743443135334337384239454545394446344142303232364145363039303933353938414145464646444130303038303130313033303133463130373845434338373630453244353735454130463132423146344341434133324534354130364534324339333230353041303343304138413330323946354541414235343341374245304341353037413731414344364132443841444331374130304139414330453042343843343130343137303530344239313831413033364643383332354446434331344230324434304335353245444335313735333530303641464630303345443032414535343741463945413834303034324444424235364139454138373842333045354144353537413530443937373046323130444434313339324131314230363132334141383235423437463543303838443537384130444143433139334238363041343644423742393635414239363845324342444142424132323338303836383237333734383941323842323942443041353841383042314331373544373536304130424534314146453245303437354236383344373143323543384237423831334145383544324439463046314137464530304135363839343544443034334444343044323931463835363543383736363839414238433045463838313338383842353335343445424242373334423138443033314634353437443846304239434632423130423237314246443136323832384141313238304130304338303638384345454342393834324139463343354343323143383145393137323932353239344633313745463135364546443830303045343634303244354137434331313644433136383545383144393739363442324443303934303236363241324535333237313336363830374534394430423138314345303644354134444435324241443736354632304346303541393541423630433732363235364232443842393430313534423435354442383339303531363439313634343133344146423434393430343037354430443334434330454333364341413941424245363542333034433132424644313944304332303838443242304145363741303831393743303335393841433738303338313035323931393039423335433932303233373431353746363937454639303232393641343535333541374530373730393534443238413630364433393737393642464243313644314335353834383133343336384641344537463830454336304337343732393642374443413437363531374144373530393033413246423137443436343231343734454434413934444335423830423133333534453042384242423730363942304233343844444332344338353431304242433632393243324641423637423134353034313734423346303538373331393631364244303841413343353133353138373038423032453145383830344544353743323143323934303742353544433733353741453741333442383238413435323039413636353338413832354143313941393134364130423534324141423633353042383243424144334441424134383034303830314130304634383733313433343433423639344433454242413739313739423841354645463537303537333042463436414433464534314636393645464433344446373944443042423431453241354432463638313234324231423639354342393241304331414137333633373436443936323935434341313644373538303435303334413531434642384433353631454430324435303241454237423537433437423332373030383732303142344245344536423938313535394145463830314339313736334238373838323546364538433335414531423132393442413844353441384133343733373430393530444139373530353745434130423042424537414436303538383836423739383831414532393642363544353733363630393435384135323033303245394144414236413144454436423539323233393239303030303143433743463143423742453842344231304445304644323734324239323343304132394444373138394130434335344445363235343644343134464138374138353534423733353544304143423338374441324446343743304632423742433536314533433834423035364437313037344242423631384446423139373038373243303744454142334543353941393045304445323246313542393841343130463539323838463734323838434437324142344538314138343839303645303231303334424645433633343830443035463630383432313941374439434541313234343244323835423442353632374533413942454438433045413039393842303531343238413242333535334237343934303242363736333632353346333832354232353537344235463344453242363834333330303234423046443043443331423239344532303439413330383330354435393831353633434443413536434431344437453332313644394335333733374143333330414146424344363246373730393135423444434239363243303132303635313146343038313337353942413442464441363836353339323943434238333245324232354432324544303037384242454130303030303530313830314536463137413245303832413230384535374231423132393544444641383744324238363430443144344445454239354136383843304436383535443239414538353841424243353937393835463043323736434532423730373130454332463835313242443242364342334546324633313842343545303038353836354332433339393830363534303334443838373534324531363332383031443732303034443336393339413542424545383031413535463041414630444234323341433842354541443436383031423034433630363633453538383030353842394530363232443531363243344644383145323839413136383031343835453445303337453134443843353045423437333042414135354343433244304144444444454642393534314243374538433039343134303737453930313032424232463244394142463242463531314134413239344430353345323034353238304135463942324244423536434131324342353430334542363330433246453035334632353332453135373537303432413337363644383744363130343537424433433345334541363146374135423434333530413444373546343539444332363335363939384242463942443641313239303641313044363038303136313838444135333241444234374532324235334134343039434245363130454232424144413533313432394341424439384145343246463143384138334131443142383230344134304645343043444137373536444331353937374532413234324136314536343139363145374132423831363831413131443944343443444544363739323644383134413035453541314330354130313045383138343544304230413246333137433134453546423032344136424131454439414543363435393532393543323442414646303043413543443034453730353936323530313445304535463839413736413138313631364335373241383430373132413744353438393543413938304537424144383839434643313535364445344341413639353031313845343630324432454336443236394339304234303644313430393042354643423138313139343435364244423245383843363145424442374133373736303137314532424245374446333244454136333641324136303143434637434542433946343442453135383243433444413335324141314636343532414241343046414134393644443037443937324131313535463635343232393331374332303441304541393443353932383446384231443335413445423238343241413034353845304432303836353845383945383542324341393645343638433136443536333645304434414334464345364242463031424533304538393735433835453835323232323541313535364232353842353941424239413541393541323245353332414636433432383037313938334131343335434434363631323131364230313339333844413135414134323939413745424232344432323231383343333530444142314243413435333939323836463831413944363438313131343033373641304242423536424239333241374133364138394130323136313430423242393942413841343946343437343044424432394242413541443333343138323242393241334644434242354331453536323432433039303036433843413231363232363838463132454243363031343632354346394438333132444632383839433546344534443732384344334338313943344246353839343632434237464331423233393431313141304333383443334639394138424532433045323435424637383633303037413034414243334431303633373538453635433136453241354438463635434642363831413835304536394234363133324644354145304237313739323341344144324534333241413246343134303532333135443833353531314141353136433643363544313438433342383946393034443132424130304243413737313641303233303634413636324236384236383044344430443441343533423331333132304130324435314338434341303538374234313644413545394545353438303845423035354141413034303845444443434141394433393635433032453944373445373132434435304242373334434245304236454535354533313336453031464133384431413341423046413445434532423444424436424639413039334331424134334539424136353732423345443031414639424138433534343345313746443442424330423032443730374644344232433442303043424530324236414641323333413935383436454132413834354641363239353531343136413041443734373938453343433435303738393035454630303830423537433332353643413041424335433245423632363041434532363346393941333245333642463244333135383633313932394344303143373531364332383730463239314435314238393830333630433736394143364238343844323432393445424435343638313531433236393835443234423330393734323845443636453441393344383542433038344131344339454234344136353946303930443731453441314635303835413542443734304137433032413037413839423837314339303743454341323046314443303836384439434246443131333745353732393541324434354641434235334542354444413433323934384535373730414634413246444432313238343832364335463237423345384336313241343642383538413732364443313832313434393542374539364130463343353741413839414632433334323831463841423330373036383835383132453330373039364141393632413530463038413139444138444442453645353030453041334434353934373730453241433144323932384435353538323042393837313636303233324334373841333930424336303031353032383041313031313438313938433632464236313643393531423146383435423832444532464346423041393633423035363835414438304437443135363343444231443745414646303038424646303039383946333244313537433330344244433531454533303841323246304244333334423537464236383938334344434130423038463739343642423331344242344634413743393437333130423030354433443346453038304535364445383532464130374533383742383045413530304235423845303334394435393139314134413136314130333832444630373043344234434345394144313442423131304631443641304434393137354137353432384138383535453733364336464241363232344139343533353831304431353134323334423441323938434230323835394530433131394231324142384639303336414335353532383536323631314230444333344132383836393633354243304332463843343731433439413134323138343137454333373035353541333343304144384239353836413742344634413142423645384639374544324544383730363938343039363741323042464432374643384432384346373734464643384131423946444244434146363546463030364639384231373631353238364438334538304543453746303442343335353041423335454442454131303031374634434545453838383133443441314130454144413345323532354344313542443941363841463935453132414345303634323831323832413344413537453832313743314230413631333935353546383141423538363133443534303838443234353431364441413341383833354244323244303031443235443533354546343945334342344134343231313044354542393235454435313230444434384530413530434132394138314637424444324342433134324332384144424236413646363438463730343131363541333842313442323131353938334134414438364644324641443937413033363135434430374136423036324639453430343130314536423439343732453844454441383535314137433932303633463433343635324242314541424644313043333639453837464630303933394139383632313233353334323836443435413535354133383246383543463434443135423033423535453946434336313545413645444143334431343431344230413435313534313842314343323638444144433533323835333432463832313443313841393543384535354243423230343345393535303737324234343832393536304330304145423436303937464330413731303535364134304542384434324431353544414130363538433145413231323132344236313032374442383834303232414638454636304431413744363635344242393238324138324130383543353733443938383136324434333041463834333637324241363539303536313534444245343434443033444330383837364345463242434141344245423735443831373533464646444130303038303130323033303133463130374235324133453631383843373442323238423432423233303830414631393134414241383935324143363142323131374431304643314232393946383937383943394231363845453141453044453432343631423630414641373837434130413146343830374231414638343742323638413731314230424343303131303238433438383032303638343541333943323936453438393631444646303032333442313135444645323746324133434332323338344636323737453144393731464134423535313046393643353033453635463235453632303046333243363732333130364336433630413935444343424535303438384134393535334239344134363331414638324135423742373332463636394243344444373833374341433938313034314232333738453431453138363130364237393835304132303642363632413744413145313331393731373231314631324138373636344544314632394334413833453931363133383637324333314636463943413838464134424441413030414531394343433632393039373641343337374233453735383442304435343043453039364146313144413944354238453033434344304439303643373546463030363238344437313143324343323035373935393632304135413743323633423241354344444334314545353336383842333530414235463439343434333838443434433333313038384637303041394443353745454339424544434533384235463146463030363730423546433445363332373041334533443635363543364537353431353634313342383538343744433545343144384133444334333432413139434142323332433239433138414443333230423043443435453936303136413138333331383044454430453746363232344235323846424638383443463035374231423843423338373841354443433641353346343431313035364138354436364336353630353435444437303437324338433235463331314136414535343141453231394137353844363536344241333237434336304531323345413136343032304332314136434133383935374346383541373130304545333143454332434241443834333232323036333145364232414136423646354438393134454343303743434642384444413641323534373043334235373536374645434231354242414642433730313937324335333238393032313438313334423844433239434334343530383938444139374443453038463433343346463233353435424238364233393246353845423133433137464341363435353634373641463233313334344537463737303936303932434438383931463235334338313842363137413637363038333034413837374238424646303042324342373634453244443846323544434133383639383137333437464238413833343744463533313143413434324536323333303738303132423239324532323038384546373838393532394443373431354233383545453730313644464534374644383342454535463033334434413241353331393142324536304133323733344541303743434145343139313635313843414341434143324630343831343132453832384536423246414131334639344639343137463646344336453439323642303844383034363633444334324144304545453034423631443737323841384637313543423232463438334539313332444532444436344235424443373632373144383642314133414432353241334136393930433942353739323943464532313835433141373742373946354642363143304645363130453337393035324343343944413232443143324231394646444130303038303130333033303133463130434441354346433435344246373243384134424138393038373345313530343432363339383041434446433941393430433742323839384337303144464630303945333636333546414343363030464431374336314238434246413233384631383345424641303041314146353344343944373935364346393846424337443231313233313534373131304532304138333932444532313934303844443232394645433444393531463332463833393733434633393843454536444246373041323235373835353932413334393546323535343233363446344439354646303037464238413543313634423330453331464630303743393132444142393336323645333134304139343235433441344442453245323435363332303936414644463131433535434330373545413531463538423745344333343434313442454231324532374538453131433243323542303935374334313131383344313035463545434145353146344446463030433846354131463741464541334443334542364345334331394344413739364236353833453335433639453743313639383832433835364146383435343545433842423635444345323644463838453536343837313233463445333042453439344433323835464430303546343833364534313241394632303041363339414137354446383845373233324341394245353431433136433338333933314341324244424643323142323839333446334645464334413745314643434336354542463946423745464532324133424637393745424138453846424132444337363237384434423834303344343233343942393838463542314530374445383434334433444230453830304541303744453336393841364530333332384144464146444534364132414135414639463946463030433838433141413646463030424639464143363636363331423738323535443435434234314342453137373044304535363637394246324641314141384241423243424238464334453741373939373037373643424236363044453145453235443334353841464446313134393636334534333239383337333143383032304332334334464330333345433237463342314436343642304134343230443741423935443441313432413544414535394332334238393532443244453032383043304631374633313145323534434131314442463837464636374235314133464537463131444630353546353042393935453234353536323733374235464630304345453037353146443335453936333432304139363642464338424431303030443945463439333944333033453831434643463146383831364430414139383737433545363833344336384341433143423341414341354341374538444535454136464133323344433838384342383535364434333842394245334634343037353033324541394632304131464237464330323134423730463646363131304334373241334336343736383535374343464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(3, 'Confections', 'Desserts, candies, and sweet breads', 0x4646443846464530303031303441343634393436303030313032303030303634303036343030303046464543303031313434373536333642373930303031303030343030303030303431303030304646454530303236343136343646363236353030363443303030303030303031303330303135303430333036304130443030303030423733303030303132434230303030314538313030303032454534464644423030383430303035303430343034303430343035303430343035303730353034303530373039303630353035303630393041303830383039303830383041304430413042304230423042304130443043304330433044304330433043304630463131313130463046313731363136313631373139313931393139313931393139313931393139303130363036303630413039304131333044304431333136313130453131313631393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931394646433230303131303830303645303041463033303131313030303231313031303331313031464643343030443430303030303230323033303130313030303030303030303030303030303030303030303430353033303630313032303730303038303130303033303130313031303130303030303030303030303030303030303030303032303330343031303530303036313030303032303230323032303330303032303230313035303030303030303030303031303230303033313130343132313331303231303532303232333131343036343133323234333431353131303030313033303330323033303530353037303230373031303030303030303030313030313130323231313230333331343135313232313336313731333234323034313038313931353232334131423143314431363237323333463045313230463138323932423234333134323431323030303130343032303330313031303030303030303030303030303030303030323131303330343031313030323035303031363133313531313330313030303230323032303230323032303230333031303130303030303030303031303031313231333134313531363137313130383139314131423143314630443145313230463146464441303030433033303130303032313130333131303030303031424437313741363545414532463645464546343945463738373237363837413835384130463235384238353637344639364435454137434439453633353239384239313636424131434536353137393337464346464439453534453141453930353735453737364346313137414434333134313139453137444434453741443941394631453333423235314434443539324432354239333435383741353630414535374637344233423036313441463845324443383635423741333443414231413344334138463942443144303243334331394638463043313837374138373633383831434546393945423130314232453630363836394234323242413136354442413543434444363835413733454344343039383733373246413232373237413238464435323636423343353834423434374346303738344633313536354136333144364436353534433336313937383141383131333432343535333041333032454238453437344539413541443933313335314531373731414143313739313533454236374135413332454330343439423838393545303646343445444441393130314431323538463642383634333035423244324336423942443945354231353434423535353834353734434437444132344439313036443335303642313534423735373333333035353933333732394338434343344434373734323233314339353733373444423341333444314437423742313944353336374445344443454235413537324435383638453536313430324430423043333433433936393545433242313134364337444538463538443741333331434334313934373234333037413438424139454446313332453443463036463543383234454639344330303944443935393132453546334330323639423831363335303444443231394245454646303044434639383139344435323942383335334133463230383734433945314243383844384130344444324230394541434242374230353033443833373235394234413635313244333444354345333941393739374539393043354241464135463941384235333638434538343442443239454131373138414131413338353031443841363630393844424143313444383741313136463432433534423436353143463139453042373139454433303831344244303532373031453735424641324639393142433045384237334245303035444339363146413645443144304639334535333333363933453039453241464134463237413839363931443639394338443036304144383339463731423632334343313439324434464630303531393031413739353737444545463141434234433735414535373445324332363936434136333932364235334543463637374435383841434144343935443041393835314236374345363032433242323732464234354139443230423141434335363531343231443741414133434331433930393445324535363446454634384635433846353346424131393946303138433941434143364533444546394235323439433136353037413532334231433735313532353542384234303633463446363430434341433734463944364345344636423643463646394546374244394344364433374143424430383643444433453530314539444145353434424433434145314136383742323642394542393239413731373935383641423631344238344238393944344239373533303231453543434538433833454442333337314439433344333831423341353144353745383745373337463630324136373331383341423644363437434438353335423235443931304436363738413438323346373839433342313444354243393943453044334646464441303030383031303130303031303530324432443841433535363641324438344435373532314146354230324442353537313137424439383642443732394146353541444438444136304441423635393641443941393431394239413037343235344441434345393635373538443344344546324646323933423242304138414531313937454535354146414441383731394144353943424643454446413830374444334230394635354142333446443844343738333633354545344144454230364234363533363531343333443534353632433744374141433642353042343341353731334231353846454235374633324444383441374534443632353541463535353344363644453638424636424543464433344439443641414344434237354646433746344543364141384136384234353943354646303042373645433441424244344637444436423534454341464242354446373344333638423638364434424633464136384145424546334235424237353546434542413736423946443142443242414235424541304141324134324344383242373242414646303036364336314632373433393941413941313437303942414133353531424544363939333537323944353935423244443641323933423742333844304445373737364436413644383942313645424239364436444338394139414434313744443833464239363834443543443632424435443438333642463742313244434631393437443044374236373735343534364430444338443637353537373743463444413535464631384635363335433636433335444146353942354630383242363530433935323236453638383635314139373231414139423832443041393239443732383736313244373630424230393244413942363641344138443242373737333944354544324446343734463436464438444244364441353941433430413033314543314233433146423739344539343639374433444134364144384232424143424342364232454142413544383239443244374130423041454339394333443745453542423536344130454335383444453132354543444437444237413944374235454339424446333941464144374544314336433744343742303638454335423735324237413241384241453439344139423537383332414132424442323941433234324137304144383942314238424145434646303046413942303542373734423536334544444330324546373331444142364434324142343341363335393445453530343746364439393742433734334646384336413444344638424144413641444632423735324642383538383733423034323833384232384143384532303433373534423243414146443942373730374436354133343736323835414236364331374437414246333735323941463930353441303639443832454436373439434146353935443337444335413834344230303531314539414444364342314635393930384230334443434432394433454536344431414538374641394244373642424643454442423644443836413642373833353638353231353136323645364144384446343735394641454546413937354145394635364332333633374144424536413237413444394238313342453633364535443241444336373335374544313945453132424646393135384141423530434334413345453542414232434641424439313936414443414634424537323639373944443542314235333533453645463539374346423946453342364544364335394630424541353633344235303044383743324344423037363030344530423442353535444144424235353732424241423538464244414638344641373544373531443834424532364241463042443639364138453837434436394633373642364636364336373535394233424435463334464135363733454633423239354443413446394237453344324437364446434346413042363542423037344236414344433636353744444236433337444436424235313739374139324337383039373243303234334243423535353736434632304442454542314637414641433732453530333034353542413236453344344542463442413643443346423432354246373131314142464231344233433735304342463632423341444634393431373842414433464630303336453637443544343441353641343238364332413231423441313444383438464236383633423643333644363632413936384346393343423330323937333541353735434436414433363038443441304342334534413733454537344232464245414134364336414237444134374130443736374235334139413744393444453830343732354133443939414636323831373441424535424446364541464345443544363542333532414234464143304336303835434146354335433637444344344545454535434631394235464437454146423242343044414638314646303034424546413641464636454243384233353937444438423732383643383546444136413632364239373934384335354645394646444130303038303130323030303130353032413846413335383333383935394439333930313030453733304132323731333145433838343938364235384539384633354137323946443738313731304332423833304345343232453030433738323434303632324532313435434141303835303138443341384336314539353039384234433041303443433643393938313243374334313633344534444533463846314643344645363246413831423230443636363338343542334444384136324142344230434141434635334639394437313537313338383942314542433730394434443331393943323633333344343146433935313033393133393036394335343436423637454536324134464435323736464246373339344545394438323545373237333031463744423339373843434533453031313346353943343139433632323632353830393938363130414632314337384336453532414345364336433332424332334336363636303130434337384637334134393935443138384530373835384436313838353843453732433345423942303935423133303536304346454243354132354338303143344334453333313135343938414238463038323335393043434333363431364345353930313443354644363142353631423237364530314438323237373939363143383539454136323134313331333930394643434333344535383835434336423039463039433633323446373135303938353036343938343046303237324343313939434136374331313035363236323636354234453630413430394437303234434341454333334232314230434543383344434637303236363731463041423341434638433739333030463037333938454445324131454341344531383845323039434232303542383036303130424345443639354236363636354237363041454337424537434130334638334433393944313135323731393838303436354331323343414536363237353435364334323443433738353632323242363232444430353830434346383345304641394341303738463933304343343032313438324238303043343330303938394643344345363536424341303431303839434131333333333345343432423338463833363632313632443037453145464344353943463836433442363537303433334446453336373946464441303030383031303330303031303530324235374438423236343139433237313236314644363745433633363434344145333830323042314135373637323836363235384438383244383630384146393837433731383436344532313433333839383434363330334234363633383043343435394441323239463636433032314236313646303542313036363241433745333943303938464338414530384230344646303037433641424435364332313635393530384539303938433731303544313946393445364432394637453131423333314533334535383430433631343036363139363733363330353533463431304243464439413735434330394437334132373531393541463131384339453733394343374531393835354137454332303632323732384346393838343443413938314238393244393842383936363235363344363343363237313943374630363832314237313145464343343639383844313530343645323237303838334446313538454238394442383832453836453935423739453533333039433436333333324336434341453943433545303237423330353632314141373143314534323146444137353939443733383742453333384341434642463241433636363731333039433035453130383236303446324443413242434635304230313339373830433630313938374434304231394231333339384536323336363036333339394630353138344145444334333734453730353930393843383237354345303231414531383030383744314346383338393831303846433242433732374239373133443738353538323331433445443130443939383344463845314543443339333838354130393839363245323632353735343334344531433631354643313244433445453843463333333330313841443333453738463843433239393831343739324130433641463231453839363246313031383146303231463138393838304532333337413536393939434131363939333946433943453233314343304133334336303131393731463845363732383143433033333346383939464345434336334332453635343635444643423739334638353745374646444130303038303130323032303633463032363442323334414546373144453934383735303935444233454130354144414233463543313334343331304345303546394332303732453730384637333245334638443746464441303030383031303330323036334630323834354233413541304434413036374334324344453745344531433138373445304332424635433239453730353443314346423134433831324541323037374646464441303030383031303130313036334630324539453432433145383746303537343634433944433138384444373446324332463731413835433930333737364142383146444335333445414135394231464630303231464331354130333337313543453345394543353446413733423235334631334434323836353834363339333046394135353043413733393443343834453136353845433535423132314544423233353732333846374131374341434335304143363145363937363934363530394234363545333142413138453232393141303436313933343935313937384330384342393434323441394132313138383739314430304435343246463444393037353343313435324346453844384641363930313743323741344338464542353432333346344439363037383432353446423432333239453639363339343035333145363134334630354435383442394246344136373132433932463939333936303038413831433533434232394545344638423337423935443338423935363843383231314639353533333036463935314634443232463743354145324231383331303741363542323442343736354635303436334439304437453242453934354242373734444241424231433646393743414543424646303033343630334432443935303633434432334546354435463539333936364341334333303939443745334232383741394346383034373236424432463233463638353737343331363343423345353339323030304431314337324430463834464530413144313934414432304444323543443932453846383844444141393441333138303843344231373135353142463143364439314143423144334543413246413338453536373134333135443645353032443246443841383433373137354633363639364642323643383638394631384246314346383641313036313230343144463434363637394143413442444541313837333033384546463031303245464539443343384241413037324241384637393345344430304545344639324438343036393845333546383935324342334331314339393637353934453743433642444641324539363038433730424541433845334245353942323146393638444639323936353934453531303743413442464441383030363644433535393343363245414644344336313832393037333544353445343331393935463345373346413930393437443343343434353138454138304339313636333531463932454145324338434642373641363236453634314344393344433232363539394445353733303546344433463832334334443136344337393634304635323336393536383835463238454233393535303834383642413135463443384234454146423245324232333438313338434442324237423135463730363532434132393843344338433237383831343746374131304337464342334130454645323531433545413732344232344134324242333737323337374138363245354239373644423734374139394536444130423444314644434231343232373942434633384437433441323333433341463044384639383332424546364335413638394531303930414234423239413736353137344244343744334342304131393041334137433139314645444141424133324233324546313242394137373144393934363532354338454332413831423634464438394643333933373741334131334339434639333430443536354536413642413830394639383435463939443445383034413543433742353038314343363545393835323130323638433833313642343038444232464333384145423932433632364131463635374346433333463043393139433634453035344131373446444332323534414441394133313334344639303838383141393737464239343445313034433231323043333437414434414232373041314442464339333445313136444545363238344132333938353032453638383933363845394133303843304645393038393235443642363743413836424334434636363444453345443039453132413739393542373742384133373638313634434638363434363643303044423144413633354638413639303244444235353643343934303635444139373146333034373136373134364435353830394232354146373135374334314237423433323732313732463837383935363436413530414243423638413646463030373442423534363232333243423941354136304337453245463343313042444244324641373345323836333246334637434246323436313343463132374342313846334344363339453138393031383939334542463035463537314336363338413643333231304339414334323034453342383239393944343946323745303946413046333341424142363231424239373446434641353537463243453246413530323643373242433933373546333843343931323141333239363639434631434230354144303842393744354638333233314438363831353044303744434239423546384146303743313641303332414339424233373241303744324338453343354136353332413133464235313846413238453331323033433745323939454531413237383839344633394645373943394337333736393335323843333330303731314632313537383844443337423834384541414135343745373936454239303139363344353933373346363641394141303645453843344339443031414136333435364339453738464339323435413436333344373541324539453837363342323934423238374543324135364436313936334433333145304542314533383343373143424337393542454330414342413533433434333942443733303734453331433546423933383030324232313941313239314430303241353946443334324543413242323830443635444444413938424532383833353845464546374530413131394632433230324639383845413439413436303137344444383944363233363530333545343145453443314232304442384141453232454145413632384631334639323033313632424442354339333444424233433742443139354132434532373634363432324531373533343141354244413845384332413130434635313838443144343236464530324634343631333842433338463646363239393843434343434237393742373343373038374342323831313131444541333842323741373934323531393839344633434236303336314237423235454142443130414345423932313441394532314437353332363143393645423242353842333737323836344245373343364643433436444445313045433432313043393643453346353039383941443134344534463531333331393335363544454446463030324132393046313636433634383843363535423843373530334234373641384346463030454246353138444531333531453730444438384532393946313638424136313943353143364341444631453137414339444141413432314531323241363535343231394133313330303241323433383242413030444132423238424543413744364232313038384645333838444642443733313033424435423841353742364236394137433530374236434530383734394334384636464532424136363430453431464530394536433332333834453441433830413837453241333143333331333834433733344134364430313930384338314345344541363341343831413330343642323132424134303832354538373545433538423235444635333138313142423737314133464443384345453638434535373938304130313345453531393144373734453130383441393145434132383843344331424334384339453943313139363445363936443144383230323532443638313734424433363445393633333539354241393239463231333246444334394642443036413742333936343434374231354332314434464444413233304635373446393732374536424539343646383944304538413138453541434138453334344531313843383338333432313637433335363035444345413434424235334335384630443935303735304543323343353030373139383039454634334644313437303939384537303236303641444235433346343935323332384434373246424444314234303644433736414238324631353436433533304536393638323331443441383839433046353434383038453246374539454341324545344339393041354443354637353731433730384334373837314330353441313737413738464331304342453943444134314242413732413835384535334136334342434143374342324645453844463331314133443537413846354638463932373039303834354245353031373437324341424334454541383038383846384131334238344146463030323344424637384141313734364439433642313945423546373731353734304631323746443241343141444338363736313946303044373341333343344530343231303638463746313530433541303937384134333630383043353843353343433641353432373231434438434238463737423335354343364245434535463634374136324242323137364242464233464630304135424134453335453238394541343839364143343839353338323638443630453444444641423730394644334534324642433430324338333334383931434337343646433137324346324446424441323439413133313330444344323232324544463632393734434444433530334135324131353734363045464130453632434231373238374633423746363433414535434545464337443946464441303030383031303130333031334632314134303435443137443945463939423836374439313444323541364338303535343942364246383844423536393536463838413939314245323137383230373632394445374644353431363936384242354531354138454142423830434334303935384144333646383934314241414632343935443946434335423530364335373736354441393446304335463232344139354446414635333039423245373041313531443038364134343531413730364345304630344234333244323137383734454246353239373434303738323641384142363937374541303845344133394144413941373133323742333145413231373635304144334530323643393938324541413632413843384537393837463532433738394331423133353441383534333936423141364143423230373641343142414141463736314143413736433146463030323138333839363738334633334431433036453935463531343532324542354643443431344142454639364239434532313641433633364645464238433036413531413746383442353231333739333531343132453344333946374434363031453833444330373943434137344333464641354646353246373642304143453145353944394333333533334534394143333842434442324441343537423933384243373545303233354344343739423734463042373130333642324335334538463044374533423935364635353134433044303535393343434633444638464234353335373441423831314336414139463131443641394235433331334638383536383844323733463238433239344533324231454335334545353139453330353730423738414545333138383536333242384446444344414336453036303739384536453835444634323246433846314334434637433845433746413833334441384334464446334635303241413942304641464544383441343245374237383245423232424334364443354241373434333233413532453833444232423943363545313533454446373643313745454441313742433546383039363633304543364441423241374138334335363638353539464342333044384642343538334541314436303038374433414630373332413930353539414437334239394235394130363941453445453337464335433242323137393045413241453645323642313032423937394541363130354641303344464630303330323245364145463339383431333143413930383141353639373132464145314636314433334331324337364241444245363335353141303331373333453743384534374144433142323538434530374138313938424236343236364635384641393845423643413735344334393437433145374338414443414435444533323934443942313730363135353646323834433837413239424645334141453131313137323941434144464132354641443242303146303945334633393845453844383137444632463237373345383530393833443233383335353238334331364646353139393330353237444334444341463338433542333744303132393036303837434630434233434341303644323731313443354644433444384546333446364536374436343546323738393830303544333834414630303133314342304138413835324230374537423838463645433535334645433341304532303746323733303243414343344131453242313239393432463446413145363141413332434235433730354545353934383331423536443346353634323135303136363045303045383944413736383335414531343743343333454344344342304137443432374435393933373543343044313037354635353336303645443437463735353244384141323835373436303042433436373037334641344341354543324346423143384246314138343146363730423541373745393243324330444430384533394443304542353538363331443531424642383639344436433537354334373139303732383633454633324331304145343233313542373230374639393939363041453533423235373636423442314238413535384543364542433437334545304242374644434144443545344134384537334435414141333442443842383635443831453838314542373937313246453034443730453343334646303037393841443537343137363642443430353342313045374439454130353339333432444137443441384330373932334437353244344646353737313142383343464145443633393042344435444235464542313338303143374233413144443431323844363431303736444430463730453531344431353144323630384131313830323542434531414243423136384441383935373135374539303439454541333237453635353044353233354541364436314236353733454445463332453430344335454441463244343343433042304338324235454532343039453944303235373736313635443837393937424436324441324533344131433736344432343730373530414341353538314530363842353541424133353245413536324337384345413142353042323535433639303144303746393436463832464435464642313645343342444646353131433144373645383039343632303842343845314535333942393834344139423430333930303346393936433744384636394332363538373437454136314245364443314246453743433135434336423433384641384236453942373530414630314445433636414630454132414646333032353243343345353044313736394645324533453341313636333642304434324342423834333835423235414441314233323738384230353338363442453641313937354534384442444337413138414446424236434232423730413734373934363032373934324233354538374544393432373330383434333835434435433731413644313830384236423637334545354545304239343033303432434241413136444635444644343644364142383332334631464546324246443046333338423445344531433737304531454536343744323737313345423341423645304546353244434139343844363736343445373436433538314646373038353146463030423437313636424145463546354234323838393239454446374532334345444342373836433831423332373242394131454531364130423834383835423635443845333836303937443842374136373142393635393431373541374533413836423838444634433637333333413136433538343141374338384444313446383045384637324645333833323037363435344239463331424134394639314146383141383633363846413636354534394142463434423936353639414430363735413939324337363835393642363544464434343245444142463437464132373133363634463437424241394435383830303246423642353933414635393837323243304132443230443037353644383443333137343733323930304243463037373932353735343735453946393934364436324637373037363933323834313431413330464333333538343646393931454439343044433035374530343141444530303443333735313630423543453237383436354135423239343544444542434330364335463241384531343135423634334435334637323935343537333437314637373241313730434435333033394333353143453241413143443735433346463843313234384342334241334142453633314341354132463832313642374532303341313135384443374131394336323039413832313832333536334136423544343438333031363437323743314133303737353530433046423043304531383143423031414346334544463530384543464443414141343536394431424545373838433542414238423043323630463245413542343530423143374637334637303243453345313333454235324336414437324336333242373538454133424345463346433841313931304545424443413732463834464343423235414634393345423838364136353439353830354537314343414236323939343336373545343737434341384139333235384246454536463133313132353946373932364142343432433033353541343730393331413735344438343132464135373131433545394332464439374645343741434445353346453939453232463344353936413646384530374331413545323243303530304534373737393433323341393532444138423536354139394641393730413134333942323731314336383643413741454133313730443042364135393041393834423438343034423031314244334543433643343639443238424238453137453332453239383835434633464132303231453142453046443844374434414143314143453637364544464238303230373335383443363639304530314241424439463732433042443344344631463834373237433739383238333939374639344531393436464445453544433936433630464137313037334641434438443832353533353939353937423130303133323232453132413838413736364344313339463731324443343246453737463746423837444530353630433441444439303241343342364445344639373243423944373037444139424532453843343244413435333930373935373939383834303732424338334434334543383342384635324341444544383646454530334344464239454637393846373233333936374237323739333343344634323946363938393933463730373243353536364545324431424334303243454345313341413934303535363844373244383339433633333330324446463635353536314644353441443543453135373045374234433144413730333946443632354334393535353346344539453231464238383333363939424436424343364435363534413642394633443835464434454331363045313333373342433630384133313238423745324546354644323137323145433238433944314542434332454433464646444130303038303130323033303133463231313241434436344131314236313245304643313938434143363732453044353138443446313839433436364445464530334533333936463130303531303935393939354243323631324645363245343937324242313830454537413443323343423133454431443933303843313043433145364135394343414531393633353131384436433034303934343138434344304643413531414238333330333044333145444239373732433836413438423330413944333246453230303737303843354442443139364137444235323941323742393946353945314239434544464330383334433430304632363241464343423345313238343734343239323939343436343633333144424333334231463038374333324231313737323933303542303538334343363941443444363739344335333646333033314238383542393945423037303539393738383139353541394339323537303934334136323445364536443331364334463241334446413635383542393632354443334444353144323046454535414443453631393543434233304345363646383939433042363838393136413036374238304443433545303841454439454234464636353133313538324141423942353832423135433441423732453034333931323942453632454533463134443138433533324345323233353835323339413635394135433437303938303735313035424343343739343434383841463939433034353231373936353139353738343346383934323235434332463538463243373937373244464341383635373331304436413744453235303134393534343139383939454536343739384431353341323238384330433136303738383032353235394244413739433839453346434545303139453236443134373731463139453834463132314346423937343731383843364345323530323043393531444331423835443944434443324246333741384237463134363936343730364130443534413839463034333934363142414334433138303432363032413631303931413233353935383745323536463531383041303841463834323033443733463046433033424238443235303432334143324433463138313143363438363737313639304242303042313035313137314233324141363841334138333737313843344238464341413238434643374330393645424531423442363334343833433746333241323046393041343244373838304144303830443131463838324232463443303842463438354632343636394337433332343043333132393543363333324331314443364535423138374343433445304643453243433044453235414233413938444436363239354646393346304537313039464644413030303830313033303330313346323134434338433631323546383537323331444237313130324141314333323936363133393845363337333938354330433143333033433743313734384235413939423643423643393941343532463130324535464533313930363242373030433731314245413042303836303841433130344132324143443543413338393734423633463139444443423836323335463746313836343038423137304443423346463337383844364543463837393544343131383441333538323441443136464142393745363734433138343337413844383133433941383943443938444444453037433032364645323139393532463343433136313230333044354339314431323737343744414343453231413937434234343730423936364536443243344339333139304343373434323836304132334631363146383541393934444138423443393134454338423738413941433432393939453034324543323539413330344146413938374343364446453337314332413337323845323631383936433235463531353132393036314531444434333144414643334441383630323743343044413543364131363930353538334435343346363845393938393130383141383637303632463245313438373831314632373034334535363331343435314232344237323038413142393734353433443238303142363544424631323843414341323036324434353832453636353243383134374539303037333139433431394545354433353242333242463530314445464530343431413543444331333030463443313646313034364530343335374138383131393738383244343546364335353832354133353335354434373631354443423541393841364436413145373046373430453539384345434336344145423030304330384343303839444630303335463238304531373041443244384437433532334343444337444333303034463034443238434535313243393732443332313046434135324536313645304131393342363039384539393837354536333634333646384646433531414142383134384542314638443645453545374330374531324230324132343832414438304638343942433938303843343235434346373146463030383641313037464533363243313033313742464344434246393433423744434534423733363932383844364338454346363131383743364136423530343743304244333441334646303035334533393131444643363645443331363439344636394136373730383537433331333838344537314238454537464644413030304330333031303030323131303331313030303031303744433843463933364130344235333545374634323337433035443435384338353037444646303044373345314437314339384131383345354539314143413033443338353644323936314243393032313032343930463546434634433632423334393839444239304334304433443442433246373145443941363746394132424638314330384437324341333442343945443738324538453441413830353739453344463346314437434342343246353031363235433138443832433246353532444232313844444135434343343841373441313538323344324243343030414235324342393831464646444130303038303130313033303133463130323632333537313741324630323839343738363533314130353142464143444635323832303836303341353034364643444342463642434136443544413946443232333241364234383136313432434630323141453830423934384238453935363433394337323831383836373134303035324435413339384334313339414344333137434533413939444641384133413133394136463330433036383431443031344130354537314641433143433142373539423631384642333039413843443245433035323435343642344441424144434237303243323038303437433932463138424545304131364534433336333635433630334545334341334145353042313932394246464139423044364232443134354145353633323435413541413143333231383835373436383244304132333436384446373339394536434637393632464541303032463345364234303135374434373242364442454331323236433041303042303938313137433535433543313630394432463132413634443634304530353442453936353733424435384239303036424243363345423732383241423538363836444131433142373131354433354539303338324630434532413637313045413938313042324146313642383841324235433842453842333537443443383346313434363339313445354541314539333139303038363830323142373330423338303630433032414230394333313838373041444144313145463938363638363439343442344432443241393946323037353832393439373830313745453646343441384339373830333437384643413043433641313635383134304241453039343938313430423935334343363433413530304534423432393836314332363035394332324630363839343733444532313445353732333732393135353844323845413035373038363630433342314233343336453043324531303133384438354339343346413834463245393337394439373833464138353036353232443139303738303135384545354439383738394332363833324637393943374136454638434239353743373342384237344330304132443334344144413230413042443537363638393539383745413035413544423030313644374135454646303033313030364335383030453643333932464335433238314241303230314141304242303346374641383737324430303934343737453930383830393531353244463444363641394436463436393837324438414338344344423634423742343541414130414235413443374132463836363543393141303641363441384341424439444335383242443137313541443135424145453032373243324432373045364644304337423636303134443044354431334245443731354139394141364230424335354433344532423736423041333033423643324333374231343135413232323031304244303746343735373244413937323736344636433037423645323833343238323230423642353732324633354138343739344331344145324332333246384343423539353630363442343437323941304132464343303731413635353433363444374537303942433034354330394234303333443231364331383732303033454445313730384245353641413035393035444432354644433231343044434236434537304236354635323838353635463630454143353836304534314434333745343333423241303338423432383541453246364546323441424434334539463138314145333233443133373041434533353343324539454338333531434533304138333641434536463542393733443838433041303042353433373830313145463930364338434543363942374434343730353435314645363445394138303246413041373231453241333237394531303143313732393846334146333034354241463642304142364544453339393730373134363144383646333444383536414136314636373433433231353830354245323636333039363144433738423537423538363645453539393944323332323839363541333233454243434246314445343044433136304337423641354138363239323844354531324545384332304239303433344438414131383546323437413136364534414242414344393936323542364433323938303335324442384536363546413743313030413838373737393934394544454334303532454230413246423934393235363631313441433241364231423232353738383244413335363942453635383834344143423338333135384443433531313432413337353534464431384133353444433134463245393544343533313436384330453330313135423346374531363130344435303730303142463331453132353530413137343338314444433641413339324444423544303543394333374535383739394345353841324136393536453339423944344334433638383038413138334144343437304333324237343439334632363830453244344435454135424131324335304434303030444231423945373637444337433036424542314341383446303342383532453231344432313741343746323939304531364542324333384144463938303935454138353335453433304230343943313930383938303136364439393435373041423242453830454330434443433431433534303334413036444545354643344338413544314237304538414345333741364430343536443544373530393731374139343141424136443543353442383034383835373342324145314530373444324141393630454230373942393938313436363444313844354436383235463534353043343741443539394631304439364135353246344433353033353243413039343341313732424143383543423344383441454337393746383939464539303839323431373937393241463039353931433939373230373141414632374139354536324434394344464242433432313731434642313932333942453144334235384336323932423134413335344438333444363630444444353142363237454430383246343832423534453145313335443936433144364635323841444130373833314332333339414636364539304132323936463035373132453632313635364137333735383146344138434442434130343532344530343330434232464630304630423236393641304135314531353437384243434342433833433138363041424241314244423331463536393935344430464239313039364344463844313735373237433430393938423441413741304537314334434433453230324533423536313144333838354341444239363335354242303336413539463838354537394632303634423830373531313832303438414632444432424334343134384330433845383346383832304530324535384239373832334532354631363532383831364330363646433542304545373942424237303442443537373041344139344141443831363838304343413632364430393330353444423233384238393836373436304331424344363030464334363933334142343844463630354643343543343842443043444236384133454430323936313134303632423239424337414139393343443830423645463030423630324643303236303038423236433346433332394431323446323230413841373246413441443036323942383041333941433644373341344136374235433332383935344444314436443141373635393242303830414132383335344546374238444130343841413730373142444342333030394631353644313839433436373337383036443136313643324630313245353936304538303142334141434342314236453541353045454344423046333138354331343035423441324445324131383941333031344546364638324536373545384339343839394335454136393431423331333736354542333142423136463534324330434142363139374532383742444344373246423830383143413531424236363333344435434344454246443630304135333535463731383736304642323943413830443138303533463942373430444137374535344343414345464132323031423941333834374231323933463331423338413838444342333639363837453145463931303330343443363035333533363142454631384130413830313542363738304330464544424336353844354635383333313431453236393131353242383736303236364232314232423842443430323844373131344538444142393142334245373131364544383236383234323546363645383833353544313830304345443346313645304644383236314141363037374139393239433134313142304233374643423841463838423536363543343043344330343144363342423430353332463137353242313233413431434434453143373332443035353643413633303645434243344135454235354434363936304537463532384535324130343837303333433834313337374132393441333235434142313030413031313436453332433245324336333136394231324439363646454233393935453237323235394141443144414246313130364530384541353144414431313244433135304433313030323543353732394241453644423244463838363041384433383037414531424230334342363543463331443643313737453442343232363142333339313942443541334438343535303136384243353037313241453832383442323841364630303435363437433238303936333131353535354239374343373534423042314437354344353331384632343543413037353541433443453736454536333236413043354339393534314234423139303430393931433737303135354332413134413646383333323342343041313830433134314642324531453032373439443443443336413145413344353136323634384131423044333541363637354136434343363441303338454133314335383134363332304433443534433845334331304236443644344233314238343038343045463730414439363044304543463331323134304141313831423732434341433838343245443936364631433038413236433533423930363041453139324144323041413138383632314146343546344336463532453535324135324636423335453441443442334434364130453232413732364536364230433536453431423733313834443334463642344635313932394333373243344546463030423944313330364434413634424536433337393639393539333244423044314146323834423645463643433145333933443045433531324639354639414343444334344130413342383738313343304130443333383538423733383938323038433532313641454631373246393434333131423030414442303242444435374343353136383643433936343438364434444637433031453645413244383836354544394535334539453230393241363644393643303030313037414138363430333430314343393334303241464630304238363832303645393943443634394244443041344632443135353136453632384534423538304241443839384642383536433233353834354237303535354243423138354330333538333233323730433538464443354235374435413635443435463431364643413030414538333839453843393731353334393539434531343939383246333637393839373035443330314141383746314133423044343045433436333839364537313636383042364330413135343534373642323144353442314230453846304233303135354434303035343435353739363939363044354344423642344537343230393036354330314339383935314338463641323844384533333145314343433630333830353032324335334233393842414143303231394231304442384145333131464441314344323542353431333537383844394230423035393337343345363545383341423936433031353746393836303234413132323931324546303546333136454141384543423239353244443630304536453037443830323830344641343741383032383833333741374434343839354332443731433846443430354138434232303142344530333041393437433230303535313434463243423843344234414330423431343243413334433632303345333641353532453845443330344539343642374538353836324541423633393031344436314530434332314538304137313645423643384533374438393042463045424331363235314342354346423845324346354638304236313437443441453132464233353133304131373635373233413834333637343538314231413030434532423034343737303930424131343730423935374636383431424330303536303043333633424331453337303243413043363830384537433546324443333032424535443532423237363235333936304530333638314139334439464337353037314130363643414335384544433443394245373844454130454532344144313033424637333933434530383542394338363231434438414341424638334637323837343136363942333338414646303039313735323038334241383334333843303336434345363943413646303246463030373043333130423134333231454142464138323546333144373644413031464330323233364137304342393039393146303234363842463732364241353934423439353845354330313730453831423034363043423732454346433536323245353042353532443245453836464341463730354242313042303138413142373931383938443644323832444343373036453939334334324339433135393544414335413236324632354236463730424134303641353430463941353143304244344338303041393231413541324431394439433641353831353831324345303732353639353936323645424137333346464644413030303830313032303330313346313045304342314342353530423431433432444433423337324630424544324341334346384635333545454231314244413233353835343236464632433633413136313833343433313537313244424433303033364430343037303835373843343642333538383042313641324637313832444434333430363235323035453845303935423830374241383844414542343643363337333938423534363545453339364430364444343638414641394641324432463832303338303045413245423042463733323437454535433843363533463438344436333134443142323033343937303537354238413239413144383834343643373743433030393746373144394344413846333334353633423831333735313131374343334545384632443942383641463043413243344545433733324441423838454139374641323533454338343938453836324430363938304545373344313838353035423830434435433633344143333032353337444230364132464135313433313442383845363236413235363036453235303337303639364239374541434643343135353834323042384432383241413132393838333735393541413138393932443343433530323533353330443431434341383238343835433841443933333530314331423845354445363643313932363339423739383445443630384635384531434230414239304238314245364431314236383935433631353836334339313633333844443543373137393138413845433935444430393841443430434643394335433431324531463531394238434136313643444337303538383932393344453241443835423836313737324134423938313734373539384430423043373234324541423032304543364135414134393534393832333136364432423141374139363243303435363943344645414533394346394531353043383336463939393742444643323032393334393630363131383637324238304545374235424641384142303145303335383935313139433134343031344443333435424239433031314336324436343733313436304337374645363235374239413537324138413832383541354237413841304143463130434243424341353038433330364144453236304544324131344333304146303142384338354446333341353939363139334531314130363241334634453530424546384545353045343738363536384537324530434445304541363432303038333943413238393531344144344235313832453838364536384442304434414244413832333841363034443730453635303634424434413941383937353338343841353832453638303832453932353736324535303434373236363746363642463142344343434333354537444331383933423934344335323330363633433231324533353637393630414237393146454132373630463238433832314231363338414633313244353841443933373646303632373545323545424239373530413835334144433738324245453632354335353838323436334130373530413332443930433534343546463531444534463939354344413930333945323530433443324643323636413735423839353431303541303132423639373246383944323438343644383239324535353930323242393638413732384138323043413941394532304243423730333044313130344144353133353536424641393532384646303045343335304434313432303736343644394345453246314434443639463731393231413941354231394442313144373330374134443839463531454132453632323531304145413234373234414143393038393041444330313444393134464630304234313042314241394144393538424545304243354336393442363038413831333542453631463245304535373434373232433233374634444332384333323532374239343142363039373243304644323530303033343443424433323944454630363938374538363133393841353035463546454530304142313030393937324336453442353533304538393244354239453631333538384341324335354638453232363037323442343242364131344530384641344244343034353437373835443637453032434238464545303435454345373731354234383632413034464437373245374335364243434237433531463530434546313031304445323636323635373137413832363843344235333346464441303030383031303330333031334631303446323630333931333030393938384630424333304330304634393741374137464438463336303443363642303031363645353442463143303036303141384142323135384531313641354532413142383543444136353132433939363532463443413831323833373332333835433544323738453338323630384145333146383941433242393045343842463238373936383837413830443137384435434130384642393443464245354630413236463132454530324342464334433437384532364531393633374644344439453541414535453133313335383630343333324233443731323833323232384233314335374639373143463842374645453031333131333839393831433138434142393235304338444342454231433443313539383642394643383846373931394239463034323535324537303041393946444231343431313845323839373034324541464145324132434330374446334645453136323533354344353745413531373933333131353737304342353130423243413731324436423134383839374135433041313635413532303535353330324544433639343145383937323232443732414442453031333343424139393943413737343238323733324341443433413436463731314246453337353131413842323734393031354138353141393533383835434339393745413033323538463043363235343634383839363531304333443133423532323434423837363434313533393744433033343746303843353730463038383231423839333231314132303942383045334333324246373433424135324530384631313144313932353533303839394236433430423139414135383535324431313637323045453033373431453636303830353441444642343233384630344345464531303534333945323136354641344137373638433841423138393244353042324232384139454432433643383844433738434330363833303643453632354431303832394335314446384646373134373343313745453144374644383345333145414343374532333532383743463037453038384137433038363430343145383531383239313431434331453330313336383345303433344632374639453230313738413938344545363241383233334541363743343546314639343130443244464630303939393442353746433131433537424646304342454330303331334139413346423435353244344242414334414230324630383436444532354642373042303236373245413332344343423130373634363042303744333332414332314135343742393336424643344237313146444536303543414131423439333638414341343137364139343337463038453530353131393046343938383744433043334239343742323132453230444334353042414243313245344541453938413433364631434331343244354336423139463345323541363533413143303639383031353935433345383534413843363335343435433243383141303342454645323837333436353242373246303333333032344341363230433534373438303836433337314441384343303430464239393942383935363443353232304446334431314144324632434132384337454342324434313731394132414530454532433137333038363241323246383345313634314432313443434336323442363145413041303836433135354643303442433733444333333434413446333242454444343037303130324235324338364531373042333641323937463834334331393631393442353033363533313533303543353731313546384342333142463133313131393834314536304332354443323138434230433233323341384246463030383036323539383934413131373642383941393831303631443235323332433945434646303039333234313041384130323334434235433032413534354438313138453233304342313238423635394130394245424531443743454543323134463843443935314238424643434334323539463735393243423946343830343642464346463132393034454431434231303845313532443734444434423337323931464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(4, 'Dairy Products', 'Cheeses', 0x464644384646453030303130344134363439343630303031303230303030363430303634303030304646454330303131343437353633364237393030303130303034303030303030353030303030464645453030323634313634364636323635303036344330303030303030303130333030313530343033303630413044303030303042323730303030313033343030303031384232303030303236313946464442303038343030303230323032303230323032303230323032303230333032303230323033303430333032303230333034303530343034303430343034303530363035303530353035303530353036303630373037303830373037303630393039304130413039303930433043304330433043304330433043304330433043304330433043304330313033303330333035303430353039303630363039304430423039304230443046304530453045304530463046304330433043304330433046304630433043304330433043304330463043304330433043304330433043304330433043304330433043304330433043304330433043304330433043304330433043304330433043464643323030313130383030364530304146303330313131303030323131303130333131303146464334303044413030303030323033303130313031303130303030303030303030303030303030303030353037303430363038303330323031303030313030303230333031303130313030303030303030303030303030303030303030303330343031303230353030303630373130303030313033303330333034303130353031303030333031303030303030303030313030303230333131303430353130323131323331323231333036313432303330343133323233313634333135323530373131303030313033303230343034303330363033303630373030303030303030303030313030303230333131323133313431313230343130353132323133363138313332323037313931423134323532323331343035413144314531383234333533333036323732413238333234313531323030303230313035303030323033303030303030303030303030303030303030303131313330303031303230343032313331313236303531363131333031303030323032303130343032303230333031303130313030303030303030303130303131323133313431313035313631373138313931413142313230433144314630463145314646444130303043303330313030303231313033313130303030303131314633424637314434314138413544333034313238384441433737334535333045383535324235343636314442323332384132414146363845344236464432454531463535453037323946393544454630434142444338334546364134453235363543443634354133444337373438453033394242453945323638414537343733374637353539463941463638383531374243413639314242413536384432434331384142333932413945453130374238423641414236303637383435423841363541344338434134384341434430394635323735413237344634464243374243394634413844364438413942443941373137334538364338334538333245313143303235324538323936443838323238453631373733444632413336424346333631303941423530363235383532323130374341443446424435393531343233354143384538444342433143464630303931454339313541383231343734394142394344454133434635313838443631393942323743353342464436334141304145423632464432463541303544463346363335414435434143334334463943314139333731423839343131373635334539353135313341323941414233414434443834373637314541314144353041393334334533333246383036334443303939313246383544444241373841344145343542463945314544413637323339333546363833323538383638384333354438423137394144353832354235423439463941433635413642384137373642364634303836344246333942393542344636373433453630394234344331423142333944463044433433363031433931423232373337443741344444363734413637363344354443384234394333313632343044303933464238453438443346394346443834383137383644453332373331373644363945413331323945384237353938323541353536333733423538353244394132424631333734384234423734354344394531344634414145443131364432344243464434304134393137313245443637394241453637353139363731383444324435383031414434444134333733314341443145433637443245344431343336353434373337353536423434394233334332453441324146413430413739344333443334313133353031333438424333313032373938343643393344353131394635324239393438454346443636364236394439434142434645314431313644303836343143454438344345354141374241423338333432434432393541433044323543373342303043323431393144343333364343303332423631344146363530323845313143423632463432453142303638323237383046343241444236353639373941413841354139303446353344423238393941343145393534393332424332434633324637324636343131423835344432424334384338334132344137313430343032433939354138434534454346384538423037343442413544353830364538373532454441443146334235373442344335313235383742423942333641323244373537423339344144373938443141344437343433393434324132343644413241323641463833304538373432323532443742463242304634384538434142344345333032453533303245324446383343343839353835353235453737333238383430323443304644333131344146334642323134463730334443304532333943433036414338443135413139364239423846363146373144443536423732304232443738423642323733324633423635454435303432373637424338424630423942334236313439433041434336303232373144414143434538383842373537414231313237383338454332464136333734373842433635363637413035454232343731364535344441304536354543343044373034353445324344424131434346384639434342343344323633463935323439423842353746313546304336363642443332314142303342424131304544303439363830313938434335333144363838304141433446354431364335413734394331314343354134443838303430323537303737353532304637464644413030303830313031303030313035303239324445343041464445303341343744353535354230414245433633333542373838423434353131323942313341383233373035373339394234423539333235374246463030413739344242363143353345453938453232453141424534333530423836413643423534323630313739383135453430423938343142303836453436353235454632393832413731463637353538424335343835413232444144454443423130314334354433433838464442324534464338374341344241354338374343463442374341453042453543383130433833393333323639393930363934444243303835453335333645433246393232394643303435374146414238414233384639334631393634344142353145313846433234413044413232373642393737463346363239464339373434414335354533384532323534353135353543434136344232393733413639453137333246373739333033383831364437364446304442354331454641364638354233333232423042363043363433314631354431304541463539373343324343453341453733333744464537333230354436423836424142333143303345364239463432383644394446453245443842453246344343303838463237454146463030314545334646303039443632314543424646303037454233423938333330423039394142354337443835434641373336453230434545314446384242423836314537323631414431463133364438373132443435333633353233364137443944464532423046353431453443454344363945333735434439374338363631334436453142374242424539384341453041333242323136353242453443313436434337343339334231433737423335424446463030413245363243413442364634343935443646324446433131444144434432454436334543363446333632424337324241444530373335333538394345363436343734324244434137314333443445344533454344393038413846363333373831414145443834324538413337323237463942454536343739433438374344373939344531463133393243423542444544413345453636363042373734463231393243453639414439393636454632354134423242363136344433434232344230453534444234373646394338323535454435374544394546333037373345304636304339344431393733354341354245364441433537313935424139394332443544464630303444364437303144323437423842414331463939463837433742423145414636363743384645334242334641384245463541423742413546453633324532453633463536413431363131424132423342443031454439314135334643364535394233304439343733444439393543444238333144434246333532334446363939313246353736453734463046454342323333383846314431354243384439323342393836313635423446304443303932424336373646374630343142343530433743393336323644323338333738433845313334424243393242413433343135463637333246383543463435444243373339413542354546313338464338333543414435463142354433344546393535333743394345463932454544324541374235394144413746394438453938373732313041383142343432333143443341393133333238323533364438414133324345363533433632363842323538414243433632324535313339333041433639454542343344423534314235353937433643434339413236424534394144363046383538443938364646303039453334344438393044324535463533373037394132333830373237324341363236304342343336463838433545334630463937433334373733363843324231463335314436393346363442393936423144383142393842323041364237463031384343313042453443443541423533333835443435453133353144453941383237394532323537353544433742414537423943334244443333374336453742393439444544373037334133433834344438413738453432433336423932393141413439314435463531424346304534463236453042333733434231333944373245323344343645324531463933373331424537423536373142373639344435334246373741393144433533393541353030393746363730443234323441424339374342373439413638413036383944374144453332443644413437464630303637363437314631354630423846354142383642423042363936393837423739333245444639303339463844394342384237463439374636374139414138413746314536463445453942324243333333364432314144353035363535414532373937313832424334443134464336423744453546384632373933393746464441303030383031303230303031303530323444303830443145394338414532423831343232323831353130413042433744363336464439414136303431313532333933354135433943394142413239314541304444303041363335384330353435344642304344314535333841364339433531363932423845453543383935364533343934413646443134353435343534344630383034434432343732454138324144313335313041344644363144383739303239303832393839453738394632324536383438413341333934354138433744313131433439323945453543423741413239393045443330454539303236373430353531333736343737333434313131424334373830363343313436343031373934323246443841393143383832383436353038434145313432303643453041343335374235334236373044303835354430463444434136333641364633384630414543453644313135343446313534433142313737303044303543344339433433323534303737353342363433444331313735313137313241343646313633344437343331413839424331353039333434313131413344383134343336423832314334363835413833313731444238323039453242413544424636363841363844333534454641303237323031343634303637324430304444413130314131364132444434454641313544313342373638443238383134343236423534413738413733344432334439413130343334373034373541363834324533353445313436453845343541383231423037394534353745333436424237373442423331463534353144303935314637323233384141413332454634343131444435353334414238374631303130303845464131443239413330443431303838443141373842454537373246343032383746364137373031343635373638383534433846453645303131353434433135303735414543443644303232384130313131353445313532353838313044354534324237453342443346453331463631423441424235334130443143413445384246464644413030303830313033303030313035303235463832353535333441414137423933394338423937323443423537333833383736343044454633463637463235333841303832393236304435433934384641453931384445303143363339314539384441344134323346363337414246343638443234444346333535443233314239443938453242384132384644343533354339413533434538313438453446373641313541364546423937463130453239414634453444374632443638413544393735314130424632383342393830333439333734373432353334414337384142454634463641303638413437373234433134314130324135303543344234423133373735433441413238444339414134373841334446353434413030394437314144353739464134343641304538333541324135313343443035424645444639303831444239313444324134464439414445344138314133433343434245434338353645333833323744444231333638304130324138333430344437353545343639453441323939444344333435303537344145384337413934463734334236393535304341344145343943373737364338413636393030454637313544353338353133374541324634374142354138413344323135434433394339433735323942413337363436384535344532464434414145383337333131444534333537363943393339433831444235414538443732414431313343394641393736423138464138303544313144354144353237364136424239324135353336313535413241414538384538303236383435304641384541304137384534433831343741354346453935454437373532384136303433353346343933354434313435433836433941454132463241393241463345334442364139343741423745383344303744304346423043454142464646444130303038303130323032303633463032383742373141433237354130323735384133374633344130303231323444374544373643384639434242414145394432423138394330424541323032333733424346443637303332373241383534414635444537434434464646444130303038303130333032303633463032383938414635443733334243444545424246384137413238344134453839423241453430413333383243444543463639364233443337463038464646444130303038303130313031303633463032364441413445343133343634314130374333384235333530414638324144364342303537303834333336413639373046353634424633324341313331434241444245343641313333373335453939444144373333463938353537324646303433424238444139414538313944393338363432423445324442353745453239423230303145434136334341384234443246434435444441423937303334434543414336383542363535323645424634393231464435304242423132464630304337363146423135384630424142423937413832433536324143353633373542393335303546314236423133463033453334344546463030333730314530393831443644353746323432323845434445343835423844373931344641373345314239443839463442323731333337453134334543453239414436364137333844394144313741414431324231463142464544373734393432423631393935314343433841333130393843313743424531344635353533414635414536384630303639394136453434374232453737323533343342373733303344393142413633414344303530374335353346303837463337463035333139413638453846363130443633343942394638323634364532343335454636423439313733373238303737454136463735373934363346374131344446433832334343363831354639414133383446333346463030423845393239464230323935424234394142314234353538433745334631354244444536454130303146304334313942374434364530423844433831453538414546433935374331333330303844443930323332453146414445443737344439394633464541314235373431423537423444354144414234384131303446384145443944463936313644433342343746313446384642434444443430344432334443423330334531453039414434314134374138383244344430303536394543464630304139344343464246364232333745343536314536383334334234423941453045363946313039394245444533464243363137353630383142383537394241414141373846373938444436304641383043353645373733423936373644434532303434354445414132393736393334394442393446353431323043354145354134334132394533334538393431443335463232413739373733424538444233303844433736463043373731444341354235333845344136464630304432373437463941443045304530433736413045464235344344393546343642464135383437333138313534373337304335374531333942323736464134443137353730314143443338433731373832444238464545303742374644413846394631303739463137313138443137353343464335343444454141363234384339334142384644334333353533424642374645454535453633323536313437384541304530424134394544423835454542423931334343364637394539373337433136444134333842453236333846393835414443424241343546464136443544424444314142413834423545374534413835433131364234463442353745394232443746414344304546334232413833383842373033323632454641314245324141453936383332364237303530344433423746454335333536414346343943324142344130424239423737303633394445413631433134423243434531414443444432314144343542354539313830453045364243304637323344393739444231334634384242374530394343363433443031443436344435313432333941384442444446433641373544414132414236423133454545363436443639334545303833373330373035363639333434453132303133334539343037313042463331313343343533353942413542363045463234453733384434394344343533303334333142444145463832323735443646363433414138353032303534423044344431303032453445303134364332444133444631423741333935393331433644434332443533343844384442434443363841423034414439343043373439414132384631413935453935383539353436303243394435423335423841333733444237354441443437353536383035364341324134324645434231464435334644334142393731313732414534413642344145454231414444354637353137354242353730393031334433313144324436413643444237393443353233373032313431424232444432453936334142383738453638464231354139433344333937304432334334463939424139374235454143464444394139314633423833384245383230363636303043443134463839433033394145303435304531373531314443383645393941424130423444373045374543333744453830463345324644434336433246383946373735333232393931433443333234384533343642303632344144423644394445413845334133424446394133454435313638434245413042344433344433384236303935444442373334443632393837443235314438434431433742383933353932464443313630414244433537453637363742373131434242343636304336443335343643463736363338333744453941374332454138443244423744343944313345394443313731343534334534353737303335384337384641414330414133394535444343384241363444304238334439323041383538324138433135333839353735343138384335303044423933363541373331384630424445393830344536303736393134413245383141343342324631353530353639414143353431354238373141313039383037413845303133314235324430343944354546353841363435413842413145443346353043383043374536383041354235363145364141343530393337343745374334463037314641384536413736314539393037413446383143443145323734423741453442333538313442433938373438463245323246413533333735323343434432384634333730363834433932423835453838423634313633394536313532303944414536453541454335334234424242394239393542463842324645453531383639453944363335333846424431413741353041463932463946423336334437344333433344384443394439423742394243454433433430434632423931353537463346363138383537393730313443373334374234304437334137323443433642414332464646444130303038303130313033303133463231333436444546323530374642324630443030463835324336344145353737303936463931464139373441444238394533363846413837383034363138344639383644443533324632383239373438373735323134453436413830443030394443363934353939444233373344384632343342304344434343333835413931383639374434314239453935353133314233333743333839374142314641313737464139363331343844434139344241383744384335394531334536313842383135463732303837363945333534373638373045344546453039374335364337313335383445353843423845464439424235394635384336343231433942464630304243434242433446464243343233313833464546313334354639313841434133453939444137453938394146433937303043423336384343333037334138413937413046313244463739353646453236344337373035454543343742433431463834413030463642444439423043423932354430383235324131313636414337453036363634453437433133333443414437383145453937454130413538374132444445303341343442393037433932354438333939344534333634464434383435414637303244433837333333354137413233394443394442333041424534363744413342463034324431444544454536463132423330433041304344424337433443324631423631343244393542324633303641373634394442463443343734443844363630393833324343423642323046324246413833323934383937373836343143333239363934374130323134333937333045313232463042464243373236323137324437394137303830423336354438444641343231373236384242364235344132334236373331424335344445434136354642384544393835363736383742354545363635443633313436414632353541333237303433384438343436424536374243443034343043413244423146463932423833304239463533433344334337423838463035353346334346453631353630373031434343303245313232304436414135313837324339453039393437343546324332454231434636374637313331353542363343393331373732414141423439364241454430394531454337413842333131323543313934303136314635333435363838324534303736423838343543333536304432314346364139393645444430394534333130323539434541304231333531364333343430434232434436343538314330334139344632354343423043394638413133363646303732373642323044414344344335313045443332413239363238313838373936394431323939314345424130383444384436313344464542424646323139383330354130344530413841373034333730373634413732343141374241384632454237413536323637434146393237303836394431313539373739384235304345344333303141423539303346364443444139383037343645414141374638334341443535434344314435333438373734343433364532454434353633414330303633444335324145454235374335433733353544384146333646423937443630363730433030314341384445374234423741383539374644373738383432394641443034364535363045324545343538333937363832353133314134463230464332363638434631373046424334424437413546323744434144343635424544323135373742343233323144463337303742393435303545443938344634434244323136374238464432363631354139433833314634393436313033424236373844334331314539453743423334343346424234373734423737433239443139463243323845303534433046353138354638423544324533344338344241414235353644393532323031334343363245414235323246424643433536443137373644303042334334303538393435303644354532333135323846333544443036314441454343443432333635353034464441334644444330353344434641303936374337464145384246373430433231343544333532453934324244434434423032393045374443463234314634364135454142333244453045353934434443363435393543343031443034414535333735353730463032313745424343393245413246333130464230453746373137343530464536304431434541424242463932364534454342384243413336454630333135423745363346414242354546433237323431413231383343363833454338354632344532354442323634383938433437303743304341303230374533313745343535463936363533443835363335464630303434423436464442463232454444413242343737444344463043363738324131363746424242454537363734324430393533373330374646303037303446384634313134323533313545394442413942303335303845304337424543303845394143444544453746323741353341374239353836344233423543333530433042444133413837383841394232453744383744433141444530343737373342323333324546323936314233343846333243413238313934443542363835364233383934334631333141364435364444434442434341313939463339443536303634304238353338384441423144323946463030443938423243434632323345443046423237333331313446423138384646303038363143323638444333364341363942333841343844314535374139344536383641453243453133463638373443464336393935354241324143343837333938463844343245363436394545304142364338463937383841364130334239324638364533343234373836383146313132423939413945433639374536304341303932423942434542423437313644453743433436353935324639324246423838314438374339393831364137334436314139354431304632444443354330343046453132303542433038363638324544424541314445314143343634444636393838354541443636344145454343383444463132443434454341463236373033363544414233333646324342463741423137313143433630303437344545304335354341463044424246373946393741333245444441353044423133324546394138383835454539423145423938353736423845304445413630313238353330383732343432383943303837424144433736343332434133434437383543333931323836433537363444343244333835454645323732384143453532444136353842454441423637324139393543363235423337303532463136464237374637323936444545353233363834314144384131424343353042303939313935463736454536323644334631354146423237373441433746353345303045384630434646303038413838443931334536324144434431394236454637334646464441303030383031303230333031334632314241374139353444323245383142334234344530323531363437423235434242433130383330383332464638363937443231313537343332393331433441383543313043344138324544434134393439454346354237393443423937324535463432383132313834413235434336303845394135323843323039384145413632423831333531443034323537463036343634413434383331324641313938333531443932384237443233383132423133413731393534313930314431393639393932343535374238374135354344413634323833373544334239413230413038424342383546313131433341343730434139383734364442394541334534343339323636453135414332323243313143343641354336323539383239433332333432304532453636324642343134313035383437303939464130383942353433393139354235303030373344314339383245323538333033303733323137423844374137303333333144303137303837393943323942333841324244333731324344344236414544314241363332414637303237383838443443363836304335423732383730454535464546413539333230383835334131324441393631323343304431393833413441353637413534354538353838454346314134313242304236354631363734303231434132313330363445393036363635303736323532374237334433334343413941393932363039353438333334383037424442443041363730334130323237343635363634433442363144303930413633314437343135434343454338414543333330453130453843343535453531344536303832373131444434434436444342313530383144413337434343413732433732393941373931423037343144423130334131383041383542464333304141353034324136413541454130444434314631383446333344464131393045443345303630343530384239313938343038453233354333374436433431443242433734363531303746333332343544314145383136324535434341444332423838433245334533413731333938363843463542443034423443344137343731334646464441303030383031303330333031334632313333304337343637343941344232313930363231453836333631444135364345444432393132323746323036333132354244374331334238453737334232384236433337413830463644334638343635343439354434423046333143374134453039423445383644303341344336323634394237463034463437413045363539363330313741343636363332424334423341334432323932303834323834453341354335433536333732453931413236303034354539364133353841453932353137314431453833413334313245443835313736344242314335313838313534423844463443393430383339323044434539304545434434463234414546384538303741373437343331383441433836364641414436323935313233393433383230334232454344354634364138463234413839383742313845413838353132323633434431324243453631423845463142324634354245393137413341354343323538343130453434353433304138364545323138363032383737383935373138333142323335443933434536333441433238413938434235373038324346303844423444413546344139353136353530423135313036323633313431373331384342324339373241353939384343343231383432413142353036424638314336324342354430304341333630443734333044463444393245453842384230384139373134434136373243413044373431453833443331434431333643414538454135434443323134423942383132433239304335393135383434373533383945384245383332453635343437443042464331383741314430423032314142393439373443413742343143333931443545393145394244433341353445363538454234433634413938414241313233443134323443324237443044374638394137354244453341314538364533314538373533464644413030304330333031303030323131303331313030303031303642364543314636373043313544354144363644313337393642434332443437343835364631453145443835413430303143303230394230314535313837433042384545303344453642364238353146323346374434364232343738384532323946373733313242423331344235364430314536313538334241304136333344343643373837414238433132343331433138393341313244394339353538433334394244424643324546433431313533313842463539454342344435394531343442364437433631424135454543444337333543434330363930434237454545333044443438344646464441303030383031303130333031334631303233323635354238344135374439464139353835363435314335383141324234343730454436354538414532353846373935363136333835374234333141433044304442344135443742364130443230353735354532393445434633313031324339343643344546323932384243303539364130304633303846363036323430453542313246443441414637383536324538333638333436453235353531323630354244324341373839353331353642364142434534433430453042334335303946423834324646303030394645434646453730464630303635334130383344453145423546303135464238423937334341414246414236323541363338394542464238413333423930383844394342443938343742413636413943313337384241363135324638383630313446303636323136424545343030373933384537434645323334443730313432433239374333343637333239353039333044354144444239454445453333424537444546363646343542463730413835413139423736444343323031434235354535423838353042434242343041333945463543344144423533444346413934433042314142434344393042333135363033434137453932324635353037304442463934433238433033423537464138313043334232414246414341424241463641364643343443344334444343323033343343363546443443363935363830313933453335313231353133383736453338383439414545383535354443303245463842363538463642303739413544324431433546314143343146383631333441433036443644363234443544454643434232443142353639443837393338303835434637313833373330394534453233343542314238373837373046303837373043333638443233323539363937343733344335354642384532414336373537343545443134363037323538464232364539373043364532324532313346413035323239343043313539383033364137423534363541304246333239393642384544324230353937333239363931343137343433363138344231444633433643333633353034444430453041463831453838363845333136464139353937413836363638324130444144353846344436334645343834343541304230303634324138333146313039393333344342434346303231423844423542363245303038443543343136424634343746324334324342464238433937353930303534313035363035353138463634333738324631333437423236424239413939463838314636303639343136304243433031373632413238393631394139363046453730313843333030303737353836353237364544383334393444334235343737333538393935333744433235304137423841394130373435304535413836303530443137393434424232343232353338383830353739423635384433353037383445433141453933414139323934353435343832363136343730354338423645354545463834413030453644353635354536393643343542394236384532394244363745413335443432314232433541313738334235443441423430304537363135454232383534414132384238393134414531303843413042344443364644303037434237313531323245303335363142414537324334373332314237344145324237444535324637393641324437393638313732464230443839423245303939413435313938423036443436453539324343323033363635373530334130393832453030303737454633383930313137304332454142303136354432443434454334333845414332433836434632353836364145314143383938313531433430443336433243453438304144463137323046373235453244383945394332363831384141383838394242454537413438414146433043443130424136434244363630453036354332433033303245313945373531343932453534433136383642413433373941424238433835434139413233323143314143433438324541394344333546393132303141393545363145334344413135374530313630343334304235453138343533344433313544313237453442424138443331343044424443313539384144454138363242304237373135413632453031384633373746383235304641423833444431464534424236453031384530313331313830453842444530393331454531334442454235303945303137313541383239343434433431394441453430373942383741393942323936304544313433433536413237413834313741364231314232393738343538433244413744423142353733373842394132363039423038413835304136354445333938323542413641463639423142423444364133383843443039333635454541433444454442354235453030373938304245433545453041413444443736334334313044374445313443414441443532423538383939424241383045314331364446373842314643354143364544454145453038383044383333343935463634323330443134364435363935343741383734353534364330423442423537364146433142363539463642413535454331393546324343334231324337363143303936453337453538413643433841353042443844363646394238463542383146423233334543384534344232414439423732364131303737353831314235444332383632323141313136443136364639434536333239353830343735303230354132463737363546393844303736344236353036433534424445394146313141453033374437354342363045433237383843443246333841453436323643373338393433393645363838423037423633313238353045453236313445373838383141433434413543304241383044363633303041334239414136434435453739414533313243384538413235363638324439393633454532443435444439313536444445363346444441423837383446353136354433363130314444313637463531384539433531413143444437363738444631303544353443444232323630354541433737303539393041354330303033324142313844313633304532323041453131323137453334443532444338363343443543333531323941314330353136434643344331313232434336423031423345363031433134394641434342304637374634344144364131443044343238363641363539373432463431354646443935373141303530453046314545363142334232413638463030363345453243413842383531343042333345313241323841383135394341414137453635313344324136324442433334463739363142314530323044383546373245334237453037334132303144443542363945323235423446413838383646393842353531423336434235393833393433303242303444333632394537434334313134304231313330333339424137333742434644343431453445384542324133423343433137323032333833313841433531313744444546333642463634443037343541354135434331393839343030303743363645343441383537333330383034343545324541393730333935463843343130413343453033453232333733303636424343334138354434394530444645453234363532453633394241454645364536334130414239364333423146363933463633313031303330313531394232413737343436393534323145364546344133373433423137313643324546364642453645353432433131393135423534443631443932423441453136383835323032443438393742323130454633333630443632323830374343343646354435303343343143353339364546364437464230394131364536423842384332383536393545363938343937374537333132333746383439323838314443323941453033323530393945303730384532303632463146313838354146433233373044343231344442393145443030353035354236434339373436453231393030363046374645343030443839354545443030453734433245333138313541414537354536313334423731423930344442324646344431343534303330314638413630383844364531423631303836383134303644434330303345323641443134343137313436364331333841414331433737383634303030373533303033374631394343353530313031463431463838393744373030414136314130453046373836413833423033343935464639313031413835463138393435464141363530393942333646334239424643353141423042323933364534384431394342454434383535363438313235353136353135383544444331363644344542393031443339453636323041303141334234353938353239303532453936414542333531354144363143314142333130433345364435424341443441394235383335423730353944363338423942453733304339393533373541304536363635433044353032324542323643434545323334413537313241453139423238353436463335304232463836433831344543313535304632394431323835323144384441413243453630443845454235373244383835343536393633303142354344434235413139373244393644354546304234373445413130414642443939344235333235304345433043314536364343383532324343314533344143323639383841353039444139324237334339323731324230303530423546423830343031344630413639354635324441383332353142323835304638323331364441443836324639303830454430444334364530324133433638464545353444444232354546324443353134323832444235374334353532383644383238423931373144464334323245303244443245313145443441414438393238303130313030463536464535384232423437333239373535413937313036414132444330314244323938363635414244364545453937373339354238313530434132413332384444434130374243413238353034443539454637303735353939374641343542324230333136443543423345394132423532443036463141383145394339304430444343354642384444363931303446313432394630413833304331324432393931424132414539373335324630463546324338354133374143393131313045463838313543393143434646303039333837333030373742444433313437314246313133363041333642444632434445384232333541354333333733323730373243424143363930393843394439464234463632363746423943364139444437393936423543384243433230423341383544423538394637373337443943444536453138314446453636394145463332323839343741313832444441454542374639394145323138374541304145353343444333394343304531444231393432303236384444353831394342413043343745333141424443444444363737334646464441303030383031303230333031334631303730323543414639453833314232363636304443443034423739313934414538383338463038373235423945383446454144453832414538323938323131363437413531353743424334413041374243413235343938363045383330373332433941343136384643344336314345453345413245363546383433413033313144314536334545443346314432434633324144343033383837383433413635343935384236324536303639393736363630344144314538394136323746423934343836363138454638393643434337414243303631413845393938323331453536453238464132393130433446343530433542333442324535433042393443333432353337303033434443413436413232434235313543423935393436463643463944374642303032333141313834393542323042383843443445314344333130303035393843383942364246333133393639463237343437433230303734334542453632323137373342433130423539453638383043333838434144423939353535304442413844413235354230363141383435313446373038304545464633464630303930443436463731314343343531373335314336453632324136303534413330423241364434364630373331353545394246303944413130313644463237453231303246374345363343333734373236344339384344463130383630433845363230303333303834344443344544453630413843384633333245453445323132464138363431393646463030373130343731394632304146443933433038423334344344413841354132333544323044303433373145314241353038353137423836323437303844303138424139393041373331313431383133323434324631383843324239393730454344373939453438413131324535353834313436363341384536373333433233463932353841333034353542444131353738414344454234413930303239313332444133414444453034423133363430433135333238373732433632323538353335314442444535463738453636304336443946333339363633424341354242383343343036373637334334413637423838433433333238313935383444393033353338363536414444354638383239393939303533363038423235454531383638383631314331394144423035413942383633373139334435383936393939373346373135343337353730413046363738423741333845354137314430323036393844334339303831424341434336323636373346313130453834434334363542344146393941384442413542333632363531333545353934454630384437434245443830343646393844344143323831453834314132323045334133343333313443443033334432343337314442343345463331304239343232453538454432334443393635323646373243353436323141313731434446313142353135413338384146303641334344343737303335334245463039363946383442303633454646303037324539353333303541333530303644343846364644433331424435344346303538443831314232454132413344433846353641453639463632354436454630344345384343413942363035443930343342323635383239393641433442423537333031423543313331444441354231433230353944423242413631304639383441313945303838423232423445434139344233384246454535313844414343424535353045454530333732434544433236303143363635333839373043303431394238303534333731313630313446333136323537354544434244324332353245323044444231443445313830434437313031304336364242313144354435464532354430334446423442394633384246413146463030373639374235433645434538423333333330363235314644453531373839453131423332393641444146323637464632353242413639333739363841423944343630443839354135343044454633354139464646444130303038303130333033303133463130313934433438343344353739323045303435323933333244454533393836353832313245363537324433453838444535343744333530353135323945413143343635434239373239323843373345323631393243333246363430313939373244353837453632364443343336353533424536454533433838444631393834303943444246373244364642343035353630313345373746393139373330363632343034373145414141333042373534364432413433433444453036453332453734344146333237453839343246333241324337353843443445444644393242434544343742304330374335353335394234374638433935313638313932453631373342443239413433354542384442354139373041384145373934304645433836454641464541333842373731353045453236393545323231413536364132423838324431424332313531433542304530363439364337373035444237423339464434414634414443334238413338333130324336303230323136414533303232333733324230333234463130313239354543394642323238364235343435423139463644354646393239363842423939323632303636393642393738383035413737354642383235354638453438443935353030333044424435363733463732383435433231453538423941363632413035363141443645354145323844444335413946304239464143434137363245383631383542413138324631303332443241333033423444324542333732463444364137363344324332364335344631373135303442313834313138304133443542443046313044354343453136443539464443313736313039384441303733343139353443333333313842343433333231303134363242463345323535313832313443413033453737333132333245443942353936333234413634423238453544323638363135314446303439424546373334324532333435454446373330303232464543313332303344464443423139364637333342423439373242383246434536333734344135353042394146413434353232393231363444334132383438343238444343363342373346373938363144443934444136324334423334363843343337394239384632394446383843444236344135353030363843343542364536313836373737313831354445323530324438333243384245443138363630413233393433413045443343374430353745383834413833454531314434364642374139423936384230393432423939344134424137413730354342423130323636314632393731444136423332423344324646303046334641384543344139364333314343373731434235303442343238313935363331414337323432304532463635333244333334334446413336393533333146303839434138383132423330314241313544453137323639344437384638393446383943304545304335433131414538323332394334443246413036363135373939384532304236363033414539324131463231313032373537313235363045433230424441443846443931434442434437463532443037383846383938363235303443323933323635443133353044344436323734303632463639393132333042423938384336343330334441303239393531444335414434323631433045334243333139453231343246373332414135333644344145423042414538454137303444314433313246433941463130333942363639443246343936453237393645363739384231413935444131373745323746464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(5, 'Grains/Cereals', 'Breads, crackers, pasta, and cereal', 0x46464438464645303030313034413436343934363030303130323030303036343030363430303030464645433030313134343735363336423739303030313030303430303030303034433030303046464545303032363431363436463632363530303634433030303030303030313033303031353034303330363041304430303030304231333030303031343933303030303146463530303030324636304646444230303834303030333032303230323032303230333032303230333034303330323033303430353034303330333034303530363035303530353035303530363038303630373036303630373036303830383039303930413039303930383043304330433043304330433044304430443044304430463046304630463046304630463046304630463031303330333033303630363036304230383038304231313044304230443131313430463046304630463134313130463046304630463046313131313046304630463046304630463131304630463046304630463046304630463046304630463046304630463046304630463046304630463046304630463046304630463046304646464332303031313038303036453030414630333031313130303032313130313033313130314646433430304445303030303031303530313031303130303030303030303030303030303030303030303035303030333034303630373032303830313031303030323033303130313031303030303030303030303030303030303030303030333034303030323035303130363037313030303031303430323031303430323032303230323033303030303030303030303031303030323033303431313035313032313132313330363230313433303331343131353232333233333234313631313030303230313032303430343033303430373035303730353030303030303030303130323033303031313231333131323034343135313232313336313731333238313432313430353130393141314231433135323233323046303732333332343330443145313632343335333135383242324532333433353132303030313034303230323033303130303030303030303030303030303030303031313330343030313231303032303130363135303630333131323133303130303033303030323032303230323032303230333031303130303030303030313030313132313331343135313631313037313831393132304131423143313330463044314531463146464441303030433033303130303032313130333131303030303031463534433841343532323931343841344639433943373236343339424144384236313741333843454132363342373234424446334437383737453542413744374231303144413841383344434136433442323843363638384132304544454345463737463345353232393134384134354338443732343739333333343734374345393831454133454443363430433133444339313342443835364539423832334341394334413246353342424332343931464533343233423242454144463744463346353232393134384134354338434632343739303538434245353446333745424142343036414546343044373734393638443639334142374242383338343642353136313730363836463539354343364333363934453837443646454533433032393233353644343843464431394233393636373531393337313844313933334243364443413241414536343639364237343441353835413439414244393736423245394439464342353931374535344432443041384232423145434337303445383033444344454446453745413446334445324641303146393541423638413030453135364236364145363036323546334646303033354538394133443733423344323932323736354433424339363835343830374639373931374533433342354144374144323646443138303936414346373344374246343846394432393333424346443343394643444641353641413442303045393635384143454430344541363936393443453439343635464345394130313644304432324444383437423441434238313230334231323144454441314535364141353937413938464130453642444245374231463230413435323635463831423939394639454634344543424439334142384642343937373131344537304242414136373843383733363234393938464230444430453639383536343130344546334231304243443434383939383731364541463444324236373135343841343532363446453737374633344330463433443335354231443936323437353145343939374445354543323635334343344334303032364438353734363537333944333030394643414546334435324331373043413638323135353642354446343945363934384134353233303342373935464339374144423932364430313843313644364341423532313230303541333445413334343344333246454442393139383135414534324244443642414235453739433232444143304433373236314335414237413546333441343543384242333841434334333246344542443839414334353744303031434236423342333835463537333444343643303645354336423639313746334442424530423937434634393835434534363834323042353038303637384235454142323745424536353631353730363038413634383242333338393434393446314335434445383243344430373436433930323841443442463341343842443136393433374335353344303545434339314143364131344633433838444344443145324633413244363735333935383636333137453937373133303639334233374235363642364131423241453737444146413142303144324544304641453544363733363731383443363932464537334439354146383245354130374339454139413744433732303537453844433437313532343645433645463443314437304142423246393642313639363145324245354241373938343037333542433537384535364436443831393835313536443737413941453533323144313537344630343244344533454239323639323936373338314232443333374343444336434434384443423935453844393936384432373744453635374137394543353831323242444443423035464433423546324530363733353237393541463539394345414143433536443545384342394530354339324334414342383344303939353746464644413030303830313031303030313035303246393937324637433736344336453842454343464542344644374342374545444342463237414646303037394137453537353938364434443446363242363745424642344241454438343733344442344234354445353633334239353942384539443932344630343231393043443630374338393434414637383835434644374345354536334139363631414536364135374130353336453235413933354241353243374231423731433337363446354442333732383645323542463739463634343043363433324238443439383438313536443746444342333244463838394639333931353745394232464434444244333936423539373045453645393336374635454242414144413335393945353632384530393939324432444342363843343646353444463439423238464539364333364244423344354437313743393545323737383944453041463945323742333545414231444544374446364646303046344635453335353245353642443131304145353938453943333733373942323934464232343533364432303235343646394439324344323842324339453539344333313131324241413139313930353341434338364335434641333737363045364341314636434245393643444439343139364536373731454339363236423142464334393138443645443435443535453642374145353036444533373246364433323044374336343936393634394534463638443433454232384134304534354531333545303437313539423931443346323635423033454242353336444334443941383344463736423742323536364443413541344236324535353733453236423738463638443046444230454544373233323339414638423633363232313044423634443144383934433935363330314143384534373039354244423736423643423541464437354338363332463845394539333731373033333433454332414234354230443839393734424233463130414546414145383736463545383435324334463943363837443045453536334644313641463143464230374145453039464632344330354136324146304338423633323543413930433634344431343331463633413241384439314445444234303542414634463731333536333245464145434545464546324637363946363139383138424442333634314634464439343542373138303742303345394430384531364638374133334333314333463046363444313738344344333138393430354346344442454539323241393142323444374336453244374433424232353339324435344545314238443730413342313945323936424242424435373745323532443932443141313535434642443536384333414341373144373742353543373138453046323335434346383445443642413144374442313235423644334146383945323243314541373243393244383941314630323243464230413934423736313545464241423744424437433337343242394133363736343630303346364131363046353641383139353641363042453742463330353932463131433531384144463043414636313335423430464646303044304539363642463233414234423130393235443644383643393546363135323041443134373544453031314233363341433435453244303530354144423130333641443546454241373534454245423938444234443235434346313138394343303039303033423243303646364445444142333335443236353941373041304636314246354344354636414146324146363141443442373741454444353238373437424344343944353646413242354542463732323545414636384331363336313237393144353235453936323332453846373741464141354646303037463533464439353539413933413541423733303542324644383538393742453136383046384134303037363631374438424132304144304639443038323438433338343339414543383342363239434433423345434441434139423833413442423641304233414544443942303243353738414530423533334136363436433732463233353446313936423646383933343937423546423538414342313845383644424530394333304438423931353739314333304538414143433143453939384437343536453436413643413635393234443935443734373233394432433936323835464437393046393331374133313641423936344237364336413646353938453644354545354236443433333739363736343544393243434330463536363039413037364437353131354636343643423141384242343246343645423142344642303645444139444435364342394632454235393442363130354241463541413746443736323746393042303635343230303843413636344239374233384143454233363844393245413036353744414141363432433638384342354546423632343346454433463839423233424336433832363833354345414645434332363341314438433942303645384235454542323632414446453337363346463030383346464441303030383031303230303031303530324643313341324243423934303237413033383039444342353335373737354643313238343537463044373832423139304433443031433233384531453136333230324346344544464332453641393036303832384645463843414332323131304233383333374544414231433932394436333038353930394145434630453736303341434139354644444330323130373045344632453443314443433544433331433443453434463131434135414133423430414231464541353032394139433338434630304143463034323835443837353938463037393939383943453538353934353336354539433035384341373732354130324338353935383444314436353031433343323345313636424132373943413343333437343839434134364132313736413642353736324544343130304242353633453336363034303730303832394343453938344337323231303935313632433731393143313238333533394438343446433543413638443734343134364134303941383339333441373043323046354438424334383843323641324632423238374338333741434630363042383236424241423942393032334538353132413337304331303134373237363936423831353337454332324232423239443241324632424141313339303942363432393741413037323143384231343235353937323631453232374530423838433932333231433541384246424238363745463845453239414443414544343541423038334630393932363134414330383932443431443935323735453342423843453433444444323537303239444642364635353845413041323130334331393136353131383538353935464333444138423038344435453343333945423039393236313634314533314430333741303736353035444243304638393530464538323741464535444441384537383038323035333346363331393346423143374646444130303038303130333030303130353032464331353738304445373343303741363135384533303846453241453741423531303838453730383834303236414644373037463133354438333139433832313633453034323037303938454538394138414346323032313539374436323943443233383633373235393534323839424442433338324544324231463036453530323945373045353845363036463443323243344636303732374437323135354646303036343530374130373832313631363339434139303734383146393138453642434238344431433736324544354439443536313338323046343143424244313732313231354443383135383434463438444335413743434546383537423038373035434230304630353137413931414133373236383538303943333843324345313137324346434142344643393844363741413743373934443732333132363344373732323745304537323638433943374334323844454242384631363134364543463046363834313045424337374133323245454341373236423338323745353932343433323635303445363634304538354432314338344435323033394541413436363533383130413246443733383444383432364234324330343630303533414139353146344530334341364343414333353430313343373046313934443037313833383733373238333742353034454537423432373339373732304534343934353939304538443331434242343134334132384431324242353635363341423541393830383431313430413235303435424330384436313335453046313834353032383134353737373436313431443934453645353631363130353934343232384242463034424330354643304341313845354338413238373037384646464441303030383031303230323036334630323632314246374533343233364446463332433843324246353233304138343843373233354135383635363932433443363833353243384546344137354338343041373746333341354246464644413030303830313033303230363346303246354442434136343335333043383445453138303937343539394342443239383839443046303739304334363045324243423746464644413030303830313031303130363346303246454333363833383044343638334342393545393737373034383844423645453242343338453537333742333739374437354134454531323430303734454446344538363138354638383137413646383830444438454138413334323334443937384533433639333530334444344241394632313835374342453346393843414642363933423039444139383030343641323644443433383635383537433536413845344443414145393642354433354442384533383041463937423645313334434433364439443235344245303141443742354539373731313030363638464444353337353242393142314145454336374131413843373331463435423437393635353742444331453334444239303244314334333546453346443841344339454134323435464343374638353243344639373131343736423241424636463736453033423239433246433330453745333544454434344543453233464135334144384230433730303738384138383645463736384630343238423143423142354445344545373133373030453343454134363544414643353431333541354230424441434439453233324138433237453942363931303838414644433545394341434333324138443337314446443132413332313437324438394531394436464135454533384438433235323330324444324443304130433345444135384133463438433431463343414643413938413132333646323345323332443246433745424142434132453338443641324446443243363245344432364441333532424232303643343845334343394645433634444143393933384330463233433238414237344338383445314532324242364533333339384531453335333431424232383434353142363832374446433338463844314638393136463938333337373941314333354539423542353330464446394437433236454342313836374434354430394536443844314234413735304330413846434133433246354239444439373933373241413534304439394330383737333938373337433330413437443936453834354245304244424638324443384237413846454639353334343433303533443541463145333944413942364339373739363438433641393644443338373831414544434246434338434539334543414544394634334644383642414346454237303746314632464137423942393931363334434145433644353234334231444237433436444533433043424146343944354643323436353537444336444537343443334141433138374438364242444235373045394637373831314634313945354338373045363642464133324230384531443341464542413444453035353644464137344343323243393837334231453335453334363438354642364441343830453333354632413538423743444444443138433142443446453630303733313230413430354333463643394432444337434331464545413231393244333035363932353934363432444639414137364443313533423333314634454242313436393033304230313439424144423444313642353730363035373644324445343743424544414443434430364539393142304546343245423734363530324334384633414541343233383846453146303334394241374539444143433342363446304630334634314336443143374337394638374433333039394246343631423234324137444445363435364244423441313636434545334545333544383945334431424331454134314637384139334232434237393444434542314337443934313737303334333946373937313541384439334431444431414645384434424435313142364234313946394437464339364343333134424646303035364245374546463030463744303643433537343843364234353845413533373432323834393130353932343636333043433038433644374434303931434230463241303235454136343844453345384634443842354546463644364230313534354244363730434633413331343234323832303133444331414434383033383531393630303631383736423330334133353734393533394639304133323644343546343944343445414435414238364146463041314443334641443146344235303431313844363445324637464137464534423638334641393843374541413745373535464334353734363145313442363136363139334632463241423933444434333844413937344641364445444133423139434645383345304134464241443941464442343335353545323446333645354535353234304644344145304139353346373738353439423635303741344443304630414238463537384431393231383734414145344345373444464341463541424236434139364541363143343843383142373042443345443045443635463843353643383245314532314239353233343942353930454538354546304438384636443743424336454236453633393335333238393135414441354635464236453244343633314237333145444136454232353846354635424539354636373141334231443943313246373537353241343737424537374541433238364542374642423438423538464434444241304434343146334145444541393144423244363445343739453146423044424546393741463445373243343345463541423637434142414232413144393931374239434235353844333937424342304638384335374442343932453639323030353644433844304431373343433531444334324535363531373034373036413142463833464637373644383438414239393546464336424142414639353543334538313433353445453644433246364642413931423644414134394135423641333730413233303338424639353343323231393045394435414137363144314432333835423342443245443737393143374446363344313645413043343637363034353435313639333136444131424646303032423138454437434635313143373937304135384531313642324441463835464442353735423332383144344336393845423544304533334644393346333044393042343737424341394338463331353633454133354141354538363543343537363737363735354337414632334544413545433146453539363542464444344338414443323834353235384334464337433642423931303137464446334137444138453835333843373743414443424439354136353136464131313845304142433435333033444346383533383839354443313241424535453343414133374438383246423939344538384435443438454441363434423532454333363841353743463143344533393945333432323033353342363745333544413635314432374138363943454143433731354239314642444144464232454144384139353230384636353645374534464244443237373942363646443336464630303736323338414237443539443330443634453344333836363239384534333146414142373546324637323041434138323635453743384644393435353331303344454144313931434337423238343533354345443838323735333741393446324135463938364439384143464234334139454445463436374435463535374331454644353737314237313837373146413538354639313135463131463241393742453945464332374436424535463941414335393437393931354135354435413645304133414246454442443439424137343644364336434136343544303438314336444341463544433933333845453430463041304430354234444341414241453736413639323436333736364537443543453844454535364337324643374636384346334335374441314444343333343834323543373643313241443745353630364136443937434232364546413237463239464633304235463045373641304343454143354335443835463232363933373342374236413843383234374536314335363937373130394644323645333646423046383841393235394345384646364231453534313836353546304330464143374233304530374345423733423646394132344244453844463443324542413842453836313735453336453943413831424339323344464131434632464633303334323544434544353545463946373232304446353143364235364345313839303746393135343744443445464531463835303843374633303831373335364643393642363334444546303646374230414430333046433642414146304335434433463133353136413642433332314645363942394246384533344338323445453644423242313138314641454234364230453841333030434235364443343643383437313445423146444634434330383946364236443333413033454537444530384139423644423337373131433533414236444342374142343630434144374131323639454445453746443638433630353446453334344543443834393146323646353533464341333732334235323331443731324237453642363233454141303830374539413843463944373631424645394136354435413645334436333835343546333639453231324134323244424338433842454238423944423941453734423246434245324433423442324541383041303033393543304139323644423036343531454130423836374531393536423844464142323338363745373532303337453034363339463046414141443145304437433638323145413536433032464441304437363942323143364230423638334546373835334335303641363834464630303330303141413942353438303046374133364239393246433334443639314446383636354635413142333744393944363932373346423745414133384232334137353136314330373935374334454439464142393131383330453443323933443342364445384246433333314335373946363542433246453945353546454345463230374433323233363137453136334338384132424541324239413943433532454633364333464143383045413445373837304138444437304546373145353433344537374332414433304231413737383537424142364335373342384533344646324631413745313042364230423643343239463439303745464138453230424641443933314230423141363535384642313235424444334341423433333638374338463041383541373436423443433231333338433535343943393945393441373539443543374337314345424241383734423042453143433742364242303243374134314246383141323632364544444633313844384435384634394632423537363845453838353531364246314636394345423136443443444336393636364232383646343330363043413743423444364243434535393531383438463536343739353341334646463030374236463836333943434133383738394236343638344431423930413038433246443538363731313135443036434530453543364435443843384233373431463133344231393339373131353838424432424544394346463030304533353732423639443036363731323246393841383941344436384530394430304231323835364636423941343944444434314637414336443831433246363334303239324231414439444234323242373731373236303735373846324134463937434631313933363742383542303934354144434234423246453232384545313138424544393331373536433441383146383531393230333744353841394244463146314139313945353536394634394637364331373936314634314437383732414542433739443336383231424130444546463030393738444138354630384542333230373141464630303235324234324335334536413936454341304337354144463042463241313235383246434644303246433543353835394432444645413730303437394644423435453335333146434330423735343731394245393337333838334635464232463439463134413034463731364537374636353735314234394333463842384430314130333435433445343745384246414345333735434141373146333044333237434245463831444337394530373831424431353342394430324545363336393133353146354532333836313741383038363931374536303139374232323344354138394235394232433732433642364432373634334643443434373044453236323036413336464434303445343239313841363936323341393245304438444243323943464341334146453543433645454139383035374434343330344630453338363134353532464133343145453330464446393537464644413030303830313031303330313346323146453442353032354132373138464236424646323332434332394233383331334145373936334544363135364239383536463539343541393744303645303245344137363343324332334435393731433031343241343337434543433534353135363842383433424339344141303542353835443235313645324239384638453341334335443243394635393238323943394338313738304237393834413643354141414138364537443330393835373446444331433136374130433638394142304444323842463046373141303339433542343345384638434646303038363343303631394545334642384238433238463435464444343734453730333432353744453630454238363832433633423730374237324642444138353237324343334230414531393435413736353944454445354531453144383739383842383832343841323845303446314637463939433633334331303035443538434141423338383144343931464234424339354431433534413139343743424335463346324646303033463731373933383235463243394531374637314244343943373336463634423041423630413042463836424334324244344235424538384146304646463030334645303039464437303039453546383635393931453537343941343236343341373032424131453241354342323444453341333633353645354532323344413344453745353343393935364435413336314141443031363035343945364143363936353846344345463136413845383146354545373132374545454331304136393837394432363441433439433435334442373542364241333839374235354238414546453844424637393338433439363239374233423442333834464434304643464244453731374635303939333842373345433934364135364630373831434142453736373144304331354538424535463530373843423546373946453541453345383136444333434443303042344533353841463233343744334630353936363430333934453032453630453343324142454442443744313132304645433030453036393445453639374634344641393639354242323233394237333242353432323437313136353537464146434331314237303031393635313144464246434130424542393544423736433235313642433935423243463442323430393232384445424333324332363138304237413439443343334539313835363836384641423137443338464434413945354437433846343742304637304243364231463037393446463030364333344436453545313537393636464237434237413831313430383134324635354545313441384138344242444246413137393943373442383530364446443730304137444133353445454130443343314236354646414232303033363743454131313046454632354135454636314542334543333246384646444541363935344430424130353833413337464441363730463433374232424445394342454644343342463433363739324133414645323141443142353638453046323237313638303730344130304637414642323244344436414343304132373142434437383843414637423932384446324243464630304534343637333535394443393743303644373033443435464436344644433138453045424131324542364331314545423837463234304543423430414638414433384639344130323436394246323046343745434339434633424437413745323542434631353639413146453533383242353444353942414633453046423844353545453045304242413330314341374439303232304638413034354342394536373236354438313734463034463730393335323730413731314636374635334344393231423146313637333637373344414341464432354342323635313746443932433143433830433036413146393338413832353234453131344230344645384630434233383331363834423642313845314234434237334133313633423238374330453645433831414133393145454232454141393734444146333134433438323033394237354237334541414131344331423939434333373536374142383731303743343937373430353637383746383236414131454244463137463932353938423543354131463035373738353843423243353146413834353933364435444641313839304442463843353245454531323936383736313533313143323633423544334639464343374332424235324345423944463246413538443241304133413143373446413946354544314246444231413845344335413146353137414333343339394636374641364639384234414344384536303934443343423339384430334144363031373738413045394244363142333444424544413134313644314633453543344230333839443644304532444444343135333939303339354630453834373530313938413246334346303945464630303842444339443131384446443446374533454136393337433046354639383135433532343037414431454539423846343037344532443546443343374532324639333637443032454544453339393536303431344242364543334144334445313442384136424637334133354438413632334338364234343937373839373943313343393338463645453638344241374134453932363839364636433541354237443744393037463136314536373430324646303733353041364536393945374136423337424644433242434441384531363539454334444446454238383442393741394542454637383834453843324545344633363235373345313831413434393134373345324246303535353637463130374431454239343535443434383743313034353837384242313838384330303144314443423743344532323830463746463030353531464331384445323946433941313837454542353339374335464139363442373032353737414132424343423839463641303934374233463131454130433333383446434138334638384230313035303346304332333041413942303537424231343345423744344230323045343132374544394238353733443543383639443143434238303244334537364636383937453641333044393435423138423145373246363632333734393139454244443733313532443644414436463934304530443230303538423742384631463337324533313738303938333641303143394435463246314231363936394234454435343545394436423737333838344431463430373931343738393943453431394534314535313332354642373730453832453930464330433138413335364432464442434443363037463046373143443033323533344546453845433736343045393731304344453830304636334344343546313233334146304142394444373443304346453433463741343134463645393144334545393036443734364141424437424631304543303846383342344641433839383345384642374245464630304334363230413536413335464543464336343646384141364235393646413934434432464334464543464631313831394241453039413845353546383839354242374235443937354636443241323543383943383738303646333231364433364545334630363346423939453046443641364546434145384632334435354343333533324533384137314536414346313730334530343644334537343341373836373637304546414133433833433434324138363446384146423136374536373534354144443945354146433430334432443746373531383642323143414241344246304331373936414630333642443933314541453042353330414137324141444435373746373132373237363033463637364633303038323636443431463536434445303531344630394542464630303542313337374431304446323731313738364330423137363835413542363731324537354635393243324643314644413434353245423435443745343543353041334441323341413543364132453235364143384133453041413739364346413845434139314142334545383134464630303530343441464441443544353338383632453930413346363132464630303733414536323336313545353930334238333942343536434639453937393343433045443334313839414543373945303637453635443645323746353434453437413834353641323235334535464643464239344242363546423742324246333134384245353633433843343843443632394135433332314342373336443046454438394342353545443832453946353830364143453246363634423743314139454446333341443945344141443537303637454339383945333533444242463533333037393130434443373842343031414142453636463045373941413135333942313139363836413537353533343441364238383141433245363638454242393643304630324430463044324646303042383834453937413033443730343231434443353534464441393646314343423041364642423737464334364133353342433445343746423843333945353941463732423531453437324632374239433845333542303142354243334543314433374430413236364342393644374533384346424133434342353741373346363746453430323734383538443532373744364335423439413546393032453634314642334343334133423638443942463137453146373133354541434331324345464146464134453631433533313044304136384631433933303135434333373437323332303535334443413433343035323042424237333244414444354431364638394543453445373433393832353432383238354534324431454634463239373033313030383731363734463132394345374542343244313437374632464635333137374235464237443441313730314143364346373030363935334237304342333546384130453544394446443643304130374333363943314532413132304636343244434646303046363733383135384237373946434335373838364433434539303532454636323343393233363737323737393035444439424432393730374445383431303634324336463946453443394432373632394433433744413539333233323741343133424345303744394346464139344135353543334233363535324538373644464434423632344131333531433142353046314237313838353831303334443239443830463535424334373538343146383532364331453437443733313543394442353132323045303644423937443332424436393934463732383346383944314346343936453035354239413642343836373143353739393444463244353931464644413030303830313032303330313346323146463030383632354335333030323732393434443338384236304238424141453232323435463134374643324341363539364236463130304637334632323542414537453136353933413937434533334332304438373134334237464333363135463031354230314233423835343445433845323232323146353246393442323030423144433530434643383143433135433435433133363743313543433442433934334443413832394432383234363741433536324331324433423141343232354632373534463831374334453045363345323345393134333631314337393934433038353139384230363346433134373137433332454645354432433936344231463233424430383831324533393835433134434132303834453339394234413644343644463041423132424645313643313635434438433041393733393530423837453739373131424237383936304245353135433930334632433031464346304330383235333333343633413635304439333044393736394630343934374443354232334141334635434341313244464532333139343037303445353546304430433537383445373137383835373443453734354243433630374343423933434531333839363542363032424639303039463045433542333834454338453541313539304336374631334142334236333735333738394231374431303342323732433635353431423239314539313745323546394643353233393943314241344432383031443937433745353244343039443346303541344634413946353643343243383436433936444335433237373336453244383434453533303743303138384632374530333144393134463532383539433933324636383733323944433344343235303436373131383138303334383035373141343231303846434643314143343332354436373641333138383637423346413833314338454446373938383833363135373233343234364135453535343437344439423244424631303930454633423936463844384332424530423530414646413445314541353135413833423733314442363143453445344342444534344244323533453930354642393037343937414438373133464646444130303038303130333033303133463231464630303830373346313442334239373335324141303034413836364331454531333146463141384134443441393838333043363537433246383531434242343631464630303842373345333644323339443937463031463137363039364330324342443533303442374341424334373444364133443643353239463835413839343336354441454131423244393534364633383846334631343735463132313344344239434245344330434434363336323434364136413735374344303937454643414643333531384431413838464335384639354142373132383938433433314134434636413541433632383635344437433643384345433743313138464333323034384646303030324146393134373330393037453135343530363432363043323434373531303545323331383437373637333936414646323632333241364338353632453534423237343333433131344336364245304236354436434636463130334533304133464335453933414446384145363242453033383943413235414133454433383835363633313837314138364633323833383839374643414130373332383433364530353531423534343033463239453333394345304130443846313239464238433533313433373730363537433346323345314533433743373146383936423631373239333230323046373039434341373745333043353132443342344643423934413944384141413232324343384631324536463646333043453039413745343435423434463831393334423730433030464134304139363833434136363136444438363342324339423032313332383532434342333939343130464334323834433546383644333937423233433134393832453644423238383738363143323838394633324437314638333946383741384437433333323330394342333938464630303733394344383544373838323930453237353338454330373533384342353433444341374337464644413030304330333031303030323131303331313030303031303932343933334341434343354344323432343932304542423945344532413132303932343830444331373637433739413132343543363932303342424143333042343930463646303639443334413032364232343843393735373935344630384439393932313633334545303343383545463836343933394543384242303738393042443932343441383844383843393235314336303433354535384238373245423043303637453230443932343038433143363133384230303146424137324141353235423338393333343541464245313935364334353145333839393742374544323439344646464441303030383031303130333031334631304645343032443830364136423337443935393746343038434441393531353239444435343531363131354535463030303541344232383436453136304442333242363938373138324332363632314231304441393836303945343446423534313841323732364344314530363032423034313830304235434546373146373831433335333441443230354534434333354132373731413530423034373435374541423838303238443339303335303235393134454133313439443331344438443130373736443231333935444633363641384643453741383031433239303042354332304146304632434335443443463631343136383746304335434132414639443442353430384139363245423746433945323330334231414531374330373734344534313341383232304344374232453142363933394342394545333134373842343634453536443232323330423830353630323442353545333433413835303037393339303133414134383344313831344341364539303738443432463531353042363733353137453630443038423542353642354543423736304339423939304338364430344331353542394138453141373138383541384441453645413337383831323335303544344141423530444634414330423134373543373134443230453733303641423436324344434341303837303238443032433631394642434433424231343035363846463030373141363031394431413942393437424346453437383941463830413632433839454337364634354641384346303646454533394538433436394242393430333642303543304134414232443133384541314146413141423337343241383432433533344536433346424232363434343941353739333830323244313645333239434443324443414532393441463243424537443435373531363145333545334332333237423543433245464541313030313334333443443745463141344345364341434146454139344530433943394234343341423042363144323436314635453633313830324336414233453743413343443441434144413831383736443434303839434535443841314445334545464136323633433832463433353239343135424635463339394244433035324243353935383335394335443730443846303243353738454541363841383835393534304439313339323032384143353743343543304436444139343531343130463030434241354345314539463733353638314243464132443842314443393530304535314539453041383830313030383542363136413530303542324142384138453543323035343134384141343437383437393934433139363841443735324144444439393844354637313144333944343330373841324146433045443543354639304542303733383538393937314532323432434646303036383030313430443036443636423332333034313146313144423543414341414635423330363236464135313343393631354131374433433435453534443239393545414443354131324639343134454331373136314231433441313238363442423041444138364432393543324437303643443634423144423731384331303641324136434541433642344246313546323933354136333335413639443441324433393333313643393035393543334233303142433431444136443530333430303830424635413343393139424335363135324636454436373342443939373038353030374131423543453037443934373643443434373630353845454634414644413133344231423437353142343639374146303432363636313843443334454535443735363546393331354134424435313435354245383133433934453636453034444141303143323533393038393134354238384145353637444231413834443436384230453233423737433739323343463845303036354543373130454331383932393530383331413837343835324338353138353441433338454445443043444337373730363433423241314141324243323630413838343033453130303530314230344445424534333438353135373032393531313038424241323836453838383937314134453333464138424636344137444139413536324443384237364645353345353132354230303335303535314639383136313243333441333841423735433930334633313743334142393234354133444139383443413035303443324230343544303633353137334431363533434138443833374433303143353941324434343636453046373931353030354541413841453939373530433038433531303331433033363730353339384231453941433039333245463441344234373545323132413138374535303933303035354245463838353944343936344539443033354242453230383736324131303239453133353536303932433036353532313032413537433242324236373845333642393243373041313041413544454130394531313836303645413043453845383332353939434231353246344130434444433441444338443542393745373046353643374135303535323836464235413043333835303536383835303036444142443543314331463230323342363932424341303732304136433541343235423030423535353538313346323142464330363844303030353541383739314434373845344536383231423444373231324638304245323332334234433232443545383137443931304338353935353845303134413136393936343030443638323232324334363046323738454535343142453931343834303537383343433445433636303230373535324139334138363646343930303538353445394438323242343935414545434336454344373845383534433731303541433541443232323541423732453235413941414144464539314530464138454233394130433045313633324232333442454330444233343042363536343741343233383536333435443831373041304530333145443531423830344635313833383033354434344646303041393542413239303532343044393734383236303530453134373744394632443741453038323631324146444632313233353545413643463037414632313538413441324238353245463346383930364433333239373530333444433342374236353336394546333144444632304641323242413843363244443041374130304645423939453738363339414144333135463241414335463331303943323444353141363036383145424631373142323033313136304235463237453635433430304239463038304232393644443646354237443631413442383042363543353338423532453731414238453039443736353835313035333634334538364136433134313638333131333838383230343237363643323033363243394330364439444631314242413332363736444234304541333145313733383231423738454645433336314132394330324136454434383037364332454632343739453033303839393132363936304432393642413238354644344441343833344641323043413230443931414143343334344139383243313534363633334638383245303037304331364544314338423843364532334339303734414141423837363735343838423546323841413032313531413436443642344431434334334134353143443730323131304135303430364241454545323334313241313444314242333945353531443032313430414441343530433431344145373337333141314435364336383835314546324543373444313037433038303234413141444330464135324546373645453533383541363134444246344341344546333731334135363238463739373936443542313235334238373232303232373836354341453432443132383432423045333246383336334138364644353841384133334333464441383739343538353841393642363638434134413937303941463536443239344435413136433733383534364436313641443541423433343536354135364436433139354639433432324334353138334346354337433544344137333732393041323131303238344331433334463832434538323139453842324234453730384439343144394230324331373133314443423933434131423134343641323033393034324234313432394444363138433432463742323133393333433035453432364538423436463445334133324142414631333237364531374430433434454133334236443131344345413631394534303233374130463042313532353538304135444636324230343434334338303839413738324446353634303738373338333330413735373935304637363632343144414130384644433034443545443139413334384245443844453431413836344335304145303532454434343145374538383045463835443536393735423641354237333134353337353938304238433736453344334632393836313231374541343537313543394638383930423730333435443139363636443738304237314545304233463730334130304630333741363732443436433536323031463835393544413241383241333530394630433841413842373932393445424538304439354239313230423431463435374441324443353635314432413834323935453935414138383637463242353332463330434332384246433031463241383345353844413035344334374443333134313843443044384542443637373038373443354338303437363135304535334341304239383833384446303235443630334346443430304538413136444231333637464233463545323339314441393537453038323246343235373943393641323336334235303536433638454538454141373336433737303830433930314330434639363731323844324443444544343037303132424139374536363146373330353034454431414631353130313539453341393132354344303044364442373233423734333238413644393436414636353746423842374638413236313530304130463034464434424641303235343134313644393635324438464139364432453644413832414332444330463237464239344332303739323345443135353230334637324238373534443530443644303633383737443232354141344244413231463131423537443042383731423444453546424235433537363530334637423238333035323041443136443431424135444639313339313943343241314634393041393143343541373837393836323638394541343439324144413933363444324539344234453231353842324141324446413330383845423931333043383436443830343536443844434344443135383144443535424135443846453937324234343542314232433245413244444133374334424434314435383938323937333733393839324345453533314344393441363945453344353945303531363737383339324543433844383131313737414142354243463934353032433743433132393031303031434531313643374239353838393335354144373745394542343343344231413542413633333433393132423933454137364438383843343041423742383939363332453931313435354238453936343535323941374539383345393830423631363845303834344638364341384243333836384341443031454143453441423146313139433031363730443837323642424634414136303942434137304145303038364643443445303934373030314530343743354141443731303033463033413443314537414639344632383444433834383631433941364241413046423842303436413132313142453537363030463545304642383241313044353634373330373042433831433639303036383041423332323542343238423732463730414443304144323433414132304633344138413231373942304332414438303535324146444443423645384432414133423339303033304536354541424142303044324645443334383931443241383639444532323234363538444531343736303542464231463945323333353437374432323042413842353035313045343236384342363343414237463844353741333941433633463032453630353739353432373946354536314644384536334435444138303034303243364533303939414439324139363830344338353230314345314143304333314441443644414633413042314242434335353941393631453336394143393542464231413044453634373639423336303938303037343632433243313042413044353137453641364534363936423733363338324138453541414646303033324334393343334331393538464638363732333531384546353245434137333636423744354336343041443244393533433536373137433735313539343141463437323238334243313942463839363031354346454535343442443535413542393044463732324439303030323238423044303839413232424135353137433936433130443441314130413935393746423846374230413842304133423045373734393441324432413945363943363745323730343735323845383231413132433638373843424541373134374337434532334137443533354634393545423533333842464334363536323243383338413334423433313437333932413632434643353934333238433030424137353141434635413635464143463634383143304235313135353235443246344138453841364143433532443239343837434144424435433442333230434642453536434143334138464136433035443534383543383730343337323838433230383635383839364231343033353542363936454142314545374646444130303038303130323033303133463130464535373136323638303838354437334343303132413533463733343330353141453138313942434138303842413846363642323731364131393832423846344343433441363542434330323546353039344637464339463832354335383930363044314434464630303530333345314134443134374134413031363332334635433742384146373934303734433145374343374330304644394646303041344136393143414242374641383735453546433946394233384230323644354431314135464331393533394434303744313041313534343444334530303935453942454535454434423542463232444141393534324334374234343936343643393746303039373443433030423242434130434336353644393734434432453137393945374335393636393031463639353239393530393246453631304243444543414543323631413631393342374536433236313239414237323639444130304443413741363632313646454133333744313733343138343533434331464631314646353132433731324241423636453330423942343534423139324345323530444534323142393442373431313546443833443431464531463344454233393834464332463531324442304237313046384536354439424145373931393839453236373838433233313338333637443234343441424239443333354536324437323245383731463533423043363532413831344146333044413338454530304130354243464531423846373934464630304338314336313539353542333630353137384334353443434337363441363042443139313038393641443038373633453945453137433336453846313038334131334336383633343733303134344432463746433443434242443941454334433843414631423338304438333642443130303045393043384145354238363430334437304133303031463243463230453139334145303737354442313543373330413830423546413838363237444341343345333746384438354541313732324633453945453633343843314141444238444545324133394541454532423035443436364130443835384337333645334434323535393632413543363338363245433435364331413243434638453034414645313635464332433243454630304638393431324532393033434331443638353845314443434531364246323836393036304534363037434341333830443346443432393641414539454135433131464633304141373535333144304142354330433146304545353238314536324634313038433444453636384134323134423834434432393144313145383746384641383235443639464443413134313336413132453642433443453637324238353044334334413836383836303438343335313837313337374641393738423742394238373932313035373730363943304438383333413133393835353445303130303538463339443937314531304432394635373846413836444238344231463131454544433735443639464138414232353746383442323241303444314138324342444434413331333641353231413530433539353843334346453238384144344335303646463030413843423532383642363138333232413645343330423443333738384138353031454137383132313744433031354246454334303030383246463030353544323332453431343442454643344335373844383738344238463037353333313036443735313445343844373846363845303330454135304134443942414338374441333743413339454636304442323736423946343441373731324131454346383830313442364639373846463030424541314141414446424341324338454535374641383844353535433344434530323537463730303142354341363133464630303933334646383134353636373245453238333145343441423642463143433642304439343846464644413030303830313033303330313346313046453634304234433431304641383638394330433238423034413232394343433344434130443331393430354138313542434332423245333946414631313039434334414338424138393945464630304531424346323843304443304631384537453635323545323038323235313339393938463132393831323938454333383839414232353238434134453739464630303836384132413139393131434635344234324343363642313936384536323046383030433846434131463142363537434237343244393735313545323735303746413935323639463936343544353538434331364644344530413838313045453243413741383931414133453533313132423938343433383543303843354537394635304544453630444246434637443539353143353445343539313130333637383936383934463144433232443733353032394138323842383044444534314333383842364342423436323036433643373130343442463131323244304633324634373933323237333739463345343937314541323041453446333341333939454139383846433932383139303738463531443031433933304436313535453632364543393639323836413342384536333043353431323046373339304536334144444543413643434545343145323231314230464531373837434530374646363033393235343645303943343235434537413839344438344335433246333138314531333031373635334332373738393432344437333135303836413236434545363842334434364234384644364646303031373734454232334232433839373932333439424642384438334443324543383937384341384437423242373936303435444335373838414635314132443042353931343241443130414342433738384546454633463841304444444334423739384533444337304345363643423830363744333244354239453235413646393138444632343543314343424434373445453137433338383530303732323731433635384132323839323034303537383838334643414330443043363230463136363635363131323332333837434635333435424643323236443530303331383642344533314636383239353945354536363839313836304637304542333244333538334535454131363245313941353146363935394344323335324635303442304436313336384138353437344544464630303930444545343837353844443442353432393830314336353543313337453544384437343936313637323441383938434246314634383130324341374644443835354231363039394434303145413033363833363138393446373030313843333743393943463532423632383945413332313532433731393242353137323945344546434337314533463730354233313844364437304644463731353236464630304341303335433433393135393345414337363243324635313231323336463130443531373241343442443046313130313130324244343235313533333438393536304238453130383142334339353134463732423534313643414646303036344633323639333938374344304646303031313132324135384434304139334545373633353133303741393732454446353138453539303143343934373130323838423630313931384332374434333639373931443634423433464238344133464644363331413443454534374639344242324638414446313243353046364641393635344237464434374142383544364535323931343735304243313838463042383834453930463436323645463133464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(6, 'Meat/Poultry', 'Prepared meats', 0x464644384646453030303130344134363439343630303031303230303030363430303634303030304646454330303131343437353633364237393030303130303034303030303030343130303030464645453030323634313634364636323635303036344330303030303030303130333030313530343033303630413044303030303039413630303030304638303030303031414542303030303243304446464442303038343030303530343034303430343034303530343034303530373035303430353037303930363035303530363039304130383038303930383038304130443041304230423042304230413044304330433043304430433043304330463046313131313046304631373136313631363137313931393139313931393139313931393139313930313036303630363041303930413133304430443133313631313045313131363139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139313931393139464643323030313130383030364530304146303330313131303030323131303130333131303146464334303043453030303030333031303130313031303130303030303030303030303030303030303030333034303530323036303130303037303130303032303330313031303030303030303030303030303030303030303030303032303330303031303430353036313030303032303230313033303330343033303130313031303030303030303030303031303230303033313131303132303432313331313332303232313430353330343133323233333332343131303030313033303230343033303530363036303230333030303030303030303030313030313130323231313233313431323230333531363133323731383134323133303431303931413142313532323346304331443145313632333337323134393234333833313230303031303430323033303130303030303030303030303030303030303030303231333034303530313131303031303032303331363131333031303030323032303230313034303230333031303130313030303030303030303130303131323133313431353136313130373138313931413142314630433144314531463132304646444130303043303330313030303231313033313130303030303132463942463530463241463735363430394137303743373041414146383630314335453130454545393830414637304443314442353431304235374130364332344638454439434138314139364231383739344541323037464133463941454431414138383432353741463435353932383141334638433732373045343043303838353243463333433835423537364430413531464145363530463133443445303439364234453144324132414445363243424641313739434436423931394441413632303043454636343338383542304144454234443336413534433846394342443533393831414139353333383933353032323537433637343343423442363734324530373431443944313130424241354534363739354136434531344332364338414244334333434242413831394337413633324130384333413931423639323244423235394433314644353937434435333932304346324346393035363546443344354432373046343943464346323244453543363745363636363645434630333535313844304136344435463044463330444435353232444342343844364330453733373741373933333244323434393535433639374432434231303344343532414533374538383342413246334641303734354144344334444333463638343346393938343635334543343832354143424430443335364533423341313942343637394144374241463843393844353434333246453539443443304636384344463438374230424238374435433835423238363636434233423842423332463436353738434544374332463036333234414138323545353833453138333138443942303834443839434537314633364633373842453837323543333538343645384235373446394245433333383545423531463346424231414441353144313633444336304131393438434443444132424146393734393641393834394541453843394238374244433233314541443143444535314243443839424230394538324230353530433545433136353132344534373242443143333642324542413438374430353943434439393739304439383242453637373431383737454334384541333644373339454538363431333144353136314438434534464533354430433644384136443838313243344643454636344231324431443539443536413938434546373031384541423531353243384242333043454431393544343333434232333045394636323243453342393342423943443541333435393235363935374133343642413639463331433646354430463645333641413241433042333942344539413245414444453839313036463242363038343739314539463339463542424634424345384535433733343144424346334432433737373432383032373545394345414241383543384639384635323144304133324346323630434439304341384542363843313946303136453931353831353144384237423334383744324333453342313330304234304539444431373431323338393341314442323936424234374338374134453433353338373430353930373236363045344434463432413239363630423936393936363442344139413230453735383744304138313533414631423246454338464342364130393538343539363546334444374532323736413733423233313934353836453331343146443046393846453633343633453646413138313436383739353030373539423243434243353042433535443536454245423544313331384244434330444435423946464644413030303830313031303030313035303235413830304133413030343444413043444233333134364438433333304346454136434343313838444445414231364342373833353045334136463632433144343446423142354542453546433245333343314334453245454630353031393738343945313443324538413733333131373131413132373234393333304330323831423942333341303945453739433736423037324142453437314544364534384442333932354432414534323544434342313643423635373533353835313541423245324542304438304330343838314332434446464537443231333337343332414136373833364337323136313630423244444637343030424235364244373142443145414646334137393638393637323935394639314335463644364438324132394438393645353631363331333338464531353438333337423534433042314230303535383044344436334543393746323032433531363539313431323736434137364336433030333234444443324532373331444143334531344336463737413743443746444132424632313532363045443541463041463831313434303042343041304336304342334133343635334234323842364446453630353132453543314141364546463542313832324644373233314237454342384530354541353430344342333045323835424141423736373135373142343046363945433646303041444636383935353945344139343933324137463746323245333638414338393546343836433444423637424132453434414230353846314245353539433842453845323531434145343942423931343535344444303731383537373930354146363644423442443444453032444533414545423041413937314245383241323945334642393438313136444631324631414432433742394444314544444344393638304335423935303145363630423535353732303346304144374233434635444138313744434133443844364536433037373136434345344443303141393438353543463839304638433342453637324639353338454531313030353733343338423032424343433037304145433539383541463946414535433537463643304433373534464535423133453444313042353942414337414343313636323732333931423534314445453837333141433435354138413644453732303042443439413543313935394330304638394534353539453435303937463334443831373739344532373146433846434246304146314546423835384443344142373436423535363941393839313839424331333735364436343343373541443933303544383932433534383938453937373042373131354238384143434231414444423132454338463239383638354638453244343046364442373342373145434242324643344637304443434636353435414142373831363537354233364334344342343532433635353930313242444132423238433745343544363446324330443634304345303539363134343646333133433545334632414436453046443444364137454642303937393136373845413335413539373245453135313937373138323344343935323346393644344141433532454141313535303533383938463132363539383034314234463432324632323739354232304233343641383738424339353832464344344135314245454239443630413035443245363643364432443338444532413933383734313330424438444339354532333239433742384630363945333535433934463038414443344338393831304245323738463931373441424541373938343046414634343343384236424533384246454335444344443435324135303645354339344535354144423432454641393542444333384246353832444146384642423830394334304131414432434637443631354238464338334245414238393046463030453644313136424438313338373339394533463935433632464532464237364535343746334531434444463243464644304646434238394536334336464630304430314143444445314531394238333846304545364444423535373844324246384639354445324630434246314646464441303030383031303230303031303530323834434343434539383837343133314142373730323645433931314343414642364633333734434343434343434331454131413138344343344539384334323630383938353938313333413033413644394237344346413333333645323133333141393842443636334143444433334136323644393838363139394437333031384334344546303939384431413532423046353142384331413936434330333436334433344345383231384142413035394642334432313332424543433633353942343731374141453939384244413745413031303230313138373531333141303830434338393636333441434642374342443543454639353236433141423334353643344644323838303443433744333330453938393938433737363833423643313033303538304537343037353733393832323243334131334132414333303938443043303734303236323337463343373344304641333131353734363830343344443736453844304539383938384235453236363636374635313537313141324343344343433431443230333938363031333141324439333330434442304143433444444545443933363430323636313842333634433433413144343843434442334134434345463036323333323838304546393532363344343334303636363637443142423444423331333344374143313531333136383042413633344442443030323630313135333036373738423038393939393938394432313731333745363236363244343034314137453836383136364445384133313131373141423435443436384239393538354338433741314231393833343144424433464644413030303830313033303030313035303246433833343232303138443146424530344442303443454137463030443046343837333045343435384344383044363636324635384235433041323344334434364238463439394246333030443041434336323139444133373530343441424232423833313436383344333843434644344542303430333432363138363133413344314432324231313241444442343236443034454133443539443039383632433330433539363143434242424146373642383038443739323542464144344332373330343331413241433330434334344431413133384431444233413637343032333039444339333039393838333432323246353939443331333141313133364342324139444244313844354441303145383736383334314442354334433039363145423738463430443139413038423039393838453142343533303741304442333734363638434642363342363734334136323636314542303838333431413344373336433133333137414336443044463044443938434439463439333036383334434330363645394437343234303939384144314445334246344635393141363237364433313331413645383538433636313332323142343436423733303946433038433631354538333544443337313830434632453235414644353943393139464337344537343237343639393846324332363145464639374646464441303030383031303230323036334630323836413835414437383837433830423532423543414541363634423033314434413541303335384236323732313646464441303030383031303330323036334630323836423644344445463033383744344645413936433843463836303233384332304437363242374646464441303030383031303130313036334630324136333235364145363333353534333932314543373344434242443736313544383535373842413746304146353143323832424339373946324145454345423245463532444439453133324644444632343034384235374532384544454534343446364137353845353435443742394237433838424245344143463336373239353741343242374343393845443837453838454543423735413345313738393135344334374230304636423631394133464337313531384637393434463135383633344536313736394142414141323230443736313137343635424132453144334238333341464538413545394143393334323833463937303434343433383736373146303433344239384434383532393441383632333434343641304144393335333232303237313141414142383343343238454545444545314236323545373032373832363139413646374141394342303445333133433533363132434430393143303531363046444341453839423430433733353033333230383138444446433930393645313231424334313744354441394341303645334237313839373843343632344146333234463239444143333841423939413633433445454241314331413845453241363337323544343038383835363030434639413236444235464444444443393031463146363141353234333335343936333831434437323042463335414141463833353131423835424344363941433333343738334534384631333430413531444337373339373343313639374632433731434341453333393631313042383933454535333931313944393145443242464533314637343933374534414438353346393733353536314136384539424431364443463646443437384245383243413345363431434333454445313530413032454642353138444446314141424236464641463338393542373233303846393630383032313933303535384634453041363745414346424430464331353639414133323744333933414137453139333836314339334632364136364435343737313843314435363942363345363843463845314438423437353743383232324144303232353543434132344535433133423930423531443131453143443739423245313841463334303336383138413931304333434342363444394245303536384139313033304145363441313030353843413838464136444441434343414444424443453738303533393735463335413633433345324232314338413237313233333444433746323430453539334530383438443045303943353635434646303033343233363632383643304330373530304231453934314331443235464244343835354535353344433831314545343032393046374138394444393744393837383436364245393838413038383545373645353045314535384338303432334535444242384444393435303936434341464438434446313546454335313831424446423135413235313244394544384343463641323033424338384336383638383430463536333245344231323146453439383534384143393032304534434337324532413531323730333832464534353139383730443538424231353339443241363838353031334341384144323643314344464630303334454545303437433546423636394534414546384139353543373134303436303446313045413637364646303042343041433737333530454535423942423044424646303043453339313530383746444231453939453646433136393830363938374241323734463646373233423630333334364238414143453436434138424138414545313832323634394133443538463632313343453732463932423942464339343431303042443633323338323135364643373145304243424344423532313536463143374242313046393244323346393434463245363843413430424536323535373536453539333835463242373335353345463435413444303443463841444344443935303144323130393644363132314434414344443938383434343442333745444335303046314230394242314137364130354635373535443831374530423431333130423542333233323831373541414145383730314432414533463832383432364544383136353737413639343946433430413743353739354531323746304341324444353130343231434435343930394339303036374331354245394641373033324532394135394136334136323341453641334235453132314132303634384330434344423133343436444143374334353645303338424644423031424238414444323642314235383441393645304141323939323243373034304430333837454532413531444244374238363943413343344144334431314130454534303036413241414141333344383135434532414231323142314636353742374439433739313038344637354236463730463441384332443333373336443130383146423742374332333937364131323843454436413137333430313546313141343937373436314237304139433633314132363643334146393238313737384545313037383639343644323942444538303643443444424334363944383130393738354141454146323433384137393641333039333542453137453038384235453433334335353436333530333041323244344239313939443532433832333239363235303331384238453237303545373741383232374239384236343130384333313233303542363034363332424141344242354246413244453931393343324344323041384332324631383344324243353146344442424146323839314335354231464543453038344535333934363233433139424136393436464441394244423146313437323535433131323031463331443946323634463244323339413738433731463146454341444443414335314236333532354443413739313736304342423535354342414435413437323531393330393033463538414145393841373144434331344131423030433738394344333645373542424341353241424131364234413145323238433330424232374337463635423930384537384346313033444541373044393831444339343045333937424434364430354630423436324133424432303038323334443744434145363739353937303846303433363839394545364539414443413530303544433341373933303243424235304532333335434638303437434238394637323739394233464339383238433737374434383531314230453442463642413836433442414133443635393930444345413233353337453435313945453931423830384239453338323744413845393936333035463438423741393544323337303637453643383031314245454144434435303833453933453235424442313133463735453831424138423635433935463233373646384541333831443441374233414236434338334544343831443334434434413342373237363839383445373938344645413837393745414337343831353731444338453931323044353735453138373635353042453635424230413037434439313246383334393046463030354230463142323835383145334335303130383131303745413035303342414536373943353046333233413543363146423239334646303036364142423846323533463245413542354139333338443734334344364536374635393243383939313337424530353744443844443142374337463446374131453439443343353334333133384338363231344235434545374437373344434644453136453044414535373941424637424144433937353741383232393033343033363946323434383834333044353037384236314641324646444130303038303130313033303133463231433444343836324546323630384330343533333738363044453230313743363241334231424131383934433338333732433737373131464331443233364231353830363730374443343531374133354242304630354645363639433236304237353645373135463539393635393942363538453734464630384243424341413241443137303142313944374532364335343438363838344244393144354531463442384446333035443734443745363530454444304242333342463739433634453245394238424136313845383038353334433642394243434239313437373742464234434337343334374430354533423635303531453545363531364139383144394536333045303331314243423333374143384341354541423432423144314637303244414530324233453046333145304436303344463846304334313731363044394635393939303036343631433145464643363230444144303845414641393643333933433937464138353134433942333032464343414444374139343334343743323939334334353636384239304444464343423032373843334342414245313838303830353942304436304243453343434433464544434636324646303042393445443432414236374544323635333937323632324234303331393331463330454643344232414239314545373130303646443343433541463738453538443633394633314437314135383746383831413244454332324335313435364544414630314532363442303630353634464630304239383244384335354442393546333136353230454239334530454532383233373736353337453145333131324339373530304235443645353037304136393537463335303835463130313335413642354139364243363230453431353944323045324646423841383735454435304233423934413341304642423345304637383044313045364243364133334333324337433335343743354336383334303241454631333937334341304243333237304437444332433238443436353543374437363342323231354230413344433344413544364146383346394536334131413244443746314239413136463832413345464434424335384530363346353330314438463943373642434139344142304639453639383845323334323732373946393839313141314139433044324239384543384430394245384643354337454433463033374538323636353739343730334334363235343543454231374541363435353336304141353636434643313038343033413034463246334644433336353730434544393630334636433033413045424145374137314345353843413832343044324437454442324642384337333541463031304531433738363543334131353145454232463234433245384233433045434636453631434437364244364245363331434331423135383437324537383837393341423043353139374635303836363245463743334446414238364632464433464139353941303736344230413134453442453746383230414232384538353443383335394544374133453130434333303733383643443535344341333646333742424136413635323836314339413739383632313432433544393834453743454532433532383344334339374545433735323832423346334643343435383238333435453642464636303036443139313336433238374633313337383943324333313431443331383545324446313646304637314236304332463232413037423636303830353834443336324246313333453432384536413044413532304243323734373543433235413832424236334143314246444334313231344132414545424137424341313845314534444235373637383936364533433837334637443435304432383936314337363837354637363433383043373243353130304236434542453633383336343142433942424143333346373145464535454443374343444134394430364632374439304238303044393446364539454131443132383045454544414636393839364244423545453437453735333036324139394342424645324333363044463938304635323835313734324245374442453236323033344545374537433430393833313933324244313245333941304445303542444243443442463531304341423635413733393545413335364242384232314133303736454131374343303342393935453033353544344430434538423646383733443235393235383641323142333239383041333331394539463335393936363133414236353739374243353533413936463944314145413246423532383042334339333137414234334639423939364238433837313433424431444331453039353031384342453639363343304233324634343646333342303542323746344230413338393531373931463344324235353135343333414342313646303631353445324536374535443046463030453443364646303045303442303939393944334533433430433030354135373246423442443943453732383344414543434343453738433634424534363939373231343939324539413239454241383735413439423532443645384445333934373733433538304544344441373132424230324233393545354133334631303141413134433746373141364336364635444333433837383333363231463333343333344531354238393939343531363246434541334632393132424445373636324535453142384143454345423935433046344538373741464434373936413531373537463634383842363530383736424131464232353332444142313541364632453645373144344339333833324341423536443241443936334245454635324538424233384136343341463333453343413330463939364338373736423730313045434345303739374541353145324534423731414137424145323634393530383545343330374239434342453735383139333646383745413545343731423045344438394143434142313046373441413739324532424233343138414533413945433838423841364235324342314544443846423432324242323933303642323937454344324435353846364433304244344638314638414536413044383644423835303844434137363633374534343043323031353333464634423833353137433143443636363236363943354236344335353542364246304434433945314144384246323046463030363242344646303045323635344535314437354546443442413430353230393835353642463331324131383533323632303232383041353133314633333239383338423739334130323333343035383238353644374239363330434632314639364135373432413937454435324446413330333535383346463039384539423634373046323746393238384434313342454430303535364245424441413533464433433944394532304234364642384644433945303635413634313536314334434344453444324342343335434530353543313235424336383143354643433539414331373834394635333231324632303046383635443646353843304245314243443843344238303733413738354636434545353943414241354144434242444537413835393442343039384242433931383531324132453535434235333138434236374346363046364637393634454132383530413633444441453233333638433545373246433432433336383746303843413530434237423242464339383937383339324543363342424237353335433146333045393039393136444641443743343736303341383043424139374333433941423535464141323344453844344532453741384438434438384237464434414431443938354235384237313736424435463037343131413144424433313731413730454637454533354546394633453839374542364343334535363241353435384135434242363943463839434235353735414145353843334637324132443532413843344236353733413236343841394445453943454244464536364332313837323335414636383033384139364430363639394444314336453546303644393844434342444530374545453335354241333042464142423844304235444346314339393737434231424534343243373141443138393534303335303544364231443441364343383746334445313334323242423731373143414138334532424445373930314244453532374144313437364446433445333441373430344244434442383336333744343341433734353842464331313334334239434246324242383141434233304433424331354646323136364141434346353143354335453742373143323133433730354336333331333631373831413744334530393937314443304530363446413936343131453043334441384446393836343437324345393646314633324532454236333446443533413936393138444233393139354144453233314343423332363736433938464334443043314135364633453235424231424535423345383936454341434444394337433445344235343242363742433034383544383541424644343136454145423431363842314244434439453334394232354334423144423739414136454231423842353435383334304141413033394532304333384132434341314646323637414545423537303937303031324343423544313833453539423636413235393544313544463332444432414145333933414334423530354536443943434243384432324433324541384133364643463730323036433131454341324231453444464443414136463130313833413733354339323834343445314544433545343133334145364538353744433543393442433137464544313134333830454235353443364337373639353243413535344331443946384132313032463032433230394644433638323035343236434636444341353444353643374341434338343734313146383836423443313742304336343442304342303241454646303033394641383441364243304237303346413835314437354130374333393835303035333537374345374138383545363433413342353745393530303032364639353735424336314144434235444135303638444438364439353030393435424543373237463533413230364336373746383731333846464630303834443332424137423639444635323839334238373832313735354641344646444130303038303130323033303133463231333345383336393632303741413130343037434343374136333042383842414238323130323533414434373738464131373937384336354532314445324238323442463442323031453832364245393636433437453530363735333034323245353030353131453038433330324141354536414135463938353235353741333846373937344342433742433345393330363735453838393936313246313545383541433138353735314230423941343043363330374332313046313134343743433133344344333042363038304444434534313030453445413537304234304146344434333045433934364233313444394538323543423545303946323133353643444545363542434341423936423842363443334441314142373533304638464545334434303635374634393746343432424431444342313339373846343635413630453636393937374543393543434246444136363035433339423743434338393941304645374246413241463838373134413839373732413841333135413338353741354341373732384336323530353834304137324641333836363733383432313539384341384641333641364231434345303837354332324638393437314139373039393634424236443936334334334343453638413842383332433834373542463435313130334446413638393536434335324230443345443937414631323935333133333531433436444139394541323531334134434633453946353037334539343936363545453742443434313145444138353743363534423845314546443044413541314143373139393839453744323639313635373838343430333042374132353635423033323444323533394443303335454230393741423835394343433233384343373332434141384242343434413331334334324444373133383039424338354341383937314541353932414530464133303133383935333239353143453544434139373138364446343530383343313142343436364639383833414634313142354239394134384142314643314539364143324241323242413944354541313638353230334139373137363432384339423843424445353839423938444136393139374343453239453337333642394635414430333843363139413436324237413832313734433142333939373139393842413432414243464131354538314145363532453142433441453931383534323733333133464644413030303830313033303330313346323139353241354342463444433235434239374539463934363544383934323532384343323245393439383436353344303534423843323731453841343744303046413536364235333733393939393246453131354232443035453842304433353634374343433437333336393532413534463131374443453032354432413538434143333842363841463145384230434132423437413536334539363536363035433438433132324436323033313042434545353138394139344641333538394343443641363432433434343641334444393936373143314431373937464246343737343433373332384243343638393735383832333332363337304341304634393437373034443343433133354136313138314245453042373034463032304231453845453543353545463334303936393444373130343031424635353746353135364533453941463844433337373137374334373131344545354342444243434246303430433943374135393631354635353931374131373330383032334542354438463037374538393242333041313434304132354345323936333545383436353338384631453937363331324145353441343631363030453236343145353935464643364541353634433943434546333043433839344146443338334433373245424432433630393438384244453538463444424430413443393939363038443133323743343544343545394342313638393233453939333734433641424139343341433437443232364432464432464432383331304331424334333241424431353641354135433037373044463330454631433846373331323243374431383332464431393934393039374134424246343130323741314241433430393731354333433446343042453843414646303045323835354532323544384242393531393834354135333132413944434246313735323934434243424634424634304634414646303045313743373939364436373530434534384336463033303537413843423935304334424639334646303038374646303038334431384641464646444130303043303330313030303231313033313130303030313045443833323339373443323336463544414134433030433632384630423833434543464245463441343941453335383545323246363044374643454638314336344246323932444338454332354141343634374245453546443741303544364338424532443137354633464234383537303838363143363834304530323141314642433835383639433946364246344635423934373241363741393434344444453437434638443931303634413841423239313941444234324436313032353331324534464235383638414543343742313542434246393432373739303939464342343435313246464644413030303830313031303330313346313035433036313434353237323041353637333939353241324545423432423638363544374243364145383732354435414345384146433431353844353932434534444433354641383536353135324535354437393935364436434237333944343636433839414141363542463941464334304239353136394331424633444342413141463132334235373743374443423141313530383541413238444439443339323134353243374230304434443042354144393938443245313143353130393432314244444332323031363632433246354233453142393441414230414141434430434439453635313834443331353739414242413333383838363238333636313832303730393139353735313037303439443035333442453941383345323533333931413039413944424436443736423442323143324145344434463341353231374234384137453332454445323637343335394439434633353136433643344336303035454136383331324246303136443341373536353436444333394144343939353534414231353741333837313730463241423239423743344236323335353441353544453245323236414235413035373635364133323931353042304334313739304233463530413042303541323236413531314231443143433631413939373042434144313639364435363043373331303943343143463332444132443739324646303043344141383435453930453730434443353936444338303130423645443539343546304336423138334141333541443842373143344135433634413935343230304442463641393837363244393836413242323931463032454530313434443633364332433338323735364639383246413838324334323137303635353433383938373842364439344444354534424242444135424432353436414231384231313744414332383833414330353031444434313030364439304643303933323430383643423646393432313145353231323541414342304144444444343034303033354230354144343643453531364145343132394344373037393846314543373531304535463645303938374542333041394338304335303846343637324331343431454236453930363135424444323137444238373341333535444336304236304331373641443132423434383939444444433331424235383241454544453630363236354146313631423943463345443242303235443243304341303845304345304141464139384245444235434246343645324143333531323933393630363831393836393643414230423834444445463244434134423033333031343044303230433134343941443143423932333537313041314139393137373830413241444439333235314542304142343545304232394346373339303830323233423735413639454631463145393638363737433144424232364442433834414438393138303843433934413235393033413136434143413937343832423742393444323434323845393542413541363842343136453838394344354132453732314242463838323930354235303045313244364230463334383831394238333438394133374436453736393631324531413637363231373543313039334331363842393041314235303431304233383136393636463244424136353936363732333042304345364430453731313446423135373241453134414136373538453042393839413541303539383030364242443132344439344236373538363734453939343734414639393031453336383833313645333135343035304445314645373034414435364338323041323933443846343842463342303033364144433138373138424334423132324433323341304534323333374337313131363736314338363045303845303535463132444531373341314344413531453646413935323135433845353437423236333138363541423638354342344645343639373035354141433130304245424345463130434142363832383432383435333644373133324538463133373330303043393945354445363039434430383436394135304431343936454238393645463835413838424233423739434334423430303336324543413031354343334336423241413046334344364630383446343136303536393736303344463331313032434443313135353945433545344334363639324232413830324638394241433630443636334342463930423443434137303246393841453243423336434142344141424538383639303330353733303638333936304333463031333538383136423830453442393639384238443644373036463343414235324531384130344432333943334431423446383841313731303935413243344332303743324530393739303137393139304544323035373337373032454334363833354538414341414635413833373431313332304142424331354633314542323836303839313238433030433545454141314135434141443842353644304637304631423833313543384445423336464345413335433038444139433541384331414534373444343542313545454132384534393944394334343535363930434142304230363934364441424637383133424633373339363541444141443942323537463743303543353630444632363033393635334431414631353243453042413342443543343536373733303442383437353535363631323043433534353243324437304232424543363234333031344444324636383730444434363745423242423445363141414238354636454135384137383430424141443031384531303142364444344239443842393936383935434331304431454343343238343642323137304437373145453841313343423032394631393343443442333336333536454145324343324146353044383744384245313334304239373335373936393831414132323732323734453435383142353637323436464135454438324632333832353330443844463441443244433832453531394343444543354133303443383533413631453241354532433431394430324143463132453333343832393532433335383335343434334630414442323338364430364233363537313143373343303841414131313737423144354639433536343935394237373631373536433431364435453842394536373243384639393634333743383336453133313441454542354544333737303541414145423045334130313945384238343433373241334336313741323643463330313634324141384636314330363641413043434243324445444336333335354141454130373137423735414536413732304539364530324443433830324531354131333046303435384438384330453845353036353731393630413536303834423331374531323836374230423138323931314637444337303631323938323042343041343441443543303545323531363035443135333031434332464330354643303336463630313537463839453637353631413842333534423137304230344544303638394634303030373037433635363333414232343139343243443445344532354646304237443439303241383944393135413032323830343432413636424130454242323138303036363642304435304243313845353745453631303141393139373945354435453538464346444641323238433337374530464239353242344431423532364235424245353241303338323830303136443239333031453646313330444244363635333735413035363838373639343841453339303437383243344131383236453837303343324142314232453331303430353342423741413430453844353646313039414336433430334441323332463144443945363345354138304338423034333731424444343731323932364137313643314630443535453635353230383244454545433044443735343738393730383141303641313832433031444145333635353338304144314530464431324135433043343037324331453344413633424432393638363531363144453043324633363239383830423635424437353335374130413337443436453832434532354531343039304139343131304235433942353634393436313339384144343031354331424339433939384337324330364238364144413037353033453636453132384441414344414446323441313841304430453735353846363637393930393245463845323542364237413137363333343739373731383236314336323731383631363832454545313135393030303531423238354131444633313345383534374135394236303831394337423434353641354341333034364335364632384233313931463932314444343131434336384433413233463732423242423841303544413833333545363034413635323945454533314446433435414334413435413132443136304231383830443030443134314136463242374334413443423536453333443146314238413445303538313638443530314335423834333730453441313239313436443644363138334539424236434536444531374139343232313639354241424338324237453631344537303931334332424236423043414334383634363236343034323932423334394139343641304242453143363443394631393845373033323838304144314233384330433536384131413430414132443630424145433443433433344131384243393937423043314630383532314445364131423730453731373041413230443534354534373631464339303831384438324445363345453444393238324330364346363635313934353846364546314432433631353739353642334131364142383939343334414439363037424444453641364344454438323637393339334545304234393137343433443831413844313043313443464630303231384633324441304139353638383135363634463331384542313942423432464130363631303435453330454239313739313444423133313335333733453135343036313037464431303232384437333634393541443345334138353439383834373439353243424343343638303936383530444241343239413433393443303938343533414438413035423338453642394443373942343439374331353536424443363638314345463230434239383146313039353432354332454642303430323332363841433042443942363936353543444334383030414332323339413135353032464237304344373441333441444332413532343843323230413030324245364131393231443637343833323841393434433843304236354442303137373036423037454535423246423738414446333736333730343142414535314336364344373730394631353934303332364644304330313239334333343939383646364646353139443434323936443935453732424343354239343542333441443537323144343233374131423531423245383230313739364130433142363637373135313542354144424245363634324434353135343838333639303444383331454438413646324533313431303833343534314130383330313531304533363238324341314238323732324432423035423237333645434630433735453531303538303235383845303643443638323541303834354139304233354346393837343334373034453031384346323943344133363135423043313444363339314434444144333442353143444341333946413138383635414131413638304430304543443437463931353431324334424135453331453632304132433337303336443844313739433146383830433435433044333942324544423846443234353532383138414236304541323239364131353433353142453534463132423038314139413239423637344439314130444638324433393035423835313135424233353245383145323639324337414444373445343937333537434142433238393541364246353030393831353543303030454437394531454631364230383239414534414230373444343141333435423641413845433436354241333436363531353735373634374338423142303539324331353832423339433937383232443930333239354534323442414533304641443436314635313939423241304239303736343935463032384334324438413032423032423945453038313833384142424235384541393935323144423244393135343535423730323830413442344343454341434139454541323536363531353241333741313044373345413045343544333730303145314330353634453238313434433145354232444636303841463832313632433530324131364535414332363536423842343043303042314436423839373635343038363930343033454235313335373942353243373035433043463734413146463042373131343036393831303630344639453936444336373932464343324533413245304544343839394346303843304537353543393630304637343139443437373038413839343336413531354245304345353735313831364131364537383138433141464243413736353842363136443633344142324332414436454432443539303437373430443539444331323133443134413233323246363430383741353738323432424534363837323732454533323138414531433938374234443542314331363834394132444230423137463130423431424137364533393436344531413038453046324530363536383445334439333631423531353132313537423134414632383034334138394134433134313843413644324546364633313535313635413737304438363134423632444543363845323039353242303135363330324236364241324536323235383245464131314242414530423631323836313944353937333444333036324138453238444143343241433646324135384330383042383433344536333243463231463330433136313332423332333136304431384641303145353943333232333141463236423332393138393442323936424632313839383837443938454441304538304542333645413143313133333545343639413136374331453132394138364139453135414339373735414539353538413937313334353141313039354136414544363941383638454141413938424142444641354533443933464644413030303830313032303330313346313030353837383833373636413038423943303337313933333243313130454131434530393641443734393630433645353346394645354230383635363138343332414446453633333346443938383030443943434132333941393944344438453630314330433642424132413238354131463731324630343546324134363142384439353837323543443431364237373046423231414436304141423830333541384239333332364646313141324232413031354336463546433631363233343733453635343045363535344233394636393438334445303333464234364141333531444333323437313838354239354532324641323441393735304132413334334441323835463443323238453838334339443343343442414630323643354346363746423042384633344334323530344131354545363134344337344346383930373145333733463836353335313530344341434231434437333139313043423041414545444334323337364532353337443533324636454141333143343538303245393832333539423631413433394337464246333034423242453339394243353139364444464630304446454137313234303041333532393134463136464234444345333246453230423146433433353533454633413035363633343143303332373237393146454130343643333737464138383632363633383934324437463834324242343832413032363230443943374637313537423131343245463531323146374635314431424537353032434233413633433433303346433738393730353543424546413437304544334637323836384646314343373830304141444342344532333635373133333037444332323442433633453742393935423641464537423434324230343134354333383345413032423135374643423939354236453346384332434135333646444331334441333836463130303145313230454331384541324439324437443434383137394541353945323141414435433341344345413044324646303046353131373935423938383043343035413839393341464139364436453446433131383042324546464436313132373935463331383845323038464441323130423433334442454430373032314434454630364644424139343135323942334635314130313645423838313534314334433942464238383845464441314139383935354343303146444333373746394546353138423331413735323032353938323135464635313830333144453333454533434331303444414541333730324235434331373235333034334331333235334533353331383639433432414236363333393132463134323542414637393631353346413844304239373246373838314241414434413141433544344239424237463337303239373437463730304444364242444638393843434433363335453731373141414634314644433733333837314139423044434244383538323244373245393342454638383446383442433239413338393442333245414330394237394331363042424637383830353641333846373939414445393635423745323731413938363139373746393833393743354645434334313031434141313245353839383633433143374342434335413831364336344234434331364632443745363534444333434444434138324637313643374445304234443036374445354232364446444331303536323042373938393738394443384546413841453636313635344132323843314432314242463346463030433832353337304133463033314443324131363235444434373042363234334236363131383235373238373637353130304636393442303632423744433730423641334342353831314335433333303732343944413532314130464535433236443034303141464438364535303144313835434136303938303544444341414546373041424238313141393734424239394633334633303731364535393936453033343333333042373041453631414332423432363434354437353046323938344631414530324445453637374639383131434443373131453535383831333337423832423533334137423433324335393038313245384537383431434336434234334634373731414334413842373536363630363630463637333136304432333936363542304639384146343837334337464439373341393831323544463739373242313535314135363939393642433130323836363435363333324135433444314136303231303134414341384535414434313133373246433842453531443231394636363641424638384242393742343246453232353041393744313244433042354335373131373735304639434330413231374141363146363543353641304443433145363638393839353033333834463842313831433544464434333537313936383239383637384343384146373245393346464644413030303830313033303330313346313044333733313342383839443241333039363331433233304437464446343334453236434143353444334335343235353436373639444341354642433441333138443443393043454136413236333839343336393042373643353643324644343436393538454534393444313542383536374432353944423730324337393934313944344244343436443635383045303841333131303644454130423645374546373245444546463438353235464537373243393243334639393937423346453431383631373243363141323530424632304631373031434132424339304538344346334431303644414541313935313939393942464343304534354246353045444131463637383936423038414630464537353133364337423746423243453038323536423838363530343034413732374234433830454231463634323033393443464343343737324434423532434245363231324535354541324243323642374434353741413235314134443032323935353933413832324443333032394544313039443146354544463130424235374346384445363535424130464133343746393038314643374243413044423044343546393746313244464630304138433437393731304137393245373335313434384342314536464334363042314532333233413545374532333135323041354243463946334645323632433334424343423132373131353333413844313634303143333243343139464535433542423137303134333737373945324631333435434137463142383636313446453834343139373731414242323336314243423741383234304643434143344138343430343538413146434646423242384443344130413732363633313144304342314233324434453431414636434337423845413335363636323343454641393833354138373445363243323935444343353938323943303434303542433143433743444646374441314233354238364545393332374431324338423535413436423435354236363134434330304341313643443845443834453945303435444131313934413835344339384342424138384343414633314241304331453630314139374430393642303535433735374642383346353030333741463739393937314131383832344241423830413135394631303843374343303642383936443231344342323541394635333933434241454245344532353945413132393137413843373337313530373439424639384639423643363835313046344443343231454543344132414535324141453233343431313546393834364442453631454643344130333532424535314233313142333838333139383646383842453530383241304543463838383335314136353141393931394146383844313939363039313634383435453142383235433937423444433037463434413536463732434343433436353135423038363945363532314130423730344335363637374446423437444331313636354541354135313644393839393143314138323442363931373333343444343441303338323333303642353245344441464532353330363931353430344243413338393836304146453238463231314238383635384331324442453838373342353446383938423330373330304243303942463641373934304334373238333839373246323841393938383242384343324343303634433032444445363036414142393433343132433737313641324536383631383342393731383636453638384232364238434343303245363542383842383230453637363936344234433445303632383242353138333338384146383432384136313431413333333935383430384435413035463639383743334639383642443942384233353031433333343830343535423733324439373033353142343032414135303331333131333830384535393945323544393832454330374434344537324636423034334130423643334344344642464545333841373837313038313642463330343241453334363836354139313042304135433741304239463432343143344136453134423042423631384443313331374531313841344545443837454438354144423530374239454543414241433339443546454530303632453234383431374242453745323635363544454637333135384634324545353645313339384641304139364239453533313434434443464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(7, 'Produce', 'Dried fruit and bean curd', 0x46464438464645303030313034413436343934363030303130323030303036343030363430303030464645433030313134343735363336423739303030313030303430303030303034363030303046464545303032363431363436463632363530303634433030303030303030313033303031353034303330363041304430303030304242353030303031343336303030303146444230303030333032464646444230303834303030343033303330333033303330343033303330343036303430333034303630373035303430343035303730383036303630373036303630383041303830393039303930393038304130413043304330433043304330413043304330443044304330433131313131313131313131343134313431343134313431343134313431343031303430353035303830373038304630413041304631343045304530453134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313431343134313446464332303031313038303036453030414630333031313130303032313130313033313130314646433430304439303030303032303330313031303130313030303030303030303030303030303030303035303630333034303730323031303030383031303030333031303130313031303030303030303030303030303030303030303030323033303430353031303030363130303030313034303230323031303430323033303030333030303030303030303030313030303230333034313130353130313232313331313331343036323033323431323231353233333332353131303030323030303330353035303330393038303130353031303030303030303030313032303031313033323133313431313230343531363137313232313338314131333231303931433144313432353232333134303546304231363238323333343335333234373232304631413243323334353431323030303130333035303030333031303030303030303030303030303030303030323130303130313132303330343035303031373035313631323231333031303030333030303230323032303230333030303330313031303030303030303130303131323133313431353136313130373138313931413142314331463044314531463132304646444130303043303330313030303231313033313130303030303144393745314145393437393445343732443737343138393930444433343245373243313030444339424538453042434634373238463144434345454244414139334641343144314642433146373833444534374431343437443137414134344445464443414238423437343632313637423534324144303734343637313137343934303141323341433544443738343035344134333233443933304335464237423836364535463543463531434237353841393743413046384537413741343344463733383439303746393644304237343230343437353636424137413644323139454532393939353937373233454441373332444243373738393141394346453643464633424437374238384644434145384239353232363846353345444235373242313733373437393539443635423031453035464439303842353346334144374139413432333645383535394644374137394245463635453931314535453737374630394146394146363138414233423439393638334238413236323743373736423438393841413933394546334245384238373631413231333136413336393938373035313841454445433346413332393845304636313342464142394536433634394634344344353143413041393536393739413330373541333933414241333839373843303630463446303039313536413433323946364343374432454333383643423943354432344246313746413044374432323543364231324246304246413044333938374136393739414146414646303033453542334345424430324346384435453831324233434132414145344331413634443233333544453834413432303744343844453335414232363742364145324331444238434644313544414645323436323538454132433233303834383142303742324639453532423142344443424142444542343432454245393642313738433242354535463837374644323531463443334344383134364544363331373930373844364138423536454437313735303843364230433441413531443137413236423636464538364333433643374543374232433838443033434243443643463246423343333846423131313144383838413834363138444235413930374138384236304332424141304242334244304438383443383444364431304545303241453631434439343433393142424534373038434243434533344133454442323534453942333442443344324231373146323436314535363631333241323938303939463043394235453136423536354237323546413044374242433335464145363338383136443831413045393542323832364334443545363941424132413341314633363344384238464232303341463344453731464137453145303541343944413146304537354632463036464144374143453444304237444237304646303041384246373946394435304533413238353245324432323245384346344641463930383431443536453431414344313645384338414331354634334537314237323435393531303143343332434344444230423146383846453631423736363643413735443536363142454544383730414233414243463041353741444439413843373245363939353433443730323833314539423736424139353931333543443532423533313536304345304435363733334137333942333344323446413432443633344542454539314633444634303846414441384330393541453535374231343841333633394538313636444139353536424134353333323444394136343333413838353039464133353030414141324339353637444131394332354630313334303930353630463831454533384530463633333746463030393646413034344439443544303333363642374334324435314138363237393236363242383541363031413131463442374444423346314345324233323346373532414642394241373946333144343641314444324343334331434346394445343937443731424337374246464644413030303830313031303030313035303238453546313233433334374243433241443443453931443134374434334631443633334631453442463239324143364335463639453233424434463541374646303033414244363837443838463533314231423542443530343536313339413143334431453543384335443944443145424142353439313039313932353339374144424237334436383641343844393139324346314332313933443337423038363538423541464131343546424246424434444631463546463543364237444338454239384132443644363130443330303334323945343742354244433034363436413845353642393741414332463139454334324544453243344530324444334439463046454243454544414137443936423035424241433932323133354641463432394438443937443637363746364242333533373941454430384232373637354535393645364345393542303636304530373839363443333443313342323238414239363045454338434636463235454244434331333631384438424443393143314432344638464233354138363541424635424138463736394534373336313636443246433744323846443837464346423245444545383336333045433335463646344342454146363444464439444341463144393533354342314145394635464239443644383834454345334546304239423343363545313841374243443831343533313934463733443842433231323330333633413737323134433046363042344532423730463744414233463446324633413842454639394231454535433430373335353141423438423345343644373544334542434643334235353345453941413939394231464234374242324333343243423236463645444245324435354242344438313936434139363636424143313131433841433742333539454442304342323946313431443836433642413133333545443944444533363933383639464139433345444539463635333334313935423244384234363833354539443435394645323641414536443244343742423845334144343642374437453141333532394430384442323432443044353034463345324335333731394135364543454234464631353932333744424243443436313844443144414244463131453646303638373335393230373445334144464245443841333936333337314630434432353741424231394343414133414544454235324144333830354244414232444342343542314435413936413736434237463730364435424139353745433545433836374439354141304439334332384637363341454345464346373834353632424435414533373132433835463637364336433441454438364335383034353232454237314343374333364443423637304346463030314536413637443842313035413043384644433844313941333633364544463245303646424133393737374142374441414436303537434539324643343243354444353638463732324637443446354435443342344636413938373541423535353437374135423446413741464230433644384438434234433442374537394130413336454345424537373133364433323333313842344643423237434333363144363846353735453939413944423043333434443641343643423436373239443131303734374636303946453145434130413537444246333736333033413044393638414534324538464541333139443244424431354539373731344635463035314133323641373541434233424141393238394133463930454139414232443036393439373632313243393134413643423138414337453937454637364241444436364330423146354236324637353044324437374239444144414444363344353039323646383334323832393232333233324342454545414144454336453636453538394645364245314141433332373938444435324535394245444237303537393533373537323936443541353545424242373335324437344432334641433136413838464630303439463243384435423542303231414641334646303039333632444541453634423531333946443243343532423536303438323438343933304341314142364230374243333631344641324146313137393643313234353339383234323638433544324135304244353034423344323331424439334334463544453436423836354531423343413835393944433337443331463841303439414642313532444232343846423137333645353637334333324533413337343337314145363039433338423938314544393033383332453530373131333431463143423430373332444336433845353046304338454333383937364142363732454145373941423345443241464144323142363941364233414336454543333235394133333133343433463245464242354234453538464530434641453735374232443738393234463738364536413937423735454542384639314236394431424132423139343344423931393235353035354641323741364237423939333631413737433931343444373031323738373436453046384142364432434435384442374534304245363936343645423245374246363745454235394135373543353046423944394638323636313030394530454439423945394146463030384246314636343241314146353844453634393039393933334241393744414335393644344639414446464146364532414643394232313939414438454232464545444635393333394645334646444130303038303130323030303130353032454338423931344445304130383231313735353945433446393445373635343031414434334642323630433237414538384230323033304537343842304231433136414332364237324244304132393833323944394539353941414337313143363042374332323533444335373734354539414635394631383042433637383241314635394246374544433334304339433438323346453839464539383531394332454443343846434133314238303131413045454142324233463844373145363646443933314142444143384541453641364243334434433341423541453433434146343539344436453533394542423231463836333938383630344446423035313243413731323842343130453339304541454530424442463139453332423346393043413343343631344446423231453037363431464630304439464435343645434238434239344537323143363339433135384534323239414443413145313131393244303842393137313239414334453339323037353643343430344541454244383238384337303346304331343041433731313934314338333832324241413642313036323145414434463636313336353231303939434244443642393734303537423630323743383133353633434146453536353337433830443544353036324330304242414543394544303130434145413041333139303837373532433634323631353943414541394245313137373943453038353845313843463144433230453641373438424232454338423930344446323938313741324546433438303335303732463731313732383838353346413833453041384336354432464132314531314643303236393443373237313539354439344137464237353437384541423143313041303145374636304531384530313435423934354238453431344437323037334330343432364630353631363136334332464434373632424246363434363131353139344535443531453332393846344534443741323832323842353735354431303641363633333236333833463833463239393943394332334342373338353145373044344534333831433746464441303030383031303330303031303530324541383035443533353132383246353431313737453037463343373139453031433230463430303445303833373242303531463143313433383237393031363136313131463930364136413238333133354141364533443739323339303130373034354443453136313735453036313031383445333834334341364235344537324231433832393945353735324241323737383538343138383835384533304242383238413641304135344334374430423536374141323732373830313334463045363835443536333831453536333042434145384230394243343837434230373333304630423143363130453031354531363536343243413033324241463031413938444533414136384332434132344137333343313431313042423245433136373836463037303137373444393137423842433230343236394530373030324336313439323845373343363137413245434242414637313637383231363738364131453437353544353133383435453537423739343633354544313544313345334332434630304133433834443039444541423039413832434133443936333837373834444342393033383435413145323531383545443634374237383434363131333945333042323938353343324332303133303238383945334245353330373832443545383941453445304131333835334337443834324435324335453544313143393846303338324230424346314435333432314530423938423039384535443732394431414538383134313335453837383731344636413239443132374237414631393545373836393538353934443231333938383045414133373232463138454130413733313739303833443133393430463845443934353634383532333742304643313839413944383431333733383732384433443437394339433237363131433231393444354643413736333837374146334646464441303030383031303230323036334630324231323832324433353044304643363845453334373731343239453238463644333835433639354639424633343441333846463239314436313643423836323833344131384333364336443445303134324637464646444130303038303130333032303633463032463131343632303437424232314132384130413135433542333430343645464630304646444130303038303130313031303633463032453736303542463046443843363633373436363533334439303639363446313443313944393746444532313537444439373734354230344432413044393444454341343330383243444232353135464539423445383346434434444139383136363539364433303445413241374339414541384145394142393635303534393434393042373030434132464330383846393444333536413735423537414142353741364332413034353336344339313634344146363633393939423639383046394233333142304545434233423346443332333734374531393739303932324643363343374444313231313936453845354144323935434232423232413844353438443939413933453030383834414131413641434130383343343437333833443832373144344133393436364444323331393141443534453646353436424439394432414541393531324335463636443333393844423734363942343338443641383641374535413632354646303036383230463843444431463335353643364241384131433542303835343636434535423939384546333132313630313837393031413632364334383032373734303043364446323130324631383739373837393635444431413937413646434335363446344346444143384431424237463138313246463145354634343443463836314641353936373245353631374333333639324141443446414145413441443341343035414342393636344235424241313335374138413244333639453735374241413233354636433638373544413237434343384345393934443843323631343935453232333444463244344344344139344136364132304637334333334236334535463534334137353533323934413637363441363633353134313943344138423034354532343443463934433836363935463132393936393742323244334446314345373336333734303442384237383436443839363345343935454442413236413245333133343443434232393844413633413842343738414235383633393536353541373936443132363934363941413333313633323332353044393436354343363432333944353934363333453631453742363339303246463930383237413242353239333145363631363534303337314635433135443439343634333631313530354244463245453836443537443245413735334539454636423239303146324631304433463343324436373534413341394433414343443541353234454132314535434135373145323231364139394432443544324644314434443346313246314441333734353444344541313745314437393735443933433034454431334238463138434441373333414139374142434331394636433032354441394431334546444444383630363439423533333742314232363233324341354232303041423335323643424143423631463346324535334338373731433644383242394333324546433233453234463742354342303434413442453838303934393239373442444132433442333744433230324236353936303034373230423633323534343933443031363845334245313637373037373042433237304439343636444132373238363133323544454343423746393132414542364133353331353138413235343145303536313246313739453046443346354130314130443438424430363041303242323845313738393435374641424539343734443734453339343446393435343643333738444430424633323145384436433537324343344637313130444634454432363937413934463137373333304638444333303934373541384145353433393733353333364342333630344336354539353239314332363438454338333431384143413839323939374441303232344336374336354538384137344632384345394631323742313044393338304343303337453238434344363531413938394246333436344644393232443338344131364432303445354439444231364436383536303637394144353844463135394537434638373635393134434645453535323641423745363336343334393938313138353834313837373535324439364544453232363037313844363033343841384342443435394642433937313145373834464136384136373533343239394638324534453533343039433741393832454430443331314632354133313343463530333536334546313342303631433230464434374541454632433239363939344441354636314635343531414434454335353030303944463135384234393932413039333039354430303438334433313631334238343735343539334232433333384135464643413637333636444230414539353346423332453441383245334241334439334441363235413836434545324530324530373734353341344432333435383143414330313136384332433830453538323239424136373939413339463442394433463238463443343934363539343142344641323144394145423542384335334433443035453641323841324431434236344130314339324143374546383030373038434435324439354239324638374432323130303534314433344443344546454338434241343431353834434233304235353444344439424131363944313339414136394442414146383445413946353436384341303243373442393835354136324442363745323936463830384634383839363241374431314630414141303237463932363232443635444245333034374446313936413442463245354543383441303142463135393331433232394434364138454338303636303733363645443635383042413246454335353746304135333036353238364541423235314339464139353732453734344532433237303641333141334145443335313345324135383731313631314536384236394643363542343242313935444230393336463634363634344536433031393741453236373238444142364331343243323644434239324632363730413933453742303833303241443241463345354536343337464141303536414535363642373438303530423338354338364538373430443638424442363435334138423232463444383338443834413939444231463331413539304436303931374539383936373144393030453943314137414534463634453333424334303141414134443441414530343843343643333139463533343437354646303039413946323346364544454438464644333744443939393239463731383546393644343235353044364534463637434631463137344530324642434136314139414433324434453537454345333031423533353045354637343445343743463037344441363743424137374236434535363644434632464241334136454334413842313430423834304146413637333445413045463142433430464142303441363141384237353445393835443334423637324637344337324235394232333130373638383939414136413231453643414438343636304236344642413138333544334535334638373634314542333039364344414230323945393431453938463644414331303545414243443844464232323532384137343335444136414134443331393036413030453532413245394345353144364539463345304432303631433638423235354539374541363944423331363937303646343334363744353641333531463444443434454441353430423344323342433643453131443441424143443445414345433441373934463944453045393238423641333444353035423438353736343630444646303031424530424437323642354232413334364635324537314444424532353536394537414536444242453141364643424544314533303639324432364237463739444136464438303438303843423430434443463836373843353333414243383841453537333032374234383835414441373042434437323544324342363737434130443234373935333733443136393742413643393436343643433337383036353142423843333244323133434246304135384536384541423635353338323633364544333139364236354130394233433637443531394541394346423539414432344334393132354232334136433243313834304539353135454231433438393946323335344137464134463639413644453136464236443841374143443234453935343136454630363044364139343931364133463844413941453545454241313134394535413943413632364136344332453232313045424541333344334136443230343738413538433036413030414143413542453341393442453230444430443239333535393732424230444242323341463437463439363943383939383137443937343734314343464134364631364139313746373139433531414434463937393935443937373033374334384130434242353443353441434132433435323630333536453633364246364335423743414538453639314546463030334335383032414341433543303131373838444631323843434343373936454336323444374531333843433739413738343444363332304245313033323939304237363838323635304134373843434346374332443346413845364639363136313242373833303941384433333033344442393831343333434339463644423139354336343734424233373243433434393036363138333842303434433045373743303645433439383636344234393030334434393439364343303434454135324539454642433437343435463534434242323133353039453042394130334131393936313633343043333834363238463833364333303536413539324231463845443830303644423443363443303544313635433633413535323635374445314539383336343834353244354135444530413943363237363441324446304245334245303441453839383835414130304142413737313935453942354335363239443741303037343642444234414439394245454543383441394435433933463032413945374633304634433043423237394442333537304337423635313442344432303638314341353639434232413836333739423246334336333242353532463843463138413944353639443141333230303644323646383241443435344134363644314344463444333942353146363837304442433232373342453237303641353346314145314234343442344138364143414432413230353244343533364132453645304438463038463434354237393845354633343341423732443341393746314442303734373537433639363736364438323532443643323241353241383234453837393831424544383345343641303846324136373044394332303830433635373938424546423742363135434642333734373230434546393444463231333841464435344237334442433631363737363131364438363039443342363641443637353534354446454631434630423242413346413939373234434536434245463633333833463336373241363037314344383441353843363534314435413333453437333235323434373836443845363131434644463134354234434633443530424430304244323339454538353634364645433831434539423639394245373036343738364638314446453531453446464644413030303830313031303330313346323144343544424133354644433242453137333242303736463935354336303330464543323146453133383245383033374131434330443836434642413830463942353331424638353630414341333442323938364130313044323843423944324243344135354141414531343633383041373232463932414436363541303232324441463042364135324444464543393535463737303941333045373044383745433242373034313737363343343031433743303837444241453438303830313843374446423746413836374446383335393532373744324239354334444237413630304537463337304334384345424545354338464133304144423943413046464445333030313630363835363733444439363446373838323830313236453230463930374631313746393835364146363530433144384542303636444531464343363835443841314233323042384133414446364341324636443144313838374442464332323434433946373446354642383934323841304239374231453045374631314445354142444442363939353036314634383631313631364431343543443733374638393935303637443046443441353737394646303035313143384442443831443137454641383230424145374343413441374536433141353746373239413538333336463535394230304536364345324143334237373046423846384445374643413141383742324646443436414132444333343442413935383946443831373233314439333945413530343130424445303145373742374536304333343645373841314534414634444533304439394538323239443531314335384137453637383635453541413842374235333932364439394533344235453733413730443830354634463046433336444333313630353433453042364430303341414131333231444443323235444234414341384245413837423235304235453137354541353543364245323542423236453243314637354331333235344430454333464439453746333835323845383242464438443238453737303431434633303645443845433042423344384332443135353546303030464630303633414633433546463939464341354133433041373036353937383441443542344530344545424638343037383535363046384133463335414338363546333037414641413146383732414544453633423532354331423143374534333536303646353146374231374338424431434633323834353536414643394437463632424339324535434344304430413945313343394335374639333830343435423539373844324142434336343138394641323242393942434130413338383345383842444434304132353345433543413833444130413532464534443936354544333933364146354242303644363037393638454238463345453134303231434634434142363044443842424642464543393432343037343235354636333646334638323644303545383532454633433241353836434344453444414246364232423430353732444645323539453845384532453745444545313130464638344235353733424437343739383144303042454245373134393631314239424132454443333035464139374137423245324135303642463742314533454332353744423537333138453137354145314231364431434442344146453830324430464545304346394142444133363839393339424132384142333935454142383934383535434235334333464137453636323141413241303641454346463931454137304330463543453445303843384446384634334546393245373146374132364638353539464630303038394132383041394242463636443946353239443139374335343630313446303244393034373839453438394643434535394141313742323032444238364638313346413034413435444637323341413537463733384236303039463635374633344641393437434441373142303539434637434433463930334541364139443031393534353142304241343837353037444631384446364346303134313344334631333233433444343145313743464137453539393136413242433542424645363838433737443843384633454538454142363243394231453345304245424437333042394631444439313739443735433433303238333142353333393636463136383545434343324631333045354231443741423943463333333944314146433131323144454130433545314637453635463835454442344442354335414441384635434541434438463431453744354633333937333539363346443931433634384333324233413241333033374237443538334445344242303243324631463835433243413239423338363941374437453138314239333030333537364546323143424236414346374545324544434239413832454446333141323746314538353546304135313133383046344331354232414336313945323741324443303436443546384537413830313945463841453133434330453743344541463833433441463646454145374444433239464533304431423138313146334437423432373045423936354137413237454130353141313641343041324433424234463135444331393838354439364631433842333843384330424343394642324446314537323732383943433032423732414345314145323543353430414633444430464341363244304534344135344543303539364230354342443033414231464339413746423335453534324441353537384346463030363530303338384431444239463131304434353431453134453645424136353038363037344242334542463645363030413234414146383641383030424532353538353731324546394632464238303337374135453735394334443233433432433830413637383844304341423630414636414436444638364644364633443645444139343739324534333838324230333446344646303030434145353735443346433333463734423534374236443439354642374631323841383532424146414246463030443442304631383236443744374641344241304136323842413732394330424637313030454437393643463244334638323330303536363944304233394137423534414542394532384639433045303935444330413741354539333931383244373530393431394233373044444338414644414345374632423032443545384145384230364543314538333343433535363532384636464235374443453333394642303946463030384439373344323444323544433637394145363245333233354332463436463335313934333730453233353435463838463142433136313535413734313939373732443532394535464336353136464630304339343333363644363342423135434632343446363338323732384341423934333046303445464344363130413739374234353835363031443738393839463238463036453546363437353337383137393645453936314539324434373939423446373941303746453335344336414146444541394235463646313138353639423237443033424142424136323830303141444433383035333545303245333133414142393239363437423831314142444430464343373736444133363537333939443744424330453745463939373035383242423544393430333134323538434646344337303238374546303531373837454133353931353532353632333433393238453737433930423345394439383339373633414130373330393742423645413535433639453743304438353430343245333837414637464543423041423130324546364433304243423437333146303243413235353546314641393635373236463332323730393043384238383336464534463536434136433934373241414544434537443132384341374144373841463331373046323138353135333046374146373746413934303042344638303137353645363541313041453642393136443832394544303742384446443837453535464242453232314534444237334243413230433237433346343245363837343732373242454646364331343137383037334232434230323545373832373837463732383441344139453045414346453632384434464539303632433537364331344335313246374544313441464435433235313643433343413146323941453446313142303632354534393542323833434645323546384431384533443430313143383746343846373830374538363539453246394545373645373636344331343346413845354530323938323344354636374239363839313644354133443644343435303936443131444238354434303844424136413134453443453244354633314444303734354242443731314444374345423739354243464434303233354532453346314642394237323430374139384441353543374641463731353046363738314538363943383143444446324630414246343741384539463937463044343144364538464630303443374437463137353731323232434530444643413535303533383744433545344436394630374633373046374438363032324237373446463845413135373145374633333831334635334245304144433641314531334136303234393531433036313545464441353731373931363943364634444639434435433943344446393930374435434138393830373333334231363545414643344134433344323146443637454531423141394137344146463443314139353930394439424638373939463939443935464442453946423744433341364545393145374541353032333845323634343033363341373533464432303445313434423033444243314639394542444344343145343539333939374541394337453235304133443145323034443231343037303731373437384642344634423333443344363142324133363943444334423144353041373646444646303037324646303037323333313241423446353531383236384245443945464332304437383230314332394335463938454135364436414142423741394443343246434231423838443934413041433738453839363044443732393445374339434631314536413537453935464630304439373839323845304446454136423735303434464232463146444132353733343736314532353143323741353443394634343742374543464238303941424334424639393346383443424235314530303534354246444336463334414538323435343346363433433932424245393030314239353942424441463134453932434534314535393239443943313846423437303537323737373041353732334141453133423443444434453739344144464533454537333143373530453535334646444130303038303130323033303133463231303946313238333645313737333834313542333443324133373235334231353033414532343638313244314431424532303843384241383737353844394336324332324231354437373246433445363035344131434330353931324431393731363743344338373532393536354135353133343932383139433738393539333333333236434245353433343444363838344541373733393345314337303532384532413136413445344130353532323534303936363337414138363736364532393130353446324132363537324135313246324632463633334139343543353844333839314436374434384242303945353939433437304341423938414639314633394138463041363435463131354242324636304342384237363639384336414530363530434632443832313143353845303933313835463330383539433430394135343441353733303230433937384336413338434242393437464630303831393435364644343044393539354346384130333539423445383843454246363843453331443330384141383035343043463832394446434243384636334238454232443537373138374534303530383442413137454339364337393936363843413538393136433532414535333732394238383743393638383033303645354344394145323041463745363139434135414139443845373142463146453344433739303534323731324441434530383832464532354139363936393534373346323134434134443333453230314434323130423543433637383939423834453030333344333530303835314434463236434533314636394430394334363633343943334532414443363230333336334342414546433541413244383831423330413736304341413732343732323846383333333834433436384638384141353031333139383132443032433845343232423144344142453045453943363032353930364530413839324446304530383344344535344242304638344231383736303743303345323537434146303232443331414342313832363543313532463531414332443042303632373230434137383939364132423944324330314343343343343135313039363345304533313533333742463133344342374532353939343935303732333035363135323933364236363543464146393131373733303144334630374138414442453345313744334632373138464346463030464644413030303830313033303330313346323137433235444630333434424137323839343836413543443442414536373346463030453043323543423937393038423235323542324434304245323242374532344531324138413931463846313937423246374534394638304535334633423531324535374335383232353232343531443842413937353143374331433435393546333539393746313241463635343345303135454341304638313834453143444231393437333031363442344134393732383838393539383633444643303541354432384533453135313443373944323846313043313931364332374331394643344641344139353138393943423245334236323631383941373132464630303639313745323632303836313142453530343245314630433036464339343743303541363235393244443445373743314345464531443232343432454643363631314334414136443730343545363742433230343839323931324533463831344330443435324643413836323245323738463836393135413941433139373138413838393531363834354541323938364341323138384237443431354631304137433032314438363245304137383833344342344336453130384232353931353142324536343133343944313133363645373238363032364445303837453730364239384539363432424541354539373933393846323039353135344239313036434338344532363146313638424639324439373135313835313338333141324335314334424638383338383137344341394638303543334643323733323930343435353246413934463332383943453942374139343138373241323532444343364341353943414338303935304645353943413035354333393246443232343537433246453136373532443533333931433542453444343933393634454341464531364346383834363442364444393033383833363243374330384434323132413536304344393934423036364337433443393541433937393642443845354230454143334537304643323644343743323335363546334630313535324230353433453346464441303030433033303130303032313130333131303030303130364142464131393342374435434539333330303932423938354643303345373138454639303042453843374343303236353044444634314334394544414541343538314146454634353445443639334344344334433131424130353242354142394536303333463536364344304132413235373637344442313833354136393533373843383942324531464434423730463735433143333738444632454631443445443843383746453445433336383538383534443835354144424434333944334436364441313635303839413636343932433633373330383835453741324130314231433037464646444130303038303130313033303133463130323342304331383934353044454444433446313045443035443646413934463141443643383334453539454130444336443744383737424130454437363437413242313334423438363244373932413145383131353141354334443643413843434237424237434437453133463838363741453541383537303536454335314531394438354145314445413942383545433434363539384131434333423831384131413239384439443333313036323032444439443043424236434434353336363831343032423030343235453344453134374241454646303045324441394336413436383846373030453833313545314342313141353746353036394137353632353946363643443631314130373434334634353745443333444237333933413334363145353936433235364230383032433539423437343534423246343035303730463933363535453432413635333545454330383541463845304241384645453841343042413433333332334544453234313433324543343542453138374631303831423337354130353033434638383141313136373136353746343930333035444238414442424133453236413830303041393641414138333944434333343335394531303833374233463839363744324343313338383546454345383542303143414441414431363643453131354335443235433035463134414145444138453235463742354445453534463543373945434630384145453543413139393231353546333743423744333530384438323841303037343034413443384343393838413442393044333044363342313539363641354433383341434242373842423835313442413441454345353545363142434439423939333831363036424646383936334635323032394145344231443346333244343542423142323934454141333636444430433738313736464545313341303345444646303042303136334230443041313533433137313946423444314242374243333245314639324630443145383546304336334144384232334234314141424330364642393535413032303646413741354445343138434330323236353945373246384243384537363036304536464131353630413344394338353043463630353036414438443031324234344231324337394237453243303246463030413132433832344545413332353243413646423033433339393630303843363145413439313730443836383338413936384434453534393432324234344235443237323431303543414641313145453238334537444345344435313430454541424530444145453542383839423530423739313431444238453444373031353336413542433335443631313239323234303842343043313032444445333633393232453334363930443538443533354446383838353433443143333636354234444143363145393634334342393333304530344235314141454146324541324338354437323434354141354137313632373944384432453532453337353537433731454632313941314541463546364230343436373236373939373034453536333739353544303644464134343132374141414144463430333845433430333430414138373436414542424139343343413034374643383638303935353935373136453439374539343734443537433846423043343743333941374441454138424141374132384435363432443945364133363937353536344534383239414541303245443830324537413246393144383245363436353143454430394231454630314233343731433644373941304146423834354143453031324132393630433834413639353445373539433930303231444445394536433245433339343537423235324136393330423243313643324346304434343545453236394434393431333146374541353543353742374343344130414430323833323633433030414139313739353133363246303139393239373243434334394544373445313446363643463531384131393541323833394242424643333030364341443130414542304431454434303036394131424439434431373535314634303530383642363135423636343738373432323830443532304241304643414642384343384630363233363430413943364244373730414331444643393145303636333944394331304535324642444631313241454242353145364338363833414646423444394344314130314141423437374630414334423741303535303033354433413845303738393235323045444235433041313344443431333031374242373238424142443033314631313934383234334139374537423539303934444130393244443832303135424337344432444435414433303541463736364541413538434330344143304443443244424132423838333446303032304145374135414243333342323342443030383246304543353643413239424243313041393534414646303036323242383738364633413837334143443941423238443738303639344232383232344235343533343437303030304635363343323535333441304331424336343738333534314536333645433633343141304634443143423939333833383238413544314532434233363938324138393641314331333942303145453731303932363734383746314346423835314546333544443130304234304230414344463330324634373336424337343036413632334541354637343538383132463938313136463537423444453231423643323432413934314644343335343639393441443945393535324345364142384139394639333333383841334331363236354338433630303339304339334445444532453833393630304143383945453836373932454243373445303234334344353134393544363343443537313042334334303530383235314132303044454537454535434238373530343238303030443736454337304244433839453730443830323936394142373932443243364332414135424532333430314131343531463131423445313939454144323943364145443645434438444341463032424641323245453739374545353534443045363830364241304535454341423732343130343638394335423231363643413335314630454431374445303744384534383045393238384241373131303934364141313138304631444138334439453041414339343534343942353931364141363644373730353032423432433142363937343643423938433130463835444139423532443945434541324430353235323644423532434345444636463132393443383044354142333437304446323930344331363242393138383537384241453343343243384437423143414130353038394339303042443744353343413445453431413343333238374144393535353936443038324239313930394130324535313534413538324430384341334241393742463630303246444246333846453542433836424544353937454434323545384235313037443545383531444344324245413334363032373941453239324430353738373942454131344431444432463933344632304643313833373737353935354239383644373237413437323643393839313534313645354132434235334342304632393936384142323239353630334243354434434645454430323530443830354135324138423734373833383142333130413331373335323830384541433239433031343146383831433333383942444534423046334234433844353746374146383030373030354239444446413934394634323535314433413032454639453636433532323044303132383343413842304432304632304533304230343834354232363542374444443445433243364134304432314344423645354442413330343131303133393633433346434336383338373835303233363137343135303731443532324144393430314236453237443130454530334531423444304237373444304645364331313831323539383034453033363545374232303934344430413834424136344632363344324135304133343738373431343536333142304641394434413941383135434538353244423638354634433344303042303535333933443145323042333235354335453043424543333744364431313645323434433644334338304139373435433741354335414132414132364133343639314637324644304238463343323931453441333945364535433631434238383846303036453436433937433434443544334138324642323533333235354233343530343045454346343632384538384333313046464432353336303931354143353944344145463439444535433234413535423435313536314533393033433345413145423244414242303045393543353731463742384530424232423846303943313538313138444534344433413044353143334643393437353431304438313430313435353730363132444432463330444333394145393231334243373244443042453536313242334637443341453131363746333443363342374137444230343137374630393833393132343542463841304332423134374135373737313745433134363137414646303033443136354243454638353334333934324441324337313235463234344130324236363238303231384132424241393532304344444336384532314441303346354141333939393536383037344344374437454338444430354245343631394533383046394545413236353139413738324345393139334434413433434234444431304433323231303135464435433436414534344131353342383037443634303430313630364239413642343242324534424144313545354346463030454343393536353332384141384443354645433738423836354330383434433031303536393743343646463135323538373635434437373941373838394443324141374336384339344444443931343636363441444241333536463738434644343735354636383535454141363731363442304635464432344538443444343041383831363536453046363530313330304238434234324331353536324538303746323241343135393842444139344130304433443037344534393931444537344630443645344234373935353044343139334332313641323337393435464532353443414441354444413044313132433438393234433044353441324538373030373035364443453744453533364137394539454342353041444330423634374330453141463838323030383432383934314345334639414530343336344444363836313832313431433030373345433935344235453042423938363642433239363236364134394433394337373435453630453646323532373441363837314439413931334232463045344230303335374434424232314438443231433943444432354142353441453134363336414541464637304435363944323842324332414430383334444537433134393435354237343646393146344330464233363337424535384641323137304142413339394246424631353131304234383530324438423533333046373032453438303744443135373845444334303238313531394133323845383246413832463239364430424430373236333043323343343238373337444644433332444244303930313144453235414444383631424535324330343638413135393139413538354532444231343545333039353743413444413542314434373431464332363538443839373441353637453034453235333231453233303832453830303343384137314338333634323036383041354239323841334343344436453030444235323941353142334546383838414431343243423444443136304435373734303039383838453430324435314136464241413846353942313430424242324443393438383234453030413839313444333445303344393241334435363830454438463644344538373143373135414430463334323032424330363732384536324142453231323541334544353931413338444434413434333631323336363043363638354344304536353941413537393131414441423944463432414141313742364236323734343544314431394441383739414642383944423837323345304536413745333838324142434246344245393130354146333543353430364236353636303239463437353032453041364138374130443142344533464630303230413232453830353642354445424343333735354431333835443733374537393944394437314438323038414532454146453243383439433546443130343537313041384541324230443642373732423641333535373334304337413339373836314344353535373033323044353436313631463038434144423842393639313645433035334142443042444334304434343430314442423941373432393939453633373942414535443738373931453645353035444435394131344235363931374138363136343530303335324531433339423732424245463035453238424237353736453042454532413542303437313735454336463342383732454132413537333645354143353733433430433632443141363241454431353742344342433133424341413231433736434132353532323135343442413238444436454436343245413335344539433735394343323045313135323338393644303346394146423831443835363935424132383445364633334646363037453130333531453141303044333243333231333341423838374143334238333546343934383332393738373544363545423035303342373836374643313936383631343630353041384241363842413839324443453631363844443042453938444144353842304234364238313245384430463443303143424345343738353038413030353132383136443137303737383031463430324133413238414143443843344533313246394141464146434242384330303836433542434433383935463231344643354334363431373742384534453230314233463341433243443639373341353536363844463545354532453632363733354343353041393444444437393731443534333145413030313537324141393343353146443543424535363936313536423431363734323343324443443046384244314633313435343935433932464630303342313139324345323239424444453745453631394134363530304436414333364245413938433230324231443137304437393745424638383535323030423939393533363546353644433035393831424542343642384137344437393830463231354641303639423345413542323239413333464146453237383842374643393933423845333937313737423345413239423946464441303030383031303230333031334631304538373631323643313142423843364231324233313738343443323041454438353131433546373745323139394333304646303039453139383932373933393546313135434530453039363137354633443442353246433343344630343333363033414336353335374138414441423132433930303433383742323235383336354239384432383845353344383431354643363730303239413934414134443834354135453539373230373543434634323837463331414141373237333230373444434141453032303733453633363931424238323031364434413837384239373834453741464630303630444642464436433030373246393845413036424545314142393741354342444330453837373034374545453242343430313343344442313433393343434243453741463531414631463446463030434541333544353446314637313146343643413833374434334241313143324644424343423237363035343744314532373230463531353042353845353642374532423233363543423437443231313735313641313643423631333143334132363934344444433439364438393637354246323731353241303241364633393237314533454132394336344243334234423932393344443133303043383035434635304242454137323045323142364443313830303836424441304338324130384639343631323738323042383543384634344432323134343638424637354541363943313734374343443934344146433739384131343632443742323541314630304241313837313342314444353430394438304634343338374138434432424236323543363339434335343144343132304630323141343232323937304338423139364245453946413636413631464546453231414630323533464630303344343430353637373031424535463838364443343541303944463332434334363032373242363138353130313637323138413841374530323335314431313130343534394530393543373333423936363430304439433745323544314533334638384432423544374645413539363245373846443435414141303235333332443941363445333143433130304235324636384339393346353239373537393039434238454335353945323235353232333144453336383231393444354336343646303630323832463538414336423346384637313438383046354343303241443038414532414643433432393937393945354338304130353346423146463531344439304341443937414338443132423743344538343633363333323239384142394436304138434538323142393130463832383830454143363234463438383641423636413544424439433745363633383345433245313739343146373238303037434437353334303933394442334533354333463132434530383646433635444441354633314230393336374230364645393941423442454130393338424438303642374545353941434137304343464138354132423835384637304241363245414545304230343342453438443831354642393531434432303942314343314130414238414638433844384134413936433735303345344239343344393239363345313830324131423144423031353435383242434334394230364533453030414444434135344342313135344139413934353435313730413443364541314236373838393632374632344133343632414235423934464135383033353030424641393434363342384138344631423431364338423143413136344541393636344134424643343541323144313035363536364345363532443232413638453631423134413745323333464139413631303834304437393837453034303534334644323235394434423737303344393032454134443137363434353443413145453044394334423242383430413138343030454532313336364539333938344238343441453041463931314337323346333138323938343338433039444536304641333242383143393644433538463246434334333042383442414230464444464238354434433345353238433745443145373235433039463639373937394537394337323536394139444346464441303030383031303330333031334631303637443232414132304238343833373046313335344237303833344139304232343736454433343842423434323136454133384334424632304338383735434342453034374437413945383938354635314544414238454636344339344141453838443641304641363335424443363244394343353945453041393042303936393244363036433631313741394144323541413844344239353445333244463830323137373431324539363539373232333942424438363934423143363834313242383442303845303441443938383034323243364245303643353641323944393031363241324645413945393244383934423730394338413343453635433535443437424444434537373046413832303336393441324242344537453244353533374343464231304330453132373338433934353130383042413739394345423934364345323533433544434331373534433146353136423545323331363931383944364430414236303832313733384236453136453133394331424443373136423635463342344144433032453434364545354234363031304545373539434133323330394536303732324135304137393944433733324633454135414330433541413730393646313035313131453931413835323744344634393338393137303531413838393933333543303043433332433230383533313744463142443242323736414338303336363839343945443043343441413346444341394237363145393832393544374334354332424332353133323631364445453539433241313432333445413134373142334341463835353239364338443843393841454336394337314631443136323532393833374236314145344534384241413432383535443830324433463330373632434644344131413736413235333841393639333444423133324443323031433931454638433934333332453231364543333438384439423846353044443331374230394330414138354341303339413943394534464535343339313635363537414243394337313336433235453836323242413935373331343245303341393945333230334541333638384235314441343036393043334532453336353935334132333835353442353544434233353545383936393643303841453130334138384431373034313332453633444134413031453631443642363038323938363343374330343843383039363441333837374633323834374239354634453132354442373343393330444546343442383943354330414537444137393937363232443245303634373331374431303934344139344134383336454139363034354334344239334443323041333443423130393631333841364132303542333145393031433244323832434239463537314643434245433746454135393544463346463346313341373439333638384545423838413246373632363931313335453932433845423146423836413933313034313735303143313030363638423833413841344432354432303445333030414433413033313845304232354541384242343630343031463332384138374432353738393044314538384134423137323236414130303245364535463846383044424631313435333144433330303936433334383445463545323042413944394646323046454532453934373436433834364242323835424436363938323841354231363537463237463530464336334541353843373633453834424142333231304433363134443841343136453631423337324130424139383644463246464644393030);
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `Description`, `Picture`) VALUES
(8, 'Seafood', 'Seaweed and fish', 0x464644384646453030303130344134363439343630303031303230303030363430303634303030304646454330303131343437353633364237393030303130303034303030303030344230303030464645453030323634313634364636323635303036344330303030303030303130333030313530343033303630413044303030303043383130303030313432393030303031463141303030303246323246464442303038343030303330323032303230323032303330323032303330353033303330333035303530343033303330343035303630353035303530353035303630383036303730373037303730363038303830393041304130413039303830433043304330433043304330453045304530453045313031303130313031303130313031303130313030313033303430343036303630363043303830383043313230453043304531323134313031303130313031343131313031303130313031303131313131303130313031303130313031313130313031303130313031303130313031303130313031303130313031303130313031303130313031303130313031303130313031303130464643323030313130383030364530304146303330313131303030323131303130333131303146464334303044423030303030323032303330313031303130303030303030303030303030303030303030353036303430373032303330383030303130393031303030323033303130313031303030303030303030303030303030303030303030343035303230333036303130303037313030303031303430323031303430323032303330313031303130313030303030303031303030323033303431313035313231303231313330363331323232303134343133323135303733303136313731313030303230303033303530353037303230333038303330313030303030303030303130323030313130333231333134313132303435313631323233323133313037313831343232333134303539313532413143313632323042314431453137323333343335334630433231353234313230303031303430323032303330313031303130303030303030303030303030303131303031303031323132303330343033313631313232323032353034313133303130303032303230323032303230323033303130313031303130303030303030313030313132313331343135313631373131303831393141314231433144314630323045314631464644413030304330333031303030323131303331313030303030313644463938374432354143393543383133384237384137344142343643413135433132424346424138434638433038383534413543333039344134313534433241433836433431353936334342303532443837363745384534444235333731413539414635463133393334434634443443394136453843383445444636393938314530393741433739434132363831344134464630303433383331394345433444354534464538353339384338374535463537463441394632384438414433334231383931413946353341433146314230433734353730454331353739374132313033343342343437393432444544363044334244354341343332343637334146313633373645384341414644423635363542343041443835443239413741314143344430463444453246334446304142433238434443364345443342303842413545414431423944344342413838463346343639303843414244393335324142314244373843434635383234343138463843463744313339393539313336453935443637443332423736374143393235324645384244323743463534433032454131353542303546383345374539324639374441454239453141303645354430364331423039304437464532343834343644433143343538443442343939443544384434413642393233463844393642304233363546343833364434384342384236463941383235434630383038414145303936354232453136433345383335443441433539423239384233413233433830434644444230313645343945364246333139453530413144434135324544363331413839374339463046304235363933413638324444394331424139393833394639443336453939304130353941443743393244303344454436453430313837363138374133463342303944353937444541343743463233353344363236314530364134384537444345364430423235443043374246393541454141353346393634323935463837363630414630453544364337363536333633373242423141443141413739443232453544433739303141343232393135394344434246363344444146463030453331303036454130363743393846324637383836353444413846413138363631373843323537324131364143434432443637443236384642393243304232344645423139304332364235463239333839393733454641463835363241463443304346393333303145384646303034313142464344424445454434313941423643353345433042333233393534334641344238384534343845443534433333343531413633374242323637313543363531414345303644443738443541303838344642453236303532353139363144444246443336313532463241303030443146364233444639453846413738383839363739423346353230303643393246444139423232414136353741413435323537423139373946353741394336453131464630303430424343304633464141443639303532374143313931343936423846323734334637323033353644323545374143353246324435414537463737443531413746384535323641454342343246383832453937433939354543463735324536434341414143333932373537313937423630464344384241364545363235334236394233314432413433433738354334454233303737413036433544393938413233333038344144303532373539413846334132374343454331363335323343454341393242443430374235393441414438334538464546343039453830374238344230324334443937333842424532323937413144323644333732434437314332333736434133343034303637324234364536384535433042384436373641423033393534363245364442324638353933344338424145384431324236463246363346304639353635463536423843314238373937363345463244463044323545383531303136413936433236444133444534433944354242383634344637383539323832433442343145383536383839423641314133374243394632363343374541373539334336373532463935313442383242313243314146453731384432413338453133383439394630463446383541444142443445423843463338354145313833343637354331384130373730413646323133373445333743393330353530464646444130303038303130313030303130353032413235423343414438464542334539424331423538363343323743344535313345353643373339393633373435423038453238444344383637374441443644364444434437463442464244304545413644364236413643454643333736343636433545433334334443454544373037444346354545383237393443423244313834363541444532443932344631414233363338324537463644303546453446433032323436423739333338424441443143343343393633413445333343373438354641443744394144384530393944324437333334463634353541423746363137333644374635373641393530364646303046343145423337393837443642443537363642363130423641354238333231443445433345384136353838363538364635423041353736353635363633464439443645463946303233433634344531383932323738374241453843314639363843453232374543324333413241454432374442333644314336393845373431314246343537314538453837374230423635374439383439463941333038323630383833354242363845334536323739363437424346343335413435414544393331434438323442444144313442363735373632423842373336363445353142433330343731304544353343394533463633443935443832443945323231443533323642424236464437414630423245353938453237364436374231374543433739374241384437433336454441364435384144354246333343433845383845374133463546304345423634464435433641384545324444323237363741434245413144463439353144304543323142353142363637303535413436424344353746384136463638393144323645423539314430393644444442334145363645363446363542313639353844423438323342313231323335463142394633333643333242443744384543444436363433333635343846434145344239323936463541393233443446413636443646343746464535434336304231464633394439343244374539453538394537353531413645434137413846393336333134304342354543303145304432394543413839454641313632443441304344304444463132423736354232423033374344333641453138384144453438443835414537313234373243313732303942354639433645443445424444314435463335314230414545443642443536444144394246364437323233393337324335343839383544323437323433363641343844414437363641364642373641354236394236314331444344373945323633454144373744413946363337323244363531394543423146303036453534383738333039353038453645363537364645424142463037394542443846363341443134344433374644383232424245393535454143313746363132433235393532344239314339323545443741453446353136433039314533373445423633374445463032443145324441344446463345313746383632444144443332434231343246374137313244304532344146304338453444384534364136354139333837343837354532344636323137363638433645334439364145424538443939384346363335454331453242463542434435414334363633393439464143324639394145363738364632414441464142303442363235374631424232394138454139343634393844394537343146453432353532413636363341454437433533334536443130433537443543344439443545423243414435413831374434363539464630304130464144433044463636463634464630303736434336373245413044323139363437394532414241373142313936334635313542334432424635373632394341434139363837414436383337443045463435314131373238454246354436423444464246303431353544453642353335344136393843433435454143374339423144384342354541333235394534313334443645303831424230444534464543374232444238384141454145434542333439413544324344333139323538314446373835453142314241373338463446413836433532384235414435423846354241394234414242324131334541364345394644413336374130374543384244443335324439353841333234464139414637443935413038414230314439314145443744324436313745423546414641333733364341433446353236424246413142314245444635304137303139464645383345443045394134393736424232423135433339343645433341423933363230423045393230314539463531443145384337344445353644353444414638424645373336324343333742443733384438464631363438434241313932423937344635414639383632464437353642373332433932363832453839463635424146363236444635343735364639413944374239413238444433374236364537364141414641423838453342443230393643343731313233383943364143344442303846433736453539464435423942373441394345364231423134373236443637424642304142414638364345434133383239344232444242353343394142424243324644303941393941443636343841304231314336433530373337304430363832434446374333414236423641343746413839424645364146364632343638314646303044394243374337334631464431463542433745444538424331464546353446383536433434363437313231424545313345453236414431463833333145313437463137374634423845433139413230413939394441454430333334374642444146313430343433314333464644413030303830313032303030313035303232394143454335453730443038423441463333393739313336354330433832423343393341333245344532443544434145303942324238324633384643453536463437383039424431434232413337373237373834303245373045353945324433383543393039393842384231433838454535363341384538334641383539303533383737304635323834353334393039393233444539414435463030373732333242433642384533464630453441343844363431343431303838354534454335363134333945323036344136333537313031333841373146463030433042423036334536394630383242433646364133304535333938343243323639353031453235333730384343303137353932424341453238323344373146383036383430313234423145394331453137393137393441463138373230433339453339343137434143323243344336453130464346324243363133373244324134423031413946393435333141353031444238463430423144333144343745303531334444334336343339454637323131363534423037363634344233383433303741313646343638353835434242413638343446354346343233414644423937393438354537314434303433413145383543353030383043413245343342414332373342303938373242303944463239453730303744353739334631364145323943313033383538363934343737373338383737314339463834453737343843374441353738364130304132453031363442384344464434333542384337453131333536343237373734354238344433384538354142393631333846344645373235333632434146453732313432313746363343343745324345433341383632323341394544443033313633424244443934443637363642344143313238333130343441434143324332314644374146433232463543393635303238383433413335384230424241313934454345334130463946453542384534374630373937363341463645383533334146463030464644413030303830313033303030313035303246453039343232303543453242323137303641453039443137374638344439444431383132413836333733384231383138423942304137443238444539444146373032443138344635383538453939344531443930343741303433423139333846314632313230303338304445344538354243354232343035433844323938324632344631413634383543444545423931453938343741433931324638354643333832384641423833303232453535363334463338314642343942373432313238373236423533384132423841364244334241374346343730303531364531363533303737313943423934393843433330463232334536443346454239323941313537363630363531343341334242373538424541433336393842394130423832453042384137423533433634353636464432363045324438454133434234364244413137454142343243363036353635363537333445373243414341453435433845313332433731344342383134373238373045383233434136443635463038413637433130384137313435363531373734323530354532434645303141414130313846453032434631354346334433384136433842393232463042463946393234414332373630303245454631464439333539463545383330383935304346433442344535333832373137324339344439353339433441393544383545363437423843373639354638353142304133443933434137303443454339393331454144353835314334354336333144384145344135454337394636384443453445453245353143303031353233383835314332344137424643364243414131383042393543383833343032413336464433463041454345323141384634423042394141454535323333393337434232343635414633433139463632453935414430454343384538323035434230414542423331433130393930464437303837343630433931463230463542364631394341363438354141333943333834393138374145343939333631334132304635303334303431313241343044324134423231413833344235394430303530333330314138323235373133384233323732374634363637324542324239374437323941453231343646364239314345314633413245434236424334313841343946324635383431314638364235313042393634373343303946463030423734334635304338434238423630433931303830304336313136373134314643353342303837373446394341453544363043373346453436313346453342373139463937384346343646344141443843334241313433324245423936453534433845374137464644413030303830313032303230363346303236304336313036464136414441373338363941433642344436393044443642333041464235364331434336464244353541434141364539414437434630343344463145463837344145333435364433433346364532353233324536373842443746323644464630304646444130303038303130333032303633463032363243323545423341363143313042423535324144313944313538304337444135314430333637384334463042453530464434454231333835373034453941434346303244353231383045313744363136453635313639464436393338303537444234453345313741453033344442393835453543344146354643324633333831443134383436343142444137423531383044303346443534414430393632433737353337363637324135463046464644413030303830313031303130363346303236413931364638343236414139463233344537444644393944363135313635393537303834463643393931383142304235413232394433443444383546393635384337353530314137353437303245334332304439313532394135323239353239393035443839323237303841323642393634303445453030364438364134364139413935303832323630353834433141454636443639363530303543423238444630313143324435344438343438464434343342453436354141303730443342433133444630434544434343343936454633303235364536313639384545384234444137393834334230313339343636383334364144393536373339364438394334413234423834314342384336354336304433414230384233333535324131303830423142413239423141413635393939443831433637464345324145353443434341373846323938364143443630353133364344313536413232434233314531353542333241433031354634464436363633393943393337384439314431443736383332384441353535413545323244383237453332423941344646364142464630304435454438414441354133353741434234434535313532353239433443323036393839303944444446313937353238344137464235364430323341423444383332454438393636464535314242423339413542314437303330394135463934423237363533443438453536454644383633364546384232434342374336463835414232423035453633413938363131333533323232453331393139383534353937314345434531383044323933434134373636354446303345313334344439443531423335343742454444394531304241364130374436414334303244444631394233333637433338364346444631393835334541304644324530464531313932424433364134464641383131443831413236363045413334444539353444443731454638323846364231433346363344393642433032413643394237453731394234353344344539433546343538463141464630303439383236394237314639453939423138373834344331393431343943433143323032353342383434413141413230394639323244413939353536434137323330333532453733353541414336434438413346383938443335324137374537304337433232344446353330444432354346423330383642333837344530434646303033384341323031443936433133383938363633363630423238454132353844363839463746363941393439343244334444373437344138334635314636413842323338304537344642314130334436304441364145324541434237464434343041354138414133353334464342353933394243343437353238424536464446443932383630314135423431384145364135343043303442324341453032353734323337433944343345444337334144334235384545384133463244463133343844313039434434434339343139303936313136353230303044383039383637454135413035394333323839393336423541363037464343323333423139353930344144384238374543443244313136373641343739313535363539414446433630363634354432353236453636323236463145394542363637463532343136413535313241454531333037463138333445413444353936433230433242453935384430413830304235364533444532303532463932344342423242324632393834414434433836393942324438394433453037393439344333443441364444343642434345373333303744434433424639423038324233423035443132383932444544374336353633393534373331444431353241323243393142393742413235334237303545434344383042434636463533363542314432453832383531373438354444443145443642424537413535334642324337303342334230434238443836303233353141423345353231323544443042304342413832303843363944463346303841384634423832394345434134443737373445314139353630353641363033314630383242393845463839333946313843384444443345433031434531333839463933333030314133323234423331423136333331453241423534444134394234304543393445464333423030383233373145433635303338414634323246303632354632394143354132433338354138413733393936453846364446314441373644313638314646423941434142363534373546443232304434463837313236393741393438464639323542333743374237413434414232314532334639343342303336394337374335344137354539313630454134303345353945443839434533323641343735313730334536313042454435423332394246454535463038463636333841343636354632383043344332444433433737343239414634383230324233353637333642333143373730383535454145373937313130423636354332333942413834384246454439453131394133324636344330384241304131443944424139414634363832353437354236364330373736333145424430323235383842413141413533334542333730443135334637364446303837413834453632433636344544383130433138463443443345323536333043383736433646383941343634443544313235464644423446394646303039433637454138373242464442393842323742453332454132414635313445304236434643363242353141343244363132303736344533333330393230453633314431434331414346413736303637424130443230333039433538423135353145434531323137423241353537423830333146463030414143333938393641414246413045314531313341373535414242363042344430464537303935413944334538353341363338353743443645443831443846344441453731323837423439363545364344374335443033333732334444313442353031373930444133363843363239464338303543433139364336343643424635444631413844324538333839343143414145344536393031463939384637373542384235324343373138443435334243413839323844454337463238423036363633373038434345333331443931394545393545423843303533384133343635323333353536453534383545394644453135454136313344393139414133383531313437453137343044453842334641463535364543414236393934334443413134374436324137433833363939334139344139363639394335453536374533303546364330384245343232434630383644343931333641393530434336463131433730443431414336463233364333304441324436414341354342353034333742373631353639334441363942354433444244463036423333363745423741393946363936424533333533423435413041394438364638463737463138364442454136394346333045453831353044343036423337393035453830364445433135453942313244333931343934314437353436453938343132313844463044414144353339413341353230423141433739444646303038303841363332463446343934443832414130433537313345333144364639434435373445384146463838313930463138374639324134423937344634393341353435413532304334463331313146463030393141313642313043454142414544313730383239414344343344343546324133314232434543303633414130463041443930303842373734363941414242344441413845413737363645444141464630303241383044313431333237434445314245303537364142454442334343414430323333333241453030454638443436393239333941383941343935334345373141383644363845323830453933353635423431313033444338453936413435394436313733374635343136443532453643423643423033314539414634443431453134433037383432374245393341444135434243383238354336434241334441363943453444323844443642344133353146323135393643344136434434393342383445334143373442413846393137313731413831393837443245383341314638454433394433384535363646423437373431414441414645413736333045353034393637433232333337363742353637433839344238383635453646303845393239364144353330313846443233343639353034394241363236304531443835444343383042343933383432364232423843424134413437333639363931424444424644384446463531453331443644353336353145353142344543384130444136363441444138443433423345414430444531444638384644324538363741323032323835393734463938313644423834313144343541384436373131313635423145423842463130363632334435363135363832363133453335394543444430324243424139343545454141424642383838373039384446304235373532323534463035433443334432434245353233324638343741353933433235304444324539354643373936354344424535314141463634323643343731344230344633313833333845314631383032394446364536334245303635443931353936413438444233413243364643443242413037363037443742344138303630323941373930423644373344463734454338323430393943303437344542363938363946343230414635364145373537323443454344463032353639444631433344394646303044333243424245303944313534394237444236433837453132383236383043434246453435334342324446303542353135334433333937383244393038314543433832333646363746464441303030383031303130333031334632313639314339353945383235454431353732424344383634453242383935343546373139384544324230343742454341384637393644384535353241434137423832443532454343434244343443314435324344393041363044373843433930344632363743344436423039433344313338393541464132384137354641383332453032463842344637324633433142354144443430334333313844374143334639323231313935364145304341374639314133423532334232443830344342343735354536424635334436384437413834353339314146424435334143344133393736393646313741464536324243443737324636383430463537383839433332333931384634434236423938343138323134303733444135333444373439443845453443333041423734313534354144424331443437433043323441373935374142344337394544454143453042453338384638313945353632373539393930333830443430373037384336453030373432393239363844304530344343303142323935464335343745333243343636344244353235384336433341374243354243453337313331304135333530424430444434344436374234313744453831444530433046313244414331363233383543464434374330373044314334463638383935343141423134463132323436313637463141373032324332353843304339393843393742363134433637433433384145334334443234453841363342383842433630343437363234444537303533363436433133393645304330303241394342383144393231313935383246393032453739363635343942314436434244374536354132344631423146414332353645454343443745353443344443343136424635373533324337394546373145394330413145364532334530444332324138364443334332304545354438323135433943443635464334423635453637323435393431383430443044363845394531383544333239383444464343373838314433304336354233423841324535374545353431413836394644433739324538303939353030443142383631423137333731393038324543333136423532464231343943333631354544334630373939394136463430333335383932323530353246393631343338324331364535303539413245303730303643414633413230314535353939454643394546383843343641393337353842384330333231433830414435453635433442303445363938334239393441364532424343383638313044414241453230384430373736384437394646323532374445313546344543383335313035354335454444383742384239384634303037373636353730304435373046363434333737374443424346304136303841374135414341413743433444353833413131454441453632353136354431374143414138373945364235333044324633463036344235353942384432453238354131464341343342383130383036354337313333333044454445373346373238373330354446444139444631304237424545314539354242463436393837413636353238324246384438344541453832353339463636423938324443424139314536464644384646443338373836353039354339333030394434413741343633353335434541433835304344414342394430344433304341424241393430463344384444324633354532353236394234304234454443393533394530303541443037383934313044374531414239393842344536433941463039433738383830324146364234313644464243433532443137314143333031313431433839353537314344374642324630453538313241333833413042443443393845323242364438384131414142454331304646383032354237374433333131353136463936374444454344373946374630414545423343463933424138433833393143333139373545453744363242463532383146333335324630384139384232444343314344333834413336353430414133354342463838314534434234373642444331344635393635334544383432453739373441383536353446444238314436374343313241414437433242333934434634343730453731313842324633374638384635414637333833414533383537463532383044343135324232424542363733333244433035373443413945454246414141313243443933353830303336323332433942354341424141373044354545314344373442444237334537423843303432414642453431344542463943443746323343323330463034423931453537363831363435343646393237363131323638464633304544333331364437413545374433324444323638373541463242364346443443344330333434334336434343364534423134424439343242334637373036443631343844343246313433353830333442353436383334333933393935424335313738364341373646373037433331444341433138383635423831364441373731354235313532444532353241414638363131414433323444304142324543393538443139303746383632353833334444344535453336363336343444334234454446423843383030384138304543334242334139433136324436304146313239363036463837384139374231374334324238413335353041453533354636464343353045383446453938373933434532304234333543363832444239313239453339333845453746353838413137393639374139394541354531324546423730304136464337383944363243453734443746373243463737413630384636343834363935414644464332373735454442354334323045433535393642333046323031394438304334324246383131394135313145414342434235453635304243433334363333343945393943433146374433333237444244434234413743433337373231343335324646393231333235433946413037453233424441324236443734344531304443414242443336314243313637384331313635313535424433374330394434433130353330453641303337454343423342423435453032313539353045333930463730313035373930303144443537463130464630304639393335333038303731453537434245323335414333373041364633394633453633313338324632394132363231344232364339343744303943323030463338353632364244463245463836434243434134394242354146424342303733463634434534413139323539324231433737333538413239344542363143443046303636354143353737313333464437303942334338463333333441333645423541454537463245363732464445304133333330463044434242333639393430453131463731304136443933423545373244393145343041313735393533393942374145413534444541313636343342304432383930354542354132433941414144343631464231413837433245414635454131423430443844303837424539364336393244433544364643413634443734443230424235433031353733324537354642393330334643433743464538364431444141363439453030343935353642353942333042433437463843453838354443423333354530464545354542334631384337323545314431434543453033423939363341414339454546383645304430303631353530433535443543424641453042433437413732303438393544344143414330313537414336394633303930373446363844323846413632464538303430464130343741304542334431354541313837343430304330333931313542353543314431324134464630304634383943344445303538433945323935374539314132443942313745383630363136454138333946433035414233333436314530324631464138383536383839363143364438433031394630453346434136454146344135353537353934423532324144323238453239463830303037353641303139353536323337413346413136384444303746363333353441383335333636433842413739363345394333444343413245323838313945303042374438304130434531434530383244433243454242393746304233363434333944353044363146344242454334453543453738334641304332363844304232364230443834344530323844314641323335373036424142344432413631453046464244344346423937453746364632344133363334424142323746303446434133333137464531393438423736343542463046433446444333454239384330303936463635424433373532394634464335413042333437393031324631413041354242364141383035314234324446423936443239373831373436393945384642393436363542353737424637393938333533423439413739334238364542373832464145334343353134374134343543414339363835323832463939303046444434343444363831353842393739324333334532303537353536463545373333334142353443464646444130303038303130323033303133463231373146323939393443393038433330444234343333433632303830333732454532433635393531413935353538464541304230333643423646384544463332463335393942434342383332453034413935413144343239384136353734344339413832394638373930344146353633373930373531434439344535383042333136343436313241314230383434303934363338394238334530333046453943393137353441333138344239444335343141463832333634344139434330354633464434343332324338323432304236333737433834313838313046384134374239444445314441324446434135384345433430324532333236434634343441313935433443443032363630314146393438433039353738463937413438373644334532463839393341394232363138454537453136363139364436443431314339313037333245323632463839364141363643313032383831463030463841383642453532434332464630303839453134313346413437313836364438393441464630303046383442324343373839383843323544313134413433333039354646384441324536363636334145334533313436353832443743423346313442383936453533303839373330394441353435443445324135353135303743313936353443334646303030423730314337383943363331313543314434423333313438374132363237343444364537334343334533453635393936303432313038353230464346463030463046433634373331423834413935333144394630303635323433303835373631333939304346463030433638414141333039343146313935393734344638393142354236333032303442364130413231313934413737303143333532413836413543313835304638324146453230394536363632394244363139324643343031303138323133453731354232384434303646314434354638314230353842313146354630333530354437463031413846383441373542384135433144384541353045323234363533304443334636464342414346433134423846383442383144323545363045453134423437433444344341383244343733444641323631434331463231434130313631433346463041304236313536314637314233463042363542324441384532353843413035374333413236354643334246383333463042414646303045333830433443343230344138434341463333363933433436454537464644413030303830313033303330313346323137313834434230323735463830343832304330323737313134433033314238363230304237434344353638383144344534434342363043443941433836303133323843353232443436324439423438444139363143433542444330323431393838354237353134413839344439393843394644393232333841434345444633383338343630423543343739303833373046383646453244434331373033313431314545333236323335373044423331314645413344443539373434324244433437324239433938374431393934374330453337324344433435423645323937393935433345333639314536443532424234373931384136383345464530433546353235333137343445363742323444363336304236363032314441354337373241353643304235303045413345413231453242453038363330344142433433303444313337313045443444384233413731333443323834364343363946304337324641384436363332363232334138433241413046363442363435443636363138384539393545313632313833303234353731363444324132363633343938313332343135383643313942363630463038454535464337334238323636303843303538423842314341353045463733313235364437433034443442423442413836433432343831374532423632304234303137414639343232334239424344343331373243333130393834424633313136453546303134354241364530443241353230353239303535323242324335413743304232444143353039453146453345313843414343414241363532373839343030384535423839364144393446363837373132394630374239363042424541373139383444303443413433363131364542453230303233443743333537384435463341393533374243433331433538304132463744434143313538373537333243323430313539363744344336424433464343333045413342393043434239393645333333354536373543454431414433464638333943324531463132434334343130324141333241354643303346424334443344343743354434434446393841363632383132464334324638323630343838414446463645323641324342413042424442383232413632383137343432304530324142313146384336323238453832313841463939343845353933363942394139313843303631333143433132324631383133463939344332463136363839383033433743364635324636334232324146353838354137434132383742334644374642324144313732313430443441383137464343344536423330313631383846453434363735423232354139314335343732393839383938423730454433313632364341383930433445424536394637464642353044434335334139383439393843344335324331383932354441434632374644383939333346314646444130303043303330313030303231313033313130303030313031363844374130353037383034324636414142313338463642364436463245373046464344453546393037303443303641383732353035344244423532414643463435333646464343443441464236454433303545373544364543434145453138434133383430413541383237443234334343323044333537383844343141353646304546423445323430463245393530323541463443453937463239343142434444454633334133434332344538414433364133443137304137393838314135414231333142373744343233304531454344363537323631323946363445454536423134394446464644413030303830313031303330313346313041423945353032444436453044333332393030324146433646454530413641453735313236353245463837334533333142334631343135443531444332384345324141444231444434413732413542413432443545354633304541353234324342343542393643444442384532353041374341364243303043393332353430413136333141384344453543453636313735373642313337353939303532454343443636363536344437413631383444423442434535443431323736333243393531374134313638443145353937424137384434443737413635434544463131354133384136323935444432443044463838363139343032463531393837393236313039324337323831434131354344384334313546354538304237383044363544343543383434344430313630454643413135383045313142323833383941344332343442383135343034303131363635383632424534363334313846423731313037314136334532454545364139414632303334454142373543394239353236313031433845343935333445453831343035464330453232344346323141343333463530343631353337364142443637394434343338333544314143384435363230433730314142423232364341453632384537453043413338393430364539424139354430423731343932394530353935413443344145384143363333303144333641413337424145453345304132353730334241453746373144384242463730303332453935333242434237314546353431433536393833423635423032443830383344304439343145433543324232414141424445433534374134383134303744434143353938393536423541454145313734323533444138423035423630373137423139354132423245313738443539393233354232324444453844384432353733373134453334364230324132453934454631324339384136433734424344343032423734373838394238463535363042343639323632393638344444413738394245313837324137333042303145314339303135333338423546323243373439303030303339373835363942414545353238353537384342343935374342383230393031344235434543454631444332423435364438443632374443303438464235383033384139463438363533304145423033373244443031463331344544343230453044413135323642454542413635334241423443313835414242354445463132413030333439423830433044384535433833314230423936353831453135314630313733334235314330334341313931374334303333374135434144373936363435423139454231354639433542323834364544374144383636464541453332353635354436434432353536304533334342324146383842393032363831344330444635333232394238433441354430463338464536453142424145373143453244353845314141363641383241454536303331353642364630434137374230313331383434434531313243433441413130443536324445453538313836444636433244423343434236384245303338314243374239363342343533463946464630303233364142393541423845334541423137313132333134463742303044454631414339334136324139463532393944343735303131393838324538353543423733343542333444363830323035373636374434303039413045343335393435433741383134373430304535413239423334314344313332464337313545304237463533423330413832384431323937424138343045393032354441384132444446443436384134384234414237423543394337443331453934383230344434313644373633353245424235384137444532453036303830463241433041354142363339384231363839423644443544353736383530433743383831353538393344314146313146433838353041313842314131444432464434333037393539413845383037454645443939333234414244323044363435343834394339393643443442343237454631454538383634344435343546394338424339463542393736303739423743303842434144454344433541323341423735304545353138343334313837323133413130393241314244344531314637423835333736433339424242423135464434424236303336333841454443443733324533324338354235333642434239343633423831383541424330413830303231343031393030353842333543433736314232393330443231433342374545363339324144314243364234464443354139364344464443413430363631464543353830433530304332304242354333333441453235424339453839364544393637413345393130383846364139443738303838424143444141434541383532433532364641343537363339414633314635383633433835394234313545353133434443303033363637313031424431344244333446383936304646383343313641333636394142323337433144413133393541393644394145373530364245324130453844343839423742364530423232313731433937303046374143443432313131304337324230393145364436303934363443393644373135363634343839433530333830343635374441383436464439364343304144364236384330323130443644304434364531424336354646454332463030363430323144324341313535364534423136324139423536443830413637303032413541384241324539413938324141353539324344454435423539393045433643373031363846433434334441353234443936433142353937314343413636313139373932314235413639324530353141374336394631354441393639303746353134423134453031394332303941314333334339303930423632334543353235384233373136394435394235364141453142344534433435363831433241374230384239384133303441453441354432384443333535443138453044324244333844423730353436333039364537443935434434323339303542304135353430464532413245343330343934343337363233353832354646393130384337443039423231433134323339454235373934324343364634333337423831323333443443444143453339323546304138324144303734463044373532384339324131434639303642303331443932303230393942373134363733303038353830394336444544433737313932393730313130324339393239313246373045354231314145364139354234413135353133334138323137334235383534414233343731353034393344453831423935353341424330353145453634324446383443323335374135423741373130323339444343313442354145353544434131413843414441384330343643453342383334433436434135353636373541393532413334453942454441374230393634323444304134303330323037363946413831364431333539353042364133324430424343324642433439413630394145434233303637304342364634383136354541413139353344394541304437373032363642313231303242393646373039383339313334304237414546323541373033383038443544333841414346333832433939333041423036463537424133383939393442384236453741434132464630303631463741414336424138423430304545363935333942364639393532423539383834343838333532433234353846343535433345354338413431333138343334463443434633463843303236383542363535454541414536334144423636444642354144414233303034363936414446304436374635313830393946373941373232323534434144343432383942313045343131433430374343354434453746374138313142354445304135463841443744344442413038393138304134353637323042413841424142413633334543333844393542334239374432444235343935423638413642304637443130333145353939393845313435424133353943463838373530454142363633313545363335353834303533323430324433363941374339313344433739413235383843303934414242363542373841394134453536373243343833393846453235434533424334303130303130423130313834423539353838363332434233313832383531333645313942463531464630303644443535383431364446323332343645423432384443443136304146444341313539333242323339413334303343344139314341324246333242393230443534423243374542303432324541303238374230373536334443364332394536393436373534324631424334313043433735344336364544453833343236364338363237383838344141383137353641363938353241434531303641444342354136463343333731334145303934324141433431334130363843444342303534313530443244343737303731323935423143354231313842303833454439363437423736323836303343303733324444393632303336463538313937463545453235313532454231433732304233434441304331393235313832443245464334373830423042453343393536353044334546353035374430383038303431353038333230443632333641393334354438433646343830323137434542364436413542444530393536323434453238303734434236413930364132423645353838303231393030323542344543303241444530363339353936364631334444393042413041364332433032383246364336413330354441383239453745453538373030373734343736413830373135464434424238463232414642354334354134303835353743314336413241354133353430354233313831354233463838343031454438333932383141344435443535304142363138324334454345443246344331363841453230313030323430353630334330374446343932423739444246424239323137443639463735303534323436393032413030413730324639334434323435343036444430363546463633433636304438313235383138413434374541334234394341423538353536393738324644433336454644383635313239454336343035314544313746353641423436383333354438463531303034313244434335353332433737393630314637383732304139393634373033364434304342333130313536303435423441313531423243453134383244443436333434423742434245394131304145423043363836433637443432413841324237383232463637323435313833394646303046363337303437314233444232444435424342303841374331353141333245393630433332343032444130383239314132343244443938333841413639433441374645413135323231433138323538423434423334423544363233373730423431363432383036453535433735333738433032324345393846303430333238394144463030453141304345413537374134394444353830323933444546414532333139333631313546423030443431394141333735324643353935433741383543373736303736463435333744303437303231364139444632414646303032363938414434423442303445423444413936383543443243333230303135373443433946303135354137394631364346423930373845304643303831333634304630354335383836423430433137444332363933353542414434353245364345373234364339444234414543413232393530424336453030314538443330393630313141454645304643464445333738303030303244353834344434423445323636373632443842334330343731453938383536334236384130393831314430434339383842314237343534363739383341353538303530454144453438384242393638333031343241453444353841423938394144453534353646423235393933313735353644424639383344364530343537383231353638413239423237304443313838334533443636303533374530384344364342344342383330433043423044314343303130313632424545363637424441413346453033423742374345463331413844333839323134324539363841353143333241453837464134303646303938464331394238383535373835343142384133394335323938303932313644374431383736464239363331313441303734333331363042323446423731303643373846424246383544323943413738353332413242313032324439323643454332303832333035413032464343364546423441453141303731324238353646413632303135443032413337424341413939423835413132354532304237364546454545314133354130324634423635393746303433393034334341303346314433413041374345374446333036344136443530423232363338443636464139374145383937374533363638373633384241383133444436304136463831333438333338373433443636374646444130303038303130323033303133463130363238374138383442304631303446364630434445373332414336363041313035333532433044443146383939354531453333374543394332343245333044394541304335443142354644434236413638373341314343324145463333353842383039373832324436433539383530303833373638383244414239383342423936313643423139393742303335353130384630464138303037383439354233373531413230443044333243443836453543323643354230313243373732414237414646414530453635423135353130343745463337453231443131373938303636413344443446453031334642383336314646424443374331393038343831373838413243383230324432383935313334414641373938333739453145433346463933423533423845393641343834423431303042343230434342303135324644353032464538463332393334303331463645314545413236333431424238423745453035414432303937353136433936323443414332323536443339323031374334313138363932303245443234323837304238363946373142413243343830423245413241363242433236323846323646394436434536464434374538413843413235373434433230333732393930463342344346394536323531303045413334393936303444413638393731313543443341453632413832424341304236393443313735394630343639373938363531344334373133434332363943444531443331353732444537313042353541383331313839433738383137364142383142354343424136343235424238353335323838313038433141304637373245433343394334323733464445354131423145353732414432303130324337394532333730374442373139343434343838423432383834303032413230363231463735434446323538314532313034343236313536303233343632303436333541344132384346324343444236423646454245324644374433433742384331423246303241453136344137393834343636394343324442344232303842333533393232353239333338384333423833343339343638304443413232443431393231384343313331424443363543353643433945453637434137383337454438414332413146374639373946353039324342303439324641393634303330344342323831344145323732453332433243384437344541333633443435313531424343423732414138393030333133324343333838313138343241334534463941344343413937433235334343303735313336353836413136414444433532433243393030313230363743343242333035444142334139353841414545324630304332413242353044413138333641383130383032383633333834323130373834424643464330333430373339424332374238384143424637343746373243433031463133353936343242423632423534463531373331324342304239323534303337313046304246393943333037313341383138303634423441323337353844434434374138424344463032373734453532303536353042454137314644393935313342323039354135414545303034433530413038354439313135413346383845413245303734324243433431374246443333303037453231364642394543464238383730373733304235304441434337423042433939363935464343333734363146433132433531424544423637304542434341463039443144434144414435344230383731333931383836423331374242354336423846384133344338383242364235324534434141354230303533333244393144343444364136453639353935353643344542413434424239413746383830443839464239443830464132323943303130304237423832333530304330333045363534303232393645434639333737324630353130453532354438463730364332434238443730354434303735373037433539444141343935413046333334353045454345323338463346423945373437393833413836423132464234424544303642413345303734374333353138433541373243384346323832303536453336453143464443433432353837303635324136394443363537354631463037464646444130303038303130333033303133463130334546344531363742383344433342314443423730343333383343433634383232463234373841443346373131334330463343343345394134374639383045454541433046373331373942333744414232463631464531323532363944444243433538383036313441424532433946383835363844424244333334313031353333443641373039304431433130343434353230363132423130343537323433354234354336413630393046303936334143343430443344343334393831363834333245303033433432364230393842324533383143414541423146373143303941444145453345374330433436323837444432324332464146354644393041344135333533333032393631384344374443324432333636463531434339383134344341324346354645343145334145333938344536353846463131454141433332453131423738323032373745363331343442314439453235343843394145463330314442464442433435314143313546443843343141333246364342453836413335413731314433313541453138423144373131463445323533304138434238383838453635373239414343433739413742464636304330363445463839363531324536343035323733313446364233323043373433443746334532413031323934333730373831343534344239303731434335333634353137383432434338423338333135424536363242383231383333344242384439424444433446453731314131414244453236373142463531353543383936453537443430414442334635333137433745424532324335423836413643394137393841433934373944424536333431354241424337444330413846383636413531354142463839343246334642383343394138333936333533324135313333324135443639413036323132424535363543413132353431323834444438323243354534304339363332433138413043363138383331393530384534304237324242313746313046423131323534333042363835334132333538323431444341443931354441323837343434323844393031423131433342444245383839364430423742463835363230313638374641383732383239353339414232323236303839343144433635443343343131373132314238433136453046353836413535423431324639374538383445413342354236334230413442443430414544374631303845333330433130423632393646454132313930334533344331413935333036423745303934303335324130374535303135433437394541313644333934333538354541304131433534373036444437323443324235414641463846393044323232443342393843363838444144344137424134464334353444323538313834363630443730364530454130343542383941373336303736444238393330323246414231323932393232303630374643423633343533333841463331334631333130343034343838394638384646323843443043444446354442453136413444413145414232464332453632353230394434363037364345313036453739453238363138333235444142364338433238463731373946343842303334384633324435383530423230443835414230343043423843354634424646323537394142463530433043303830323338384245313833374645323534314531323946354137463331353630324544453232444245453035333937463543433541314130343346443435353845304633333042303239463331454531313130383042433443463730453142393635303138383542363646354434313941344232393738374646303042324146383236414241333938303734303131463230323737333136454446443430303332453841393943383244463336464635323843423731324233434337373733464543413042374532323932453644384236323132314139373042383146364145363533384638343939434230303939423933423739363635333643464541313436323541393838393541334136334332364535393742343635323937314334444238464531464644383033314339374530344641323136344342343733453231454138334633434334414236303138343434304134413132354136304645413641373937453031354133373135363535463537383746363935454544384136363134433738323031303533344435374442423934463538333845313934353242363344333042423542464635304542444643453338383434443530423333444532323235463330463830414235454243424334434244393035333639454532303731363645464432354542453241413044333246333546463030333843433232303541334239373845383134304643393546423833354331314638393633353238423636334344353432393341464344343641433539433943353744453232313342414237384642464630303533444337433746464644393030);

-- --------------------------------------------------------

--
-- 資料表結構 `customers`
--

CREATE TABLE `customers` (
  `CustomerID` varchar(5) NOT NULL,
  `CompanyName` varchar(40) NOT NULL,
  `ContactName` varchar(30) DEFAULT NULL,
  `ContactTitle` varchar(30) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(15) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(15) DEFAULT NULL,
  `Phone` varchar(24) DEFAULT NULL,
  `Fax` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `customers`
--

INSERT INTO `customers` (`CustomerID`, `CompanyName`, `ContactName`, `ContactTitle`, `Address`, `City`, `Region`, `PostalCode`, `Country`, `Phone`, `Fax`) VALUES
('ALFKI', 'Alfreds Futterkiste', 'Maria Anders', 'Sales Representative', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany', '030-0074321', '030-0076545'),
('ANATR', 'Ana Trujillo Emparedados y helados', 'Ana Trujillo', 'Owner', 'Avda. de la Constitucin 2222', 'Mxico D.F.', NULL, '05021', 'Mexico', '(5) 555-4729', '(5) 555-3745'),
('ANTON', 'Antonio Moreno Taquera', 'Antonio Moreno', 'Owner', 'Mataderos  2312', 'Mxico D.F.', NULL, '05023', 'Mexico', '(5) 555-3932', NULL),
('AROUT', 'Around the Horn', 'Thomas Hardy', 'Sales Representative', '120 Hanover Sq.', 'London', NULL, 'WA1 1DP', 'UK', '(171) 555-7788', '(171) 555-6750'),
('BERGS', 'Berglunds snabbkp', 'Christina Berglund', 'Order Administrator', 'Berguvsvgen  8', 'Lule', NULL, 'S-958 22', 'Sweden', '0921-12 34 65', '0921-12 34 67'),
('BLAUS', 'Blauer See Delikatessen', 'Hanna Moos', 'Sales Representative', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany', '0621-08460', '0621-08924'),
('BLONP', 'Blondesddsl pre et fils', 'Frdrique Citeaux', 'Marketing Manager', '24, place Klber', 'Strasbourg', NULL, '67000', 'France', '88.60.15.31', '88.60.15.32'),
('BOLID', 'Blido Comidas preparadas', 'Martn Sommer', 'Owner', 'C/ Araquil, 67', 'Madrid', NULL, '28023', 'Spain', '(91) 555 22 82', '(91) 555 91 99'),
('BONAP', 'Bon app\'', 'Laurence Lebihan', 'Owner', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France', '91.24.45.40', '91.24.45.41'),
('BOTTM', 'Bottom-Dollar Markets', 'Elizabeth Lincoln', 'Accounting Manager', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada', '(604) 555-4729', '(604) 555-3745'),
('BSBEV', 'B\'s Beverages', 'Victoria Ashworth', 'Sales Representative', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK', '(171) 555-1212', NULL),
('CACTU', 'Cactus Comidas para llevar', 'Patricio Simpson', 'Sales Agent', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina', '(1) 135-5555', '(1) 135-4892'),
('CENTC', 'Centro comercial Moctezuma', 'Francisco Chang', 'Marketing Manager', 'Sierras de Granada 9993', 'Mxico D.F.', NULL, '05022', 'Mexico', '(5) 555-3392', '(5) 555-7293'),
('CHOPS', 'Chop-suey Chinese', 'Yang Wang', 'Owner', 'Hauptstr. 29', 'Bern', NULL, '3012', 'Switzerland', '0452-076545', NULL),
('COMMI', 'Comrcio Mineiro', 'Pedro Afonso', 'Sales Associate', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil', '(11) 555-7647', NULL),
('CONSH', 'Consolidated Holdings', 'Elizabeth Brown', 'Sales Representative', 'Berkeley Gardens 12  Brewery', 'London', NULL, 'WX1 6LT', 'UK', '(171) 555-2282', '(171) 555-9199'),
('DRACD', 'Drachenblut Delikatessen', 'Sven Ottlieb', 'Order Administrator', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany', '0241-039123', '0241-059428'),
('DUMON', 'Du monde entier', 'Janine Labrune', 'Owner', '67, rue des Cinquante Otages', 'Nantes', NULL, '44000', 'France', '40.67.88.88', '40.67.89.89'),
('EASTC', 'Eastern Connection', 'Ann Devon', 'Sales Agent', '35 King George', 'London', NULL, 'WX3 6FW', 'UK', '(171) 555-0297', '(171) 555-3373'),
('ERNSH', 'Ernst Handel', 'Roland Mendel', 'Sales Manager', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria', '7675-3425', '7675-3426'),
('FAMIA', 'Familia Arquibaldo', 'Aria Cruz', 'Marketing Assistant', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil', '(11) 555-9857', NULL),
('FISSA', 'FISSA Fabrica Inter. Salchichas S.A.', 'Diego Roel', 'Accounting Manager', 'C/ Moralzarzal, 86', 'Madrid', NULL, '28034', 'Spain', '(91) 555 94 44', '(91) 555 55 93'),
('FOLIG', 'Folies gourmandes', 'Martine Ranc', 'Assistant Sales Agent', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France', '20.16.10.16', '20.16.10.17'),
('FOLKO', 'Folk och f HB', 'Maria Larsson', 'Owner', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden', '0695-34 67 21', NULL),
('FRANK', 'Frankenversand', 'Peter Franken', 'Marketing Manager', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany', '089-0877310', '089-0877451'),
('FRANR', 'France restauration', 'Carine Schmitt', 'Marketing Manager', '54, rue Royale', 'Nantes', NULL, '44000', 'France', '40.32.21.21', '40.32.21.20'),
('FRANS', 'Franchi S.p.A.', 'Paolo Accorti', 'Sales Representative', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy', '011-4988260', '011-4988261'),
('FURIB', 'Furia Bacalhau e Frutos do Mar', 'Lino Rodriguez', 'Sales Manager', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal', '(1) 354-2534', '(1) 354-2535'),
('GALED', 'Galera del gastrnomo', 'Eduardo Saavedra', 'Marketing Manager', 'Rambla de Catalua, 23', 'Barcelona', NULL, '08022', 'Spain', '(93) 203 4560', '(93) 203 4561'),
('GODOS', 'Godos Cocina Tpica', 'Jos Pedro Freyre', 'Sales Manager', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain', '(95) 555 82 82', NULL),
('GOURL', 'Gourmet Lanchonetes', 'Andr Fonseca', 'Sales Associate', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil', '(11) 555-9482', NULL),
('GREAL', 'Great Lakes Food Market', 'Howard Snyder', 'Marketing Manager', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA', '(503) 555-7555', NULL),
('GROSR', 'GROSELLA-Restaurante', 'Manuel Pereira', 'Owner', '5 Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela', '(2) 283-2951', '(2) 283-3397'),
('HANAR', 'Hanari Carnes', 'Mario Pontes', 'Accounting Manager', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil', '(21) 555-0091', '(21) 555-8765'),
('HILAA', 'HILARION-Abastos', 'Carlos Hernndez', 'Sales Representative', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela', '(5) 555-1340', '(5) 555-1948'),
('HUNGC', 'Hungry Coyote Import Store', 'Yoshi Latimer', 'Sales Representative', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA', '(503) 555-6874', '(503) 555-2376'),
('HUNGO', 'Hungry Owl All-Night Grocers', 'Patricia McKenna', 'Sales Associate', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland', '2967 542', '2967 3333'),
('ISLAT', 'Island Trading', 'Helen Bennett', 'Marketing Manager', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK', '(198) 555-8888', NULL),
('KOENE', 'Kniglich Essen', 'Philip Cramer', 'Sales Associate', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany', '0555-09876', NULL),
('LACOR', 'La corne d\'abondance', 'Daniel Tonini', 'Sales Representative', '67, avenue de l\'Europe', 'Versailles', NULL, '78000', 'France', '30.59.84.10', '30.59.85.11'),
('LAMAI', 'La maison d\'Asie', 'Annette Roulet', 'Sales Manager', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France', '61.77.61.10', '61.77.61.11'),
('LAUGB', 'Laughing Bacchus Wine Cellars', 'Yoshi Tannamuri', 'Marketing Assistant', '1900 Oak St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada', '(604) 555-3392', '(604) 555-7293'),
('LAZYK', 'Lazy K Kountry Store', 'John Steel', 'Marketing Manager', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA', '(509) 555-7969', '(509) 555-6221'),
('LEHMS', 'Lehmanns Marktstand', 'Renate Messner', 'Sales Representative', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany', '069-0245984', '069-0245874'),
('LETSS', 'Let\'s Stop N Shop', 'Jaime Yorres', 'Owner', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA', '(415) 555-5938', NULL),
('LILAS', 'LILA-Supermercado', 'Carlos Gonzlez', 'Accounting Manager', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela', '(9) 331-6954', '(9) 331-7256'),
('LINOD', 'LINO-Delicateses', 'Felipe Izquierdo', 'Owner', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela', '(8) 34-56-12', '(8) 34-93-93'),
('LONEP', 'Lonesome Pine Restaurant', 'Fran Wilson', 'Sales Manager', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA', '(503) 555-9573', '(503) 555-9646'),
('MAGAA', 'Magazzini Alimentari Riuniti', 'Giovanni Rovelli', 'Marketing Manager', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy', '035-640230', '035-640231'),
('MAISD', 'Maison Dewey', 'Catherine Dewey', 'Sales Agent', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium', '(02) 201 24 67', '(02) 201 24 68'),
('MEREP', 'Mre Paillarde', 'Jean Fresnire', 'Marketing Assistant', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada', '(514) 555-8054', '(514) 555-8055'),
('MORGK', 'Morgenstern Gesundkost', 'Alexander Feuer', 'Marketing Assistant', 'Heerstr. 22', 'Leipzig', NULL, '04179', 'Germany', '0342-023176', NULL),
('NORTS', 'North/South', 'Simon Crowther', 'Sales Associate', 'South House 300 Queensbridge', 'London', NULL, 'SW7 1RZ', 'UK', '(171) 555-7733', '(171) 555-2530'),
('OCEAN', 'Ocano Atlntico Ltda.', 'Yvonne Moncada', 'Sales Agent', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina', '(1) 135-5333', '(1) 135-5535'),
('OLDWO', 'Old World Delicatessen', 'Rene Phillips', 'Sales Representative', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA', '(907) 555-7584', '(907) 555-2880'),
('OTTIK', 'Ottilies Kseladen', 'Henriette Pfalzheim', 'Owner', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany', '0221-0644327', '0221-0765721'),
('PARIS', 'Paris spcialits', 'Marie Bertrand', 'Owner', '265, boulevard Charonne', 'Paris', NULL, '75012', 'France', '(1) 42.34.22.66', '(1) 42.34.22.77'),
('PERIC', 'Pericles Comidas clsicas', 'Guillermo Fernndez', 'Sales Representative', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '05033', 'Mexico', '(5) 552-3745', '(5) 545-3745'),
('PICCO', 'Piccolo und mehr', 'Georg Pipps', 'Sales Manager', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria', '6562-9722', '6562-9723'),
('PRINI', 'Princesa Isabel Vinhos', 'Isabel de Castro', 'Sales Representative', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal', '(1) 356-5634', NULL),
('QUEDE', 'Que Delcia', 'Bernardo Batista', 'Accounting Manager', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil', '(21) 555-4252', '(21) 555-4545'),
('QUEEN', 'Queen Cozinha', 'Lcia Carvalho', 'Marketing Assistant', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil', '(11) 555-1189', NULL),
('QUICK', 'QUICK-Stop', 'Horst Kloss', 'Accounting Manager', 'Taucherstrae 10', 'Cunewalde', NULL, '01307', 'Germany', '0372-035188', NULL),
('RANCH', 'Rancho grande', 'Sergio Gutirrez', 'Sales Representative', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina', '(1) 123-5555', '(1) 123-5556'),
('RATTC', 'Rattlesnake Canyon Grocery', 'Paula Wilson', 'Assistant Sales Representative', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA', '(505) 555-5939', '(505) 555-3620'),
('REGGC', 'Reggiani Caseifici', 'Maurizio Moroni', 'Sales Associate', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy', '0522-556721', '0522-556722'),
('RICAR', 'Ricardo Adocicados', 'Janete Limeira', 'Assistant Sales Agent', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil', '(21) 555-3412', NULL),
('RICSU', 'Richter Supermarkt', 'Michael Holz', 'Sales Manager', 'Grenzacherweg 237', 'Genve', NULL, '1203', 'Switzerland', '0897-034214', NULL),
('ROMEY', 'Romero y tomillo', 'Alejandra Camino', 'Accounting Manager', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain', '(91) 745 6200', '(91) 745 6210'),
('SANTG', 'Sant Gourmet', 'Jonas Bergulfsen', 'Owner', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway', '07-98 92 35', '07-98 92 47'),
('SAVEA', 'Save-a-lot Markets', 'Jose Pavarotti', 'Sales Representative', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA', '(208) 555-8097', NULL),
('SEVES', 'Seven Seas Imports', 'Hari Kumar', 'Sales Manager', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK', '(171) 555-1717', '(171) 555-5646'),
('SIMOB', 'Simons bistro', 'Jytte Petersen', 'Owner', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark', '31 12 34 56', '31 13 35 57'),
('SPECD', 'Spcialits du monde', 'Dominique Perrier', 'Marketing Manager', '25, rue Lauriston', 'Paris', NULL, '75016', 'France', '(1) 47.55.60.10', '(1) 47.55.60.20'),
('SPLIR', 'Split Rail Beer & Ale', 'Art Braunschweiger', 'Sales Manager', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA', '(307) 555-4680', '(307) 555-6525'),
('SUPRD', 'Suprmes dlices', 'Pascale Cartrain', 'Accounting Manager', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium', '(071) 23 67 22 20', '(071) 23 67 22 21'),
('THEBI', 'The Big Cheese', 'Liz Nixon', 'Marketing Manager', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA', '(503) 555-3612', NULL),
('THECR', 'The Cracker Box', 'Liu Wong', 'Marketing Assistant', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA', '(406) 555-5834', '(406) 555-8083'),
('TOMSP', 'Toms Spezialitten', 'Karin Josephs', 'Marketing Manager', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany', '0251-031259', '0251-035695'),
('TORTU', 'Tortuga Restaurante', 'Miguel Angel Paolino', 'Owner', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '05033', 'Mexico', '(5) 555-2933', NULL),
('TRADH', 'Tradio Hipermercados', 'Anabela Domingues', 'Sales Representative', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil', '(11) 555-2167', '(11) 555-2168'),
('TRAIH', 'Trail\'s Head Gourmet Provisioners', 'Helvetius Nagy', 'Sales Associate', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA', '(206) 555-8257', '(206) 555-2174'),
('VAFFE', 'Vaffeljernet', 'Palle Ibsen', 'Sales Manager', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark', '86 21 32 43', '86 22 33 44'),
('Val2 ', 'IT', 'Val2', 'IT', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('VALON', 'IT', 'Valon Hoti', 'IT', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('VICTE', 'Victuailles en stock', 'Mary Saveley', 'Sales Agent', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France', '78.32.54.86', '78.32.54.87'),
('VINET', 'Vins et alcools Chevalier', 'Paul Henriot', 'Accounting Manager', '59 rue de l\'Abbaye', 'Reims', NULL, '51100', 'France', '26.47.15.10', '26.47.15.11'),
('WANDK', 'Die Wandernde Kuh', 'Rita Mller', 'Sales Representative', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany', '0711-020361', '0711-035428'),
('WARTH', 'Wartian Herkku', 'Pirkko Koskitalo', 'Accounting Manager', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland', '981-443655', '981-443655'),
('WELLI', 'Wellington Importadora', 'Paula Parente', 'Sales Manager', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil', '(14) 555-8122', NULL),
('WHITC', 'White Clover Markets', 'Karl Jablonski', 'Owner', '305 - 14th Ave. S. Suite 3B', 'Seattle', 'WA', '98128', 'USA', '(206) 555-4112', '(206) 555-4115'),
('WILMK', 'Wilman Kala', 'Matti Karttunen', 'Owner/Marketing Assistant', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland', '90-224 8858', '90-224 8858'),
('WOLZA', 'Wolski  Zajazd', 'Zbyszek Piestrzeniewicz', 'Owner', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland', '(26) 642-7012', '(26) 642-7012');

-- --------------------------------------------------------

--
-- 資料表結構 `employees`
--

CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(10) NOT NULL,
  `Title` varchar(30) DEFAULT NULL,
  `TitleOfCourtesy` varchar(25) DEFAULT NULL,
  `BirthDate` datetime DEFAULT NULL,
  `HireDate` datetime DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(15) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(15) DEFAULT NULL,
  `HomePhone` varchar(24) DEFAULT NULL,
  `Extension` varchar(4) DEFAULT NULL,
  `Notes` mediumtext NOT NULL,
  `ReportsTo` int(11) DEFAULT NULL,
  `PhotoPath` varchar(255) DEFAULT NULL,
  `Salary` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `employees`
--

INSERT INTO `employees` (`EmployeeID`, `LastName`, `FirstName`, `Title`, `TitleOfCourtesy`, `BirthDate`, `HireDate`, `Address`, `City`, `Region`, `PostalCode`, `Country`, `HomePhone`, `Extension`, `Notes`, `ReportsTo`, `PhotoPath`, `Salary`) VALUES
(1, 'Davolio', 'Nancy', 'Sales Representative', 'Ms.', '1948-12-08 00:00:00', '1992-05-01 00:00:00', '507 - 20th Ave. E.Apt. 2A', 'Seattle', 'WA', '98122', 'USA', '(206) 555-9857', '5467', 'Education includes a BA in psychology from Colorado State University in 1970.  She also completed \"The Art of the Cold Call.\"  Nancy is a member of Toastmasters International.', 2, 'http://accweb/emmployees/davolio.bmp', 2954.55),
(2, 'Fuller', 'Andrew', 'Vice President, Sales', 'Dr.', '1952-02-19 00:00:00', '1992-08-14 00:00:00', '908 W. Capital Way', 'Tacoma', 'WA', '98401', 'USA', '(206) 555-9482', '3457', 'Andrew received his BTS commercial in 1974 and a Ph.D. in international marketing from the University of Dallas in 1981.  He is fluent in French and Italian and reads German.  He joined the company as a sales representative, was promoted to sales manager in January 1992 and to vice president of sales in March 1993.  Andrew is a member of the Sales Management Roundtable, the Seattle Chamber of Commerce, and the Pacific Rim Importers Association.', NULL, 'http://accweb/emmployees/fuller.bmp', 2254.49),
(3, 'Leverling', 'Janet', 'Sales Representative', 'Ms.', '1963-08-30 00:00:00', '1992-04-01 00:00:00', '722 Moss Bay Blvd.', 'Kirkland', 'WA', '98033', 'USA', '(206) 555-3412', '3355', 'Janet has a BS degree in chemistry from Boston College (1984).  She has also completed a certificate program in food retailing management.  Janet was hired as a sales associate in 1991 and promoted to sales representative in February 1992.', 2, 'http://accweb/emmployees/leverling.bmp', 3119.15),
(4, 'Peacock', 'Margaret', 'Sales Representative', 'Mrs.', '1937-09-19 00:00:00', '1993-05-03 00:00:00', '4110 Old Redmond Rd.', 'Redmond', 'WA', '98052', 'USA', '(206) 555-8122', '5176', 'Margaret holds a BA in English literature from Concordia College (1958) and an MA from the American Institute of Culinary Arts (1966).  She was assigned to the London office temporarily from July through November 1992.', 2, 'http://accweb/emmployees/peacock.bmp', 1861.08),
(5, 'Buchanan', 'Steven', 'Sales Manager', 'Mr.', '1955-03-04 00:00:00', '1993-10-17 00:00:00', '14 Garrett Hill', 'London', NULL, 'SW1 8JR', 'UK', '(71) 555-4848', '3453', 'Steven Buchanan graduated from St. Andrews University, Scotland, with a BSC degree in 1976.  Upon joining the company as a sales representative in 1992, he spent 6 months in an orientation program at the Seattle office and then returned to his permanent post in London.  He was promoted to sales manager in March 1993.  Mr. Buchanan has completed the courses \"Successful Telemarketing\" and \"International Sales Management.\"  He is fluent in French.', 2, 'http://accweb/emmployees/buchanan.bmp', 1744.21),
(6, 'Suyama', 'Michael', 'Sales Representative', 'Mr.', '1963-07-02 00:00:00', '1993-10-17 00:00:00', 'Coventry House\r\nMiner Rd.', 'London', NULL, 'EC2 7JR', 'UK', '(71) 555-7773', '428', 'Michael is a graduate of Sussex University (MA, economics, 1983) and the University of California at Los Angeles (MBA, marketing, 1986).  He has also taken the courses \"Multi-Cultural Selling\" and \"Time Management for the Sales Professional.\"  He is fluent in Japanese and can read and write French, Portuguese, and Spanish.', 5, 'http://accweb/emmployees/davolio.bmp', 2004.07),
(7, 'King', 'Robert', 'Sales Representative', 'Mr.', '1960-05-29 00:00:00', '1994-01-02 00:00:00', 'Edgeham Hollow\r\nWinchester Way', 'London', NULL, 'RG1 9SP', 'UK', '(71) 555-5598', '465', 'Robert King served in the Peace Corps and traveled extensively before completing his degree in English at the University of Michigan in 1992, the year he joined the company.  After completing a course entitled \"Selling in Europe,\" he was transferred to the London office in March 1993.', 5, 'http://accweb/emmployees/davolio.bmp', 1991.55),
(8, 'Callahan', 'Laura', 'Inside Sales Coordinator', 'Ms.', '1958-01-09 00:00:00', '1994-03-05 00:00:00', '4726 - 11th Ave. N.E.', 'Seattle', 'WA', '98105', 'USA', '(206) 555-1189', '2344', 'Laura received a BA in psychology from the University of Washington.  She has also completed a course in business French.  She reads and writes French.', 2, 'http://accweb/emmployees/davolio.bmp', 2100.5),
(9, 'Dodsworth', 'Anne', 'Sales Representative', 'Ms.', '1966-01-27 00:00:00', '1994-11-15 00:00:00', '7 Houndstooth Rd.', 'London', NULL, 'WG2 7LT', 'UK', '(71) 555-4444', '452', 'Anne has a BA degree in English from St. Lawrence College.  She is fluent in French and German.', 5, 'http://accweb/emmployees/davolio.bmp', 2333.33);

-- --------------------------------------------------------

--
-- 資料表結構 `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `UnitPrice` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `Quantity` smallint(2) NOT NULL DEFAULT '1',
  `Discount` double(8,0) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `orderdetails`
--

INSERT INTO `orderdetails` (`OrderID`, `ProductID`, `UnitPrice`, `Quantity`, `Discount`) VALUES
(10248, 11, '14.0000', 12, 0),
(10248, 42, '9.8000', 10, 0),
(10248, 72, '34.8000', 5, 0),
(10249, 14, '18.6000', 9, 0),
(10249, 51, '42.4000', 40, 0),
(10250, 41, '7.7000', 10, 0),
(10250, 51, '42.4000', 35, 0),
(10250, 65, '16.8000', 15, 0),
(10251, 22, '16.8000', 6, 0),
(10251, 57, '15.6000', 15, 0),
(10251, 65, '16.8000', 20, 0),
(10252, 20, '64.8000', 40, 0),
(10252, 33, '2.0000', 25, 0),
(10252, 60, '27.2000', 40, 0),
(10253, 31, '10.0000', 20, 0),
(10253, 39, '14.4000', 42, 0),
(10253, 49, '16.0000', 40, 0),
(10254, 24, '3.6000', 15, 0),
(10254, 55, '19.2000', 21, 0),
(10254, 74, '8.0000', 21, 0),
(10255, 2, '15.2000', 20, 0),
(10255, 16, '13.9000', 35, 0),
(10255, 36, '15.2000', 25, 0),
(10255, 59, '44.0000', 30, 0),
(10256, 53, '26.2000', 15, 0),
(10256, 77, '10.4000', 12, 0),
(10257, 27, '35.1000', 25, 0),
(10257, 39, '14.4000', 6, 0),
(10257, 77, '10.4000', 15, 0),
(10258, 2, '15.2000', 50, 0),
(10258, 5, '17.0000', 65, 0),
(10258, 32, '25.6000', 6, 0),
(10259, 21, '8.0000', 10, 0),
(10259, 37, '20.8000', 1, 0),
(10260, 41, '7.7000', 16, 0),
(10260, 57, '15.6000', 50, 0),
(10260, 62, '39.4000', 15, 0),
(10260, 70, '12.0000', 21, 0),
(10261, 21, '8.0000', 20, 0),
(10261, 35, '14.4000', 20, 0),
(10262, 5, '17.0000', 12, 0),
(10262, 7, '24.0000', 15, 0),
(10262, 56, '30.4000', 2, 0),
(10263, 16, '13.9000', 60, 0),
(10263, 24, '3.6000', 28, 0),
(10263, 30, '20.7000', 60, 0),
(10263, 74, '8.0000', 36, 0),
(10264, 2, '15.2000', 35, 0),
(10264, 41, '7.7000', 25, 0),
(10265, 17, '31.2000', 30, 0),
(10265, 70, '12.0000', 20, 0),
(10266, 12, '30.4000', 12, 0),
(10267, 40, '14.7000', 50, 0),
(10267, 59, '44.0000', 70, 0),
(10267, 76, '14.4000', 15, 0),
(10268, 29, '99.0000', 10, 0),
(10268, 72, '27.8000', 4, 0),
(10269, 33, '2.0000', 60, 0),
(10269, 72, '27.8000', 20, 0),
(10270, 36, '15.2000', 30, 0),
(10270, 43, '36.8000', 25, 0),
(10271, 33, '2.0000', 24, 0),
(10272, 20, '64.8000', 6, 0),
(10272, 31, '10.0000', 40, 0),
(10272, 72, '27.8000', 24, 0),
(10273, 10, '24.8000', 24, 0),
(10273, 31, '10.0000', 15, 0),
(10273, 33, '2.0000', 20, 0),
(10273, 40, '14.7000', 60, 0),
(10273, 76, '14.4000', 33, 0),
(10274, 71, '17.2000', 20, 0),
(10274, 72, '27.8000', 7, 0),
(10275, 24, '3.6000', 12, 0),
(10275, 59, '44.0000', 6, 0),
(10276, 10, '24.8000', 15, 0),
(10276, 13, '4.8000', 10, 0),
(10277, 28, '36.4000', 20, 0),
(10277, 62, '39.4000', 12, 0),
(10278, 44, '15.5000', 16, 0),
(10278, 59, '44.0000', 15, 0),
(10278, 63, '35.1000', 8, 0),
(10278, 73, '12.0000', 25, 0),
(10279, 17, '31.2000', 15, 0),
(10280, 24, '3.6000', 12, 0),
(10280, 55, '19.2000', 20, 0),
(10280, 75, '6.2000', 30, 0),
(10281, 19, '7.3000', 1, 0),
(10281, 24, '3.6000', 6, 0),
(10281, 35, '14.4000', 4, 0),
(10282, 30, '20.7000', 6, 0),
(10282, 57, '15.6000', 2, 0),
(10283, 15, '12.4000', 20, 0),
(10283, 19, '7.3000', 18, 0),
(10283, 60, '27.2000', 35, 0),
(10283, 72, '27.8000', 3, 0),
(10284, 27, '35.1000', 15, 0),
(10284, 44, '15.5000', 21, 0),
(10284, 60, '27.2000', 20, 0),
(10284, 67, '11.2000', 5, 0),
(10285, 1, '14.4000', 45, 0),
(10285, 40, '14.7000', 40, 0),
(10285, 53, '26.2000', 36, 0),
(10286, 35, '14.4000', 100, 0),
(10286, 62, '39.4000', 40, 0),
(10287, 16, '13.9000', 40, 0),
(10287, 34, '11.2000', 20, 0),
(10287, 46, '9.6000', 15, 0),
(10288, 54, '5.9000', 10, 0),
(10288, 68, '10.0000', 3, 0),
(10289, 3, '8.0000', 30, 0),
(10289, 64, '26.6000', 9, 0),
(10290, 5, '17.0000', 20, 0),
(10290, 29, '99.0000', 15, 0),
(10290, 49, '16.0000', 15, 0),
(10290, 77, '10.4000', 10, 0),
(10291, 13, '4.8000', 20, 0),
(10291, 44, '15.5000', 24, 0),
(10291, 51, '42.4000', 2, 0),
(10292, 20, '64.8000', 20, 0),
(10293, 18, '50.0000', 12, 0),
(10293, 24, '3.6000', 10, 0),
(10293, 63, '35.1000', 5, 0),
(10293, 75, '6.2000', 6, 0),
(10294, 1, '14.4000', 18, 0),
(10294, 17, '31.2000', 15, 0),
(10294, 43, '36.8000', 15, 0),
(10294, 60, '27.2000', 21, 0),
(10294, 75, '6.2000', 6, 0),
(10295, 56, '30.4000', 4, 0),
(10296, 11, '16.8000', 12, 0),
(10296, 16, '13.9000', 30, 0),
(10296, 69, '28.8000', 15, 0),
(10297, 39, '14.4000', 60, 0),
(10297, 72, '27.8000', 20, 0),
(10298, 2, '15.2000', 40, 0),
(10298, 36, '15.2000', 40, 0),
(10298, 59, '44.0000', 30, 0),
(10298, 62, '39.4000', 15, 0),
(10299, 19, '7.3000', 15, 0),
(10299, 70, '12.0000', 20, 0),
(10300, 66, '13.6000', 30, 0),
(10300, 68, '10.0000', 20, 0),
(10301, 40, '14.7000', 10, 0),
(10301, 56, '30.4000', 20, 0),
(10302, 17, '31.2000', 40, 0),
(10302, 28, '36.4000', 28, 0),
(10302, 43, '36.8000', 12, 0),
(10303, 40, '14.7000', 40, 0),
(10303, 65, '16.8000', 30, 0),
(10303, 68, '10.0000', 15, 0),
(10304, 49, '16.0000', 30, 0),
(10304, 59, '44.0000', 10, 0),
(10304, 71, '17.2000', 2, 0),
(10305, 18, '50.0000', 25, 0),
(10305, 29, '99.0000', 25, 0),
(10305, 39, '14.4000', 30, 0),
(10306, 30, '20.7000', 10, 0),
(10306, 53, '26.2000', 10, 0),
(10306, 54, '5.9000', 5, 0),
(10307, 62, '39.4000', 10, 0),
(10307, 68, '10.0000', 3, 0),
(10308, 69, '28.8000', 1, 0),
(10308, 70, '12.0000', 5, 0),
(10309, 4, '17.6000', 20, 0),
(10309, 6, '20.0000', 30, 0),
(10309, 42, '11.2000', 2, 0),
(10309, 43, '36.8000', 20, 0),
(10309, 71, '17.2000', 3, 0),
(10310, 16, '13.9000', 10, 0),
(10310, 62, '39.4000', 5, 0),
(10311, 42, '11.2000', 6, 0),
(10311, 69, '28.8000', 7, 0),
(10312, 28, '36.4000', 4, 0),
(10312, 43, '36.8000', 24, 0),
(10312, 53, '26.2000', 20, 0),
(10312, 75, '6.2000', 10, 0),
(10313, 36, '15.2000', 12, 0),
(10314, 32, '25.6000', 40, 0),
(10314, 58, '10.6000', 30, 0),
(10314, 62, '39.4000', 25, 0),
(10315, 34, '11.2000', 14, 0),
(10315, 70, '12.0000', 30, 0),
(10316, 41, '7.7000', 10, 0),
(10316, 62, '39.4000', 70, 0),
(10317, 1, '14.4000', 20, 0),
(10318, 41, '7.7000', 20, 0),
(10318, 76, '14.4000', 6, 0),
(10319, 17, '31.2000', 8, 0),
(10319, 28, '36.4000', 14, 0),
(10319, 76, '14.4000', 30, 0),
(10320, 71, '17.2000', 30, 0),
(10321, 35, '14.4000', 10, 0),
(10322, 52, '5.6000', 20, 0),
(10323, 15, '12.4000', 5, 0),
(10323, 25, '11.2000', 4, 0),
(10323, 39, '14.4000', 4, 0),
(10324, 16, '13.9000', 21, 0),
(10324, 35, '14.4000', 70, 0),
(10324, 46, '9.6000', 30, 0),
(10324, 59, '44.0000', 40, 0),
(10324, 63, '35.1000', 80, 0),
(10325, 6, '20.0000', 6, 0),
(10325, 13, '4.8000', 12, 0),
(10325, 14, '18.6000', 9, 0),
(10325, 31, '10.0000', 4, 0),
(10325, 72, '27.8000', 40, 0),
(10326, 4, '17.6000', 24, 0),
(10326, 57, '15.6000', 16, 0),
(10326, 75, '6.2000', 50, 0),
(10327, 2, '15.2000', 25, 0),
(10327, 11, '16.8000', 50, 0),
(10327, 30, '20.7000', 35, 0),
(10327, 58, '10.6000', 30, 0),
(10328, 59, '44.0000', 9, 0),
(10328, 65, '16.8000', 40, 0),
(10328, 68, '10.0000', 10, 0),
(10329, 19, '7.3000', 10, 0),
(10329, 30, '20.7000', 8, 0),
(10329, 38, '210.8000', 20, 0),
(10329, 56, '30.4000', 12, 0),
(10330, 26, '24.9000', 50, 0),
(10330, 72, '27.8000', 25, 0),
(10331, 54, '5.9000', 15, 0),
(10332, 18, '50.0000', 40, 0),
(10332, 42, '11.2000', 10, 0),
(10332, 47, '7.6000', 16, 0),
(10333, 14, '18.6000', 10, 0),
(10333, 21, '8.0000', 10, 0),
(10333, 71, '17.2000', 40, 0),
(10334, 52, '5.6000', 8, 0),
(10334, 68, '10.0000', 10, 0),
(10335, 2, '15.2000', 7, 0),
(10335, 31, '10.0000', 25, 0),
(10335, 32, '25.6000', 6, 0),
(10335, 51, '42.4000', 48, 0),
(10336, 4, '17.6000', 18, 0),
(10337, 23, '7.2000', 40, 0),
(10337, 26, '24.9000', 24, 0),
(10337, 36, '15.2000', 20, 0),
(10337, 37, '20.8000', 28, 0),
(10337, 72, '27.8000', 25, 0),
(10338, 17, '31.2000', 20, 0),
(10338, 30, '20.7000', 15, 0),
(10339, 4, '17.6000', 10, 0),
(10339, 17, '31.2000', 70, 0),
(10339, 62, '39.4000', 28, 0),
(10340, 18, '50.0000', 20, 0),
(10340, 41, '7.7000', 12, 0),
(10340, 43, '36.8000', 40, 0),
(10341, 33, '2.0000', 8, 0),
(10341, 59, '44.0000', 9, 0),
(10342, 2, '15.2000', 24, 0),
(10342, 31, '10.0000', 56, 0),
(10342, 36, '15.2000', 40, 0),
(10342, 55, '19.2000', 40, 0),
(10343, 64, '26.6000', 50, 0),
(10343, 68, '10.0000', 4, 0),
(10343, 76, '14.4000', 15, 0),
(10344, 4, '17.6000', 35, 0),
(10344, 8, '32.0000', 70, 0),
(10345, 8, '32.0000', 70, 0),
(10345, 19, '7.3000', 80, 0),
(10345, 42, '11.2000', 9, 0),
(10346, 17, '31.2000', 36, 0),
(10346, 56, '30.4000', 20, 0),
(10347, 25, '11.2000', 10, 0),
(10347, 39, '14.4000', 50, 0),
(10347, 40, '14.7000', 4, 0),
(10347, 75, '6.2000', 6, 0),
(10348, 1, '14.4000', 15, 0),
(10348, 23, '7.2000', 25, 0),
(10349, 54, '5.9000', 24, 0),
(10350, 50, '13.0000', 15, 0),
(10350, 69, '28.8000', 18, 0),
(10351, 38, '210.8000', 20, 0),
(10351, 41, '7.7000', 13, 0),
(10351, 44, '15.5000', 77, 0),
(10351, 65, '16.8000', 10, 0),
(10352, 24, '3.6000', 10, 0),
(10352, 54, '5.9000', 20, 0),
(10353, 11, '16.8000', 12, 0),
(10353, 38, '210.8000', 50, 0),
(10354, 1, '14.4000', 12, 0),
(10354, 29, '99.0000', 4, 0),
(10355, 24, '3.6000', 25, 0),
(10355, 57, '15.6000', 25, 0),
(10356, 31, '10.0000', 30, 0),
(10356, 55, '19.2000', 12, 0),
(10356, 69, '28.8000', 20, 0),
(10357, 10, '24.8000', 30, 0),
(10357, 26, '24.9000', 16, 0),
(10357, 60, '27.2000', 8, 0),
(10358, 24, '3.6000', 10, 0),
(10358, 34, '11.2000', 10, 0),
(10358, 36, '15.2000', 20, 0),
(10359, 16, '13.9000', 56, 0),
(10359, 31, '10.0000', 70, 0),
(10359, 60, '27.2000', 80, 0),
(10360, 28, '36.4000', 30, 0),
(10360, 29, '99.0000', 35, 0),
(10360, 38, '210.8000', 10, 0),
(10360, 49, '16.0000', 35, 0),
(10360, 54, '5.9000', 28, 0),
(10361, 39, '14.4000', 54, 0),
(10361, 60, '27.2000', 55, 0),
(10362, 25, '11.2000', 50, 0),
(10362, 51, '42.4000', 20, 0),
(10362, 54, '5.9000', 24, 0),
(10363, 31, '10.0000', 20, 0),
(10363, 75, '6.2000', 12, 0),
(10363, 76, '14.4000', 12, 0),
(10364, 69, '28.8000', 30, 0),
(10364, 71, '17.2000', 5, 0),
(10365, 11, '16.8000', 24, 0),
(10366, 65, '16.8000', 5, 0),
(10366, 77, '10.4000', 5, 0),
(10367, 34, '11.2000', 36, 0),
(10367, 54, '5.9000', 18, 0),
(10367, 65, '16.8000', 15, 0),
(10367, 77, '10.4000', 7, 0),
(10368, 21, '8.0000', 5, 0),
(10368, 28, '36.4000', 13, 0),
(10368, 57, '15.6000', 25, 0),
(10368, 64, '26.6000', 35, 0),
(10369, 29, '99.0000', 20, 0),
(10369, 56, '30.4000', 18, 0),
(10370, 1, '14.4000', 15, 0),
(10370, 64, '26.6000', 30, 0),
(10370, 74, '8.0000', 20, 0),
(10371, 36, '15.2000', 6, 0),
(10372, 20, '64.8000', 12, 0),
(10372, 38, '210.8000', 40, 0),
(10372, 60, '27.2000', 70, 0),
(10372, 72, '27.8000', 42, 0),
(10373, 58, '10.6000', 80, 0),
(10373, 71, '17.2000', 50, 0),
(10374, 31, '10.0000', 30, 0),
(10374, 58, '10.6000', 15, 0),
(10375, 14, '18.6000', 15, 0),
(10375, 54, '5.9000', 10, 0),
(10376, 31, '10.0000', 42, 0),
(10377, 28, '36.4000', 20, 0),
(10377, 39, '14.4000', 20, 0),
(10378, 71, '17.2000', 6, 0),
(10379, 41, '7.7000', 8, 0),
(10379, 63, '35.1000', 16, 0),
(10379, 65, '16.8000', 20, 0),
(10380, 30, '20.7000', 18, 0),
(10380, 53, '26.2000', 20, 0),
(10380, 60, '27.2000', 6, 0),
(10380, 70, '12.0000', 30, 0),
(10381, 74, '8.0000', 14, 0),
(10382, 5, '17.0000', 32, 0),
(10382, 18, '50.0000', 9, 0),
(10382, 29, '99.0000', 14, 0),
(10382, 33, '2.0000', 60, 0),
(10382, 74, '8.0000', 50, 0),
(10383, 13, '4.8000', 20, 0),
(10383, 50, '13.0000', 15, 0),
(10383, 56, '30.4000', 20, 0),
(10384, 20, '64.8000', 28, 0),
(10384, 60, '27.2000', 15, 0),
(10385, 7, '24.0000', 10, 0),
(10385, 60, '27.2000', 20, 0),
(10385, 68, '10.0000', 8, 0),
(10386, 24, '3.6000', 15, 0),
(10386, 34, '11.2000', 10, 0),
(10387, 24, '3.6000', 15, 0),
(10387, 28, '36.4000', 6, 0),
(10387, 59, '44.0000', 12, 0),
(10387, 71, '17.2000', 15, 0),
(10388, 45, '7.6000', 15, 0),
(10388, 52, '5.6000', 20, 0),
(10388, 53, '26.2000', 40, 0),
(10389, 10, '24.8000', 16, 0),
(10389, 55, '19.2000', 15, 0),
(10389, 62, '39.4000', 20, 0),
(10389, 70, '12.0000', 30, 0),
(10390, 31, '10.0000', 60, 0),
(10390, 35, '14.4000', 40, 0),
(10390, 46, '9.6000', 45, 0),
(10390, 72, '27.8000', 24, 0),
(10391, 13, '4.8000', 18, 0),
(10392, 69, '28.8000', 50, 0),
(10393, 2, '15.2000', 25, 0),
(10393, 14, '18.6000', 42, 0),
(10393, 25, '11.2000', 7, 0),
(10393, 26, '24.9000', 70, 0),
(10393, 31, '10.0000', 32, 0),
(10394, 13, '4.8000', 10, 0),
(10394, 62, '39.4000', 10, 0),
(10395, 46, '9.6000', 28, 0),
(10395, 53, '26.2000', 70, 0),
(10395, 69, '28.8000', 8, 0),
(10396, 23, '7.2000', 40, 0),
(10396, 71, '17.2000', 60, 0),
(10396, 72, '27.8000', 21, 0),
(10397, 21, '8.0000', 10, 0),
(10397, 51, '42.4000', 18, 0),
(10398, 35, '14.4000', 30, 0),
(10398, 55, '19.2000', 120, 0),
(10399, 68, '10.0000', 60, 0),
(10399, 71, '17.2000', 30, 0),
(10399, 76, '14.4000', 35, 0),
(10399, 77, '10.4000', 14, 0),
(10400, 29, '99.0000', 21, 0),
(10400, 35, '14.4000', 35, 0),
(10400, 49, '16.0000', 30, 0),
(10401, 30, '20.7000', 18, 0),
(10401, 56, '30.4000', 70, 0),
(10401, 65, '16.8000', 20, 0),
(10401, 71, '17.2000', 60, 0),
(10402, 23, '7.2000', 60, 0),
(10402, 63, '35.1000', 65, 0),
(10403, 16, '13.9000', 21, 0),
(10403, 48, '10.2000', 70, 0),
(10404, 26, '24.9000', 30, 0),
(10404, 42, '11.2000', 40, 0),
(10404, 49, '16.0000', 30, 0),
(10405, 3, '8.0000', 50, 0),
(10406, 1, '14.4000', 10, 0),
(10406, 21, '8.0000', 30, 0),
(10406, 28, '36.4000', 42, 0),
(10406, 36, '15.2000', 5, 0),
(10406, 40, '14.7000', 2, 0),
(10407, 11, '16.8000', 30, 0),
(10407, 69, '28.8000', 15, 0),
(10407, 71, '17.2000', 15, 0),
(10408, 37, '20.8000', 10, 0),
(10408, 54, '5.9000', 6, 0),
(10408, 62, '39.4000', 35, 0),
(10409, 14, '18.6000', 12, 0),
(10409, 21, '8.0000', 12, 0),
(10410, 33, '2.0000', 49, 0),
(10410, 59, '44.0000', 16, 0),
(10411, 41, '7.7000', 25, 0),
(10411, 44, '15.5000', 40, 0),
(10411, 59, '44.0000', 9, 0),
(10412, 14, '18.6000', 20, 0),
(10413, 1, '14.4000', 24, 0),
(10413, 62, '39.4000', 40, 0),
(10413, 76, '14.4000', 14, 0),
(10414, 19, '7.3000', 18, 0),
(10414, 33, '2.0000', 50, 0),
(10415, 17, '31.2000', 2, 0),
(10415, 33, '2.0000', 20, 0),
(10416, 19, '7.3000', 20, 0),
(10416, 53, '26.2000', 10, 0),
(10416, 57, '15.6000', 20, 0),
(10417, 38, '210.8000', 50, 0),
(10417, 46, '9.6000', 2, 0),
(10417, 68, '10.0000', 36, 0),
(10417, 77, '10.4000', 35, 0),
(10418, 2, '15.2000', 60, 0),
(10418, 47, '7.6000', 55, 0),
(10418, 61, '22.8000', 16, 0),
(10418, 74, '8.0000', 15, 0),
(10419, 60, '27.2000', 60, 0),
(10419, 69, '28.8000', 20, 0),
(10420, 9, '77.6000', 20, 0),
(10420, 13, '4.8000', 2, 0),
(10420, 70, '12.0000', 8, 0),
(10420, 73, '12.0000', 20, 0),
(10421, 19, '7.3000', 4, 0),
(10421, 26, '24.9000', 30, 0),
(10421, 53, '26.2000', 15, 0),
(10421, 77, '10.4000', 10, 0),
(10422, 26, '24.9000', 2, 0),
(10423, 31, '10.0000', 14, 0),
(10423, 59, '44.0000', 20, 0),
(10424, 35, '14.4000', 60, 0),
(10424, 38, '210.8000', 49, 0),
(10424, 68, '10.0000', 30, 0),
(10425, 55, '19.2000', 10, 0),
(10425, 76, '14.4000', 20, 0),
(10426, 56, '30.4000', 5, 0),
(10426, 64, '26.6000', 7, 0),
(10427, 14, '18.6000', 35, 0),
(10428, 46, '9.6000', 20, 0),
(10429, 50, '13.0000', 40, 0),
(10429, 63, '35.1000', 35, 0),
(10430, 17, '31.2000', 45, 0),
(10430, 21, '8.0000', 50, 0),
(10430, 56, '30.4000', 30, 0),
(10430, 59, '44.0000', 70, 0),
(10431, 17, '31.2000', 50, 0),
(10431, 40, '14.7000', 50, 0),
(10431, 47, '7.6000', 30, 0),
(10432, 26, '24.9000', 10, 0),
(10432, 54, '5.9000', 40, 0),
(10433, 56, '30.4000', 28, 0),
(10434, 11, '16.8000', 6, 0),
(10434, 76, '14.4000', 18, 0),
(10435, 2, '15.2000', 10, 0),
(10435, 22, '16.8000', 12, 0),
(10435, 72, '27.8000', 10, 0),
(10436, 46, '9.6000', 5, 0),
(10436, 56, '30.4000', 40, 0),
(10436, 64, '26.6000', 30, 0),
(10436, 75, '6.2000', 24, 0),
(10437, 53, '26.2000', 15, 0),
(10438, 19, '7.3000', 15, 0),
(10438, 34, '11.2000', 20, 0),
(10438, 57, '15.6000', 15, 0),
(10439, 12, '30.4000', 15, 0),
(10439, 16, '13.9000', 16, 0),
(10439, 64, '26.6000', 6, 0),
(10439, 74, '8.0000', 30, 0),
(10440, 2, '15.2000', 45, 0),
(10440, 16, '13.9000', 49, 0),
(10440, 29, '99.0000', 24, 0),
(10440, 61, '22.8000', 90, 0),
(10441, 27, '35.1000', 50, 0),
(10442, 11, '16.8000', 30, 0),
(10442, 54, '5.9000', 80, 0),
(10442, 66, '13.6000', 60, 0),
(10443, 11, '16.8000', 6, 0),
(10443, 28, '36.4000', 12, 0),
(10444, 17, '31.2000', 10, 0),
(10444, 26, '24.9000', 15, 0),
(10444, 35, '14.4000', 8, 0),
(10444, 41, '7.7000', 30, 0),
(10445, 39, '14.4000', 6, 0),
(10445, 54, '5.9000', 15, 0),
(10446, 19, '7.3000', 12, 0),
(10446, 24, '3.6000', 20, 0),
(10446, 31, '10.0000', 3, 0),
(10446, 52, '5.6000', 15, 0),
(10447, 19, '7.3000', 40, 0),
(10447, 65, '16.8000', 35, 0),
(10447, 71, '17.2000', 2, 0),
(10448, 26, '24.9000', 6, 0),
(10448, 40, '14.7000', 20, 0),
(10449, 10, '24.8000', 14, 0),
(10449, 52, '5.6000', 20, 0),
(10449, 62, '39.4000', 35, 0),
(10450, 10, '24.8000', 20, 0),
(10450, 54, '5.9000', 6, 0),
(10451, 55, '19.2000', 120, 0),
(10451, 64, '26.6000', 35, 0),
(10451, 65, '16.8000', 28, 0),
(10451, 77, '10.4000', 55, 0),
(10452, 28, '36.4000', 15, 0),
(10452, 44, '15.5000', 100, 0),
(10453, 48, '10.2000', 15, 0),
(10453, 70, '12.0000', 25, 0),
(10454, 16, '13.9000', 20, 0),
(10454, 33, '2.0000', 20, 0),
(10454, 46, '9.6000', 10, 0),
(10455, 39, '14.4000', 20, 0),
(10455, 53, '26.2000', 50, 0),
(10455, 61, '22.8000', 25, 0),
(10455, 71, '17.2000', 30, 0),
(10456, 21, '8.0000', 40, 0),
(10456, 49, '16.0000', 21, 0),
(10457, 59, '44.0000', 36, 0),
(10458, 26, '24.9000', 30, 0),
(10458, 28, '36.4000', 30, 0),
(10458, 43, '36.8000', 20, 0),
(10458, 56, '30.4000', 15, 0),
(10458, 71, '17.2000', 50, 0),
(10459, 7, '24.0000', 16, 0),
(10459, 46, '9.6000', 20, 0),
(10459, 72, '27.8000', 40, 0),
(10460, 68, '10.0000', 21, 0),
(10460, 75, '6.2000', 4, 0),
(10461, 21, '8.0000', 40, 0),
(10461, 30, '20.7000', 28, 0),
(10461, 55, '19.2000', 60, 0),
(10462, 13, '4.8000', 1, 0),
(10462, 23, '7.2000', 21, 0),
(10463, 19, '7.3000', 21, 0),
(10463, 42, '11.2000', 50, 0),
(10464, 4, '17.6000', 16, 0),
(10464, 43, '36.8000', 3, 0),
(10464, 56, '30.4000', 30, 0),
(10464, 60, '27.2000', 20, 0),
(10465, 24, '3.6000', 25, 0),
(10465, 29, '99.0000', 18, 0),
(10465, 40, '14.7000', 20, 0),
(10465, 45, '7.6000', 30, 0),
(10465, 50, '13.0000', 25, 0),
(10466, 11, '16.8000', 10, 0),
(10466, 46, '9.6000', 5, 0),
(10467, 24, '3.6000', 28, 0),
(10467, 25, '11.2000', 12, 0),
(10468, 30, '20.7000', 8, 0),
(10468, 43, '36.8000', 15, 0),
(10469, 2, '15.2000', 40, 0),
(10469, 16, '13.9000', 35, 0),
(10469, 44, '15.5000', 2, 0),
(10470, 18, '50.0000', 30, 0),
(10470, 23, '7.2000', 15, 0),
(10470, 64, '26.6000', 8, 0),
(10471, 7, '24.0000', 30, 0),
(10471, 56, '30.4000', 20, 0),
(10472, 24, '3.6000', 80, 0),
(10472, 51, '42.4000', 18, 0),
(10473, 33, '2.0000', 12, 0),
(10473, 71, '17.2000', 12, 0),
(10474, 14, '18.6000', 12, 0),
(10474, 28, '36.4000', 18, 0),
(10474, 40, '14.7000', 21, 0),
(10474, 75, '6.2000', 10, 0),
(10475, 31, '10.0000', 35, 0),
(10475, 66, '13.6000', 60, 0),
(10475, 76, '14.4000', 42, 0),
(10476, 55, '19.2000', 2, 0),
(10476, 70, '12.0000', 12, 0),
(10477, 1, '14.4000', 15, 0),
(10477, 21, '8.0000', 21, 0),
(10477, 39, '14.4000', 20, 0),
(10478, 10, '24.8000', 20, 0),
(10479, 38, '210.8000', 30, 0),
(10479, 53, '26.2000', 28, 0),
(10479, 59, '44.0000', 60, 0),
(10479, 64, '26.6000', 30, 0),
(10480, 47, '7.6000', 30, 0),
(10480, 59, '44.0000', 12, 0),
(10481, 49, '16.0000', 24, 0),
(10481, 60, '27.2000', 40, 0),
(10482, 40, '14.7000', 10, 0),
(10483, 34, '11.2000', 35, 0),
(10483, 77, '10.4000', 30, 0),
(10484, 21, '8.0000', 14, 0),
(10484, 40, '14.7000', 10, 0),
(10484, 51, '42.4000', 3, 0),
(10485, 2, '15.2000', 20, 0),
(10485, 3, '8.0000', 20, 0),
(10485, 55, '19.2000', 30, 0),
(10485, 70, '12.0000', 60, 0),
(10486, 11, '16.8000', 5, 0),
(10486, 51, '42.4000', 25, 0),
(10486, 74, '8.0000', 16, 0),
(10487, 19, '7.3000', 5, 0),
(10487, 26, '24.9000', 30, 0),
(10487, 54, '5.9000', 24, 0),
(10488, 59, '44.0000', 30, 0),
(10488, 73, '12.0000', 20, 0),
(10489, 11, '16.8000', 15, 0),
(10489, 16, '13.9000', 18, 0),
(10490, 59, '44.0000', 60, 0),
(10490, 68, '10.0000', 30, 0),
(10490, 75, '6.2000', 36, 0),
(10491, 44, '15.5000', 15, 0),
(10491, 77, '10.4000', 7, 0),
(10492, 25, '11.2000', 60, 0),
(10492, 42, '11.2000', 20, 0),
(10493, 65, '16.8000', 15, 0),
(10493, 66, '13.6000', 10, 0),
(10493, 69, '28.8000', 10, 0),
(10494, 56, '30.4000', 30, 0),
(10495, 23, '7.2000', 10, 0),
(10495, 41, '7.7000', 20, 0),
(10495, 77, '10.4000', 5, 0),
(10496, 31, '10.0000', 20, 0),
(10497, 56, '30.4000', 14, 0),
(10497, 72, '27.8000', 25, 0),
(10497, 77, '10.4000', 25, 0),
(10498, 24, '4.5000', 14, 0),
(10498, 40, '18.4000', 5, 0),
(10498, 42, '14.0000', 30, 0),
(10499, 28, '45.6000', 20, 0),
(10499, 49, '20.0000', 25, 0),
(10500, 15, '15.5000', 12, 0),
(10500, 28, '45.6000', 8, 0),
(10501, 54, '7.4500', 20, 0),
(10502, 45, '9.5000', 21, 0),
(10502, 53, '32.8000', 6, 0),
(10502, 67, '14.0000', 30, 0),
(10503, 14, '23.2500', 70, 0),
(10503, 65, '21.0500', 20, 0),
(10504, 2, '19.0000', 12, 0),
(10504, 21, '10.0000', 12, 0),
(10504, 53, '32.8000', 10, 0),
(10504, 61, '28.5000', 25, 0),
(10505, 62, '49.3000', 3, 0),
(10506, 25, '14.0000', 18, 0),
(10506, 70, '15.0000', 14, 0),
(10507, 43, '46.0000', 15, 0),
(10507, 48, '12.7500', 15, 0),
(10508, 13, '6.0000', 10, 0),
(10508, 39, '18.0000', 10, 0),
(10509, 28, '45.6000', 3, 0),
(10510, 29, '123.7900', 36, 0),
(10510, 75, '7.7500', 36, 0),
(10511, 4, '22.0000', 50, 0),
(10511, 7, '30.0000', 50, 0),
(10511, 8, '40.0000', 10, 0),
(10512, 24, '4.5000', 10, 0),
(10512, 46, '12.0000', 9, 0),
(10512, 47, '9.5000', 6, 0),
(10512, 60, '34.0000', 12, 0),
(10513, 21, '10.0000', 40, 0),
(10513, 32, '32.0000', 50, 0),
(10513, 61, '28.5000', 15, 0),
(10514, 20, '81.0000', 39, 0),
(10514, 28, '45.6000', 35, 0),
(10514, 56, '38.0000', 70, 0),
(10514, 65, '21.0500', 39, 0),
(10514, 75, '7.7500', 50, 0),
(10515, 9, '97.0000', 16, 0),
(10515, 16, '17.4500', 50, 0),
(10515, 27, '43.9000', 120, 0),
(10515, 33, '2.5000', 16, 0),
(10515, 60, '34.0000', 84, 0),
(10516, 18, '62.5000', 25, 0),
(10516, 41, '9.6500', 80, 0),
(10516, 42, '14.0000', 20, 0),
(10517, 52, '7.0000', 6, 0),
(10517, 59, '55.0000', 4, 0),
(10517, 70, '15.0000', 6, 0),
(10518, 24, '4.5000', 5, 0),
(10518, 38, '263.5000', 15, 0),
(10518, 44, '19.4500', 9, 0),
(10519, 10, '31.0000', 16, 0),
(10519, 56, '38.0000', 40, 0),
(10519, 60, '34.0000', 10, 0),
(10520, 24, '4.5000', 8, 0),
(10520, 53, '32.8000', 5, 0),
(10521, 35, '18.0000', 3, 0),
(10521, 41, '9.6500', 10, 0),
(10521, 68, '12.5000', 6, 0),
(10522, 1, '18.0000', 40, 0),
(10522, 8, '40.0000', 24, 0),
(10522, 30, '25.8900', 20, 0),
(10522, 40, '18.4000', 25, 0),
(10523, 17, '39.0000', 25, 0),
(10523, 20, '81.0000', 15, 0),
(10523, 37, '26.0000', 18, 0),
(10523, 41, '9.6500', 6, 0),
(10524, 10, '31.0000', 2, 0),
(10524, 30, '25.8900', 10, 0),
(10524, 43, '46.0000', 60, 0),
(10524, 54, '7.4500', 15, 0),
(10525, 36, '19.0000', 30, 0),
(10525, 40, '18.4000', 15, 0),
(10526, 1, '18.0000', 8, 0),
(10526, 13, '6.0000', 10, 0),
(10526, 56, '38.0000', 30, 0),
(10527, 4, '22.0000', 50, 0),
(10527, 36, '19.0000', 30, 0),
(10528, 11, '21.0000', 3, 0),
(10528, 33, '2.5000', 8, 0),
(10528, 72, '34.8000', 9, 0),
(10529, 55, '24.0000', 14, 0),
(10529, 68, '12.5000', 20, 0),
(10529, 69, '36.0000', 10, 0),
(10530, 17, '39.0000', 40, 0),
(10530, 43, '46.0000', 25, 0),
(10530, 61, '28.5000', 20, 0),
(10530, 76, '18.0000', 50, 0),
(10531, 59, '55.0000', 2, 0),
(10532, 30, '25.8900', 15, 0),
(10532, 66, '17.0000', 24, 0),
(10533, 4, '22.0000', 50, 0),
(10533, 72, '34.8000', 24, 0),
(10533, 73, '15.0000', 24, 0),
(10534, 30, '25.8900', 10, 0),
(10534, 40, '18.4000', 10, 0),
(10534, 54, '7.4500', 10, 0),
(10535, 11, '21.0000', 50, 0),
(10535, 40, '18.4000', 10, 0),
(10535, 57, '19.5000', 5, 0),
(10535, 59, '55.0000', 15, 0),
(10536, 12, '38.0000', 15, 0),
(10536, 31, '12.5000', 20, 0),
(10536, 33, '2.5000', 30, 0),
(10536, 60, '34.0000', 35, 0),
(10537, 31, '12.5000', 30, 0),
(10537, 51, '53.0000', 6, 0),
(10537, 58, '13.2500', 20, 0),
(10537, 72, '34.8000', 21, 0),
(10537, 73, '15.0000', 9, 0),
(10538, 70, '15.0000', 7, 0),
(10538, 72, '34.8000', 1, 0),
(10539, 13, '6.0000', 8, 0),
(10539, 21, '10.0000', 15, 0),
(10539, 33, '2.5000', 15, 0),
(10539, 49, '20.0000', 6, 0),
(10540, 3, '10.0000', 60, 0),
(10540, 26, '31.2300', 40, 0),
(10540, 38, '263.5000', 30, 0),
(10540, 68, '12.5000', 35, 0),
(10541, 24, '4.5000', 35, 0),
(10541, 38, '263.5000', 4, 0),
(10541, 65, '21.0500', 36, 0),
(10541, 71, '21.5000', 9, 0),
(10542, 11, '21.0000', 15, 0),
(10542, 54, '7.4500', 24, 0),
(10543, 12, '38.0000', 30, 0),
(10543, 23, '9.0000', 70, 0),
(10544, 28, '45.6000', 7, 0),
(10544, 67, '14.0000', 7, 0),
(10545, 11, '21.0000', 10, 0),
(10546, 7, '30.0000', 10, 0),
(10546, 35, '18.0000', 30, 0),
(10546, 62, '49.3000', 40, 0),
(10547, 32, '32.0000', 24, 0),
(10547, 36, '19.0000', 60, 0),
(10548, 34, '14.0000', 10, 0),
(10548, 41, '9.6500', 14, 0),
(10549, 31, '12.5000', 55, 0),
(10549, 45, '9.5000', 100, 0),
(10549, 51, '53.0000', 48, 0),
(10550, 17, '39.0000', 8, 0),
(10550, 19, '9.2000', 10, 0),
(10550, 21, '10.0000', 6, 0),
(10550, 61, '28.5000', 10, 0),
(10551, 16, '17.4500', 40, 0),
(10551, 35, '18.0000', 20, 0),
(10551, 44, '19.4500', 40, 0),
(10552, 69, '36.0000', 18, 0),
(10552, 75, '7.7500', 30, 0),
(10553, 11, '21.0000', 15, 0),
(10553, 16, '17.4500', 14, 0),
(10553, 22, '21.0000', 24, 0),
(10553, 31, '12.5000', 30, 0),
(10553, 35, '18.0000', 6, 0),
(10554, 16, '17.4500', 30, 0),
(10554, 23, '9.0000', 20, 0),
(10554, 62, '49.3000', 20, 0),
(10554, 77, '13.0000', 10, 0),
(10555, 14, '23.2500', 30, 0),
(10555, 19, '9.2000', 35, 0),
(10555, 24, '4.5000', 18, 0),
(10555, 51, '53.0000', 20, 0),
(10555, 56, '38.0000', 40, 0),
(10556, 72, '34.8000', 24, 0),
(10557, 64, '33.2500', 30, 0),
(10557, 75, '7.7500', 20, 0),
(10558, 47, '9.5000', 25, 0),
(10558, 51, '53.0000', 20, 0),
(10558, 52, '7.0000', 30, 0),
(10558, 53, '32.8000', 18, 0),
(10558, 73, '15.0000', 3, 0),
(10559, 41, '9.6500', 12, 0),
(10559, 55, '24.0000', 18, 0),
(10560, 30, '25.8900', 20, 0),
(10560, 62, '49.3000', 15, 0),
(10561, 44, '19.4500', 10, 0),
(10561, 51, '53.0000', 50, 0),
(10562, 33, '2.5000', 20, 0),
(10562, 62, '49.3000', 10, 0),
(10563, 36, '19.0000', 25, 0),
(10563, 52, '7.0000', 70, 0),
(10564, 17, '39.0000', 16, 0),
(10564, 31, '12.5000', 6, 0),
(10564, 55, '24.0000', 25, 0),
(10565, 24, '4.5000', 25, 0),
(10565, 64, '33.2500', 18, 0),
(10566, 11, '21.0000', 35, 0),
(10566, 18, '62.5000', 18, 0),
(10566, 76, '18.0000', 10, 0),
(10567, 31, '12.5000', 60, 0),
(10567, 51, '53.0000', 3, 0),
(10567, 59, '55.0000', 40, 0),
(10568, 10, '31.0000', 5, 0),
(10569, 31, '12.5000', 35, 0),
(10569, 76, '18.0000', 30, 0),
(10570, 11, '21.0000', 15, 0),
(10570, 56, '38.0000', 60, 0),
(10571, 14, '23.2500', 11, 0),
(10571, 42, '14.0000', 28, 0),
(10572, 16, '17.4500', 12, 0),
(10572, 32, '32.0000', 10, 0),
(10572, 40, '18.4000', 50, 0),
(10572, 75, '7.7500', 15, 0),
(10573, 17, '39.0000', 18, 0),
(10573, 34, '14.0000', 40, 0),
(10573, 53, '32.8000', 25, 0),
(10574, 33, '2.5000', 14, 0),
(10574, 40, '18.4000', 2, 0),
(10574, 62, '49.3000', 10, 0),
(10574, 64, '33.2500', 6, 0),
(10575, 59, '55.0000', 12, 0),
(10575, 63, '43.9000', 6, 0),
(10575, 72, '34.8000', 30, 0),
(10575, 76, '18.0000', 10, 0),
(10576, 1, '18.0000', 10, 0),
(10576, 31, '12.5000', 20, 0),
(10576, 44, '19.4500', 21, 0),
(10577, 39, '18.0000', 10, 0),
(10577, 75, '7.7500', 20, 0),
(10577, 77, '13.0000', 18, 0),
(10578, 35, '18.0000', 20, 0),
(10578, 57, '19.5000', 6, 0),
(10579, 15, '15.5000', 10, 0),
(10579, 75, '7.7500', 21, 0),
(10580, 14, '23.2500', 15, 0),
(10580, 41, '9.6500', 9, 0),
(10580, 65, '21.0500', 30, 0),
(10581, 75, '7.7500', 50, 0),
(10582, 57, '19.5000', 4, 0),
(10582, 76, '18.0000', 14, 0),
(10583, 29, '123.7900', 10, 0),
(10583, 60, '34.0000', 24, 0),
(10583, 69, '36.0000', 10, 0),
(10584, 31, '12.5000', 50, 0),
(10585, 47, '9.5000', 15, 0),
(10586, 52, '7.0000', 4, 0),
(10587, 26, '31.2300', 6, 0),
(10587, 35, '18.0000', 20, 0),
(10587, 77, '13.0000', 20, 0),
(10588, 18, '62.5000', 40, 0),
(10588, 42, '14.0000', 100, 0),
(10589, 35, '18.0000', 4, 0),
(10590, 1, '18.0000', 20, 0),
(10590, 77, '13.0000', 60, 0),
(10591, 3, '10.0000', 14, 0),
(10591, 7, '30.0000', 10, 0),
(10591, 54, '7.4500', 50, 0),
(10592, 15, '15.5000', 25, 0),
(10592, 26, '31.2300', 5, 0),
(10593, 20, '81.0000', 21, 0),
(10593, 69, '36.0000', 20, 0),
(10593, 76, '18.0000', 4, 0),
(10594, 52, '7.0000', 24, 0),
(10594, 58, '13.2500', 30, 0),
(10595, 35, '18.0000', 30, 0),
(10595, 61, '28.5000', 120, 0),
(10595, 69, '36.0000', 65, 0),
(10596, 56, '38.0000', 5, 0),
(10596, 63, '43.9000', 24, 0),
(10596, 75, '7.7500', 30, 0),
(10597, 24, '4.5000', 35, 0),
(10597, 57, '19.5000', 20, 0),
(10597, 65, '21.0500', 12, 0),
(10598, 27, '43.9000', 50, 0),
(10598, 71, '21.5000', 9, 0),
(10599, 62, '49.3000', 10, 0),
(10600, 54, '7.4500', 4, 0),
(10600, 73, '15.0000', 30, 0),
(10601, 13, '6.0000', 60, 0),
(10601, 59, '55.0000', 35, 0),
(10602, 77, '13.0000', 5, 0),
(10603, 22, '21.0000', 48, 0),
(10603, 49, '20.0000', 25, 0),
(10604, 48, '12.7500', 6, 0),
(10604, 76, '18.0000', 10, 0),
(10605, 16, '17.4500', 30, 0),
(10605, 59, '55.0000', 20, 0),
(10605, 60, '34.0000', 70, 0),
(10605, 71, '21.5000', 15, 0),
(10606, 4, '22.0000', 20, 0),
(10606, 55, '24.0000', 20, 0),
(10606, 62, '49.3000', 10, 0),
(10607, 7, '30.0000', 45, 0),
(10607, 17, '39.0000', 100, 0),
(10607, 33, '2.5000', 14, 0),
(10607, 40, '18.4000', 42, 0),
(10607, 72, '34.8000', 12, 0),
(10608, 56, '38.0000', 28, 0),
(10609, 1, '18.0000', 3, 0),
(10609, 10, '31.0000', 10, 0),
(10609, 21, '10.0000', 6, 0),
(10610, 36, '19.0000', 21, 0),
(10611, 1, '18.0000', 6, 0),
(10611, 2, '19.0000', 10, 0),
(10611, 60, '34.0000', 15, 0),
(10612, 10, '31.0000', 70, 0),
(10612, 36, '19.0000', 55, 0),
(10612, 49, '20.0000', 18, 0),
(10612, 60, '34.0000', 40, 0),
(10612, 76, '18.0000', 80, 0),
(10613, 13, '6.0000', 8, 0),
(10613, 75, '7.7500', 40, 0),
(10614, 11, '21.0000', 14, 0),
(10614, 21, '10.0000', 8, 0),
(10614, 39, '18.0000', 5, 0),
(10615, 55, '24.0000', 5, 0),
(10616, 38, '263.5000', 15, 0),
(10616, 56, '38.0000', 14, 0),
(10616, 70, '15.0000', 15, 0),
(10616, 71, '21.5000', 15, 0),
(10617, 59, '55.0000', 30, 0),
(10618, 6, '25.0000', 70, 0),
(10618, 56, '38.0000', 20, 0),
(10618, 68, '12.5000', 15, 0),
(10619, 21, '10.0000', 42, 0),
(10619, 22, '21.0000', 40, 0),
(10620, 24, '4.5000', 5, 0),
(10620, 52, '7.0000', 5, 0),
(10621, 19, '9.2000', 5, 0),
(10621, 23, '9.0000', 10, 0),
(10621, 70, '15.0000', 20, 0),
(10621, 71, '21.5000', 15, 0),
(10622, 2, '19.0000', 20, 0),
(10622, 68, '12.5000', 18, 0),
(10623, 14, '23.2500', 21, 0),
(10623, 19, '9.2000', 15, 0),
(10623, 21, '10.0000', 25, 0),
(10623, 24, '4.5000', 3, 0),
(10623, 35, '18.0000', 30, 0),
(10624, 28, '45.6000', 10, 0),
(10624, 29, '123.7900', 6, 0),
(10624, 44, '19.4500', 10, 0),
(10625, 14, '23.2500', 3, 0),
(10625, 42, '14.0000', 5, 0),
(10625, 60, '34.0000', 10, 0),
(10626, 53, '32.8000', 12, 0),
(10626, 60, '34.0000', 20, 0),
(10626, 71, '21.5000', 20, 0),
(10627, 62, '49.3000', 15, 0),
(10627, 73, '15.0000', 35, 0),
(10628, 1, '18.0000', 25, 0),
(10629, 29, '123.7900', 20, 0),
(10629, 64, '33.2500', 9, 0),
(10630, 55, '24.0000', 12, 0),
(10630, 76, '18.0000', 35, 0),
(10631, 75, '7.7500', 8, 0),
(10632, 2, '19.0000', 30, 0),
(10632, 33, '2.5000', 20, 0),
(10633, 12, '38.0000', 36, 0),
(10633, 13, '6.0000', 13, 0),
(10633, 26, '31.2300', 35, 0),
(10633, 62, '49.3000', 80, 0),
(10634, 7, '30.0000', 35, 0),
(10634, 18, '62.5000', 50, 0),
(10634, 51, '53.0000', 15, 0),
(10634, 75, '7.7500', 2, 0),
(10635, 4, '22.0000', 10, 0),
(10635, 5, '21.3500', 15, 0),
(10635, 22, '21.0000', 40, 0),
(10636, 4, '22.0000', 25, 0),
(10636, 58, '13.2500', 6, 0),
(10637, 11, '21.0000', 10, 0),
(10637, 50, '16.2500', 25, 0),
(10637, 56, '38.0000', 60, 0),
(10638, 45, '9.5000', 20, 0),
(10638, 65, '21.0500', 21, 0),
(10638, 72, '34.8000', 60, 0),
(10639, 18, '62.5000', 8, 0),
(10640, 69, '36.0000', 20, 0),
(10640, 70, '15.0000', 15, 0),
(10641, 2, '19.0000', 50, 0),
(10641, 40, '18.4000', 60, 0),
(10642, 21, '10.0000', 30, 0),
(10642, 61, '28.5000', 20, 0),
(10643, 28, '45.6000', 15, 0),
(10643, 39, '18.0000', 21, 0),
(10643, 46, '12.0000', 2, 0),
(10644, 18, '62.5000', 4, 0),
(10644, 43, '46.0000', 20, 0),
(10644, 46, '12.0000', 21, 0),
(10645, 18, '62.5000', 20, 0),
(10645, 36, '19.0000', 15, 0),
(10646, 1, '18.0000', 15, 0),
(10646, 10, '31.0000', 18, 0),
(10646, 71, '21.5000', 30, 0),
(10646, 77, '13.0000', 35, 0),
(10647, 19, '9.2000', 30, 0),
(10647, 39, '18.0000', 20, 0),
(10648, 22, '21.0000', 15, 0),
(10648, 24, '4.5000', 15, 0),
(10649, 28, '45.6000', 20, 0),
(10649, 72, '34.8000', 15, 0),
(10650, 30, '25.8900', 30, 0),
(10650, 53, '32.8000', 25, 0),
(10650, 54, '7.4500', 30, 0),
(10651, 19, '9.2000', 12, 0),
(10651, 22, '21.0000', 20, 0),
(10652, 30, '25.8900', 2, 0),
(10652, 42, '14.0000', 20, 0),
(10653, 16, '17.4500', 30, 0),
(10653, 60, '34.0000', 20, 0),
(10654, 4, '22.0000', 12, 0),
(10654, 39, '18.0000', 20, 0),
(10654, 54, '7.4500', 6, 0),
(10655, 41, '9.6500', 20, 0),
(10656, 14, '23.2500', 3, 0),
(10656, 44, '19.4500', 28, 0),
(10656, 47, '9.5000', 6, 0),
(10657, 15, '15.5000', 50, 0),
(10657, 41, '9.6500', 24, 0),
(10657, 46, '12.0000', 45, 0),
(10657, 47, '9.5000', 10, 0),
(10657, 56, '38.0000', 45, 0),
(10657, 60, '34.0000', 30, 0),
(10658, 21, '10.0000', 60, 0),
(10658, 40, '18.4000', 70, 0),
(10658, 60, '34.0000', 55, 0),
(10658, 77, '13.0000', 70, 0),
(10659, 31, '12.5000', 20, 0),
(10659, 40, '18.4000', 24, 0),
(10659, 70, '15.0000', 40, 0),
(10660, 20, '81.0000', 21, 0),
(10661, 39, '18.0000', 3, 0),
(10661, 58, '13.2500', 49, 0),
(10662, 68, '12.5000', 10, 0),
(10663, 40, '18.4000', 30, 0),
(10663, 42, '14.0000', 30, 0),
(10663, 51, '53.0000', 20, 0),
(10664, 10, '31.0000', 24, 0),
(10664, 56, '38.0000', 12, 0),
(10664, 65, '21.0500', 15, 0),
(10665, 51, '53.0000', 20, 0),
(10665, 59, '55.0000', 1, 0),
(10665, 76, '18.0000', 10, 0),
(10666, 29, '123.7900', 36, 0),
(10666, 65, '21.0500', 10, 0),
(10667, 69, '36.0000', 45, 0),
(10667, 71, '21.5000', 14, 0),
(10668, 31, '12.5000', 8, 0),
(10668, 55, '24.0000', 4, 0),
(10668, 64, '33.2500', 15, 0),
(10669, 36, '19.0000', 30, 0),
(10670, 23, '9.0000', 32, 0),
(10670, 46, '12.0000', 60, 0),
(10670, 67, '14.0000', 25, 0),
(10670, 73, '15.0000', 50, 0),
(10670, 75, '7.7500', 25, 0),
(10671, 16, '17.4500', 10, 0),
(10671, 62, '49.3000', 10, 0),
(10671, 65, '21.0500', 12, 0),
(10672, 38, '263.5000', 15, 0),
(10672, 71, '21.5000', 12, 0),
(10673, 16, '17.4500', 3, 0),
(10673, 42, '14.0000', 6, 0),
(10673, 43, '46.0000', 6, 0),
(10674, 23, '9.0000', 5, 0),
(10675, 14, '23.2500', 30, 0),
(10675, 53, '32.8000', 10, 0),
(10675, 58, '13.2500', 30, 0),
(10676, 10, '31.0000', 2, 0),
(10676, 19, '9.2000', 7, 0),
(10676, 44, '19.4500', 21, 0),
(10677, 26, '31.2300', 30, 0),
(10677, 33, '2.5000', 8, 0),
(10678, 12, '38.0000', 100, 0),
(10678, 33, '2.5000', 30, 0),
(10678, 41, '9.6500', 120, 0),
(10678, 54, '7.4500', 30, 0),
(10679, 59, '55.0000', 12, 0),
(10680, 16, '17.4500', 50, 0),
(10680, 31, '12.5000', 20, 0),
(10680, 42, '14.0000', 40, 0),
(10681, 19, '9.2000', 30, 0),
(10681, 21, '10.0000', 12, 0),
(10681, 64, '33.2500', 28, 0),
(10682, 33, '2.5000', 30, 0),
(10682, 66, '17.0000', 4, 0),
(10682, 75, '7.7500', 30, 0),
(10683, 52, '7.0000', 9, 0),
(10684, 40, '18.4000', 20, 0),
(10684, 47, '9.5000', 40, 0),
(10684, 60, '34.0000', 30, 0),
(10685, 10, '31.0000', 20, 0),
(10685, 41, '9.6500', 4, 0),
(10685, 47, '9.5000', 15, 0),
(10686, 17, '39.0000', 30, 0),
(10686, 26, '31.2300', 15, 0),
(10687, 9, '97.0000', 50, 0),
(10687, 29, '123.7900', 10, 0),
(10687, 36, '19.0000', 6, 0),
(10688, 10, '31.0000', 18, 0),
(10688, 28, '45.6000', 60, 0),
(10688, 34, '14.0000', 14, 0),
(10689, 1, '18.0000', 35, 0),
(10690, 56, '38.0000', 20, 0),
(10690, 77, '13.0000', 30, 0),
(10691, 1, '18.0000', 30, 0),
(10691, 29, '123.7900', 40, 0),
(10691, 43, '46.0000', 40, 0),
(10691, 44, '19.4500', 24, 0),
(10691, 62, '49.3000', 48, 0),
(10692, 63, '43.9000', 20, 0),
(10693, 9, '97.0000', 6, 0),
(10693, 54, '7.4500', 60, 0),
(10693, 69, '36.0000', 30, 0),
(10693, 73, '15.0000', 15, 0),
(10694, 7, '30.0000', 90, 0),
(10694, 59, '55.0000', 25, 0),
(10694, 70, '15.0000', 50, 0),
(10695, 8, '40.0000', 10, 0),
(10695, 12, '38.0000', 4, 0),
(10695, 24, '4.5000', 20, 0),
(10696, 17, '39.0000', 20, 0),
(10696, 46, '12.0000', 18, 0),
(10697, 19, '9.2000', 7, 0),
(10697, 35, '18.0000', 9, 0),
(10697, 58, '13.2500', 30, 0),
(10697, 70, '15.0000', 30, 0),
(10698, 11, '21.0000', 15, 0),
(10698, 17, '39.0000', 8, 0),
(10698, 29, '123.7900', 12, 0),
(10698, 65, '21.0500', 65, 0),
(10698, 70, '15.0000', 8, 0),
(10699, 47, '9.5000', 12, 0),
(10700, 1, '18.0000', 5, 0),
(10700, 34, '14.0000', 12, 0),
(10700, 68, '12.5000', 40, 0),
(10700, 71, '21.5000', 60, 0),
(10701, 59, '55.0000', 42, 0),
(10701, 71, '21.5000', 20, 0),
(10701, 76, '18.0000', 35, 0),
(10702, 3, '10.0000', 6, 0),
(10702, 76, '18.0000', 15, 0),
(10703, 2, '19.0000', 5, 0),
(10703, 59, '55.0000', 35, 0),
(10703, 73, '15.0000', 35, 0),
(10704, 4, '22.0000', 6, 0),
(10704, 24, '4.5000', 35, 0),
(10704, 48, '12.7500', 24, 0),
(10705, 31, '12.5000', 20, 0),
(10705, 32, '32.0000', 4, 0),
(10706, 16, '17.4500', 20, 0),
(10706, 43, '46.0000', 24, 0),
(10706, 59, '55.0000', 8, 0),
(10707, 55, '24.0000', 21, 0),
(10707, 57, '19.5000', 40, 0),
(10707, 70, '15.0000', 28, 0),
(10708, 5, '21.3500', 4, 0),
(10708, 36, '19.0000', 5, 0),
(10709, 8, '40.0000', 40, 0),
(10709, 51, '53.0000', 28, 0),
(10709, 60, '34.0000', 10, 0),
(10710, 19, '9.2000', 5, 0),
(10710, 47, '9.5000', 5, 0),
(10711, 19, '9.2000', 12, 0),
(10711, 41, '9.6500', 42, 0),
(10711, 53, '32.8000', 120, 0),
(10712, 53, '32.8000', 3, 0),
(10712, 56, '38.0000', 30, 0),
(10713, 10, '31.0000', 18, 0),
(10713, 26, '31.2300', 30, 0),
(10713, 45, '9.5000', 110, 0),
(10713, 46, '12.0000', 24, 0),
(10714, 2, '19.0000', 30, 0),
(10714, 17, '39.0000', 27, 0),
(10714, 47, '9.5000', 50, 0),
(10714, 56, '38.0000', 18, 0),
(10714, 58, '13.2500', 12, 0),
(10715, 10, '31.0000', 21, 0),
(10715, 71, '21.5000', 30, 0),
(10716, 21, '10.0000', 5, 0),
(10716, 51, '53.0000', 7, 0),
(10716, 61, '28.5000', 10, 0),
(10717, 21, '10.0000', 32, 0),
(10717, 54, '7.4500', 15, 0),
(10717, 69, '36.0000', 25, 0),
(10718, 12, '38.0000', 36, 0),
(10718, 16, '17.4500', 20, 0),
(10718, 36, '19.0000', 40, 0),
(10718, 62, '49.3000', 20, 0),
(10719, 18, '62.5000', 12, 0),
(10719, 30, '25.8900', 3, 0),
(10719, 54, '7.4500', 40, 0),
(10720, 35, '18.0000', 21, 0),
(10720, 71, '21.5000', 8, 0),
(10721, 44, '19.4500', 50, 0),
(10722, 2, '19.0000', 3, 0),
(10722, 31, '12.5000', 50, 0),
(10722, 68, '12.5000', 45, 0),
(10722, 75, '7.7500', 42, 0),
(10723, 26, '31.2300', 15, 0),
(10724, 10, '31.0000', 16, 0),
(10724, 61, '28.5000', 5, 0),
(10725, 41, '9.6500', 12, 0),
(10725, 52, '7.0000', 4, 0),
(10725, 55, '24.0000', 6, 0),
(10726, 4, '22.0000', 25, 0),
(10726, 11, '21.0000', 5, 0),
(10727, 17, '39.0000', 20, 0),
(10727, 56, '38.0000', 10, 0),
(10727, 59, '55.0000', 10, 0),
(10728, 30, '25.8900', 15, 0),
(10728, 40, '18.4000', 6, 0),
(10728, 55, '24.0000', 12, 0),
(10728, 60, '34.0000', 15, 0),
(10729, 1, '18.0000', 50, 0),
(10729, 21, '10.0000', 30, 0),
(10729, 50, '16.2500', 40, 0),
(10730, 16, '17.4500', 15, 0),
(10730, 31, '12.5000', 3, 0),
(10730, 65, '21.0500', 10, 0),
(10731, 21, '10.0000', 40, 0),
(10731, 51, '53.0000', 30, 0),
(10732, 76, '18.0000', 20, 0),
(10733, 14, '23.2500', 16, 0),
(10733, 28, '45.6000', 20, 0),
(10733, 52, '7.0000', 25, 0),
(10734, 6, '25.0000', 30, 0),
(10734, 30, '25.8900', 15, 0),
(10734, 76, '18.0000', 20, 0),
(10735, 61, '28.5000', 20, 0),
(10735, 77, '13.0000', 2, 0),
(10736, 65, '21.0500', 40, 0),
(10736, 75, '7.7500', 20, 0),
(10737, 13, '6.0000', 4, 0),
(10737, 41, '9.6500', 12, 0),
(10738, 16, '17.4500', 3, 0),
(10739, 36, '19.0000', 6, 0),
(10739, 52, '7.0000', 18, 0),
(10740, 28, '45.6000', 5, 0),
(10740, 35, '18.0000', 35, 0),
(10740, 45, '9.5000', 40, 0),
(10740, 56, '38.0000', 14, 0),
(10741, 2, '19.0000', 15, 0),
(10742, 3, '10.0000', 20, 0),
(10742, 60, '34.0000', 50, 0),
(10742, 72, '34.8000', 35, 0),
(10743, 46, '12.0000', 28, 0),
(10744, 40, '18.4000', 50, 0),
(10745, 18, '62.5000', 24, 0),
(10745, 44, '19.4500', 16, 0),
(10745, 59, '55.0000', 45, 0),
(10745, 72, '34.8000', 7, 0),
(10746, 13, '6.0000', 6, 0),
(10746, 42, '14.0000', 28, 0),
(10746, 62, '49.3000', 9, 0),
(10746, 69, '36.0000', 40, 0),
(10747, 31, '12.5000', 8, 0),
(10747, 41, '9.6500', 35, 0),
(10747, 63, '43.9000', 9, 0),
(10747, 69, '36.0000', 30, 0),
(10748, 23, '9.0000', 44, 0),
(10748, 40, '18.4000', 40, 0),
(10748, 56, '38.0000', 28, 0),
(10749, 56, '38.0000', 15, 0),
(10749, 59, '55.0000', 6, 0),
(10749, 76, '18.0000', 10, 0),
(10750, 14, '23.2500', 5, 0),
(10750, 45, '9.5000', 40, 0),
(10750, 59, '55.0000', 25, 0),
(10751, 26, '31.2300', 12, 0),
(10751, 30, '25.8900', 30, 0),
(10751, 50, '16.2500', 20, 0),
(10751, 73, '15.0000', 15, 0),
(10752, 1, '18.0000', 8, 0),
(10752, 69, '36.0000', 3, 0),
(10753, 45, '9.5000', 4, 0),
(10753, 74, '10.0000', 5, 0),
(10754, 40, '18.4000', 3, 0),
(10755, 47, '9.5000', 30, 0),
(10755, 56, '38.0000', 30, 0),
(10755, 57, '19.5000', 14, 0),
(10755, 69, '36.0000', 25, 0),
(10756, 18, '62.5000', 21, 0),
(10756, 36, '19.0000', 20, 0),
(10756, 68, '12.5000', 6, 0),
(10756, 69, '36.0000', 20, 0),
(10757, 34, '14.0000', 30, 0),
(10757, 59, '55.0000', 7, 0),
(10757, 62, '49.3000', 30, 0),
(10757, 64, '33.2500', 24, 0),
(10758, 26, '31.2300', 20, 0),
(10758, 52, '7.0000', 60, 0),
(10758, 70, '15.0000', 40, 0),
(10759, 32, '32.0000', 10, 0),
(10760, 25, '14.0000', 12, 0),
(10760, 27, '43.9000', 40, 0),
(10760, 43, '46.0000', 30, 0),
(10761, 25, '14.0000', 35, 0),
(10761, 75, '7.7500', 18, 0),
(10762, 39, '18.0000', 16, 0),
(10762, 47, '9.5000', 30, 0),
(10762, 51, '53.0000', 28, 0),
(10762, 56, '38.0000', 60, 0),
(10763, 21, '10.0000', 40, 0),
(10763, 22, '21.0000', 6, 0),
(10763, 24, '4.5000', 20, 0),
(10764, 3, '10.0000', 20, 0),
(10764, 39, '18.0000', 130, 0),
(10765, 65, '21.0500', 80, 0),
(10766, 2, '19.0000', 40, 0),
(10766, 7, '30.0000', 35, 0),
(10766, 68, '12.5000', 40, 0),
(10767, 42, '14.0000', 2, 0),
(10768, 22, '21.0000', 4, 0),
(10768, 31, '12.5000', 50, 0),
(10768, 60, '34.0000', 15, 0),
(10768, 71, '21.5000', 12, 0),
(10769, 41, '9.6500', 30, 0),
(10769, 52, '7.0000', 15, 0),
(10769, 61, '28.5000', 20, 0),
(10769, 62, '49.3000', 15, 0),
(10770, 11, '21.0000', 15, 0),
(10771, 71, '21.5000', 16, 0),
(10772, 29, '123.7900', 18, 0),
(10772, 59, '55.0000', 25, 0),
(10773, 17, '39.0000', 33, 0),
(10773, 31, '12.5000', 70, 0),
(10773, 75, '7.7500', 7, 0),
(10774, 31, '12.5000', 2, 0),
(10774, 66, '17.0000', 50, 0),
(10775, 10, '31.0000', 6, 0),
(10775, 67, '14.0000', 3, 0),
(10776, 31, '12.5000', 16, 0),
(10776, 42, '14.0000', 12, 0),
(10776, 45, '9.5000', 27, 0),
(10776, 51, '53.0000', 120, 0),
(10777, 42, '14.0000', 20, 0),
(10778, 41, '9.6500', 10, 0),
(10779, 16, '17.4500', 20, 0),
(10779, 62, '49.3000', 20, 0),
(10780, 70, '15.0000', 35, 0),
(10780, 77, '13.0000', 15, 0),
(10781, 54, '7.4500', 3, 0),
(10781, 56, '38.0000', 20, 0),
(10781, 74, '10.0000', 35, 0),
(10782, 31, '12.5000', 1, 0),
(10783, 31, '12.5000', 10, 0),
(10783, 38, '263.5000', 5, 0),
(10784, 36, '19.0000', 30, 0),
(10784, 39, '18.0000', 2, 0),
(10784, 72, '34.8000', 30, 0),
(10785, 10, '31.0000', 10, 0),
(10785, 75, '7.7500', 10, 0),
(10786, 8, '40.0000', 30, 0),
(10786, 30, '25.8900', 15, 0),
(10786, 75, '7.7500', 42, 0),
(10787, 2, '19.0000', 15, 0),
(10787, 29, '123.7900', 20, 0),
(10788, 19, '9.2000', 50, 0),
(10788, 75, '7.7500', 40, 0),
(10789, 18, '62.5000', 30, 0),
(10789, 35, '18.0000', 15, 0),
(10789, 63, '43.9000', 30, 0),
(10789, 68, '12.5000', 18, 0),
(10790, 7, '30.0000', 3, 0),
(10790, 56, '38.0000', 20, 0),
(10791, 29, '123.7900', 14, 0),
(10791, 41, '9.6500', 20, 0),
(10792, 2, '19.0000', 10, 0),
(10792, 54, '7.4500', 3, 0),
(10792, 68, '12.5000', 15, 0),
(10793, 41, '9.6500', 14, 0),
(10793, 52, '7.0000', 8, 0),
(10794, 14, '23.2500', 15, 0),
(10794, 54, '7.4500', 6, 0),
(10795, 16, '17.4500', 65, 0),
(10795, 17, '39.0000', 35, 0),
(10796, 26, '31.2300', 21, 0),
(10796, 44, '19.4500', 10, 0),
(10796, 64, '33.2500', 35, 0),
(10796, 69, '36.0000', 24, 0),
(10797, 11, '21.0000', 20, 0),
(10798, 62, '49.3000', 2, 0),
(10798, 72, '34.8000', 10, 0),
(10799, 13, '6.0000', 20, 0),
(10799, 24, '4.5000', 20, 0),
(10799, 59, '55.0000', 25, 0),
(10800, 11, '21.0000', 50, 0),
(10800, 51, '53.0000', 10, 0),
(10800, 54, '7.4500', 7, 0),
(10801, 17, '39.0000', 40, 0),
(10801, 29, '123.7900', 20, 0),
(10802, 30, '25.8900', 25, 0),
(10802, 51, '53.0000', 30, 0),
(10802, 55, '24.0000', 60, 0),
(10802, 62, '49.3000', 5, 0),
(10803, 19, '9.2000', 24, 0),
(10803, 25, '14.0000', 15, 0),
(10803, 59, '55.0000', 15, 0),
(10804, 10, '31.0000', 36, 0),
(10804, 28, '45.6000', 24, 0),
(10804, 49, '20.0000', 4, 0),
(10805, 34, '14.0000', 10, 0),
(10805, 38, '263.5000', 10, 0),
(10806, 2, '19.0000', 20, 0),
(10806, 65, '21.0500', 2, 0),
(10806, 74, '10.0000', 15, 0),
(10807, 40, '18.4000', 1, 0),
(10808, 56, '38.0000', 20, 0),
(10808, 76, '18.0000', 50, 0),
(10809, 52, '7.0000', 20, 0),
(10810, 13, '6.0000', 7, 0),
(10810, 25, '14.0000', 5, 0),
(10810, 70, '15.0000', 5, 0),
(10811, 19, '9.2000', 15, 0),
(10811, 23, '9.0000', 18, 0),
(10811, 40, '18.4000', 30, 0),
(10812, 31, '12.5000', 16, 0),
(10812, 72, '34.8000', 40, 0),
(10812, 77, '13.0000', 20, 0),
(10813, 2, '19.0000', 12, 0),
(10813, 46, '12.0000', 35, 0),
(10814, 41, '9.6500', 20, 0),
(10814, 43, '46.0000', 20, 0),
(10814, 48, '12.7500', 8, 0),
(10814, 61, '28.5000', 30, 0),
(10815, 33, '2.5000', 16, 0),
(10816, 38, '263.5000', 30, 0),
(10816, 62, '49.3000', 20, 0),
(10817, 26, '31.2300', 40, 0),
(10817, 38, '263.5000', 30, 0),
(10817, 40, '18.4000', 60, 0),
(10817, 62, '49.3000', 25, 0),
(10818, 32, '32.0000', 20, 0),
(10818, 41, '9.6500', 20, 0),
(10819, 43, '46.0000', 7, 0),
(10819, 75, '7.7500', 20, 0),
(10820, 56, '38.0000', 30, 0),
(10821, 35, '18.0000', 20, 0),
(10821, 51, '53.0000', 6, 0),
(10822, 62, '49.3000', 3, 0),
(10822, 70, '15.0000', 6, 0),
(10823, 11, '21.0000', 20, 0),
(10823, 57, '19.5000', 15, 0),
(10823, 59, '55.0000', 40, 0),
(10823, 77, '13.0000', 15, 0),
(10824, 41, '9.6500', 12, 0),
(10824, 70, '15.0000', 9, 0),
(10825, 26, '31.2300', 12, 0),
(10825, 53, '32.8000', 20, 0),
(10826, 31, '12.5000', 35, 0),
(10826, 57, '19.5000', 15, 0),
(10827, 10, '31.0000', 15, 0),
(10827, 39, '18.0000', 21, 0),
(10828, 20, '81.0000', 5, 0),
(10828, 38, '263.5000', 2, 0),
(10829, 2, '19.0000', 10, 0),
(10829, 8, '40.0000', 20, 0),
(10829, 13, '6.0000', 10, 0),
(10829, 60, '34.0000', 21, 0),
(10830, 6, '25.0000', 6, 0),
(10830, 39, '18.0000', 28, 0),
(10830, 60, '34.0000', 30, 0),
(10830, 68, '12.5000', 24, 0),
(10831, 19, '9.2000', 2, 0),
(10831, 35, '18.0000', 8, 0),
(10831, 38, '263.5000', 8, 0),
(10831, 43, '46.0000', 9, 0),
(10832, 13, '6.0000', 3, 0),
(10832, 25, '14.0000', 10, 0),
(10832, 44, '19.4500', 16, 0),
(10832, 64, '33.2500', 3, 0),
(10833, 7, '30.0000', 20, 0),
(10833, 31, '12.5000', 9, 0),
(10833, 53, '32.8000', 9, 0),
(10834, 29, '123.7900', 8, 0),
(10834, 30, '25.8900', 20, 0),
(10835, 59, '55.0000', 15, 0),
(10835, 77, '13.0000', 2, 0),
(10836, 22, '21.0000', 52, 0),
(10836, 35, '18.0000', 6, 0),
(10836, 57, '19.5000', 24, 0),
(10836, 60, '34.0000', 60, 0),
(10836, 64, '33.2500', 30, 0),
(10837, 13, '6.0000', 6, 0),
(10837, 40, '18.4000', 25, 0),
(10837, 47, '9.5000', 40, 0),
(10837, 76, '18.0000', 21, 0),
(10838, 1, '18.0000', 4, 0),
(10838, 18, '62.5000', 25, 0),
(10838, 36, '19.0000', 50, 0),
(10839, 58, '13.2500', 30, 0),
(10839, 72, '34.8000', 15, 0),
(10840, 25, '14.0000', 6, 0),
(10840, 39, '18.0000', 10, 0),
(10841, 10, '31.0000', 16, 0),
(10841, 56, '38.0000', 30, 0),
(10841, 59, '55.0000', 50, 0),
(10841, 77, '13.0000', 15, 0),
(10842, 11, '21.0000', 15, 0),
(10842, 43, '46.0000', 5, 0),
(10842, 68, '12.5000', 20, 0),
(10842, 70, '15.0000', 12, 0),
(10843, 51, '53.0000', 4, 0),
(10844, 22, '21.0000', 35, 0),
(10845, 23, '9.0000', 70, 0),
(10845, 35, '18.0000', 25, 0),
(10845, 42, '14.0000', 42, 0),
(10845, 58, '13.2500', 60, 0),
(10845, 64, '33.2500', 48, 0),
(10846, 4, '22.0000', 21, 0),
(10846, 70, '15.0000', 30, 0),
(10846, 74, '10.0000', 20, 0),
(10847, 1, '18.0000', 80, 0),
(10847, 19, '9.2000', 12, 0),
(10847, 37, '26.0000', 60, 0),
(10847, 45, '9.5000', 36, 0),
(10847, 60, '34.0000', 45, 0),
(10847, 71, '21.5000', 55, 0),
(10848, 5, '21.3500', 30, 0),
(10848, 9, '97.0000', 3, 0),
(10849, 3, '10.0000', 49, 0),
(10849, 26, '31.2300', 18, 0),
(10850, 25, '14.0000', 20, 0),
(10850, 33, '2.5000', 4, 0),
(10850, 70, '15.0000', 30, 0),
(10851, 2, '19.0000', 5, 0),
(10851, 25, '14.0000', 10, 0),
(10851, 57, '19.5000', 10, 0),
(10851, 59, '55.0000', 42, 0),
(10852, 2, '19.0000', 15, 0),
(10852, 17, '39.0000', 6, 0),
(10852, 62, '49.3000', 50, 0),
(10853, 18, '62.5000', 10, 0),
(10854, 10, '31.0000', 100, 0),
(10854, 13, '6.0000', 65, 0),
(10855, 16, '17.4500', 50, 0),
(10855, 31, '12.5000', 14, 0),
(10855, 56, '38.0000', 24, 0),
(10855, 65, '21.0500', 15, 0),
(10856, 2, '19.0000', 20, 0),
(10856, 42, '14.0000', 20, 0),
(10857, 3, '10.0000', 30, 0),
(10857, 26, '31.2300', 35, 0),
(10857, 29, '123.7900', 10, 0),
(10858, 7, '30.0000', 5, 0),
(10858, 27, '43.9000', 10, 0),
(10858, 70, '15.0000', 4, 0),
(10859, 24, '4.5000', 40, 0),
(10859, 54, '7.4500', 35, 0),
(10859, 64, '33.2500', 30, 0),
(10860, 51, '53.0000', 3, 0),
(10860, 76, '18.0000', 20, 0),
(10861, 17, '39.0000', 42, 0),
(10861, 18, '62.5000', 20, 0),
(10861, 21, '10.0000', 40, 0),
(10861, 33, '2.5000', 35, 0),
(10861, 62, '49.3000', 3, 0),
(10862, 11, '21.0000', 25, 0),
(10862, 52, '7.0000', 8, 0),
(10863, 1, '18.0000', 20, 0),
(10863, 58, '13.2500', 12, 0),
(10864, 35, '18.0000', 4, 0),
(10864, 67, '14.0000', 15, 0),
(10865, 38, '263.5000', 60, 0),
(10865, 39, '18.0000', 80, 0),
(10866, 2, '19.0000', 21, 0),
(10866, 24, '4.5000', 6, 0),
(10866, 30, '25.8900', 40, 0),
(10867, 53, '32.8000', 3, 0),
(10868, 26, '31.2300', 20, 0),
(10868, 35, '18.0000', 30, 0),
(10868, 49, '20.0000', 42, 0),
(10869, 1, '18.0000', 40, 0),
(10869, 11, '21.0000', 10, 0),
(10869, 23, '9.0000', 50, 0),
(10869, 68, '12.5000', 20, 0),
(10870, 35, '18.0000', 3, 0),
(10870, 51, '53.0000', 2, 0),
(10871, 6, '25.0000', 50, 0),
(10871, 16, '17.4500', 12, 0),
(10871, 17, '39.0000', 16, 0),
(10872, 55, '24.0000', 10, 0),
(10872, 62, '49.3000', 20, 0),
(10872, 64, '33.2500', 15, 0),
(10872, 65, '21.0500', 21, 0),
(10873, 21, '10.0000', 20, 0),
(10873, 28, '45.6000', 3, 0),
(10874, 10, '31.0000', 10, 0),
(10875, 19, '9.2000', 25, 0),
(10875, 47, '9.5000', 21, 0),
(10875, 49, '20.0000', 15, 0),
(10876, 46, '12.0000', 21, 0),
(10876, 64, '33.2500', 20, 0),
(10877, 16, '17.4500', 30, 0),
(10877, 18, '62.5000', 25, 0),
(10878, 20, '81.0000', 20, 0),
(10879, 40, '18.4000', 12, 0),
(10879, 65, '21.0500', 10, 0),
(10879, 76, '18.0000', 10, 0),
(10880, 23, '9.0000', 30, 0),
(10880, 61, '28.5000', 30, 0),
(10880, 70, '15.0000', 50, 0),
(10881, 73, '15.0000', 10, 0),
(10882, 42, '14.0000', 25, 0),
(10882, 49, '20.0000', 20, 0),
(10882, 54, '7.4500', 32, 0),
(10883, 24, '4.5000', 8, 0),
(10884, 21, '10.0000', 40, 0),
(10884, 56, '38.0000', 21, 0),
(10884, 65, '21.0500', 12, 0),
(10885, 2, '19.0000', 20, 0),
(10885, 24, '4.5000', 12, 0),
(10885, 70, '15.0000', 30, 0),
(10885, 77, '13.0000', 25, 0),
(10886, 10, '31.0000', 70, 0),
(10886, 31, '12.5000', 35, 0),
(10886, 77, '13.0000', 40, 0),
(10887, 25, '14.0000', 5, 0),
(10888, 2, '19.0000', 20, 0),
(10888, 68, '12.5000', 18, 0),
(10889, 11, '21.0000', 40, 0),
(10889, 38, '263.5000', 40, 0),
(10890, 17, '39.0000', 15, 0),
(10890, 34, '14.0000', 10, 0),
(10890, 41, '9.6500', 14, 0),
(10891, 30, '25.8900', 15, 0),
(10892, 59, '55.0000', 40, 0),
(10893, 8, '40.0000', 30, 0),
(10893, 24, '4.5000', 10, 0),
(10893, 29, '123.7900', 24, 0),
(10893, 30, '25.8900', 35, 0),
(10893, 36, '19.0000', 20, 0),
(10894, 13, '6.0000', 28, 0),
(10894, 69, '36.0000', 50, 0),
(10894, 75, '7.7500', 120, 0),
(10895, 24, '4.5000', 110, 0),
(10895, 39, '18.0000', 45, 0),
(10895, 40, '18.4000', 91, 0),
(10895, 60, '34.0000', 100, 0),
(10896, 45, '9.5000', 15, 0),
(10896, 56, '38.0000', 16, 0),
(10897, 29, '123.7900', 80, 0),
(10897, 30, '25.8900', 36, 0),
(10898, 13, '6.0000', 5, 0),
(10899, 39, '18.0000', 8, 0),
(10900, 70, '15.0000', 3, 0),
(10901, 41, '9.6500', 30, 0),
(10901, 71, '21.5000', 30, 0),
(10902, 55, '24.0000', 30, 0),
(10902, 62, '49.3000', 6, 0),
(10903, 13, '6.0000', 40, 0),
(10903, 65, '21.0500', 21, 0),
(10903, 68, '12.5000', 20, 0),
(10904, 58, '13.2500', 15, 0),
(10904, 62, '49.3000', 35, 0),
(10905, 1, '18.0000', 20, 0),
(10906, 61, '28.5000', 15, 0),
(10907, 75, '7.7500', 14, 0),
(10908, 7, '30.0000', 20, 0),
(10908, 52, '7.0000', 14, 0),
(10909, 7, '30.0000', 12, 0),
(10909, 16, '17.4500', 15, 0),
(10909, 41, '9.6500', 5, 0),
(10910, 19, '9.2000', 12, 0),
(10910, 49, '20.0000', 10, 0),
(10910, 61, '28.5000', 5, 0),
(10911, 1, '18.0000', 10, 0),
(10911, 17, '39.0000', 12, 0),
(10911, 67, '14.0000', 15, 0),
(10912, 11, '21.0000', 40, 0),
(10912, 29, '123.7900', 60, 0),
(10913, 4, '22.0000', 30, 0),
(10913, 33, '2.5000', 40, 0),
(10913, 58, '13.2500', 15, 0),
(10914, 71, '21.5000', 25, 0),
(10915, 17, '39.0000', 10, 0),
(10915, 33, '2.5000', 30, 0),
(10915, 54, '7.4500', 10, 0),
(10916, 16, '17.4500', 6, 0),
(10916, 32, '32.0000', 6, 0),
(10916, 57, '19.5000', 20, 0),
(10917, 30, '25.8900', 1, 0),
(10917, 60, '34.0000', 10, 0),
(10918, 1, '18.0000', 60, 0),
(10918, 60, '34.0000', 25, 0),
(10919, 16, '17.4500', 24, 0),
(10919, 25, '14.0000', 24, 0),
(10919, 40, '18.4000', 20, 0);
INSERT INTO `orderdetails` (`OrderID`, `ProductID`, `UnitPrice`, `Quantity`, `Discount`) VALUES
(10920, 50, '16.2500', 24, 0),
(10921, 35, '18.0000', 10, 0),
(10921, 63, '43.9000', 40, 0),
(10922, 17, '39.0000', 15, 0),
(10922, 24, '4.5000', 35, 0),
(10923, 42, '14.0000', 10, 0),
(10923, 43, '46.0000', 10, 0),
(10923, 67, '14.0000', 24, 0),
(10924, 10, '31.0000', 20, 0),
(10924, 28, '45.6000', 30, 0),
(10924, 75, '7.7500', 6, 0),
(10925, 36, '19.0000', 25, 0),
(10925, 52, '7.0000', 12, 0),
(10926, 11, '21.0000', 2, 0),
(10926, 13, '6.0000', 10, 0),
(10926, 19, '9.2000', 7, 0),
(10926, 72, '34.8000', 10, 0),
(10927, 20, '81.0000', 5, 0),
(10927, 52, '7.0000', 5, 0),
(10927, 76, '18.0000', 20, 0),
(10928, 47, '9.5000', 5, 0),
(10928, 76, '18.0000', 5, 0),
(10929, 21, '10.0000', 60, 0),
(10929, 75, '7.7500', 49, 0),
(10929, 77, '13.0000', 15, 0),
(10930, 21, '10.0000', 36, 0),
(10930, 27, '43.9000', 25, 0),
(10930, 55, '24.0000', 25, 0),
(10930, 58, '13.2500', 30, 0),
(10931, 13, '6.0000', 42, 0),
(10931, 57, '19.5000', 30, 0),
(10932, 16, '17.4500', 30, 0),
(10932, 62, '49.3000', 14, 0),
(10932, 72, '34.8000', 16, 0),
(10932, 75, '7.7500', 20, 0),
(10933, 53, '32.8000', 2, 0),
(10933, 61, '28.5000', 30, 0),
(10934, 6, '25.0000', 20, 0),
(10935, 1, '18.0000', 21, 0),
(10935, 18, '62.5000', 4, 0),
(10935, 23, '9.0000', 8, 0),
(10936, 36, '19.0000', 30, 0),
(10937, 28, '45.6000', 8, 0),
(10937, 34, '14.0000', 20, 0),
(10938, 13, '6.0000', 20, 0),
(10938, 43, '46.0000', 24, 0),
(10938, 60, '34.0000', 49, 0),
(10938, 71, '21.5000', 35, 0),
(10939, 2, '19.0000', 10, 0),
(10939, 67, '14.0000', 40, 0),
(10940, 7, '30.0000', 8, 0),
(10940, 13, '6.0000', 20, 0),
(10941, 31, '12.5000', 44, 0),
(10941, 62, '49.3000', 30, 0),
(10941, 68, '12.5000', 80, 0),
(10941, 72, '34.8000', 50, 0),
(10942, 49, '20.0000', 28, 0),
(10943, 13, '6.0000', 15, 0),
(10943, 22, '21.0000', 21, 0),
(10943, 46, '12.0000', 15, 0),
(10944, 11, '21.0000', 5, 0),
(10944, 44, '19.4500', 18, 0),
(10944, 56, '38.0000', 18, 0),
(10945, 13, '6.0000', 20, 0),
(10945, 31, '12.5000', 10, 0),
(10946, 10, '31.0000', 25, 0),
(10946, 24, '4.5000', 25, 0),
(10946, 77, '13.0000', 40, 0),
(10947, 59, '55.0000', 4, 0),
(10948, 50, '16.2500', 9, 0),
(10948, 51, '53.0000', 40, 0),
(10948, 55, '24.0000', 4, 0),
(10949, 6, '25.0000', 12, 0),
(10949, 10, '31.0000', 30, 0),
(10949, 17, '39.0000', 6, 0),
(10949, 62, '49.3000', 60, 0),
(10950, 4, '22.0000', 5, 0),
(10951, 33, '2.5000', 15, 0),
(10951, 41, '9.6500', 6, 0),
(10951, 75, '7.7500', 50, 0),
(10952, 6, '25.0000', 16, 0),
(10952, 28, '45.6000', 2, 0),
(10953, 20, '81.0000', 50, 0),
(10953, 31, '12.5000', 50, 0),
(10954, 16, '17.4500', 28, 0),
(10954, 31, '12.5000', 25, 0),
(10954, 45, '9.5000', 30, 0),
(10954, 60, '34.0000', 24, 0),
(10955, 75, '7.7500', 12, 0),
(10956, 21, '10.0000', 12, 0),
(10956, 47, '9.5000', 14, 0),
(10956, 51, '53.0000', 8, 0),
(10957, 30, '25.8900', 30, 0),
(10957, 35, '18.0000', 40, 0),
(10957, 64, '33.2500', 8, 0),
(10958, 5, '21.3500', 20, 0),
(10958, 7, '30.0000', 6, 0),
(10958, 72, '34.8000', 5, 0),
(10959, 75, '7.7500', 20, 0),
(10960, 24, '4.5000', 10, 0),
(10960, 41, '9.6500', 24, 0),
(10961, 52, '7.0000', 6, 0),
(10961, 76, '18.0000', 60, 0),
(10962, 7, '30.0000', 45, 0),
(10962, 13, '6.0000', 77, 0),
(10962, 53, '32.8000', 20, 0),
(10962, 69, '36.0000', 9, 0),
(10962, 76, '18.0000', 44, 0),
(10963, 60, '34.0000', 2, 0),
(10964, 18, '62.5000', 6, 0),
(10964, 38, '263.5000', 5, 0),
(10964, 69, '36.0000', 10, 0),
(10965, 51, '53.0000', 16, 0),
(10966, 37, '26.0000', 8, 0),
(10966, 56, '38.0000', 12, 0),
(10966, 62, '49.3000', 12, 0),
(10967, 19, '9.2000', 12, 0),
(10967, 49, '20.0000', 40, 0),
(10968, 12, '38.0000', 30, 0),
(10968, 24, '4.5000', 30, 0),
(10968, 64, '33.2500', 4, 0),
(10969, 46, '12.0000', 9, 0),
(10970, 52, '7.0000', 40, 0),
(10971, 29, '123.7900', 14, 0),
(10972, 17, '39.0000', 6, 0),
(10972, 33, '2.5000', 7, 0),
(10973, 26, '31.2300', 5, 0),
(10973, 41, '9.6500', 6, 0),
(10973, 75, '7.7500', 10, 0),
(10974, 63, '43.9000', 10, 0),
(10975, 8, '40.0000', 16, 0),
(10975, 75, '7.7500', 10, 0),
(10976, 28, '45.6000', 20, 0),
(10977, 39, '18.0000', 30, 0),
(10977, 47, '9.5000', 30, 0),
(10977, 51, '53.0000', 10, 0),
(10977, 63, '43.9000', 20, 0),
(10978, 8, '40.0000', 20, 0),
(10978, 21, '10.0000', 40, 0),
(10978, 40, '18.4000', 10, 0),
(10978, 44, '19.4500', 6, 0),
(10979, 7, '30.0000', 18, 0),
(10979, 12, '38.0000', 20, 0),
(10979, 24, '4.5000', 80, 0),
(10979, 27, '43.9000', 30, 0),
(10979, 31, '12.5000', 24, 0),
(10979, 63, '43.9000', 35, 0),
(10980, 75, '7.7500', 40, 0),
(10981, 38, '263.5000', 60, 0),
(10982, 7, '30.0000', 20, 0),
(10982, 43, '46.0000', 9, 0),
(10983, 13, '6.0000', 84, 0),
(10983, 57, '19.5000', 15, 0),
(10984, 16, '17.4500', 55, 0),
(10984, 24, '4.5000', 20, 0),
(10984, 36, '19.0000', 40, 0),
(10985, 16, '17.4500', 36, 0),
(10985, 18, '62.5000', 8, 0),
(10985, 32, '32.0000', 35, 0),
(10986, 11, '21.0000', 30, 0),
(10986, 20, '81.0000', 15, 0),
(10986, 76, '18.0000', 10, 0),
(10986, 77, '13.0000', 15, 0),
(10987, 7, '30.0000', 60, 0),
(10987, 43, '46.0000', 6, 0),
(10987, 72, '34.8000', 20, 0),
(10988, 7, '30.0000', 60, 0),
(10988, 62, '49.3000', 40, 0),
(10989, 6, '25.0000', 40, 0),
(10989, 11, '21.0000', 15, 0),
(10989, 41, '9.6500', 4, 0),
(10990, 21, '10.0000', 65, 0),
(10990, 34, '14.0000', 60, 0),
(10990, 55, '24.0000', 65, 0),
(10990, 61, '28.5000', 66, 0),
(10991, 2, '19.0000', 50, 0),
(10991, 70, '15.0000', 20, 0),
(10991, 76, '18.0000', 90, 0),
(10992, 72, '34.8000', 2, 0),
(10993, 29, '123.7900', 50, 0),
(10993, 41, '9.6500', 35, 0),
(10994, 59, '55.0000', 18, 0),
(10995, 51, '53.0000', 20, 0),
(10995, 60, '34.0000', 4, 0),
(10996, 42, '14.0000', 40, 0),
(10997, 32, '32.0000', 50, 0),
(10997, 46, '12.0000', 20, 0),
(10997, 52, '7.0000', 20, 0),
(10998, 24, '4.5000', 12, 0),
(10998, 61, '28.5000', 7, 0),
(10998, 74, '10.0000', 20, 0),
(10998, 75, '7.7500', 30, 0),
(10999, 41, '9.6500', 20, 0),
(10999, 51, '53.0000', 15, 0),
(10999, 77, '13.0000', 21, 0),
(11000, 4, '22.0000', 25, 0),
(11000, 24, '4.5000', 30, 0),
(11000, 77, '13.0000', 30, 0),
(11001, 7, '30.0000', 60, 0),
(11001, 22, '21.0000', 25, 0),
(11001, 46, '12.0000', 25, 0),
(11001, 55, '24.0000', 6, 0),
(11002, 13, '6.0000', 56, 0),
(11002, 35, '18.0000', 15, 0),
(11002, 42, '14.0000', 24, 0),
(11002, 55, '24.0000', 40, 0),
(11003, 1, '18.0000', 4, 0),
(11003, 40, '18.4000', 10, 0),
(11003, 52, '7.0000', 10, 0),
(11004, 26, '31.2300', 6, 0),
(11004, 76, '18.0000', 6, 0),
(11005, 1, '18.0000', 2, 0),
(11005, 59, '55.0000', 10, 0),
(11006, 1, '18.0000', 8, 0),
(11006, 29, '123.7900', 2, 0),
(11007, 8, '40.0000', 30, 0),
(11007, 29, '123.7900', 10, 0),
(11007, 42, '14.0000', 14, 0),
(11008, 28, '45.6000', 70, 0),
(11008, 34, '14.0000', 90, 0),
(11008, 71, '21.5000', 21, 0),
(11009, 24, '4.5000', 12, 0),
(11009, 36, '19.0000', 18, 0),
(11009, 60, '34.0000', 9, 0),
(11010, 7, '30.0000', 20, 0),
(11010, 24, '4.5000', 10, 0),
(11011, 58, '13.2500', 40, 0),
(11011, 71, '21.5000', 20, 0),
(11012, 19, '9.2000', 50, 0),
(11012, 60, '34.0000', 36, 0),
(11012, 71, '21.5000', 60, 0),
(11013, 23, '9.0000', 10, 0),
(11013, 42, '14.0000', 4, 0),
(11013, 45, '9.5000', 20, 0),
(11013, 68, '12.5000', 2, 0),
(11014, 41, '9.6500', 28, 0),
(11015, 30, '25.8900', 15, 0),
(11015, 77, '13.0000', 18, 0),
(11016, 31, '12.5000', 15, 0),
(11016, 36, '19.0000', 16, 0),
(11017, 3, '10.0000', 25, 0),
(11017, 59, '55.0000', 110, 0),
(11017, 70, '15.0000', 30, 0),
(11018, 12, '38.0000', 20, 0),
(11018, 18, '62.5000', 10, 0),
(11018, 56, '38.0000', 5, 0),
(11019, 46, '12.0000', 3, 0),
(11019, 49, '20.0000', 2, 0),
(11020, 10, '31.0000', 24, 0),
(11021, 2, '19.0000', 11, 0),
(11021, 20, '81.0000', 15, 0),
(11021, 26, '31.2300', 63, 0),
(11021, 51, '53.0000', 44, 0),
(11021, 72, '34.8000', 35, 0),
(11022, 19, '9.2000', 35, 0),
(11022, 69, '36.0000', 30, 0),
(11023, 7, '30.0000', 4, 0),
(11023, 43, '46.0000', 30, 0),
(11024, 26, '31.2300', 12, 0),
(11024, 33, '2.5000', 30, 0),
(11024, 65, '21.0500', 21, 0),
(11024, 71, '21.5000', 50, 0),
(11025, 1, '18.0000', 10, 0),
(11025, 13, '6.0000', 20, 0),
(11026, 18, '62.5000', 8, 0),
(11026, 51, '53.0000', 10, 0),
(11027, 24, '4.5000', 30, 0),
(11027, 62, '49.3000', 21, 0),
(11028, 55, '24.0000', 35, 0),
(11028, 59, '55.0000', 24, 0),
(11029, 56, '38.0000', 20, 0),
(11029, 63, '43.9000', 12, 0),
(11030, 2, '19.0000', 100, 0),
(11030, 5, '21.3500', 70, 0),
(11030, 29, '123.7900', 60, 0),
(11030, 59, '55.0000', 100, 0),
(11031, 1, '18.0000', 45, 0),
(11031, 13, '6.0000', 80, 0),
(11031, 24, '4.5000', 21, 0),
(11031, 64, '33.2500', 20, 0),
(11031, 71, '21.5000', 16, 0),
(11032, 36, '19.0000', 35, 0),
(11032, 38, '263.5000', 25, 0),
(11032, 59, '55.0000', 30, 0),
(11033, 53, '32.8000', 70, 0),
(11033, 69, '36.0000', 36, 0),
(11034, 21, '10.0000', 15, 0),
(11034, 44, '19.4500', 12, 0),
(11034, 61, '28.5000', 6, 0),
(11035, 1, '18.0000', 10, 0),
(11035, 35, '18.0000', 60, 0),
(11035, 42, '14.0000', 30, 0),
(11035, 54, '7.4500', 10, 0),
(11036, 13, '6.0000', 7, 0),
(11036, 59, '55.0000', 30, 0),
(11037, 70, '15.0000', 4, 0),
(11038, 40, '18.4000', 5, 0),
(11038, 52, '7.0000', 2, 0),
(11038, 71, '21.5000', 30, 0),
(11039, 28, '45.6000', 20, 0),
(11039, 35, '18.0000', 24, 0),
(11039, 49, '20.0000', 60, 0),
(11039, 57, '19.5000', 28, 0),
(11040, 21, '10.0000', 20, 0),
(11041, 2, '19.0000', 30, 0),
(11041, 63, '43.9000', 30, 0),
(11042, 44, '19.4500', 15, 0),
(11042, 61, '28.5000', 4, 0),
(11043, 11, '21.0000', 10, 0),
(11044, 62, '49.3000', 12, 0),
(11045, 33, '2.5000', 15, 0),
(11045, 51, '53.0000', 24, 0),
(11046, 12, '38.0000', 20, 0),
(11046, 32, '32.0000', 15, 0),
(11046, 35, '18.0000', 18, 0),
(11047, 1, '18.0000', 25, 0),
(11047, 5, '21.3500', 30, 0),
(11048, 68, '12.5000', 42, 0),
(11049, 2, '19.0000', 10, 0),
(11049, 12, '38.0000', 4, 0),
(11050, 76, '18.0000', 50, 0),
(11051, 24, '4.5000', 10, 0),
(11052, 43, '46.0000', 30, 0),
(11052, 61, '28.5000', 10, 0),
(11053, 18, '62.5000', 35, 0),
(11053, 32, '32.0000', 20, 0),
(11053, 64, '33.2500', 25, 0),
(11054, 33, '2.5000', 10, 0),
(11054, 67, '14.0000', 20, 0),
(11055, 24, '4.5000', 15, 0),
(11055, 25, '14.0000', 15, 0),
(11055, 51, '53.0000', 20, 0),
(11055, 57, '19.5000', 20, 0),
(11056, 7, '30.0000', 40, 0),
(11056, 55, '24.0000', 35, 0),
(11056, 60, '34.0000', 50, 0),
(11057, 70, '15.0000', 3, 0),
(11058, 21, '10.0000', 3, 0),
(11058, 60, '34.0000', 21, 0),
(11058, 61, '28.5000', 4, 0),
(11059, 13, '6.0000', 30, 0),
(11059, 17, '39.0000', 12, 0),
(11059, 60, '34.0000', 35, 0),
(11060, 60, '34.0000', 4, 0),
(11060, 77, '13.0000', 10, 0),
(11061, 60, '34.0000', 15, 0),
(11062, 53, '32.8000', 10, 0),
(11062, 70, '15.0000', 12, 0),
(11063, 34, '14.0000', 30, 0),
(11063, 40, '18.4000', 40, 0),
(11063, 41, '9.6500', 30, 0),
(11064, 17, '39.0000', 77, 0),
(11064, 41, '9.6500', 12, 0),
(11064, 53, '32.8000', 25, 0),
(11064, 55, '24.0000', 4, 0),
(11064, 68, '12.5000', 55, 0),
(11065, 30, '25.8900', 4, 0),
(11065, 54, '7.4500', 20, 0),
(11066, 16, '17.4500', 3, 0),
(11066, 19, '9.2000', 42, 0),
(11066, 34, '14.0000', 35, 0),
(11067, 41, '9.6500', 9, 0),
(11068, 28, '45.6000', 8, 0),
(11068, 43, '46.0000', 36, 0),
(11068, 77, '13.0000', 28, 0),
(11069, 39, '18.0000', 20, 0),
(11070, 1, '18.0000', 40, 0),
(11070, 2, '19.0000', 20, 0),
(11070, 16, '17.4500', 30, 0),
(11070, 31, '12.5000', 20, 0),
(11071, 7, '30.0000', 15, 0),
(11071, 13, '6.0000', 10, 0),
(11072, 2, '19.0000', 8, 0),
(11072, 41, '9.6500', 40, 0),
(11072, 50, '16.2500', 22, 0),
(11072, 64, '33.2500', 130, 0),
(11073, 11, '21.0000', 10, 0),
(11073, 24, '4.5000', 20, 0),
(11074, 16, '17.4500', 14, 0),
(11075, 2, '19.0000', 10, 0),
(11075, 46, '12.0000', 30, 0),
(11075, 76, '18.0000', 2, 0),
(11076, 6, '25.0000', 20, 0),
(11076, 14, '23.2500', 20, 0),
(11076, 19, '9.2000', 10, 0),
(11077, 2, '19.0000', 24, 0),
(11077, 3, '10.0000', 4, 0),
(11077, 4, '22.0000', 1, 0),
(11077, 6, '25.0000', 1, 0),
(11077, 7, '30.0000', 1, 0),
(11077, 8, '40.0000', 2, 0),
(11077, 10, '31.0000', 1, 0),
(11077, 12, '38.0000', 2, 0),
(11077, 13, '6.0000', 4, 0),
(11077, 14, '23.2500', 1, 0),
(11077, 16, '17.4500', 2, 0),
(11077, 20, '81.0000', 1, 0),
(11077, 23, '9.0000', 2, 0),
(11077, 32, '32.0000', 1, 0),
(11077, 39, '18.0000', 2, 0),
(11077, 41, '9.6500', 3, 0),
(11077, 46, '12.0000', 3, 0),
(11077, 52, '7.0000', 2, 0),
(11077, 55, '24.0000', 2, 0),
(11077, 60, '34.0000', 2, 0),
(11077, 64, '33.2500', 2, 0),
(11077, 66, '17.0000', 1, 0),
(11077, 73, '15.0000', 2, 0),
(11077, 75, '7.7500', 4, 0),
(11077, 77, '13.0000', 2, 0);

-- --------------------------------------------------------

--
-- 資料表結構 `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `CustomerID` varchar(5) DEFAULT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `OrderDate` datetime DEFAULT NULL,
  `RequiredDate` datetime DEFAULT NULL,
  `ShippedDate` datetime DEFAULT NULL,
  `ShipVia` int(11) DEFAULT NULL,
  `Freight` decimal(10,4) DEFAULT '0.0000',
  `ShipName` varchar(40) DEFAULT NULL,
  `ShipAddress` varchar(60) DEFAULT NULL,
  `ShipCity` varchar(15) DEFAULT NULL,
  `ShipRegion` varchar(15) DEFAULT NULL,
  `ShipPostalCode` varchar(10) DEFAULT NULL,
  `ShipCountry` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `orders`
--

INSERT INTO `orders` (`OrderID`, `CustomerID`, `EmployeeID`, `OrderDate`, `RequiredDate`, `ShippedDate`, `ShipVia`, `Freight`, `ShipName`, `ShipAddress`, `ShipCity`, `ShipRegion`, `ShipPostalCode`, `ShipCountry`) VALUES
(10248, 'VINET', 5, '1996-07-04 00:00:00', '1996-08-01 00:00:00', '1996-07-16 00:00:00', 3, '32.3800', 'Vins et alcools Chevalier', '59 rue de l-Abbaye', 'Reims', NULL, '51100', 'France'),
(10249, 'TOMSP', 6, '1996-07-05 00:00:00', '1996-08-16 00:00:00', '1996-07-10 00:00:00', 1, '11.6100', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10250, 'HANAR', 4, '1996-07-08 00:00:00', '1996-08-05 00:00:00', '1996-07-12 00:00:00', 2, '65.8300', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10251, 'VICTE', 3, '1996-07-08 00:00:00', '1996-08-05 00:00:00', '1996-07-15 00:00:00', 1, '41.3400', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10252, 'SUPRD', 4, '1996-07-09 00:00:00', '1996-08-06 00:00:00', '1996-07-11 00:00:00', 2, '51.3000', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10253, 'HANAR', 3, '1996-07-10 00:00:00', '1996-07-24 00:00:00', '1996-07-16 00:00:00', 2, '58.1700', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10254, 'CHOPS', 5, '1996-07-11 00:00:00', '1996-08-08 00:00:00', '1996-07-23 00:00:00', 2, '22.9800', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10255, 'RICSU', 9, '1996-07-12 00:00:00', '1996-08-09 00:00:00', '1996-07-15 00:00:00', 3, '148.3300', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10256, 'WELLI', 3, '1996-07-15 00:00:00', '1996-08-12 00:00:00', '1996-07-17 00:00:00', 2, '13.9700', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10257, 'HILAA', 4, '1996-07-16 00:00:00', '1996-08-13 00:00:00', '1996-07-22 00:00:00', 3, '81.9100', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10258, 'ERNSH', 1, '1996-07-17 00:00:00', '1996-08-14 00:00:00', '1996-07-23 00:00:00', 1, '140.5100', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10259, 'CENTC', 4, '1996-07-18 00:00:00', '1996-08-15 00:00:00', '1996-07-25 00:00:00', 3, '3.2500', 'Centro comercial Moctezuma', 'Sierras de Granada 9993', 'Mxico D.F.', NULL, '5022', 'Mexico'),
(10260, 'OTTIK', 4, '1996-07-19 00:00:00', '1996-08-16 00:00:00', '1996-07-29 00:00:00', 1, '55.0900', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10261, 'QUEDE', 4, '1996-07-19 00:00:00', '1996-08-16 00:00:00', '1996-07-30 00:00:00', 2, '3.0500', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10262, 'RATTC', 8, '1996-07-22 00:00:00', '1996-08-19 00:00:00', '1996-07-25 00:00:00', 3, '48.2900', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10263, 'ERNSH', 9, '1996-07-23 00:00:00', '1996-08-20 00:00:00', '1996-07-31 00:00:00', 3, '146.0600', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10264, 'FOLKO', 6, '1996-07-24 00:00:00', '1996-08-21 00:00:00', '1996-08-23 00:00:00', 3, '3.6700', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10265, 'BLONP', 2, '1996-07-25 00:00:00', '1996-08-22 00:00:00', '1996-08-12 00:00:00', 1, '55.2800', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10266, 'WARTH', 3, '1996-07-26 00:00:00', '1996-09-06 00:00:00', '1996-07-31 00:00:00', 3, '25.7300', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10267, 'FRANK', 4, '1996-07-29 00:00:00', '1996-08-26 00:00:00', '1996-08-06 00:00:00', 1, '208.5800', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10268, 'GROSR', 8, '1996-07-30 00:00:00', '1996-08-27 00:00:00', '1996-08-02 00:00:00', 3, '66.2900', 'GROSELLA-Restaurante', '5 Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela'),
(10269, 'WHITC', 5, '1996-07-31 00:00:00', '1996-08-14 00:00:00', '1996-08-09 00:00:00', 1, '4.5600', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10270, 'WARTH', 1, '1996-08-01 00:00:00', '1996-08-29 00:00:00', '1996-08-02 00:00:00', 1, '136.5400', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10271, 'SPLIR', 6, '1996-08-01 00:00:00', '1996-08-29 00:00:00', '1996-08-30 00:00:00', 2, '4.5400', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10272, 'RATTC', 6, '1996-08-02 00:00:00', '1996-08-30 00:00:00', '1996-08-06 00:00:00', 2, '98.0300', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10273, 'QUICK', 3, '1996-08-05 00:00:00', '1996-09-02 00:00:00', '1996-08-12 00:00:00', 3, '76.0700', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10274, 'VINET', 6, '1996-08-06 00:00:00', '1996-09-03 00:00:00', '1996-08-16 00:00:00', 1, '6.0100', 'Vins et alcools Chevalier', '59 rue de l-Abbaye', 'Reims', NULL, '51100', 'France'),
(10275, 'MAGAA', 1, '1996-08-07 00:00:00', '1996-09-04 00:00:00', '1996-08-09 00:00:00', 1, '26.9300', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10276, 'TORTU', 8, '1996-08-08 00:00:00', '1996-08-22 00:00:00', '1996-08-14 00:00:00', 3, '13.8400', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10277, 'MORGK', 2, '1996-08-09 00:00:00', '1996-09-06 00:00:00', '1996-08-13 00:00:00', 3, '125.7700', 'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig', NULL, '4179', 'Germany'),
(10278, 'BERGS', 8, '1996-08-12 00:00:00', '1996-09-09 00:00:00', '1996-08-16 00:00:00', 2, '92.6900', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10279, 'LEHMS', 8, '1996-08-13 00:00:00', '1996-09-10 00:00:00', '1996-08-16 00:00:00', 2, '25.8300', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10280, 'BERGS', 2, '1996-08-14 00:00:00', '1996-09-11 00:00:00', '1996-09-12 00:00:00', 1, '8.9800', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10281, 'ROMEY', 4, '1996-08-14 00:00:00', '1996-08-28 00:00:00', '1996-08-21 00:00:00', 1, '2.9400', 'Romero y tomillo', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain'),
(10282, 'ROMEY', 4, '1996-08-15 00:00:00', '1996-09-12 00:00:00', '1996-08-21 00:00:00', 1, '12.6900', 'Romero y tomillo', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain'),
(10283, 'LILAS', 3, '1996-08-16 00:00:00', '1996-09-13 00:00:00', '1996-08-23 00:00:00', 3, '84.8100', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10284, 'LEHMS', 4, '1996-08-19 00:00:00', '1996-09-16 00:00:00', '1996-08-27 00:00:00', 1, '76.5600', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10285, 'QUICK', 1, '1996-08-20 00:00:00', '1996-09-17 00:00:00', '1996-08-26 00:00:00', 2, '76.8300', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10286, 'QUICK', 8, '1996-08-21 00:00:00', '1996-09-18 00:00:00', '1996-08-30 00:00:00', 3, '229.2400', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10287, 'RICAR', 8, '1996-08-22 00:00:00', '1996-09-19 00:00:00', '1996-08-28 00:00:00', 3, '12.7600', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10288, 'REGGC', 4, '1996-08-23 00:00:00', '1996-09-20 00:00:00', '1996-09-03 00:00:00', 1, '7.4500', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10289, 'BSBEV', 7, '1996-08-26 00:00:00', '1996-09-23 00:00:00', '1996-08-28 00:00:00', 3, '22.7700', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10290, 'COMMI', 8, '1996-08-27 00:00:00', '1996-09-24 00:00:00', '1996-09-03 00:00:00', 1, '79.7000', 'Comrcio Mineiro', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'),
(10291, 'QUEDE', 6, '1996-08-27 00:00:00', '1996-09-24 00:00:00', '1996-09-04 00:00:00', 2, '6.4000', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10292, 'TRADH', 1, '1996-08-28 00:00:00', '1996-09-25 00:00:00', '1996-09-02 00:00:00', 2, '1.3500', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10293, 'TORTU', 1, '1996-08-29 00:00:00', '1996-09-26 00:00:00', '1996-09-11 00:00:00', 3, '21.1800', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10294, 'RATTC', 4, '1996-08-30 00:00:00', '1996-09-27 00:00:00', '1996-09-05 00:00:00', 2, '147.2600', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10295, 'VINET', 2, '1996-09-02 00:00:00', '1996-09-30 00:00:00', '1996-09-10 00:00:00', 2, '1.1500', 'Vins et alcools Chevalier', '59 rue de l-Abbaye', 'Reims', NULL, '51100', 'France'),
(10296, 'LILAS', 6, '1996-09-03 00:00:00', '1996-10-01 00:00:00', '1996-09-11 00:00:00', 1, '0.1200', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10297, 'BLONP', 5, '1996-09-04 00:00:00', '1996-10-16 00:00:00', '1996-09-10 00:00:00', 2, '5.7400', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10298, 'HUNGO', 6, '1996-09-05 00:00:00', '1996-10-03 00:00:00', '1996-09-11 00:00:00', 2, '168.2200', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10299, 'RICAR', 4, '1996-09-06 00:00:00', '1996-10-04 00:00:00', '1996-09-13 00:00:00', 2, '29.7600', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10300, 'MAGAA', 2, '1996-09-09 00:00:00', '1996-10-07 00:00:00', '1996-09-18 00:00:00', 2, '17.6800', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10301, 'WANDK', 8, '1996-09-09 00:00:00', '1996-10-07 00:00:00', '1996-09-17 00:00:00', 2, '45.0800', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10302, 'SUPRD', 4, '1996-09-10 00:00:00', '1996-10-08 00:00:00', '1996-10-09 00:00:00', 2, '6.2700', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10303, 'GODOS', 7, '1996-09-11 00:00:00', '1996-10-09 00:00:00', '1996-09-18 00:00:00', 2, '107.8300', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10304, 'TORTU', 1, '1996-09-12 00:00:00', '1996-10-10 00:00:00', '1996-09-17 00:00:00', 2, '63.7900', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10305, 'OLDWO', 8, '1996-09-13 00:00:00', '1996-10-11 00:00:00', '1996-10-09 00:00:00', 3, '257.6200', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10306, 'ROMEY', 1, '1996-09-16 00:00:00', '1996-10-14 00:00:00', '1996-09-23 00:00:00', 3, '7.5600', 'Romero y tomillo', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain'),
(10307, 'LONEP', 2, '1996-09-17 00:00:00', '1996-10-15 00:00:00', '1996-09-25 00:00:00', 2, '0.5600', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10308, 'ANATR', 7, '1996-09-18 00:00:00', '1996-10-16 00:00:00', '1996-09-24 00:00:00', 3, '1.6100', 'Ana Trujillo Emparedados y helados', 'Avda. de la Constitucin 2222', 'Mxico D.F.', NULL, '5021', 'Mexico'),
(10309, 'HUNGO', 3, '1996-09-19 00:00:00', '1996-10-17 00:00:00', '1996-10-23 00:00:00', 1, '47.3000', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10310, 'THEBI', 8, '1996-09-20 00:00:00', '1996-10-18 00:00:00', '1996-09-27 00:00:00', 2, '17.5200', 'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'),
(10311, 'DUMON', 1, '1996-09-20 00:00:00', '1996-10-04 00:00:00', '1996-09-26 00:00:00', 3, '24.6900', 'Du monde entier', '67, rue des Cinquante Otages', 'Nantes', NULL, '44000', 'France'),
(10312, 'WANDK', 2, '1996-09-23 00:00:00', '1996-10-21 00:00:00', '1996-10-03 00:00:00', 2, '40.2600', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10313, 'QUICK', 2, '1996-09-24 00:00:00', '1996-10-22 00:00:00', '1996-10-04 00:00:00', 2, '1.9600', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10314, 'RATTC', 1, '1996-09-25 00:00:00', '1996-10-23 00:00:00', '1996-10-04 00:00:00', 2, '74.1600', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10315, 'ISLAT', 4, '1996-09-26 00:00:00', '1996-10-24 00:00:00', '1996-10-03 00:00:00', 2, '41.7600', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10316, 'RATTC', 1, '1996-09-27 00:00:00', '1996-10-25 00:00:00', '1996-10-08 00:00:00', 3, '150.1500', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10317, 'LONEP', 6, '1996-09-30 00:00:00', '1996-10-28 00:00:00', '1996-10-10 00:00:00', 1, '12.6900', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10318, 'ISLAT', 8, '1996-10-01 00:00:00', '1996-10-29 00:00:00', '1996-10-04 00:00:00', 2, '4.7300', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10319, 'TORTU', 7, '1996-10-02 00:00:00', '1996-10-30 00:00:00', '1996-10-11 00:00:00', 3, '64.5000', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10320, 'WARTH', 5, '1996-10-03 00:00:00', '1996-10-17 00:00:00', '1996-10-18 00:00:00', 3, '34.5700', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10321, 'ISLAT', 3, '1996-10-03 00:00:00', '1996-10-31 00:00:00', '1996-10-11 00:00:00', 2, '3.4300', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10322, 'PERIC', 7, '1996-10-04 00:00:00', '1996-11-01 00:00:00', '1996-10-23 00:00:00', 3, '0.4000', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10323, 'KOENE', 4, '1996-10-07 00:00:00', '1996-11-04 00:00:00', '1996-10-14 00:00:00', 1, '4.8800', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10324, 'SAVEA', 9, '1996-10-08 00:00:00', '1996-11-05 00:00:00', '1996-10-10 00:00:00', 1, '214.2700', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10325, 'KOENE', 1, '1996-10-09 00:00:00', '1996-10-23 00:00:00', '1996-10-14 00:00:00', 3, '64.8600', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10326, 'BOLID', 4, '1996-10-10 00:00:00', '1996-11-07 00:00:00', '1996-10-14 00:00:00', 2, '77.9200', 'Blido Comidas preparadas', 'C/ Araquil, 67', 'Madrid', NULL, '28023', 'Spain'),
(10327, 'FOLKO', 2, '1996-10-11 00:00:00', '1996-11-08 00:00:00', '1996-10-14 00:00:00', 1, '63.3600', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10328, 'FURIB', 4, '1996-10-14 00:00:00', '1996-11-11 00:00:00', '1996-10-17 00:00:00', 3, '87.0300', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10329, 'SPLIR', 4, '1996-10-15 00:00:00', '1996-11-26 00:00:00', '1996-10-23 00:00:00', 2, '191.6700', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10330, 'LILAS', 3, '1996-10-16 00:00:00', '1996-11-13 00:00:00', '1996-10-28 00:00:00', 1, '12.7500', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10331, 'BONAP', 9, '1996-10-16 00:00:00', '1996-11-27 00:00:00', '1996-10-21 00:00:00', 1, '10.1900', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10332, 'MEREP', 3, '1996-10-17 00:00:00', '1996-11-28 00:00:00', '1996-10-21 00:00:00', 2, '52.8400', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10333, 'WARTH', 5, '1996-10-18 00:00:00', '1996-11-15 00:00:00', '1996-10-25 00:00:00', 3, '0.5900', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10334, 'VICTE', 8, '1996-10-21 00:00:00', '1996-11-18 00:00:00', '1996-10-28 00:00:00', 2, '8.5600', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10335, 'HUNGO', 7, '1996-10-22 00:00:00', '1996-11-19 00:00:00', '1996-10-24 00:00:00', 2, '42.1100', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10336, 'PRINI', 7, '1996-10-23 00:00:00', '1996-11-20 00:00:00', '1996-10-25 00:00:00', 2, '15.5100', 'Princesa Isabel Vinhos', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal'),
(10337, 'FRANK', 4, '1996-10-24 00:00:00', '1996-11-21 00:00:00', '1996-10-29 00:00:00', 3, '108.2600', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10338, 'OLDWO', 4, '1996-10-25 00:00:00', '1996-11-22 00:00:00', '1996-10-29 00:00:00', 3, '84.2100', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10339, 'MEREP', 2, '1996-10-28 00:00:00', '1996-11-25 00:00:00', '1996-11-04 00:00:00', 2, '15.6600', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10340, 'BONAP', 1, '1996-10-29 00:00:00', '1996-11-26 00:00:00', '1996-11-08 00:00:00', 3, '166.3100', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10341, 'SIMOB', 7, '1996-10-29 00:00:00', '1996-11-26 00:00:00', '1996-11-05 00:00:00', 3, '26.7800', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10342, 'FRANK', 4, '1996-10-30 00:00:00', '1996-11-13 00:00:00', '1996-11-04 00:00:00', 2, '54.8300', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10343, 'LEHMS', 4, '1996-10-31 00:00:00', '1996-11-28 00:00:00', '1996-11-06 00:00:00', 1, '110.3700', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10344, 'WHITC', 4, '1996-11-01 00:00:00', '1996-11-29 00:00:00', '1996-11-05 00:00:00', 2, '23.2900', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10345, 'QUICK', 2, '1996-11-04 00:00:00', '1996-12-02 00:00:00', '1996-11-11 00:00:00', 2, '249.0600', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10346, 'RATTC', 3, '1996-11-05 00:00:00', '1996-12-17 00:00:00', '1996-11-08 00:00:00', 3, '142.0800', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10347, 'FAMIA', 4, '1996-11-06 00:00:00', '1996-12-04 00:00:00', '1996-11-08 00:00:00', 3, '3.1000', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10348, 'WANDK', 4, '1996-11-07 00:00:00', '1996-12-05 00:00:00', '1996-11-15 00:00:00', 2, '0.7800', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10349, 'SPLIR', 7, '1996-11-08 00:00:00', '1996-12-06 00:00:00', '1996-11-15 00:00:00', 1, '8.6300', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10350, 'LAMAI', 6, '1996-11-11 00:00:00', '1996-12-09 00:00:00', '1996-12-03 00:00:00', 2, '64.1900', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10351, 'ERNSH', 1, '1996-11-11 00:00:00', '1996-12-09 00:00:00', '1996-11-20 00:00:00', 1, '162.3300', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10352, 'FURIB', 3, '1996-11-12 00:00:00', '1996-11-26 00:00:00', '1996-11-18 00:00:00', 3, '1.3000', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10353, 'PICCO', 7, '1996-11-13 00:00:00', '1996-12-11 00:00:00', '1996-11-25 00:00:00', 3, '360.6300', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10354, 'PERIC', 8, '1996-11-14 00:00:00', '1996-12-12 00:00:00', '1996-11-20 00:00:00', 3, '53.8000', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10355, 'AROUT', 6, '1996-11-15 00:00:00', '1996-12-13 00:00:00', '1996-11-20 00:00:00', 1, '41.9500', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10356, 'WANDK', 6, '1996-11-18 00:00:00', '1996-12-16 00:00:00', '1996-11-27 00:00:00', 2, '36.7100', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10357, 'LILAS', 1, '1996-11-19 00:00:00', '1996-12-17 00:00:00', '1996-12-02 00:00:00', 3, '34.8800', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10358, 'LAMAI', 5, '1996-11-20 00:00:00', '1996-12-18 00:00:00', '1996-11-27 00:00:00', 1, '19.6400', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10359, 'SEVES', 5, '1996-11-21 00:00:00', '1996-12-19 00:00:00', '1996-11-26 00:00:00', 3, '288.4300', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10360, 'BLONP', 4, '1996-11-22 00:00:00', '1996-12-20 00:00:00', '1996-12-02 00:00:00', 3, '131.7000', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10361, 'QUICK', 1, '1996-11-22 00:00:00', '1996-12-20 00:00:00', '1996-12-03 00:00:00', 2, '183.1700', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10362, 'BONAP', 3, '1996-11-25 00:00:00', '1996-12-23 00:00:00', '1996-11-28 00:00:00', 1, '96.0400', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10363, 'DRACD', 4, '1996-11-26 00:00:00', '1996-12-24 00:00:00', '1996-12-04 00:00:00', 3, '30.5400', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(10364, 'EASTC', 1, '1996-11-26 00:00:00', '1997-01-07 00:00:00', '1996-12-04 00:00:00', 1, '71.9700', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(10365, 'ANTON', 3, '1996-11-27 00:00:00', '1996-12-25 00:00:00', '1996-12-02 00:00:00', 2, '22.0000', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10366, 'GALED', 8, '1996-11-28 00:00:00', '1997-01-09 00:00:00', '1996-12-30 00:00:00', 2, '10.1400', 'Galera del gastronmo', 'Rambla de Catalua, 23', 'Barcelona', NULL, '8022', 'Spain'),
(10367, 'VAFFE', 7, '1996-11-28 00:00:00', '1996-12-26 00:00:00', '1996-12-02 00:00:00', 3, '13.5500', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10368, 'ERNSH', 2, '1996-11-29 00:00:00', '1996-12-27 00:00:00', '1996-12-02 00:00:00', 2, '101.9500', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10369, 'SPLIR', 8, '1996-12-02 00:00:00', '1996-12-30 00:00:00', '1996-12-09 00:00:00', 2, '195.6800', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10370, 'CHOPS', 6, '1996-12-03 00:00:00', '1996-12-31 00:00:00', '1996-12-27 00:00:00', 2, '1.1700', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10371, 'LAMAI', 1, '1996-12-03 00:00:00', '1996-12-31 00:00:00', '1996-12-24 00:00:00', 1, '0.4500', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10372, 'QUEEN', 5, '1996-12-04 00:00:00', '1997-01-01 00:00:00', '1996-12-09 00:00:00', 2, '890.7800', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10373, 'HUNGO', 4, '1996-12-05 00:00:00', '1997-01-02 00:00:00', '1996-12-11 00:00:00', 3, '124.1200', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10374, 'WOLZA', 1, '1996-12-05 00:00:00', '1997-01-02 00:00:00', '1996-12-09 00:00:00', 3, '3.9400', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10375, 'HUNGC', 3, '1996-12-06 00:00:00', '1997-01-03 00:00:00', '1996-12-09 00:00:00', 2, '20.1200', 'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'),
(10376, 'MEREP', 1, '1996-12-09 00:00:00', '1997-01-06 00:00:00', '1996-12-13 00:00:00', 2, '20.3900', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10377, 'SEVES', 1, '1996-12-09 00:00:00', '1997-01-06 00:00:00', '1996-12-13 00:00:00', 3, '22.2100', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10378, 'FOLKO', 5, '1996-12-10 00:00:00', '1997-01-07 00:00:00', '1996-12-19 00:00:00', 3, '5.4400', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10379, 'QUEDE', 2, '1996-12-11 00:00:00', '1997-01-08 00:00:00', '1996-12-13 00:00:00', 1, '45.0300', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10380, 'HUNGO', 8, '1996-12-12 00:00:00', '1997-01-09 00:00:00', '1997-01-16 00:00:00', 3, '35.0300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10381, 'LILAS', 3, '1996-12-12 00:00:00', '1997-01-09 00:00:00', '1996-12-13 00:00:00', 3, '7.9900', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10382, 'ERNSH', 4, '1996-12-13 00:00:00', '1997-01-10 00:00:00', '1996-12-16 00:00:00', 1, '94.7700', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10383, 'AROUT', 8, '1996-12-16 00:00:00', '1997-01-13 00:00:00', '1996-12-18 00:00:00', 3, '34.2400', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10384, 'BERGS', 3, '1996-12-16 00:00:00', '1997-01-13 00:00:00', '1996-12-20 00:00:00', 3, '168.6400', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10385, 'SPLIR', 1, '1996-12-17 00:00:00', '1997-01-14 00:00:00', '1996-12-23 00:00:00', 2, '30.9600', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10386, 'FAMIA', 9, '1996-12-18 00:00:00', '1997-01-01 00:00:00', '1996-12-25 00:00:00', 3, '13.9900', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10387, 'SANTG', 1, '1996-12-18 00:00:00', '1997-01-15 00:00:00', '1996-12-20 00:00:00', 2, '93.6300', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(10388, 'SEVES', 2, '1996-12-19 00:00:00', '1997-01-16 00:00:00', '1996-12-20 00:00:00', 1, '34.8600', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10389, 'BOTTM', 4, '1996-12-20 00:00:00', '1997-01-17 00:00:00', '1996-12-24 00:00:00', 2, '47.4200', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10390, 'ERNSH', 6, '1996-12-23 00:00:00', '1997-01-20 00:00:00', '1996-12-26 00:00:00', 1, '126.3800', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10391, 'DRACD', 3, '1996-12-23 00:00:00', '1997-01-20 00:00:00', '1996-12-31 00:00:00', 3, '5.4500', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(10392, 'PICCO', 2, '1996-12-24 00:00:00', '1997-01-21 00:00:00', '1997-01-01 00:00:00', 3, '122.4600', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10393, 'SAVEA', 1, '1996-12-25 00:00:00', '1997-01-22 00:00:00', '1997-01-03 00:00:00', 3, '126.5600', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10394, 'HUNGC', 1, '1996-12-25 00:00:00', '1997-01-22 00:00:00', '1997-01-03 00:00:00', 3, '30.3400', 'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'),
(10395, 'HILAA', 6, '1996-12-26 00:00:00', '1997-01-23 00:00:00', '1997-01-03 00:00:00', 1, '184.4100', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10396, 'FRANK', 1, '1996-12-27 00:00:00', '1997-01-10 00:00:00', '1997-01-06 00:00:00', 3, '135.3500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10397, 'PRINI', 5, '1996-12-27 00:00:00', '1997-01-24 00:00:00', '1997-01-02 00:00:00', 1, '60.2600', 'Princesa Isabel Vinhos', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal'),
(10398, 'SAVEA', 2, '1996-12-30 00:00:00', '1997-01-27 00:00:00', '1997-01-09 00:00:00', 3, '89.1600', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10399, 'VAFFE', 8, '1996-12-31 00:00:00', '1997-01-14 00:00:00', '1997-01-08 00:00:00', 3, '27.3600', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10400, 'EASTC', 1, '1997-01-01 00:00:00', '1997-01-29 00:00:00', '1997-01-16 00:00:00', 3, '83.9300', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(10401, 'RATTC', 1, '1997-01-01 00:00:00', '1997-01-29 00:00:00', '1997-01-10 00:00:00', 1, '12.5100', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10402, 'ERNSH', 8, '1997-01-02 00:00:00', '1997-02-13 00:00:00', '1997-01-10 00:00:00', 2, '67.8800', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10403, 'ERNSH', 4, '1997-01-03 00:00:00', '1997-01-31 00:00:00', '1997-01-09 00:00:00', 3, '73.7900', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10404, 'MAGAA', 2, '1997-01-03 00:00:00', '1997-01-31 00:00:00', '1997-01-08 00:00:00', 1, '155.9700', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10405, 'LINOD', 1, '1997-01-06 00:00:00', '1997-02-03 00:00:00', '1997-01-22 00:00:00', 1, '34.8200', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10406, 'QUEEN', 7, '1997-01-07 00:00:00', '1997-02-18 00:00:00', '1997-01-13 00:00:00', 1, '108.0400', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10407, 'OTTIK', 2, '1997-01-07 00:00:00', '1997-02-04 00:00:00', '1997-01-30 00:00:00', 2, '91.4800', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10408, 'FOLIG', 8, '1997-01-08 00:00:00', '1997-02-05 00:00:00', '1997-01-14 00:00:00', 1, '11.2600', 'Folies gourmandes', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France'),
(10409, 'OCEAN', 3, '1997-01-09 00:00:00', '1997-02-06 00:00:00', '1997-01-14 00:00:00', 1, '29.8300', 'Ocano Atlntico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10410, 'BOTTM', 3, '1997-01-10 00:00:00', '1997-02-07 00:00:00', '1997-01-15 00:00:00', 3, '2.4000', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10411, 'BOTTM', 9, '1997-01-10 00:00:00', '1997-02-07 00:00:00', '1997-01-21 00:00:00', 3, '23.6500', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10412, 'WARTH', 8, '1997-01-13 00:00:00', '1997-02-10 00:00:00', '1997-01-15 00:00:00', 2, '3.7700', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10413, 'LAMAI', 3, '1997-01-14 00:00:00', '1997-02-11 00:00:00', '1997-01-16 00:00:00', 2, '95.6600', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10414, 'FAMIA', 2, '1997-01-14 00:00:00', '1997-02-11 00:00:00', '1997-01-17 00:00:00', 3, '21.4800', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10415, 'HUNGC', 3, '1997-01-15 00:00:00', '1997-02-12 00:00:00', '1997-01-24 00:00:00', 1, '0.2000', 'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'),
(10416, 'WARTH', 8, '1997-01-16 00:00:00', '1997-02-13 00:00:00', '1997-01-27 00:00:00', 3, '22.7200', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10417, 'SIMOB', 4, '1997-01-16 00:00:00', '1997-02-13 00:00:00', '1997-01-28 00:00:00', 3, '70.2900', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10418, 'QUICK', 4, '1997-01-17 00:00:00', '1997-02-14 00:00:00', '1997-01-24 00:00:00', 1, '17.5500', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10419, 'RICSU', 4, '1997-01-20 00:00:00', '1997-02-17 00:00:00', '1997-01-30 00:00:00', 2, '137.3500', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10420, 'WELLI', 3, '1997-01-21 00:00:00', '1997-02-18 00:00:00', '1997-01-27 00:00:00', 1, '44.1200', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10421, 'QUEDE', 8, '1997-01-21 00:00:00', '1997-03-04 00:00:00', '1997-01-27 00:00:00', 1, '99.2300', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10422, 'FRANS', 2, '1997-01-22 00:00:00', '1997-02-19 00:00:00', '1997-01-31 00:00:00', 1, '3.0200', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(10423, 'GOURL', 6, '1997-01-23 00:00:00', '1997-02-06 00:00:00', '1997-02-24 00:00:00', 3, '24.5000', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10424, 'MEREP', 7, '1997-01-23 00:00:00', '1997-02-20 00:00:00', '1997-01-27 00:00:00', 2, '370.6100', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10425, 'LAMAI', 6, '1997-01-24 00:00:00', '1997-02-21 00:00:00', '1997-02-14 00:00:00', 2, '7.9300', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10426, 'GALED', 4, '1997-01-27 00:00:00', '1997-02-24 00:00:00', '1997-02-06 00:00:00', 1, '18.6900', 'Galera del gastronmo', 'Rambla de Catalua, 23', 'Barcelona', NULL, '8022', 'Spain'),
(10427, 'PICCO', 4, '1997-01-27 00:00:00', '1997-02-24 00:00:00', '1997-03-03 00:00:00', 2, '31.2900', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10428, 'REGGC', 7, '1997-01-28 00:00:00', '1997-02-25 00:00:00', '1997-02-04 00:00:00', 1, '11.0900', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10429, 'HUNGO', 3, '1997-01-29 00:00:00', '1997-03-12 00:00:00', '1997-02-07 00:00:00', 2, '56.6300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10430, 'ERNSH', 4, '1997-01-30 00:00:00', '1997-02-13 00:00:00', '1997-02-03 00:00:00', 1, '458.7800', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10431, 'BOTTM', 4, '1997-01-30 00:00:00', '1997-02-13 00:00:00', '1997-02-07 00:00:00', 2, '44.1700', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10432, 'SPLIR', 3, '1997-01-31 00:00:00', '1997-02-14 00:00:00', '1997-02-07 00:00:00', 2, '4.3400', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10433, 'PRINI', 3, '1997-02-03 00:00:00', '1997-03-03 00:00:00', '1997-03-04 00:00:00', 3, '73.8300', 'Princesa Isabel Vinhos', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal'),
(10434, 'FOLKO', 3, '1997-02-03 00:00:00', '1997-03-03 00:00:00', '1997-02-13 00:00:00', 2, '17.9200', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10435, 'CONSH', 8, '1997-02-04 00:00:00', '1997-03-18 00:00:00', '1997-02-07 00:00:00', 2, '9.2100', 'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London', NULL, 'WX1 6LT', 'UK'),
(10436, 'BLONP', 3, '1997-02-05 00:00:00', '1997-03-05 00:00:00', '1997-02-11 00:00:00', 2, '156.6600', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10437, 'WARTH', 8, '1997-02-05 00:00:00', '1997-03-05 00:00:00', '1997-02-12 00:00:00', 1, '19.9700', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10438, 'TOMSP', 3, '1997-02-06 00:00:00', '1997-03-06 00:00:00', '1997-02-14 00:00:00', 2, '8.2400', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10439, 'MEREP', 6, '1997-02-07 00:00:00', '1997-03-07 00:00:00', '1997-02-10 00:00:00', 3, '4.0700', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10440, 'SAVEA', 4, '1997-02-10 00:00:00', '1997-03-10 00:00:00', '1997-02-28 00:00:00', 2, '86.5300', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10441, 'OLDWO', 3, '1997-02-10 00:00:00', '1997-03-24 00:00:00', '1997-03-14 00:00:00', 2, '73.0200', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10442, 'ERNSH', 3, '1997-02-11 00:00:00', '1997-03-11 00:00:00', '1997-02-18 00:00:00', 2, '47.9400', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10443, 'REGGC', 8, '1997-02-12 00:00:00', '1997-03-12 00:00:00', '1997-02-14 00:00:00', 1, '13.9500', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10444, 'BERGS', 3, '1997-02-12 00:00:00', '1997-03-12 00:00:00', '1997-02-21 00:00:00', 3, '3.5000', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10445, 'BERGS', 3, '1997-02-13 00:00:00', '1997-03-13 00:00:00', '1997-02-20 00:00:00', 1, '9.3000', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10446, 'TOMSP', 6, '1997-02-14 00:00:00', '1997-03-14 00:00:00', '1997-02-19 00:00:00', 1, '14.6800', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10447, 'RICAR', 4, '1997-02-14 00:00:00', '1997-03-14 00:00:00', '1997-03-07 00:00:00', 2, '68.6600', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10448, 'RANCH', 4, '1997-02-17 00:00:00', '1997-03-17 00:00:00', '1997-02-24 00:00:00', 2, '38.8200', 'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10449, 'BLONP', 3, '1997-02-18 00:00:00', '1997-03-18 00:00:00', '1997-02-27 00:00:00', 2, '53.3000', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10450, 'VICTE', 8, '1997-02-19 00:00:00', '1997-03-19 00:00:00', '1997-03-11 00:00:00', 2, '7.2300', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10451, 'QUICK', 4, '1997-02-19 00:00:00', '1997-03-05 00:00:00', '1997-03-12 00:00:00', 3, '189.0900', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10452, 'SAVEA', 8, '1997-02-20 00:00:00', '1997-03-20 00:00:00', '1997-02-26 00:00:00', 1, '140.2600', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10453, 'AROUT', 1, '1997-02-21 00:00:00', '1997-03-21 00:00:00', '1997-02-26 00:00:00', 2, '25.3600', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10454, 'LAMAI', 4, '1997-02-21 00:00:00', '1997-03-21 00:00:00', '1997-02-25 00:00:00', 3, '2.7400', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10455, 'WARTH', 8, '1997-02-24 00:00:00', '1997-04-07 00:00:00', '1997-03-03 00:00:00', 2, '180.4500', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10456, 'KOENE', 8, '1997-02-25 00:00:00', '1997-04-08 00:00:00', '1997-02-28 00:00:00', 2, '8.1200', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10457, 'KOENE', 2, '1997-02-25 00:00:00', '1997-03-25 00:00:00', '1997-03-03 00:00:00', 1, '11.5700', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10458, 'SUPRD', 7, '1997-02-26 00:00:00', '1997-03-26 00:00:00', '1997-03-04 00:00:00', 3, '147.0600', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10459, 'VICTE', 4, '1997-02-27 00:00:00', '1997-03-27 00:00:00', '1997-02-28 00:00:00', 2, '25.0900', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10460, 'FOLKO', 8, '1997-02-28 00:00:00', '1997-03-28 00:00:00', '1997-03-03 00:00:00', 1, '16.2700', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10461, 'LILAS', 1, '1997-02-28 00:00:00', '1997-03-28 00:00:00', '1997-03-05 00:00:00', 3, '148.6100', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10462, 'CONSH', 2, '1997-03-03 00:00:00', '1997-03-31 00:00:00', '1997-03-18 00:00:00', 1, '6.1700', 'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London', NULL, 'WX1 6LT', 'UK'),
(10463, 'SUPRD', 5, '1997-03-04 00:00:00', '1997-04-01 00:00:00', '1997-03-06 00:00:00', 3, '14.7800', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10464, 'FURIB', 4, '1997-03-04 00:00:00', '1997-04-01 00:00:00', '1997-03-14 00:00:00', 2, '89.0000', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10465, 'VAFFE', 1, '1997-03-05 00:00:00', '1997-04-02 00:00:00', '1997-03-14 00:00:00', 3, '145.0400', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10466, 'COMMI', 4, '1997-03-06 00:00:00', '1997-04-03 00:00:00', '1997-03-13 00:00:00', 1, '11.9300', 'Comrcio Mineiro', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'),
(10467, 'MAGAA', 8, '1997-03-06 00:00:00', '1997-04-03 00:00:00', '1997-03-11 00:00:00', 2, '4.9300', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10468, 'KOENE', 3, '1997-03-07 00:00:00', '1997-04-04 00:00:00', '1997-03-12 00:00:00', 3, '44.1200', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10469, 'WHITC', 1, '1997-03-10 00:00:00', '1997-04-07 00:00:00', '1997-03-14 00:00:00', 1, '60.1800', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10470, 'BONAP', 4, '1997-03-11 00:00:00', '1997-04-08 00:00:00', '1997-03-14 00:00:00', 2, '64.5600', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10471, 'BSBEV', 2, '1997-03-11 00:00:00', '1997-04-08 00:00:00', '1997-03-18 00:00:00', 3, '45.5900', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10472, 'SEVES', 8, '1997-03-12 00:00:00', '1997-04-09 00:00:00', '1997-03-19 00:00:00', 1, '4.2000', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10473, 'ISLAT', 1, '1997-03-13 00:00:00', '1997-03-27 00:00:00', '1997-03-21 00:00:00', 3, '16.3700', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10474, 'PERIC', 5, '1997-03-13 00:00:00', '1997-04-10 00:00:00', '1997-03-21 00:00:00', 2, '83.4900', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10475, 'SUPRD', 9, '1997-03-14 00:00:00', '1997-04-11 00:00:00', '1997-04-04 00:00:00', 1, '68.5200', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10476, 'HILAA', 8, '1997-03-17 00:00:00', '1997-04-14 00:00:00', '1997-03-24 00:00:00', 3, '4.4100', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10477, 'PRINI', 5, '1997-03-17 00:00:00', '1997-04-14 00:00:00', '1997-03-25 00:00:00', 2, '13.0200', 'Princesa Isabel Vinhos', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal'),
(10478, 'VICTE', 2, '1997-03-18 00:00:00', '1997-04-01 00:00:00', '1997-03-26 00:00:00', 3, '4.8100', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10479, 'RATTC', 3, '1997-03-19 00:00:00', '1997-04-16 00:00:00', '1997-03-21 00:00:00', 3, '708.9500', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10480, 'FOLIG', 6, '1997-03-20 00:00:00', '1997-04-17 00:00:00', '1997-03-24 00:00:00', 2, '1.3500', 'Folies gourmandes', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France'),
(10481, 'RICAR', 8, '1997-03-20 00:00:00', '1997-04-17 00:00:00', '1997-03-25 00:00:00', 2, '64.3300', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10482, 'LAZYK', 1, '1997-03-21 00:00:00', '1997-04-18 00:00:00', '1997-04-10 00:00:00', 3, '7.4800', 'Lazy K Kountry Store', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA'),
(10483, 'WHITC', 7, '1997-03-24 00:00:00', '1997-04-21 00:00:00', '1997-04-25 00:00:00', 2, '15.2800', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10484, 'BSBEV', 3, '1997-03-24 00:00:00', '1997-04-21 00:00:00', '1997-04-01 00:00:00', 3, '6.8800', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10485, 'LINOD', 4, '1997-03-25 00:00:00', '1997-04-08 00:00:00', '1997-03-31 00:00:00', 2, '64.4500', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10486, 'HILAA', 1, '1997-03-26 00:00:00', '1997-04-23 00:00:00', '1997-04-02 00:00:00', 2, '30.5300', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10487, 'QUEEN', 2, '1997-03-26 00:00:00', '1997-04-23 00:00:00', '1997-03-28 00:00:00', 2, '71.0700', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10488, 'FRANK', 8, '1997-03-27 00:00:00', '1997-04-24 00:00:00', '1997-04-02 00:00:00', 2, '4.9300', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10489, 'PICCO', 6, '1997-03-28 00:00:00', '1997-04-25 00:00:00', '1997-04-09 00:00:00', 2, '5.2900', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10490, 'HILAA', 7, '1997-03-31 00:00:00', '1997-04-28 00:00:00', '1997-04-03 00:00:00', 2, '210.1900', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10491, 'FURIB', 8, '1997-03-31 00:00:00', '1997-04-28 00:00:00', '1997-04-08 00:00:00', 3, '16.9600', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10492, 'BOTTM', 3, '1997-04-01 00:00:00', '1997-04-29 00:00:00', '1997-04-11 00:00:00', 1, '62.8900', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10493, 'LAMAI', 4, '1997-04-02 00:00:00', '1997-04-30 00:00:00', '1997-04-10 00:00:00', 3, '10.6400', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10494, 'COMMI', 4, '1997-04-02 00:00:00', '1997-04-30 00:00:00', '1997-04-09 00:00:00', 2, '65.9900', 'Comrcio Mineiro', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'),
(10495, 'LAUGB', 3, '1997-04-03 00:00:00', '1997-05-01 00:00:00', '1997-04-11 00:00:00', 3, '4.6500', 'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'),
(10496, 'TRADH', 7, '1997-04-04 00:00:00', '1997-05-02 00:00:00', '1997-04-07 00:00:00', 2, '46.7700', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10497, 'LEHMS', 7, '1997-04-04 00:00:00', '1997-05-02 00:00:00', '1997-04-07 00:00:00', 1, '36.2100', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10498, 'HILAA', 8, '1997-04-07 00:00:00', '1997-05-05 00:00:00', '1997-04-11 00:00:00', 2, '29.7500', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10499, 'LILAS', 4, '1997-04-08 00:00:00', '1997-05-06 00:00:00', '1997-04-16 00:00:00', 2, '102.0200', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10500, 'LAMAI', 6, '1997-04-09 00:00:00', '1997-05-07 00:00:00', '1997-04-17 00:00:00', 1, '42.6800', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10501, 'BLAUS', 9, '1997-04-09 00:00:00', '1997-05-07 00:00:00', '1997-04-16 00:00:00', 3, '8.8500', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10502, 'PERIC', 2, '1997-04-10 00:00:00', '1997-05-08 00:00:00', '1997-04-29 00:00:00', 1, '69.3200', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10503, 'HUNGO', 6, '1997-04-11 00:00:00', '1997-05-09 00:00:00', '1997-04-16 00:00:00', 2, '16.7400', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10504, 'WHITC', 4, '1997-04-11 00:00:00', '1997-05-09 00:00:00', '1997-04-18 00:00:00', 3, '59.1300', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10505, 'MEREP', 3, '1997-04-14 00:00:00', '1997-05-12 00:00:00', '1997-04-21 00:00:00', 3, '7.1300', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10506, 'KOENE', 9, '1997-04-15 00:00:00', '1997-05-13 00:00:00', '1997-05-02 00:00:00', 2, '21.1900', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10507, 'ANTON', 7, '1997-04-15 00:00:00', '1997-05-13 00:00:00', '1997-04-22 00:00:00', 1, '47.4500', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10508, 'OTTIK', 1, '1997-04-16 00:00:00', '1997-05-14 00:00:00', '1997-05-13 00:00:00', 2, '4.9900', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10509, 'BLAUS', 4, '1997-04-17 00:00:00', '1997-05-15 00:00:00', '1997-04-29 00:00:00', 1, '0.1500', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10510, 'SAVEA', 6, '1997-04-18 00:00:00', '1997-05-16 00:00:00', '1997-04-28 00:00:00', 3, '367.6300', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10511, 'BONAP', 4, '1997-04-18 00:00:00', '1997-05-16 00:00:00', '1997-04-21 00:00:00', 3, '350.6400', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10512, 'FAMIA', 7, '1997-04-21 00:00:00', '1997-05-19 00:00:00', '1997-04-24 00:00:00', 2, '3.5300', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10513, 'WANDK', 7, '1997-04-22 00:00:00', '1997-06-03 00:00:00', '1997-04-28 00:00:00', 1, '105.6500', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10514, 'ERNSH', 3, '1997-04-22 00:00:00', '1997-05-20 00:00:00', '1997-05-16 00:00:00', 2, '789.9500', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10515, 'QUICK', 2, '1997-04-23 00:00:00', '1997-05-07 00:00:00', '1997-05-23 00:00:00', 1, '204.4700', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10516, 'HUNGO', 2, '1997-04-24 00:00:00', '1997-05-22 00:00:00', '1997-05-01 00:00:00', 3, '62.7800', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10517, 'NORTS', 3, '1997-04-24 00:00:00', '1997-05-22 00:00:00', '1997-04-29 00:00:00', 3, '32.0700', 'North/South', 'South House 300 Queensbridge', 'London', NULL, 'SW7 1RZ', 'UK');
INSERT INTO `orders` (`OrderID`, `CustomerID`, `EmployeeID`, `OrderDate`, `RequiredDate`, `ShippedDate`, `ShipVia`, `Freight`, `ShipName`, `ShipAddress`, `ShipCity`, `ShipRegion`, `ShipPostalCode`, `ShipCountry`) VALUES
(10518, 'TORTU', 4, '1997-04-25 00:00:00', '1997-05-09 00:00:00', '1997-05-05 00:00:00', 2, '218.1500', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10519, 'CHOPS', 6, '1997-04-28 00:00:00', '1997-05-26 00:00:00', '1997-05-01 00:00:00', 3, '91.7600', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10520, 'SANTG', 7, '1997-04-29 00:00:00', '1997-05-27 00:00:00', '1997-05-01 00:00:00', 1, '13.3700', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(10521, 'CACTU', 8, '1997-04-29 00:00:00', '1997-05-27 00:00:00', '1997-05-02 00:00:00', 2, '17.2200', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10522, 'LEHMS', 4, '1997-04-30 00:00:00', '1997-05-28 00:00:00', '1997-05-06 00:00:00', 1, '45.3300', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10523, 'SEVES', 7, '1997-05-01 00:00:00', '1997-05-29 00:00:00', '1997-05-30 00:00:00', 2, '77.6300', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10524, 'BERGS', 1, '1997-05-01 00:00:00', '1997-05-29 00:00:00', '1997-05-07 00:00:00', 2, '244.7900', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10525, 'BONAP', 1, '1997-05-02 00:00:00', '1997-05-30 00:00:00', '1997-05-23 00:00:00', 2, '11.0600', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10526, 'WARTH', 4, '1997-05-05 00:00:00', '1997-06-02 00:00:00', '1997-05-15 00:00:00', 2, '58.5900', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10527, 'QUICK', 7, '1997-05-05 00:00:00', '1997-06-02 00:00:00', '1997-05-07 00:00:00', 1, '41.9000', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10528, 'GREAL', 6, '1997-05-06 00:00:00', '1997-05-20 00:00:00', '1997-05-09 00:00:00', 2, '3.3500', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10529, 'MAISD', 5, '1997-05-07 00:00:00', '1997-06-04 00:00:00', '1997-05-09 00:00:00', 2, '66.6900', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10530, 'PICCO', 3, '1997-05-08 00:00:00', '1997-06-05 00:00:00', '1997-05-12 00:00:00', 2, '339.2200', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10531, 'OCEAN', 7, '1997-05-08 00:00:00', '1997-06-05 00:00:00', '1997-05-19 00:00:00', 1, '8.1200', 'Ocano Atlntico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10532, 'EASTC', 7, '1997-05-09 00:00:00', '1997-06-06 00:00:00', '1997-05-12 00:00:00', 3, '74.4600', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(10533, 'FOLKO', 8, '1997-05-12 00:00:00', '1997-06-09 00:00:00', '1997-05-22 00:00:00', 1, '188.0400', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10534, 'LEHMS', 8, '1997-05-12 00:00:00', '1997-06-09 00:00:00', '1997-05-14 00:00:00', 2, '27.9400', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10535, 'ANTON', 4, '1997-05-13 00:00:00', '1997-06-10 00:00:00', '1997-05-21 00:00:00', 1, '15.6400', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10536, 'LEHMS', 3, '1997-05-14 00:00:00', '1997-06-11 00:00:00', '1997-06-06 00:00:00', 2, '58.8800', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10537, 'RICSU', 1, '1997-05-14 00:00:00', '1997-05-28 00:00:00', '1997-05-19 00:00:00', 1, '78.8500', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10538, 'BSBEV', 9, '1997-05-15 00:00:00', '1997-06-12 00:00:00', '1997-05-16 00:00:00', 3, '4.8700', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10539, 'BSBEV', 6, '1997-05-16 00:00:00', '1997-06-13 00:00:00', '1997-05-23 00:00:00', 3, '12.3600', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10540, 'QUICK', 3, '1997-05-19 00:00:00', '1997-06-16 00:00:00', '1997-06-13 00:00:00', 3, '1007.6400', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10541, 'HANAR', 2, '1997-05-19 00:00:00', '1997-06-16 00:00:00', '1997-05-29 00:00:00', 1, '68.6500', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10542, 'KOENE', 1, '1997-05-20 00:00:00', '1997-06-17 00:00:00', '1997-05-26 00:00:00', 3, '10.9500', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10543, 'LILAS', 8, '1997-05-21 00:00:00', '1997-06-18 00:00:00', '1997-05-23 00:00:00', 2, '48.1700', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10544, 'LONEP', 4, '1997-05-21 00:00:00', '1997-06-18 00:00:00', '1997-05-30 00:00:00', 1, '24.9100', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10545, 'LAZYK', 8, '1997-05-22 00:00:00', '1997-06-19 00:00:00', '1997-06-26 00:00:00', 2, '11.9200', 'Lazy K Kountry Store', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA'),
(10546, 'VICTE', 1, '1997-05-23 00:00:00', '1997-06-20 00:00:00', '1997-05-27 00:00:00', 3, '194.7200', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10547, 'SEVES', 3, '1997-05-23 00:00:00', '1997-06-20 00:00:00', '1997-06-02 00:00:00', 2, '178.4300', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10548, 'TOMSP', 3, '1997-05-26 00:00:00', '1997-06-23 00:00:00', '1997-06-02 00:00:00', 2, '1.4300', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10549, 'QUICK', 5, '1997-05-27 00:00:00', '1997-06-10 00:00:00', '1997-05-30 00:00:00', 1, '171.2400', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10550, 'GODOS', 7, '1997-05-28 00:00:00', '1997-06-25 00:00:00', '1997-06-06 00:00:00', 3, '4.3200', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10551, 'FURIB', 4, '1997-05-28 00:00:00', '1997-07-09 00:00:00', '1997-06-06 00:00:00', 3, '72.9500', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10552, 'HILAA', 2, '1997-05-29 00:00:00', '1997-06-26 00:00:00', '1997-06-05 00:00:00', 1, '83.2200', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10553, 'WARTH', 2, '1997-05-30 00:00:00', '1997-06-27 00:00:00', '1997-06-03 00:00:00', 2, '149.4900', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10554, 'OTTIK', 4, '1997-05-30 00:00:00', '1997-06-27 00:00:00', '1997-06-05 00:00:00', 3, '120.9700', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10555, 'SAVEA', 6, '1997-06-02 00:00:00', '1997-06-30 00:00:00', '1997-06-04 00:00:00', 3, '252.4900', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10556, 'SIMOB', 2, '1997-06-03 00:00:00', '1997-07-15 00:00:00', '1997-06-13 00:00:00', 1, '9.8000', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10557, 'LEHMS', 9, '1997-06-03 00:00:00', '1997-06-17 00:00:00', '1997-06-06 00:00:00', 2, '96.7200', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10558, 'AROUT', 1, '1997-06-04 00:00:00', '1997-07-02 00:00:00', '1997-06-10 00:00:00', 2, '72.9700', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10559, 'BLONP', 6, '1997-06-05 00:00:00', '1997-07-03 00:00:00', '1997-06-13 00:00:00', 1, '8.0500', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10560, 'FRANK', 8, '1997-06-06 00:00:00', '1997-07-04 00:00:00', '1997-06-09 00:00:00', 1, '36.6500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10561, 'FOLKO', 2, '1997-06-06 00:00:00', '1997-07-04 00:00:00', '1997-06-09 00:00:00', 2, '242.2100', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10562, 'REGGC', 1, '1997-06-09 00:00:00', '1997-07-07 00:00:00', '1997-06-12 00:00:00', 1, '22.9500', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10563, 'RICAR', 2, '1997-06-10 00:00:00', '1997-07-22 00:00:00', '1997-06-24 00:00:00', 2, '60.4300', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10564, 'RATTC', 4, '1997-06-10 00:00:00', '1997-07-08 00:00:00', '1997-06-16 00:00:00', 3, '13.7500', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10565, 'MEREP', 8, '1997-06-11 00:00:00', '1997-07-09 00:00:00', '1997-06-18 00:00:00', 2, '7.1500', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10566, 'BLONP', 9, '1997-06-12 00:00:00', '1997-07-10 00:00:00', '1997-06-18 00:00:00', 1, '88.4000', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10567, 'HUNGO', 1, '1997-06-12 00:00:00', '1997-07-10 00:00:00', '1997-06-17 00:00:00', 1, '33.9700', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10568, 'GALED', 3, '1997-06-13 00:00:00', '1997-07-11 00:00:00', '1997-07-09 00:00:00', 3, '6.5400', 'Galera del gastronmo', 'Rambla de Catalua, 23', 'Barcelona', NULL, '8022', 'Spain'),
(10569, 'RATTC', 5, '1997-06-16 00:00:00', '1997-07-14 00:00:00', '1997-07-11 00:00:00', 1, '58.9800', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10570, 'MEREP', 3, '1997-06-17 00:00:00', '1997-07-15 00:00:00', '1997-06-19 00:00:00', 3, '188.9900', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10571, 'ERNSH', 8, '1997-06-17 00:00:00', '1997-07-29 00:00:00', '1997-07-04 00:00:00', 3, '26.0600', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10572, 'BERGS', 3, '1997-06-18 00:00:00', '1997-07-16 00:00:00', '1997-06-25 00:00:00', 2, '116.4300', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10573, 'ANTON', 7, '1997-06-19 00:00:00', '1997-07-17 00:00:00', '1997-06-20 00:00:00', 3, '84.8400', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10574, 'TRAIH', 4, '1997-06-19 00:00:00', '1997-07-17 00:00:00', '1997-06-30 00:00:00', 2, '37.6000', 'Trail-s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'),
(10575, 'MORGK', 5, '1997-06-20 00:00:00', '1997-07-04 00:00:00', '1997-06-30 00:00:00', 1, '127.3400', 'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig', NULL, '4179', 'Germany'),
(10576, 'TORTU', 3, '1997-06-23 00:00:00', '1997-07-07 00:00:00', '1997-06-30 00:00:00', 3, '18.5600', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10577, 'TRAIH', 9, '1997-06-23 00:00:00', '1997-08-04 00:00:00', '1997-06-30 00:00:00', 2, '25.4100', 'Trail-s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'),
(10578, 'BSBEV', 4, '1997-06-24 00:00:00', '1997-07-22 00:00:00', '1997-07-25 00:00:00', 3, '29.6000', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10579, 'LETSS', 1, '1997-06-25 00:00:00', '1997-07-23 00:00:00', '1997-07-04 00:00:00', 2, '13.7300', 'Let-s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'),
(10580, 'OTTIK', 4, '1997-06-26 00:00:00', '1997-07-24 00:00:00', '1997-07-01 00:00:00', 3, '75.8900', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10581, 'FAMIA', 3, '1997-06-26 00:00:00', '1997-07-24 00:00:00', '1997-07-02 00:00:00', 1, '3.0100', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10582, 'BLAUS', 3, '1997-06-27 00:00:00', '1997-07-25 00:00:00', '1997-07-14 00:00:00', 2, '27.7100', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10583, 'WARTH', 2, '1997-06-30 00:00:00', '1997-07-28 00:00:00', '1997-07-04 00:00:00', 2, '7.2800', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10584, 'BLONP', 4, '1997-06-30 00:00:00', '1997-07-28 00:00:00', '1997-07-04 00:00:00', 1, '59.1400', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10585, 'WELLI', 7, '1997-07-01 00:00:00', '1997-07-29 00:00:00', '1997-07-10 00:00:00', 1, '13.4100', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10586, 'REGGC', 9, '1997-07-02 00:00:00', '1997-07-30 00:00:00', '1997-07-09 00:00:00', 1, '0.4800', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10587, 'QUEDE', 1, '1997-07-02 00:00:00', '1997-07-30 00:00:00', '1997-07-09 00:00:00', 1, '62.5200', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10588, 'QUICK', 2, '1997-07-03 00:00:00', '1997-07-31 00:00:00', '1997-07-10 00:00:00', 3, '194.6700', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10589, 'GREAL', 8, '1997-07-04 00:00:00', '1997-08-01 00:00:00', '1997-07-14 00:00:00', 2, '4.4200', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10590, 'MEREP', 4, '1997-07-07 00:00:00', '1997-08-04 00:00:00', '1997-07-14 00:00:00', 3, '44.7700', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10591, 'VAFFE', 1, '1997-07-07 00:00:00', '1997-07-21 00:00:00', '1997-07-16 00:00:00', 1, '55.9200', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10592, 'LEHMS', 3, '1997-07-08 00:00:00', '1997-08-05 00:00:00', '1997-07-16 00:00:00', 1, '32.1000', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10593, 'LEHMS', 7, '1997-07-09 00:00:00', '1997-08-06 00:00:00', '1997-08-13 00:00:00', 2, '174.2000', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10594, 'OLDWO', 3, '1997-07-09 00:00:00', '1997-08-06 00:00:00', '1997-07-16 00:00:00', 2, '5.2400', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10595, 'ERNSH', 2, '1997-07-10 00:00:00', '1997-08-07 00:00:00', '1997-07-14 00:00:00', 1, '96.7800', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10596, 'WHITC', 8, '1997-07-11 00:00:00', '1997-08-08 00:00:00', '1997-08-12 00:00:00', 1, '16.3400', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10597, 'PICCO', 7, '1997-07-11 00:00:00', '1997-08-08 00:00:00', '1997-07-18 00:00:00', 3, '35.1200', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10598, 'RATTC', 1, '1997-07-14 00:00:00', '1997-08-11 00:00:00', '1997-07-18 00:00:00', 3, '44.4200', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10599, 'BSBEV', 6, '1997-07-15 00:00:00', '1997-08-26 00:00:00', '1997-07-21 00:00:00', 3, '29.9800', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10600, 'HUNGC', 4, '1997-07-16 00:00:00', '1997-08-13 00:00:00', '1997-07-21 00:00:00', 1, '45.1300', 'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'),
(10601, 'HILAA', 7, '1997-07-16 00:00:00', '1997-08-27 00:00:00', '1997-07-22 00:00:00', 1, '58.3000', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10602, 'VAFFE', 8, '1997-07-17 00:00:00', '1997-08-14 00:00:00', '1997-07-22 00:00:00', 2, '2.9200', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10603, 'SAVEA', 8, '1997-07-18 00:00:00', '1997-08-15 00:00:00', '1997-08-08 00:00:00', 2, '48.7700', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10604, 'FURIB', 1, '1997-07-18 00:00:00', '1997-08-15 00:00:00', '1997-07-29 00:00:00', 1, '7.4600', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10605, 'MEREP', 1, '1997-07-21 00:00:00', '1997-08-18 00:00:00', '1997-07-29 00:00:00', 2, '379.1300', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10606, 'TRADH', 4, '1997-07-22 00:00:00', '1997-08-19 00:00:00', '1997-07-31 00:00:00', 3, '79.4000', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10607, 'SAVEA', 5, '1997-07-22 00:00:00', '1997-08-19 00:00:00', '1997-07-25 00:00:00', 1, '200.2400', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10608, 'TOMSP', 4, '1997-07-23 00:00:00', '1997-08-20 00:00:00', '1997-08-01 00:00:00', 2, '27.7900', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10609, 'DUMON', 7, '1997-07-24 00:00:00', '1997-08-21 00:00:00', '1997-07-30 00:00:00', 2, '1.8500', 'Du monde entier', '67, rue des Cinquante Otages', 'Nantes', NULL, '44000', 'France'),
(10610, 'LAMAI', 8, '1997-07-25 00:00:00', '1997-08-22 00:00:00', '1997-08-06 00:00:00', 1, '26.7800', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10611, 'WOLZA', 6, '1997-07-25 00:00:00', '1997-08-22 00:00:00', '1997-08-01 00:00:00', 2, '80.6500', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10612, 'SAVEA', 1, '1997-07-28 00:00:00', '1997-08-25 00:00:00', '1997-08-01 00:00:00', 2, '544.0800', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10613, 'HILAA', 4, '1997-07-29 00:00:00', '1997-08-26 00:00:00', '1997-08-01 00:00:00', 2, '8.1100', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10614, 'BLAUS', 8, '1997-07-29 00:00:00', '1997-08-26 00:00:00', '1997-08-01 00:00:00', 3, '1.9300', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10615, 'WILMK', 2, '1997-07-30 00:00:00', '1997-08-27 00:00:00', '1997-08-06 00:00:00', 3, '0.7500', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10616, 'GREAL', 1, '1997-07-31 00:00:00', '1997-08-28 00:00:00', '1997-08-05 00:00:00', 2, '116.5300', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10617, 'GREAL', 4, '1997-07-31 00:00:00', '1997-08-28 00:00:00', '1997-08-04 00:00:00', 2, '18.5300', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10618, 'MEREP', 1, '1997-08-01 00:00:00', '1997-09-12 00:00:00', '1997-08-08 00:00:00', 1, '154.6800', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10619, 'MEREP', 3, '1997-08-04 00:00:00', '1997-09-01 00:00:00', '1997-08-07 00:00:00', 3, '91.0500', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10620, 'LAUGB', 2, '1997-08-05 00:00:00', '1997-09-02 00:00:00', '1997-08-14 00:00:00', 3, '0.9400', 'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'),
(10621, 'ISLAT', 4, '1997-08-05 00:00:00', '1997-09-02 00:00:00', '1997-08-11 00:00:00', 2, '23.7300', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10622, 'RICAR', 4, '1997-08-06 00:00:00', '1997-09-03 00:00:00', '1997-08-11 00:00:00', 3, '50.9700', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10623, 'FRANK', 8, '1997-08-07 00:00:00', '1997-09-04 00:00:00', '1997-08-12 00:00:00', 2, '97.1800', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10624, 'THECR', 4, '1997-08-07 00:00:00', '1997-09-04 00:00:00', '1997-08-19 00:00:00', 2, '94.8000', 'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'),
(10625, 'ANATR', 3, '1997-08-08 00:00:00', '1997-09-05 00:00:00', '1997-08-14 00:00:00', 1, '43.9000', 'Ana Trujillo Emparedados y helados', 'Avda. de la Constitucin 2222', 'Mxico D.F.', NULL, '5021', 'Mexico'),
(10626, 'BERGS', 1, '1997-08-11 00:00:00', '1997-09-08 00:00:00', '1997-08-20 00:00:00', 2, '138.6900', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10627, 'SAVEA', 8, '1997-08-11 00:00:00', '1997-09-22 00:00:00', '1997-08-21 00:00:00', 3, '107.4600', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10628, 'BLONP', 4, '1997-08-12 00:00:00', '1997-09-09 00:00:00', '1997-08-20 00:00:00', 3, '30.3600', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10629, 'GODOS', 4, '1997-08-12 00:00:00', '1997-09-09 00:00:00', '1997-08-20 00:00:00', 3, '85.4600', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10630, 'KOENE', 1, '1997-08-13 00:00:00', '1997-09-10 00:00:00', '1997-08-19 00:00:00', 2, '32.3500', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10631, 'LAMAI', 8, '1997-08-14 00:00:00', '1997-09-11 00:00:00', '1997-08-15 00:00:00', 1, '0.8700', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10632, 'WANDK', 8, '1997-08-14 00:00:00', '1997-09-11 00:00:00', '1997-08-19 00:00:00', 1, '41.3800', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10633, 'ERNSH', 7, '1997-08-15 00:00:00', '1997-09-12 00:00:00', '1997-08-18 00:00:00', 3, '477.9000', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10634, 'FOLIG', 4, '1997-08-15 00:00:00', '1997-09-12 00:00:00', '1997-08-21 00:00:00', 3, '487.3800', 'Folies gourmandes', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France'),
(10635, 'MAGAA', 8, '1997-08-18 00:00:00', '1997-09-15 00:00:00', '1997-08-21 00:00:00', 3, '47.4600', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10636, 'WARTH', 4, '1997-08-19 00:00:00', '1997-09-16 00:00:00', '1997-08-26 00:00:00', 1, '1.1500', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10637, 'QUEEN', 6, '1997-08-19 00:00:00', '1997-09-16 00:00:00', '1997-08-26 00:00:00', 1, '201.2900', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10638, 'LINOD', 3, '1997-08-20 00:00:00', '1997-09-17 00:00:00', '1997-09-01 00:00:00', 1, '158.4400', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10639, 'SANTG', 7, '1997-08-20 00:00:00', '1997-09-17 00:00:00', '1997-08-27 00:00:00', 3, '38.6400', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(10640, 'WANDK', 4, '1997-08-21 00:00:00', '1997-09-18 00:00:00', '1997-08-28 00:00:00', 1, '23.5500', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10641, 'HILAA', 4, '1997-08-22 00:00:00', '1997-09-19 00:00:00', '1997-08-26 00:00:00', 2, '179.6100', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10642, 'SIMOB', 7, '1997-08-22 00:00:00', '1997-09-19 00:00:00', '1997-09-05 00:00:00', 3, '41.8900', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10643, 'ALFKI', 6, '1997-08-25 00:00:00', '1997-09-22 00:00:00', '1997-09-02 00:00:00', 1, '29.4600', 'Alfreds Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(10644, 'WELLI', 3, '1997-08-25 00:00:00', '1997-09-22 00:00:00', '1997-09-01 00:00:00', 2, '0.1400', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10645, 'HANAR', 4, '1997-08-26 00:00:00', '1997-09-23 00:00:00', '1997-09-02 00:00:00', 1, '12.4100', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10646, 'HUNGO', 9, '1997-08-27 00:00:00', '1997-10-08 00:00:00', '1997-09-03 00:00:00', 3, '142.3300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10647, 'QUEDE', 4, '1997-08-27 00:00:00', '1997-09-10 00:00:00', '1997-09-03 00:00:00', 2, '45.5400', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10648, 'RICAR', 5, '1997-08-28 00:00:00', '1997-10-09 00:00:00', '1997-09-09 00:00:00', 2, '14.2500', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10649, 'MAISD', 5, '1997-08-28 00:00:00', '1997-09-25 00:00:00', '1997-08-29 00:00:00', 3, '6.2000', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10650, 'FAMIA', 5, '1997-08-29 00:00:00', '1997-09-26 00:00:00', '1997-09-03 00:00:00', 3, '176.8100', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10651, 'WANDK', 8, '1997-09-01 00:00:00', '1997-09-29 00:00:00', '1997-09-11 00:00:00', 2, '20.6000', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10652, 'GOURL', 4, '1997-09-01 00:00:00', '1997-09-29 00:00:00', '1997-09-08 00:00:00', 2, '7.1400', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10653, 'FRANK', 1, '1997-09-02 00:00:00', '1997-09-30 00:00:00', '1997-09-19 00:00:00', 1, '93.2500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10654, 'BERGS', 5, '1997-09-02 00:00:00', '1997-09-30 00:00:00', '1997-09-11 00:00:00', 1, '55.2600', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10655, 'REGGC', 1, '1997-09-03 00:00:00', '1997-10-01 00:00:00', '1997-09-11 00:00:00', 2, '4.4100', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10656, 'GREAL', 6, '1997-09-04 00:00:00', '1997-10-02 00:00:00', '1997-09-10 00:00:00', 1, '57.1500', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10657, 'SAVEA', 2, '1997-09-04 00:00:00', '1997-10-02 00:00:00', '1997-09-15 00:00:00', 2, '352.6900', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10658, 'QUICK', 4, '1997-09-05 00:00:00', '1997-10-03 00:00:00', '1997-09-08 00:00:00', 1, '364.1500', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10659, 'QUEEN', 7, '1997-09-05 00:00:00', '1997-10-03 00:00:00', '1997-09-10 00:00:00', 2, '105.8100', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10660, 'HUNGC', 8, '1997-09-08 00:00:00', '1997-10-06 00:00:00', '1997-10-15 00:00:00', 1, '111.2900', 'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'),
(10661, 'HUNGO', 7, '1997-09-09 00:00:00', '1997-10-07 00:00:00', '1997-09-15 00:00:00', 3, '17.5500', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10662, 'LONEP', 3, '1997-09-09 00:00:00', '1997-10-07 00:00:00', '1997-09-18 00:00:00', 2, '1.2800', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10663, 'BONAP', 2, '1997-09-10 00:00:00', '1997-09-24 00:00:00', '1997-10-03 00:00:00', 2, '113.1500', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10664, 'FURIB', 1, '1997-09-10 00:00:00', '1997-10-08 00:00:00', '1997-09-19 00:00:00', 3, '1.2700', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10665, 'LONEP', 1, '1997-09-11 00:00:00', '1997-10-09 00:00:00', '1997-09-17 00:00:00', 2, '26.3100', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10666, 'RICSU', 7, '1997-09-12 00:00:00', '1997-10-10 00:00:00', '1997-09-22 00:00:00', 2, '232.4200', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10667, 'ERNSH', 7, '1997-09-12 00:00:00', '1997-10-10 00:00:00', '1997-09-19 00:00:00', 1, '78.0900', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10668, 'WANDK', 1, '1997-09-15 00:00:00', '1997-10-13 00:00:00', '1997-09-23 00:00:00', 2, '47.2200', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(10669, 'SIMOB', 2, '1997-09-15 00:00:00', '1997-10-13 00:00:00', '1997-09-22 00:00:00', 1, '24.3900', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10670, 'FRANK', 4, '1997-09-16 00:00:00', '1997-10-14 00:00:00', '1997-09-18 00:00:00', 1, '203.4800', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10671, 'FRANR', 1, '1997-09-17 00:00:00', '1997-10-15 00:00:00', '1997-09-24 00:00:00', 1, '30.3400', 'France restauration', '54, rue Royale', 'Nantes', NULL, '44000', 'France'),
(10672, 'BERGS', 9, '1997-09-17 00:00:00', '1997-10-01 00:00:00', '1997-09-26 00:00:00', 2, '95.7500', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10673, 'WILMK', 2, '1997-09-18 00:00:00', '1997-10-16 00:00:00', '1997-09-19 00:00:00', 1, '22.7600', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10674, 'ISLAT', 4, '1997-09-18 00:00:00', '1997-10-16 00:00:00', '1997-09-30 00:00:00', 2, '0.9000', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10675, 'FRANK', 5, '1997-09-19 00:00:00', '1997-10-17 00:00:00', '1997-09-23 00:00:00', 2, '31.8500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10676, 'TORTU', 2, '1997-09-22 00:00:00', '1997-10-20 00:00:00', '1997-09-29 00:00:00', 2, '2.0100', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10677, 'ANTON', 1, '1997-09-22 00:00:00', '1997-10-20 00:00:00', '1997-09-26 00:00:00', 3, '4.0300', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10678, 'SAVEA', 7, '1997-09-23 00:00:00', '1997-10-21 00:00:00', '1997-10-16 00:00:00', 3, '388.9800', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10679, 'BLONP', 8, '1997-09-23 00:00:00', '1997-10-21 00:00:00', '1997-09-30 00:00:00', 3, '27.9400', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10680, 'OLDWO', 1, '1997-09-24 00:00:00', '1997-10-22 00:00:00', '1997-09-26 00:00:00', 1, '26.6100', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10681, 'GREAL', 3, '1997-09-25 00:00:00', '1997-10-23 00:00:00', '1997-09-30 00:00:00', 3, '76.1300', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10682, 'ANTON', 3, '1997-09-25 00:00:00', '1997-10-23 00:00:00', '1997-10-01 00:00:00', 2, '36.1300', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10683, 'DUMON', 2, '1997-09-26 00:00:00', '1997-10-24 00:00:00', '1997-10-01 00:00:00', 1, '4.4000', 'Du monde entier', '67, rue des Cinquante Otages', 'Nantes', NULL, '44000', 'France'),
(10684, 'OTTIK', 3, '1997-09-26 00:00:00', '1997-10-24 00:00:00', '1997-09-30 00:00:00', 1, '145.6300', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10685, 'GOURL', 4, '1997-09-29 00:00:00', '1997-10-13 00:00:00', '1997-10-03 00:00:00', 2, '33.7500', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10686, 'PICCO', 2, '1997-09-30 00:00:00', '1997-10-28 00:00:00', '1997-10-08 00:00:00', 1, '96.5000', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10687, 'HUNGO', 9, '1997-09-30 00:00:00', '1997-10-28 00:00:00', '1997-10-30 00:00:00', 2, '296.4300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10688, 'VAFFE', 4, '1997-10-01 00:00:00', '1997-10-15 00:00:00', '1997-10-07 00:00:00', 2, '299.0900', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10689, 'BERGS', 1, '1997-10-01 00:00:00', '1997-10-29 00:00:00', '1997-10-07 00:00:00', 2, '13.4200', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10690, 'HANAR', 1, '1997-10-02 00:00:00', '1997-10-30 00:00:00', '1997-10-03 00:00:00', 1, '15.8000', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10691, 'QUICK', 2, '1997-10-03 00:00:00', '1997-11-14 00:00:00', '1997-10-22 00:00:00', 2, '810.0500', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10692, 'ALFKI', 4, '1997-10-03 00:00:00', '1997-10-31 00:00:00', '1997-10-13 00:00:00', 2, '61.0200', 'Alfred-s Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(10693, 'WHITC', 3, '1997-10-06 00:00:00', '1997-10-20 00:00:00', '1997-10-10 00:00:00', 3, '139.3400', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10694, 'QUICK', 8, '1997-10-06 00:00:00', '1997-11-03 00:00:00', '1997-10-09 00:00:00', 3, '398.3600', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10695, 'WILMK', 7, '1997-10-07 00:00:00', '1997-11-18 00:00:00', '1997-10-14 00:00:00', 1, '16.7200', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10696, 'WHITC', 8, '1997-10-08 00:00:00', '1997-11-19 00:00:00', '1997-10-14 00:00:00', 3, '102.5500', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10697, 'LINOD', 3, '1997-10-08 00:00:00', '1997-11-05 00:00:00', '1997-10-14 00:00:00', 1, '45.5200', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10698, 'ERNSH', 4, '1997-10-09 00:00:00', '1997-11-06 00:00:00', '1997-10-17 00:00:00', 1, '272.4700', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10699, 'MORGK', 3, '1997-10-09 00:00:00', '1997-11-06 00:00:00', '1997-10-13 00:00:00', 3, '0.5800', 'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig', NULL, '4179', 'Germany'),
(10700, 'SAVEA', 3, '1997-10-10 00:00:00', '1997-11-07 00:00:00', '1997-10-16 00:00:00', 1, '65.1000', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10701, 'HUNGO', 6, '1997-10-13 00:00:00', '1997-10-27 00:00:00', '1997-10-15 00:00:00', 3, '220.3100', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10702, 'ALFKI', 4, '1997-10-13 00:00:00', '1997-11-24 00:00:00', '1997-10-21 00:00:00', 1, '23.9400', 'Alfred-s Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(10703, 'FOLKO', 6, '1997-10-14 00:00:00', '1997-11-11 00:00:00', '1997-10-20 00:00:00', 2, '152.3000', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10704, 'QUEEN', 6, '1997-10-14 00:00:00', '1997-11-11 00:00:00', '1997-11-07 00:00:00', 1, '4.7800', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10705, 'HILAA', 9, '1997-10-15 00:00:00', '1997-11-12 00:00:00', '1997-11-18 00:00:00', 2, '3.5200', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10706, 'OLDWO', 8, '1997-10-16 00:00:00', '1997-11-13 00:00:00', '1997-10-21 00:00:00', 3, '135.6300', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10707, 'AROUT', 4, '1997-10-16 00:00:00', '1997-10-30 00:00:00', '1997-10-23 00:00:00', 3, '21.7400', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10708, 'THEBI', 6, '1997-10-17 00:00:00', '1997-11-28 00:00:00', '1997-11-05 00:00:00', 2, '2.9600', 'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'),
(10709, 'GOURL', 1, '1997-10-17 00:00:00', '1997-11-14 00:00:00', '1997-11-20 00:00:00', 3, '210.8000', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10710, 'FRANS', 1, '1997-10-20 00:00:00', '1997-11-17 00:00:00', '1997-10-23 00:00:00', 1, '4.9800', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(10711, 'SAVEA', 5, '1997-10-21 00:00:00', '1997-12-02 00:00:00', '1997-10-29 00:00:00', 2, '52.4100', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10712, 'HUNGO', 3, '1997-10-21 00:00:00', '1997-11-18 00:00:00', '1997-10-31 00:00:00', 1, '89.9300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10713, 'SAVEA', 1, '1997-10-22 00:00:00', '1997-11-19 00:00:00', '1997-10-24 00:00:00', 1, '167.0500', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10714, 'SAVEA', 5, '1997-10-22 00:00:00', '1997-11-19 00:00:00', '1997-10-27 00:00:00', 3, '24.4900', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10715, 'BONAP', 3, '1997-10-23 00:00:00', '1997-11-06 00:00:00', '1997-10-29 00:00:00', 1, '63.2000', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10716, 'RANCH', 4, '1997-10-24 00:00:00', '1997-11-21 00:00:00', '1997-10-27 00:00:00', 2, '22.5700', 'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10717, 'FRANK', 1, '1997-10-24 00:00:00', '1997-11-21 00:00:00', '1997-10-29 00:00:00', 2, '59.2500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10718, 'KOENE', 1, '1997-10-27 00:00:00', '1997-11-24 00:00:00', '1997-10-29 00:00:00', 3, '170.8800', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10719, 'LETSS', 8, '1997-10-27 00:00:00', '1997-11-24 00:00:00', '1997-11-05 00:00:00', 2, '51.4400', 'Let-s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'),
(10720, 'QUEDE', 8, '1997-10-28 00:00:00', '1997-11-11 00:00:00', '1997-11-05 00:00:00', 2, '9.5300', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10721, 'QUICK', 5, '1997-10-29 00:00:00', '1997-11-26 00:00:00', '1997-10-31 00:00:00', 3, '48.9200', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10722, 'SAVEA', 8, '1997-10-29 00:00:00', '1997-12-10 00:00:00', '1997-11-04 00:00:00', 1, '74.5800', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10723, 'WHITC', 3, '1997-10-30 00:00:00', '1997-11-27 00:00:00', '1997-11-25 00:00:00', 1, '21.7200', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10724, 'MEREP', 8, '1997-10-30 00:00:00', '1997-12-11 00:00:00', '1997-11-05 00:00:00', 2, '57.7500', 'Mre Paillarde', '43 rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada'),
(10725, 'FAMIA', 4, '1997-10-31 00:00:00', '1997-11-28 00:00:00', '1997-11-05 00:00:00', 3, '10.8300', 'Familia Arquibaldo', 'Rua Ors, 92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'),
(10726, 'EASTC', 4, '1997-11-03 00:00:00', '1997-11-17 00:00:00', '1997-12-05 00:00:00', 1, '16.5600', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(10727, 'REGGC', 2, '1997-11-03 00:00:00', '1997-12-01 00:00:00', '1997-12-05 00:00:00', 1, '89.9000', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10728, 'QUEEN', 4, '1997-11-04 00:00:00', '1997-12-02 00:00:00', '1997-11-11 00:00:00', 2, '58.3300', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10729, 'LINOD', 8, '1997-11-04 00:00:00', '1997-12-16 00:00:00', '1997-11-14 00:00:00', 3, '141.0600', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10730, 'BONAP', 5, '1997-11-05 00:00:00', '1997-12-03 00:00:00', '1997-11-14 00:00:00', 1, '20.1200', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10731, 'CHOPS', 7, '1997-11-06 00:00:00', '1997-12-04 00:00:00', '1997-11-14 00:00:00', 1, '96.6500', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10732, 'BONAP', 3, '1997-11-06 00:00:00', '1997-12-04 00:00:00', '1997-11-07 00:00:00', 1, '16.9700', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10733, 'BERGS', 1, '1997-11-07 00:00:00', '1997-12-05 00:00:00', '1997-11-10 00:00:00', 3, '110.1100', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10734, 'GOURL', 2, '1997-11-07 00:00:00', '1997-12-05 00:00:00', '1997-11-12 00:00:00', 3, '1.6300', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10735, 'LETSS', 6, '1997-11-10 00:00:00', '1997-12-08 00:00:00', '1997-11-21 00:00:00', 2, '45.9700', 'Let-s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'),
(10736, 'HUNGO', 9, '1997-11-11 00:00:00', '1997-12-09 00:00:00', '1997-11-21 00:00:00', 2, '44.1000', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10737, 'VINET', 2, '1997-11-11 00:00:00', '1997-12-09 00:00:00', '1997-11-18 00:00:00', 2, '7.7900', 'Vins et alcools Chevalier', '59 rue de l-Abbaye', 'Reims', NULL, '51100', 'France'),
(10738, 'SPECD', 2, '1997-11-12 00:00:00', '1997-12-10 00:00:00', '1997-11-18 00:00:00', 1, '2.9100', 'Spcialits du monde', '25, rue Lauriston', 'Paris', NULL, '75016', 'France'),
(10739, 'VINET', 3, '1997-11-12 00:00:00', '1997-12-10 00:00:00', '1997-11-17 00:00:00', 3, '11.0800', 'Vins et alcools Chevalier', '59 rue de l-Abbaye', 'Reims', NULL, '51100', 'France'),
(10740, 'WHITC', 4, '1997-11-13 00:00:00', '1997-12-11 00:00:00', '1997-11-25 00:00:00', 2, '81.8800', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10741, 'AROUT', 4, '1997-11-14 00:00:00', '1997-11-28 00:00:00', '1997-11-18 00:00:00', 3, '10.9600', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10742, 'BOTTM', 3, '1997-11-14 00:00:00', '1997-12-12 00:00:00', '1997-11-18 00:00:00', 3, '243.7300', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10743, 'AROUT', 1, '1997-11-17 00:00:00', '1997-12-15 00:00:00', '1997-11-21 00:00:00', 2, '23.7200', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10744, 'VAFFE', 6, '1997-11-17 00:00:00', '1997-12-15 00:00:00', '1997-11-24 00:00:00', 1, '69.1900', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10745, 'QUICK', 9, '1997-11-18 00:00:00', '1997-12-16 00:00:00', '1997-11-27 00:00:00', 1, '3.5200', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10746, 'CHOPS', 1, '1997-11-19 00:00:00', '1997-12-17 00:00:00', '1997-11-21 00:00:00', 3, '31.4300', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10747, 'PICCO', 6, '1997-11-19 00:00:00', '1997-12-17 00:00:00', '1997-11-26 00:00:00', 1, '117.3300', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10748, 'SAVEA', 3, '1997-11-20 00:00:00', '1997-12-18 00:00:00', '1997-11-28 00:00:00', 1, '232.5500', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10749, 'ISLAT', 4, '1997-11-20 00:00:00', '1997-12-18 00:00:00', '1997-12-19 00:00:00', 2, '61.5300', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10750, 'WARTH', 9, '1997-11-21 00:00:00', '1997-12-19 00:00:00', '1997-11-24 00:00:00', 1, '79.3000', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10751, 'RICSU', 3, '1997-11-24 00:00:00', '1997-12-22 00:00:00', '1997-12-03 00:00:00', 3, '130.7900', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10752, 'NORTS', 2, '1997-11-24 00:00:00', '1997-12-22 00:00:00', '1997-11-28 00:00:00', 3, '1.3900', 'North/South', 'South House 300 Queensbridge', 'London', NULL, 'SW7 1RZ', 'UK'),
(10753, 'FRANS', 3, '1997-11-25 00:00:00', '1997-12-23 00:00:00', '1997-11-27 00:00:00', 1, '7.7000', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(10754, 'MAGAA', 6, '1997-11-25 00:00:00', '1997-12-23 00:00:00', '1997-11-27 00:00:00', 3, '2.3800', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10755, 'BONAP', 4, '1997-11-26 00:00:00', '1997-12-24 00:00:00', '1997-11-28 00:00:00', 2, '16.7100', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10756, 'SPLIR', 8, '1997-11-27 00:00:00', '1997-12-25 00:00:00', '1997-12-02 00:00:00', 2, '73.2100', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10757, 'SAVEA', 6, '1997-11-27 00:00:00', '1997-12-25 00:00:00', '1997-12-15 00:00:00', 1, '8.1900', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10758, 'RICSU', 3, '1997-11-28 00:00:00', '1997-12-26 00:00:00', '1997-12-04 00:00:00', 3, '138.1700', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10759, 'ANATR', 3, '1997-11-28 00:00:00', '1997-12-26 00:00:00', '1997-12-12 00:00:00', 3, '11.9900', 'Ana Trujillo Emparedados y helados', 'Avda. de la Constitucin 2222', 'Mxico D.F.', NULL, '5021', 'Mexico'),
(10760, 'MAISD', 4, '1997-12-01 00:00:00', '1997-12-29 00:00:00', '1997-12-10 00:00:00', 1, '155.6400', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10761, 'RATTC', 5, '1997-12-02 00:00:00', '1997-12-30 00:00:00', '1997-12-08 00:00:00', 2, '18.6600', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10762, 'FOLKO', 3, '1997-12-02 00:00:00', '1997-12-30 00:00:00', '1997-12-09 00:00:00', 1, '328.7400', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10763, 'FOLIG', 3, '1997-12-03 00:00:00', '1997-12-31 00:00:00', '1997-12-08 00:00:00', 3, '37.3500', 'Folies gourmandes', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France'),
(10764, 'ERNSH', 6, '1997-12-03 00:00:00', '1997-12-31 00:00:00', '1997-12-08 00:00:00', 3, '145.4500', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10765, 'QUICK', 3, '1997-12-04 00:00:00', '1998-01-01 00:00:00', '1997-12-09 00:00:00', 3, '42.7400', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10766, 'OTTIK', 4, '1997-12-05 00:00:00', '1998-01-02 00:00:00', '1997-12-09 00:00:00', 1, '157.5500', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10767, 'SUPRD', 4, '1997-12-05 00:00:00', '1998-01-02 00:00:00', '1997-12-15 00:00:00', 3, '1.5900', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10768, 'AROUT', 3, '1997-12-08 00:00:00', '1998-01-05 00:00:00', '1997-12-15 00:00:00', 2, '146.3200', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10769, 'VAFFE', 3, '1997-12-08 00:00:00', '1998-01-05 00:00:00', '1997-12-12 00:00:00', 1, '65.0600', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10770, 'HANAR', 8, '1997-12-09 00:00:00', '1998-01-06 00:00:00', '1997-12-17 00:00:00', 3, '5.3200', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10771, 'ERNSH', 9, '1997-12-10 00:00:00', '1998-01-07 00:00:00', '1998-01-02 00:00:00', 2, '11.1900', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10772, 'LEHMS', 3, '1997-12-10 00:00:00', '1998-01-07 00:00:00', '1997-12-19 00:00:00', 2, '91.2800', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10773, 'ERNSH', 1, '1997-12-11 00:00:00', '1998-01-08 00:00:00', '1997-12-16 00:00:00', 3, '96.4300', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10774, 'FOLKO', 4, '1997-12-11 00:00:00', '1997-12-25 00:00:00', '1997-12-12 00:00:00', 1, '48.2000', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10775, 'THECR', 7, '1997-12-12 00:00:00', '1998-01-09 00:00:00', '1997-12-26 00:00:00', 1, '20.2500', 'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'),
(10776, 'ERNSH', 1, '1997-12-15 00:00:00', '1998-01-12 00:00:00', '1997-12-18 00:00:00', 3, '351.5300', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10777, 'GOURL', 7, '1997-12-15 00:00:00', '1997-12-29 00:00:00', '1998-01-21 00:00:00', 2, '3.0100', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10778, 'BERGS', 3, '1997-12-16 00:00:00', '1998-01-13 00:00:00', '1997-12-24 00:00:00', 1, '6.7900', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10779, 'MORGK', 3, '1997-12-16 00:00:00', '1998-01-13 00:00:00', '1998-01-14 00:00:00', 2, '58.1300', 'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig', NULL, '4179', 'Germany'),
(10780, 'LILAS', 2, '1997-12-16 00:00:00', '1997-12-30 00:00:00', '1997-12-25 00:00:00', 1, '42.1300', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10781, 'WARTH', 2, '1997-12-17 00:00:00', '1998-01-14 00:00:00', '1997-12-19 00:00:00', 3, '73.1600', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(10782, 'CACTU', 9, '1997-12-17 00:00:00', '1998-01-14 00:00:00', '1997-12-22 00:00:00', 3, '1.1000', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10783, 'HANAR', 4, '1997-12-18 00:00:00', '1998-01-15 00:00:00', '1997-12-19 00:00:00', 2, '124.9800', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10784, 'MAGAA', 4, '1997-12-18 00:00:00', '1998-01-15 00:00:00', '1997-12-22 00:00:00', 3, '70.0900', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10785, 'GROSR', 1, '1997-12-18 00:00:00', '1998-01-15 00:00:00', '1997-12-24 00:00:00', 3, '1.5100', 'GROSELLA-Restaurante', '5 Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela'),
(10786, 'QUEEN', 8, '1997-12-19 00:00:00', '1998-01-16 00:00:00', '1997-12-23 00:00:00', 1, '110.8700', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10787, 'LAMAI', 2, '1997-12-19 00:00:00', '1998-01-02 00:00:00', '1997-12-26 00:00:00', 1, '249.9300', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10788, 'QUICK', 1, '1997-12-22 00:00:00', '1998-01-19 00:00:00', '1998-01-19 00:00:00', 2, '42.7000', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10789, 'FOLIG', 1, '1997-12-22 00:00:00', '1998-01-19 00:00:00', '1997-12-31 00:00:00', 2, '100.6000', 'Folies gourmandes', '184, chausse de Tournai', 'Lille', NULL, '59000', 'France'),
(10790, 'GOURL', 6, '1997-12-22 00:00:00', '1998-01-19 00:00:00', '1997-12-26 00:00:00', 1, '28.2300', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil');
INSERT INTO `orders` (`OrderID`, `CustomerID`, `EmployeeID`, `OrderDate`, `RequiredDate`, `ShippedDate`, `ShipVia`, `Freight`, `ShipName`, `ShipAddress`, `ShipCity`, `ShipRegion`, `ShipPostalCode`, `ShipCountry`) VALUES
(10791, 'FRANK', 6, '1997-12-23 00:00:00', '1998-01-20 00:00:00', '1998-01-01 00:00:00', 2, '16.8500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10792, 'WOLZA', 1, '1997-12-23 00:00:00', '1998-01-20 00:00:00', '1997-12-31 00:00:00', 3, '23.7900', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10793, 'AROUT', 3, '1997-12-24 00:00:00', '1998-01-21 00:00:00', '1998-01-08 00:00:00', 3, '4.5200', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10794, 'QUEDE', 6, '1997-12-24 00:00:00', '1998-01-21 00:00:00', '1998-01-02 00:00:00', 1, '21.4900', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10795, 'ERNSH', 8, '1997-12-24 00:00:00', '1998-01-21 00:00:00', '1998-01-20 00:00:00', 2, '126.6600', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10796, 'HILAA', 3, '1997-12-25 00:00:00', '1998-01-22 00:00:00', '1998-01-14 00:00:00', 1, '26.5200', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10797, 'DRACD', 7, '1997-12-25 00:00:00', '1998-01-22 00:00:00', '1998-01-05 00:00:00', 2, '33.3500', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(10798, 'ISLAT', 2, '1997-12-26 00:00:00', '1998-01-23 00:00:00', '1998-01-05 00:00:00', 1, '2.3300', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10799, 'KOENE', 9, '1997-12-26 00:00:00', '1998-02-06 00:00:00', '1998-01-05 00:00:00', 3, '30.7600', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10800, 'SEVES', 1, '1997-12-26 00:00:00', '1998-01-23 00:00:00', '1998-01-05 00:00:00', 3, '137.4400', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10801, 'BOLID', 4, '1997-12-29 00:00:00', '1998-01-26 00:00:00', '1997-12-31 00:00:00', 2, '97.0900', 'Blido Comidas preparadas', 'C/ Araquil, 67', 'Madrid', NULL, '28023', 'Spain'),
(10802, 'SIMOB', 4, '1997-12-29 00:00:00', '1998-01-26 00:00:00', '1998-01-02 00:00:00', 2, '257.2600', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(10803, 'WELLI', 4, '1997-12-30 00:00:00', '1998-01-27 00:00:00', '1998-01-06 00:00:00', 1, '55.2300', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10804, 'SEVES', 6, '1997-12-30 00:00:00', '1998-01-27 00:00:00', '1998-01-07 00:00:00', 2, '27.3300', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10805, 'THEBI', 2, '1997-12-30 00:00:00', '1998-01-27 00:00:00', '1998-01-09 00:00:00', 3, '237.3400', 'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'),
(10806, 'VICTE', 3, '1997-12-31 00:00:00', '1998-01-28 00:00:00', '1998-01-05 00:00:00', 2, '22.1100', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10807, 'FRANS', 4, '1997-12-31 00:00:00', '1998-01-28 00:00:00', '1998-01-30 00:00:00', 1, '1.3600', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(10808, 'OLDWO', 2, '1998-01-01 00:00:00', '1998-01-29 00:00:00', '1998-01-09 00:00:00', 3, '45.5300', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10809, 'WELLI', 7, '1998-01-01 00:00:00', '1998-01-29 00:00:00', '1998-01-07 00:00:00', 1, '4.8700', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10810, 'LAUGB', 2, '1998-01-01 00:00:00', '1998-01-29 00:00:00', '1998-01-07 00:00:00', 3, '4.3300', 'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'),
(10811, 'LINOD', 8, '1998-01-02 00:00:00', '1998-01-30 00:00:00', '1998-01-08 00:00:00', 1, '31.2200', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10812, 'REGGC', 5, '1998-01-02 00:00:00', '1998-01-30 00:00:00', '1998-01-12 00:00:00', 1, '59.7800', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10813, 'RICAR', 1, '1998-01-05 00:00:00', '1998-02-02 00:00:00', '1998-01-09 00:00:00', 1, '47.3800', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10814, 'VICTE', 3, '1998-01-05 00:00:00', '1998-02-02 00:00:00', '1998-01-14 00:00:00', 3, '130.9400', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10815, 'SAVEA', 2, '1998-01-05 00:00:00', '1998-02-02 00:00:00', '1998-01-14 00:00:00', 3, '14.6200', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10816, 'GREAL', 4, '1998-01-06 00:00:00', '1998-02-03 00:00:00', '1998-02-04 00:00:00', 2, '719.7800', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10817, 'KOENE', 3, '1998-01-06 00:00:00', '1998-01-20 00:00:00', '1998-01-13 00:00:00', 2, '306.0700', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10818, 'MAGAA', 7, '1998-01-07 00:00:00', '1998-02-04 00:00:00', '1998-01-12 00:00:00', 3, '65.4800', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10819, 'CACTU', 2, '1998-01-07 00:00:00', '1998-02-04 00:00:00', '1998-01-16 00:00:00', 3, '19.7600', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10820, 'RATTC', 3, '1998-01-07 00:00:00', '1998-02-04 00:00:00', '1998-01-13 00:00:00', 2, '37.5200', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10821, 'SPLIR', 1, '1998-01-08 00:00:00', '1998-02-05 00:00:00', '1998-01-15 00:00:00', 1, '36.6800', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10822, 'TRAIH', 6, '1998-01-08 00:00:00', '1998-02-05 00:00:00', '1998-01-16 00:00:00', 3, '7.0000', 'Trail-s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'),
(10823, 'LILAS', 5, '1998-01-09 00:00:00', '1998-02-06 00:00:00', '1998-01-13 00:00:00', 2, '163.9700', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10824, 'FOLKO', 8, '1998-01-09 00:00:00', '1998-02-06 00:00:00', '1998-01-30 00:00:00', 1, '1.2300', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10825, 'DRACD', 1, '1998-01-09 00:00:00', '1998-02-06 00:00:00', '1998-01-14 00:00:00', 1, '79.2500', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(10826, 'BLONP', 6, '1998-01-12 00:00:00', '1998-02-09 00:00:00', '1998-02-06 00:00:00', 1, '7.0900', 'Blondel pre et fils', '24, place Klber', 'Strasbourg', NULL, '67000', 'France'),
(10827, 'BONAP', 1, '1998-01-12 00:00:00', '1998-01-26 00:00:00', '1998-02-06 00:00:00', 2, '63.5400', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10828, 'RANCH', 9, '1998-01-13 00:00:00', '1998-01-27 00:00:00', '1998-02-04 00:00:00', 1, '90.8500', 'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10829, 'ISLAT', 9, '1998-01-13 00:00:00', '1998-02-10 00:00:00', '1998-01-23 00:00:00', 1, '154.7200', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10830, 'TRADH', 4, '1998-01-13 00:00:00', '1998-02-24 00:00:00', '1998-01-21 00:00:00', 2, '81.8300', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10831, 'SANTG', 3, '1998-01-14 00:00:00', '1998-02-11 00:00:00', '1998-01-23 00:00:00', 2, '72.1900', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(10832, 'LAMAI', 2, '1998-01-14 00:00:00', '1998-02-11 00:00:00', '1998-01-19 00:00:00', 2, '43.2600', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10833, 'OTTIK', 6, '1998-01-15 00:00:00', '1998-02-12 00:00:00', '1998-01-23 00:00:00', 2, '71.4900', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(10834, 'TRADH', 1, '1998-01-15 00:00:00', '1998-02-12 00:00:00', '1998-01-19 00:00:00', 3, '29.7800', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10835, 'ALFKI', 1, '1998-01-15 00:00:00', '1998-02-12 00:00:00', '1998-01-21 00:00:00', 3, '69.5300', 'Alfred-s Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(10836, 'ERNSH', 7, '1998-01-16 00:00:00', '1998-02-13 00:00:00', '1998-01-21 00:00:00', 1, '411.8800', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10837, 'BERGS', 9, '1998-01-16 00:00:00', '1998-02-13 00:00:00', '1998-01-23 00:00:00', 3, '13.3200', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10838, 'LINOD', 3, '1998-01-19 00:00:00', '1998-02-16 00:00:00', '1998-01-23 00:00:00', 3, '59.2800', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10839, 'TRADH', 3, '1998-01-19 00:00:00', '1998-02-16 00:00:00', '1998-01-22 00:00:00', 3, '35.4300', 'Tradiao Hipermercados', 'Av. Ins de Castro, 414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'),
(10840, 'LINOD', 4, '1998-01-19 00:00:00', '1998-03-02 00:00:00', '1998-02-16 00:00:00', 2, '2.7100', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10841, 'SUPRD', 5, '1998-01-20 00:00:00', '1998-02-17 00:00:00', '1998-01-29 00:00:00', 2, '424.3000', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10842, 'TORTU', 1, '1998-01-20 00:00:00', '1998-02-17 00:00:00', '1998-01-29 00:00:00', 3, '54.4200', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10843, 'VICTE', 4, '1998-01-21 00:00:00', '1998-02-18 00:00:00', '1998-01-26 00:00:00', 2, '9.2600', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10844, 'PICCO', 8, '1998-01-21 00:00:00', '1998-02-18 00:00:00', '1998-01-26 00:00:00', 2, '25.2200', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(10845, 'QUICK', 8, '1998-01-21 00:00:00', '1998-02-04 00:00:00', '1998-01-30 00:00:00', 1, '212.9800', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10846, 'SUPRD', 2, '1998-01-22 00:00:00', '1998-03-05 00:00:00', '1998-01-23 00:00:00', 3, '56.4600', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10847, 'SAVEA', 4, '1998-01-22 00:00:00', '1998-02-05 00:00:00', '1998-02-10 00:00:00', 3, '487.5700', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10848, 'CONSH', 7, '1998-01-23 00:00:00', '1998-02-20 00:00:00', '1998-01-29 00:00:00', 2, '38.2400', 'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London', NULL, 'WX1 6LT', 'UK'),
(10849, 'KOENE', 9, '1998-01-23 00:00:00', '1998-02-20 00:00:00', '1998-01-30 00:00:00', 2, '0.5600', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10850, 'VICTE', 1, '1998-01-23 00:00:00', '1998-03-06 00:00:00', '1998-01-30 00:00:00', 1, '49.1900', 'Victuailles en stock', '2, rue du Commerce', 'Lyon', NULL, '69004', 'France'),
(10851, 'RICAR', 5, '1998-01-26 00:00:00', '1998-02-23 00:00:00', '1998-02-02 00:00:00', 1, '160.5500', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10852, 'RATTC', 8, '1998-01-26 00:00:00', '1998-02-09 00:00:00', '1998-01-30 00:00:00', 1, '174.0500', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10853, 'BLAUS', 9, '1998-01-27 00:00:00', '1998-02-24 00:00:00', '1998-02-03 00:00:00', 2, '53.8300', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10854, 'ERNSH', 3, '1998-01-27 00:00:00', '1998-02-24 00:00:00', '1998-02-05 00:00:00', 2, '100.2200', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10855, 'OLDWO', 3, '1998-01-27 00:00:00', '1998-02-24 00:00:00', '1998-02-04 00:00:00', 1, '170.9700', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10856, 'ANTON', 3, '1998-01-28 00:00:00', '1998-02-25 00:00:00', '1998-02-10 00:00:00', 2, '58.4300', 'Antonio Moreno Taquera', 'Mataderos 2312', 'Mxico D.F.', NULL, '5023', 'Mexico'),
(10857, 'BERGS', 8, '1998-01-28 00:00:00', '1998-02-25 00:00:00', '1998-02-06 00:00:00', 2, '188.8500', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10858, 'LACOR', 2, '1998-01-29 00:00:00', '1998-02-26 00:00:00', '1998-02-03 00:00:00', 1, '52.5100', 'La corne d-abondance', '67, avenue de l-Europe', 'Versailles', NULL, '78000', 'France'),
(10859, 'FRANK', 1, '1998-01-29 00:00:00', '1998-02-26 00:00:00', '1998-02-02 00:00:00', 2, '76.1000', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10860, 'FRANR', 3, '1998-01-29 00:00:00', '1998-02-26 00:00:00', '1998-02-04 00:00:00', 3, '19.2600', 'France restauration', '54, rue Royale', 'Nantes', NULL, '44000', 'France'),
(10861, 'WHITC', 4, '1998-01-30 00:00:00', '1998-02-27 00:00:00', '1998-02-17 00:00:00', 2, '14.9300', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10862, 'LEHMS', 8, '1998-01-30 00:00:00', '1998-03-13 00:00:00', '1998-02-02 00:00:00', 2, '53.2300', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10863, 'HILAA', 4, '1998-02-02 00:00:00', '1998-03-02 00:00:00', '1998-02-17 00:00:00', 2, '30.2600', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10864, 'AROUT', 4, '1998-02-02 00:00:00', '1998-03-02 00:00:00', '1998-02-09 00:00:00', 2, '3.0400', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10865, 'QUICK', 2, '1998-02-02 00:00:00', '1998-02-16 00:00:00', '1998-02-12 00:00:00', 1, '348.1400', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10866, 'BERGS', 5, '1998-02-03 00:00:00', '1998-03-03 00:00:00', '1998-02-12 00:00:00', 1, '109.1100', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10867, 'LONEP', 6, '1998-02-03 00:00:00', '1998-03-17 00:00:00', '1998-02-11 00:00:00', 1, '1.9300', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10868, 'QUEEN', 7, '1998-02-04 00:00:00', '1998-03-04 00:00:00', '1998-02-23 00:00:00', 2, '191.2700', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10869, 'SEVES', 5, '1998-02-04 00:00:00', '1998-03-04 00:00:00', '1998-02-09 00:00:00', 1, '143.2800', 'Seven Seas Imports', '90 Wadhurst Rd.', 'London', NULL, 'OX15 4NB', 'UK'),
(10870, 'WOLZA', 5, '1998-02-04 00:00:00', '1998-03-04 00:00:00', '1998-02-13 00:00:00', 3, '12.0400', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10871, 'BONAP', 9, '1998-02-05 00:00:00', '1998-03-05 00:00:00', '1998-02-10 00:00:00', 2, '112.2700', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10872, 'GODOS', 5, '1998-02-05 00:00:00', '1998-03-05 00:00:00', '1998-02-09 00:00:00', 2, '175.3200', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10873, 'WILMK', 4, '1998-02-06 00:00:00', '1998-03-06 00:00:00', '1998-02-09 00:00:00', 1, '0.8200', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10874, 'GODOS', 5, '1998-02-06 00:00:00', '1998-03-06 00:00:00', '1998-02-11 00:00:00', 2, '19.5800', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10875, 'BERGS', 4, '1998-02-06 00:00:00', '1998-03-06 00:00:00', '1998-03-03 00:00:00', 2, '32.3700', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10876, 'BONAP', 7, '1998-02-09 00:00:00', '1998-03-09 00:00:00', '1998-02-12 00:00:00', 3, '60.4200', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10877, 'RICAR', 1, '1998-02-09 00:00:00', '1998-03-09 00:00:00', '1998-02-19 00:00:00', 1, '38.0600', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(10878, 'QUICK', 4, '1998-02-10 00:00:00', '1998-03-10 00:00:00', '1998-02-12 00:00:00', 1, '46.6900', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10879, 'WILMK', 3, '1998-02-10 00:00:00', '1998-03-10 00:00:00', '1998-02-12 00:00:00', 3, '8.5000', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10880, 'FOLKO', 7, '1998-02-10 00:00:00', '1998-03-24 00:00:00', '1998-02-18 00:00:00', 1, '88.0100', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10881, 'CACTU', 4, '1998-02-11 00:00:00', '1998-03-11 00:00:00', '1998-02-18 00:00:00', 1, '2.8400', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10882, 'SAVEA', 4, '1998-02-11 00:00:00', '1998-03-11 00:00:00', '1998-02-20 00:00:00', 3, '23.1000', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10883, 'LONEP', 8, '1998-02-12 00:00:00', '1998-03-12 00:00:00', '1998-02-20 00:00:00', 3, '0.5300', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(10884, 'LETSS', 4, '1998-02-12 00:00:00', '1998-03-12 00:00:00', '1998-02-13 00:00:00', 2, '90.9700', 'Let-s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'),
(10885, 'SUPRD', 6, '1998-02-12 00:00:00', '1998-03-12 00:00:00', '1998-02-18 00:00:00', 3, '5.6400', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10886, 'HANAR', 1, '1998-02-13 00:00:00', '1998-03-13 00:00:00', '1998-03-02 00:00:00', 1, '4.9900', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10887, 'GALED', 8, '1998-02-13 00:00:00', '1998-03-13 00:00:00', '1998-02-16 00:00:00', 3, '1.2500', 'Galera del gastronmo', 'Rambla de Catalua, 23', 'Barcelona', NULL, '8022', 'Spain'),
(10888, 'GODOS', 1, '1998-02-16 00:00:00', '1998-03-16 00:00:00', '1998-02-23 00:00:00', 2, '51.8700', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10889, 'RATTC', 9, '1998-02-16 00:00:00', '1998-03-16 00:00:00', '1998-02-23 00:00:00', 3, '280.6100', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10890, 'DUMON', 7, '1998-02-16 00:00:00', '1998-03-16 00:00:00', '1998-02-18 00:00:00', 1, '32.7600', 'Du monde entier', '67, rue des Cinquante Otages', 'Nantes', NULL, '44000', 'France'),
(10891, 'LEHMS', 7, '1998-02-17 00:00:00', '1998-03-17 00:00:00', '1998-02-19 00:00:00', 2, '20.3700', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10892, 'MAISD', 4, '1998-02-17 00:00:00', '1998-03-17 00:00:00', '1998-02-19 00:00:00', 2, '120.2700', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10893, 'KOENE', 9, '1998-02-18 00:00:00', '1998-03-18 00:00:00', '1998-02-20 00:00:00', 2, '77.7800', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(10894, 'SAVEA', 1, '1998-02-18 00:00:00', '1998-03-18 00:00:00', '1998-02-20 00:00:00', 1, '116.1300', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10895, 'ERNSH', 3, '1998-02-18 00:00:00', '1998-03-18 00:00:00', '1998-02-23 00:00:00', 1, '162.7500', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10896, 'MAISD', 7, '1998-02-19 00:00:00', '1998-03-19 00:00:00', '1998-02-27 00:00:00', 3, '32.4500', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10897, 'HUNGO', 3, '1998-02-19 00:00:00', '1998-03-19 00:00:00', '1998-02-25 00:00:00', 2, '603.5400', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10898, 'OCEAN', 4, '1998-02-20 00:00:00', '1998-03-20 00:00:00', '1998-03-06 00:00:00', 2, '1.2700', 'Ocano Atlntico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10899, 'LILAS', 5, '1998-02-20 00:00:00', '1998-03-20 00:00:00', '1998-02-26 00:00:00', 3, '1.2100', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10900, 'WELLI', 1, '1998-02-20 00:00:00', '1998-03-20 00:00:00', '1998-03-04 00:00:00', 2, '1.6600', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10901, 'HILAA', 4, '1998-02-23 00:00:00', '1998-03-23 00:00:00', '1998-02-26 00:00:00', 1, '62.0900', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10902, 'FOLKO', 1, '1998-02-23 00:00:00', '1998-03-23 00:00:00', '1998-03-03 00:00:00', 1, '44.1500', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10903, 'HANAR', 3, '1998-02-24 00:00:00', '1998-03-24 00:00:00', '1998-03-04 00:00:00', 3, '36.7100', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10904, 'WHITC', 3, '1998-02-24 00:00:00', '1998-03-24 00:00:00', '1998-02-27 00:00:00', 3, '162.9500', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(10905, 'WELLI', 9, '1998-02-24 00:00:00', '1998-03-24 00:00:00', '1998-03-06 00:00:00', 2, '13.7200', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10906, 'WOLZA', 4, '1998-02-25 00:00:00', '1998-03-11 00:00:00', '1998-03-03 00:00:00', 3, '26.2900', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10907, 'SPECD', 6, '1998-02-25 00:00:00', '1998-03-25 00:00:00', '1998-02-27 00:00:00', 3, '9.1900', 'Spcialits du monde', '25, rue Lauriston', 'Paris', NULL, '75016', 'France'),
(10908, 'REGGC', 4, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-06 00:00:00', 2, '32.9600', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10909, 'SANTG', 1, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-10 00:00:00', 2, '53.0500', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(10910, 'WILMK', 1, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-04 00:00:00', 3, '38.1100', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(10911, 'GODOS', 3, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-05 00:00:00', 1, '38.1900', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10912, 'HUNGO', 2, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-18 00:00:00', 2, '580.9100', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10913, 'QUEEN', 4, '1998-02-26 00:00:00', '1998-03-26 00:00:00', '1998-03-04 00:00:00', 1, '33.0500', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10914, 'QUEEN', 6, '1998-02-27 00:00:00', '1998-03-27 00:00:00', '1998-03-02 00:00:00', 1, '21.1900', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10915, 'TORTU', 2, '1998-02-27 00:00:00', '1998-03-27 00:00:00', '1998-03-02 00:00:00', 2, '3.5100', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10916, 'RANCH', 1, '1998-02-27 00:00:00', '1998-03-27 00:00:00', '1998-03-09 00:00:00', 2, '63.7700', 'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10917, 'ROMEY', 4, '1998-03-02 00:00:00', '1998-03-30 00:00:00', '1998-03-11 00:00:00', 2, '8.2900', 'Romero y tomillo', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain'),
(10918, 'BOTTM', 3, '1998-03-02 00:00:00', '1998-03-30 00:00:00', '1998-03-11 00:00:00', 3, '48.8300', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10919, 'LINOD', 2, '1998-03-02 00:00:00', '1998-03-30 00:00:00', '1998-03-04 00:00:00', 2, '19.8000', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10920, 'AROUT', 4, '1998-03-03 00:00:00', '1998-03-31 00:00:00', '1998-03-09 00:00:00', 2, '29.6100', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10921, 'VAFFE', 1, '1998-03-03 00:00:00', '1998-04-14 00:00:00', '1998-03-09 00:00:00', 1, '176.4800', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10922, 'HANAR', 5, '1998-03-03 00:00:00', '1998-03-31 00:00:00', '1998-03-05 00:00:00', 3, '62.7400', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10923, 'LAMAI', 7, '1998-03-03 00:00:00', '1998-04-14 00:00:00', '1998-03-13 00:00:00', 3, '68.2600', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(10924, 'BERGS', 3, '1998-03-04 00:00:00', '1998-04-01 00:00:00', '1998-04-08 00:00:00', 2, '151.5200', 'Berglunds snabbkp', 'Berguvsvgen 8', 'Lule', NULL, 'S-958 22', 'Sweden'),
(10925, 'HANAR', 3, '1998-03-04 00:00:00', '1998-04-01 00:00:00', '1998-03-13 00:00:00', 1, '2.2700', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10926, 'ANATR', 4, '1998-03-04 00:00:00', '1998-04-01 00:00:00', '1998-03-11 00:00:00', 3, '39.9200', 'Ana Trujillo Emparedados y helados', 'Avda. de la Constitucin 2222', 'Mxico D.F.', NULL, '5021', 'Mexico'),
(10927, 'LACOR', 4, '1998-03-05 00:00:00', '1998-04-02 00:00:00', '1998-04-08 00:00:00', 1, '19.7900', 'La corne d-abondance', '67, avenue de l-Europe', 'Versailles', NULL, '78000', 'France'),
(10928, 'GALED', 1, '1998-03-05 00:00:00', '1998-04-02 00:00:00', '1998-03-18 00:00:00', 1, '1.3600', 'Galera del gastronmo', 'Rambla de Catalua, 23', 'Barcelona', NULL, '8022', 'Spain'),
(10929, 'FRANK', 6, '1998-03-05 00:00:00', '1998-04-02 00:00:00', '1998-03-12 00:00:00', 1, '33.9300', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(10930, 'SUPRD', 4, '1998-03-06 00:00:00', '1998-04-17 00:00:00', '1998-03-18 00:00:00', 3, '15.5500', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(10931, 'RICSU', 4, '1998-03-06 00:00:00', '1998-03-20 00:00:00', '1998-03-19 00:00:00', 2, '13.6000', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10932, 'BONAP', 8, '1998-03-06 00:00:00', '1998-04-03 00:00:00', '1998-03-24 00:00:00', 1, '134.6400', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10933, 'ISLAT', 6, '1998-03-06 00:00:00', '1998-04-03 00:00:00', '1998-03-16 00:00:00', 3, '54.1500', 'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'),
(10934, 'LEHMS', 3, '1998-03-09 00:00:00', '1998-04-06 00:00:00', '1998-03-12 00:00:00', 3, '32.0100', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(10935, 'WELLI', 4, '1998-03-09 00:00:00', '1998-04-06 00:00:00', '1998-03-18 00:00:00', 3, '47.5900', 'Wellington Importadora', 'Rua do Mercado, 12', 'Resende', 'SP', '08737-363', 'Brazil'),
(10936, 'GREAL', 3, '1998-03-09 00:00:00', '1998-04-06 00:00:00', '1998-03-18 00:00:00', 2, '33.6800', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(10937, 'CACTU', 7, '1998-03-10 00:00:00', '1998-03-24 00:00:00', '1998-03-13 00:00:00', 3, '31.5100', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10938, 'QUICK', 3, '1998-03-10 00:00:00', '1998-04-07 00:00:00', '1998-03-16 00:00:00', 2, '31.8900', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10939, 'MAGAA', 2, '1998-03-10 00:00:00', '1998-04-07 00:00:00', '1998-03-13 00:00:00', 2, '76.3300', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10940, 'BONAP', 8, '1998-03-11 00:00:00', '1998-04-08 00:00:00', '1998-03-23 00:00:00', 3, '19.7700', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(10941, 'SAVEA', 7, '1998-03-11 00:00:00', '1998-04-08 00:00:00', '1998-03-20 00:00:00', 2, '400.8100', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10942, 'REGGC', 9, '1998-03-11 00:00:00', '1998-04-08 00:00:00', '1998-03-18 00:00:00', 3, '17.9500', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(10943, 'BSBEV', 4, '1998-03-11 00:00:00', '1998-04-08 00:00:00', '1998-03-19 00:00:00', 2, '2.1700', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10944, 'BOTTM', 6, '1998-03-12 00:00:00', '1998-03-26 00:00:00', '1998-03-13 00:00:00', 3, '52.9200', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10945, 'MORGK', 4, '1998-03-12 00:00:00', '1998-04-09 00:00:00', '1998-03-18 00:00:00', 1, '10.2200', 'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig', NULL, '4179', 'Germany'),
(10946, 'VAFFE', 1, '1998-03-12 00:00:00', '1998-04-09 00:00:00', '1998-03-19 00:00:00', 2, '27.2000', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10947, 'BSBEV', 3, '1998-03-13 00:00:00', '1998-04-10 00:00:00', '1998-03-16 00:00:00', 2, '3.2600', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(10948, 'GODOS', 3, '1998-03-13 00:00:00', '1998-04-10 00:00:00', '1998-03-19 00:00:00', 3, '23.3900', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(10949, 'BOTTM', 2, '1998-03-13 00:00:00', '1998-04-10 00:00:00', '1998-03-17 00:00:00', 3, '74.4400', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10950, 'MAGAA', 1, '1998-03-16 00:00:00', '1998-04-13 00:00:00', '1998-03-23 00:00:00', 2, '2.5000', 'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo', NULL, '24100', 'Italy'),
(10951, 'RICSU', 9, '1998-03-16 00:00:00', '1998-04-27 00:00:00', '1998-04-07 00:00:00', 2, '30.8500', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(10952, 'ALFKI', 1, '1998-03-16 00:00:00', '1998-04-27 00:00:00', '1998-03-24 00:00:00', 1, '40.4200', 'Alfred-s Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(10953, 'AROUT', 9, '1998-03-16 00:00:00', '1998-03-30 00:00:00', '1998-03-25 00:00:00', 2, '23.7200', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(10954, 'LINOD', 5, '1998-03-17 00:00:00', '1998-04-28 00:00:00', '1998-03-20 00:00:00', 1, '27.9100', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(10955, 'FOLKO', 8, '1998-03-17 00:00:00', '1998-04-14 00:00:00', '1998-03-20 00:00:00', 2, '3.2600', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10956, 'BLAUS', 6, '1998-03-17 00:00:00', '1998-04-28 00:00:00', '1998-03-20 00:00:00', 2, '44.6500', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(10957, 'HILAA', 8, '1998-03-18 00:00:00', '1998-04-15 00:00:00', '1998-03-27 00:00:00', 3, '105.3600', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10958, 'OCEAN', 7, '1998-03-18 00:00:00', '1998-04-15 00:00:00', '1998-03-27 00:00:00', 2, '49.5600', 'Ocano Atlntico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10959, 'GOURL', 6, '1998-03-18 00:00:00', '1998-04-29 00:00:00', '1998-03-23 00:00:00', 2, '4.9800', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(10960, 'HILAA', 3, '1998-03-19 00:00:00', '1998-04-02 00:00:00', '1998-04-08 00:00:00', 1, '2.0800', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10961, 'QUEEN', 8, '1998-03-19 00:00:00', '1998-04-16 00:00:00', '1998-03-30 00:00:00', 1, '104.4700', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(10962, 'QUICK', 8, '1998-03-19 00:00:00', '1998-04-16 00:00:00', '1998-03-23 00:00:00', 2, '275.7900', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10963, 'FURIB', 9, '1998-03-19 00:00:00', '1998-04-16 00:00:00', '1998-03-26 00:00:00', 3, '2.7000', 'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa', NULL, '1675', 'Portugal'),
(10964, 'SPECD', 3, '1998-03-20 00:00:00', '1998-04-17 00:00:00', '1998-03-24 00:00:00', 2, '87.3800', 'Spcialits du monde', '25, rue Lauriston', 'Paris', NULL, '75016', 'France'),
(10965, 'OLDWO', 6, '1998-03-20 00:00:00', '1998-04-17 00:00:00', '1998-03-30 00:00:00', 3, '144.3800', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(10966, 'CHOPS', 4, '1998-03-20 00:00:00', '1998-04-17 00:00:00', '1998-04-08 00:00:00', 1, '27.1900', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(10967, 'TOMSP', 2, '1998-03-23 00:00:00', '1998-04-20 00:00:00', '1998-04-02 00:00:00', 2, '62.2200', 'Toms Spezialitten', 'Luisenstr. 48', 'Mnster', NULL, '44087', 'Germany'),
(10968, 'ERNSH', 1, '1998-03-23 00:00:00', '1998-04-20 00:00:00', '1998-04-01 00:00:00', 3, '74.6000', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10969, 'COMMI', 1, '1998-03-23 00:00:00', '1998-04-20 00:00:00', '1998-03-30 00:00:00', 2, '0.2100', 'Comrcio Mineiro', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'),
(10970, 'BOLID', 9, '1998-03-24 00:00:00', '1998-04-07 00:00:00', '1998-04-24 00:00:00', 1, '16.1600', 'Blido Comidas preparadas', 'C/ Araquil, 67', 'Madrid', NULL, '28023', 'Spain'),
(10971, 'FRANR', 2, '1998-03-24 00:00:00', '1998-04-21 00:00:00', '1998-04-02 00:00:00', 2, '121.8200', 'France restauration', '54, rue Royale', 'Nantes', NULL, '44000', 'France'),
(10972, 'LACOR', 4, '1998-03-24 00:00:00', '1998-04-21 00:00:00', '1998-03-26 00:00:00', 2, '0.0200', 'La corne d-abondance', '67, avenue de l-Europe', 'Versailles', NULL, '78000', 'France'),
(10973, 'LACOR', 6, '1998-03-24 00:00:00', '1998-04-21 00:00:00', '1998-03-27 00:00:00', 2, '15.1700', 'La corne d-abondance', '67, avenue de l-Europe', 'Versailles', NULL, '78000', 'France'),
(10974, 'SPLIR', 3, '1998-03-25 00:00:00', '1998-04-08 00:00:00', '1998-04-03 00:00:00', 3, '12.9600', 'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'),
(10975, 'BOTTM', 1, '1998-03-25 00:00:00', '1998-04-22 00:00:00', '1998-03-27 00:00:00', 3, '32.2700', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10976, 'HILAA', 1, '1998-03-25 00:00:00', '1998-05-06 00:00:00', '1998-04-03 00:00:00', 1, '37.9700', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(10977, 'FOLKO', 8, '1998-03-26 00:00:00', '1998-04-23 00:00:00', '1998-04-10 00:00:00', 3, '208.5000', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10978, 'MAISD', 9, '1998-03-26 00:00:00', '1998-04-23 00:00:00', '1998-04-23 00:00:00', 2, '32.8200', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(10979, 'ERNSH', 8, '1998-03-26 00:00:00', '1998-04-23 00:00:00', '1998-03-31 00:00:00', 2, '353.0700', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10980, 'FOLKO', 4, '1998-03-27 00:00:00', '1998-05-08 00:00:00', '1998-04-17 00:00:00', 1, '1.2600', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10981, 'HANAR', 1, '1998-03-27 00:00:00', '1998-04-24 00:00:00', '1998-04-02 00:00:00', 2, '193.3700', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(10982, 'BOTTM', 2, '1998-03-27 00:00:00', '1998-04-24 00:00:00', '1998-04-08 00:00:00', 1, '14.0100', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(10983, 'SAVEA', 2, '1998-03-27 00:00:00', '1998-04-24 00:00:00', '1998-04-06 00:00:00', 2, '657.5400', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10984, 'SAVEA', 1, '1998-03-30 00:00:00', '1998-04-27 00:00:00', '1998-04-03 00:00:00', 3, '211.2200', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(10985, 'HUNGO', 2, '1998-03-30 00:00:00', '1998-04-27 00:00:00', '1998-04-02 00:00:00', 1, '91.5100', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(10986, 'OCEAN', 8, '1998-03-30 00:00:00', '1998-04-27 00:00:00', '1998-04-21 00:00:00', 2, '217.8600', 'Ocano Atlntico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires', NULL, '1010', 'Argentina'),
(10987, 'EASTC', 8, '1998-03-31 00:00:00', '1998-04-28 00:00:00', '1998-04-06 00:00:00', 1, '185.4800', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(10988, 'RATTC', 3, '1998-03-31 00:00:00', '1998-04-28 00:00:00', '1998-04-10 00:00:00', 2, '61.1400', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(10989, 'QUEDE', 2, '1998-03-31 00:00:00', '1998-04-28 00:00:00', '1998-04-02 00:00:00', 1, '34.7600', 'Que Delcia', 'Rua da Panificadora, 12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'),
(10990, 'ERNSH', 2, '1998-04-01 00:00:00', '1998-05-13 00:00:00', '1998-04-07 00:00:00', 3, '117.6100', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(10991, 'QUICK', 1, '1998-04-01 00:00:00', '1998-04-29 00:00:00', '1998-04-07 00:00:00', 1, '38.5100', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10992, 'THEBI', 1, '1998-04-01 00:00:00', '1998-04-29 00:00:00', '1998-04-03 00:00:00', 3, '4.2700', 'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'),
(10993, 'FOLKO', 7, '1998-04-01 00:00:00', '1998-04-29 00:00:00', '1998-04-10 00:00:00', 3, '8.8100', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(10994, 'VAFFE', 2, '1998-04-02 00:00:00', '1998-04-16 00:00:00', '1998-04-09 00:00:00', 3, '65.5300', 'Vaffeljernet', 'Smagsloget 45', 'rhus', NULL, '8200', 'Denmark'),
(10995, 'PERIC', 1, '1998-04-02 00:00:00', '1998-04-30 00:00:00', '1998-04-06 00:00:00', 3, '46.0000', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(10996, 'QUICK', 4, '1998-04-02 00:00:00', '1998-04-30 00:00:00', '1998-04-10 00:00:00', 2, '1.1200', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(10997, 'LILAS', 8, '1998-04-03 00:00:00', '1998-05-15 00:00:00', '1998-04-13 00:00:00', 2, '73.9100', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(10998, 'WOLZA', 8, '1998-04-03 00:00:00', '1998-04-17 00:00:00', '1998-04-17 00:00:00', 2, '20.3100', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(10999, 'OTTIK', 6, '1998-04-03 00:00:00', '1998-05-01 00:00:00', '1998-04-10 00:00:00', 2, '96.3500', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(11000, 'RATTC', 2, '1998-04-06 00:00:00', '1998-05-04 00:00:00', '1998-04-14 00:00:00', 3, '55.1200', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'),
(11001, 'FOLKO', 2, '1998-04-06 00:00:00', '1998-05-04 00:00:00', '1998-04-14 00:00:00', 2, '197.3000', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(11002, 'SAVEA', 4, '1998-04-06 00:00:00', '1998-05-04 00:00:00', '1998-04-16 00:00:00', 1, '141.1600', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(11003, 'THECR', 3, '1998-04-06 00:00:00', '1998-05-04 00:00:00', '1998-04-08 00:00:00', 3, '14.9100', 'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'),
(11004, 'MAISD', 3, '1998-04-07 00:00:00', '1998-05-05 00:00:00', '1998-04-20 00:00:00', 1, '44.8400', 'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles', NULL, 'B-1180', 'Belgium'),
(11005, 'WILMK', 2, '1998-04-07 00:00:00', '1998-05-05 00:00:00', '1998-04-10 00:00:00', 1, '0.7500', 'Wilman Kala', 'Keskuskatu 45', 'Helsinki', NULL, '21240', 'Finland'),
(11006, 'GREAL', 3, '1998-04-07 00:00:00', '1998-05-05 00:00:00', '1998-04-15 00:00:00', 2, '25.1900', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(11007, 'PRINI', 8, '1998-04-08 00:00:00', '1998-05-06 00:00:00', '1998-04-13 00:00:00', 2, '202.2400', 'Princesa Isabel Vinhos', 'Estrada da sade n. 58', 'Lisboa', NULL, '1756', 'Portugal'),
(11008, 'ERNSH', 7, '1998-04-08 00:00:00', '1998-05-06 00:00:00', NULL, 3, '79.4600', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(11009, 'GODOS', 2, '1998-04-08 00:00:00', '1998-05-06 00:00:00', '1998-04-10 00:00:00', 1, '59.1100', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(11010, 'REGGC', 2, '1998-04-09 00:00:00', '1998-05-07 00:00:00', '1998-04-21 00:00:00', 2, '28.7100', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy'),
(11011, 'ALFKI', 3, '1998-04-09 00:00:00', '1998-05-07 00:00:00', '1998-04-13 00:00:00', 1, '1.2100', 'Alfred-s Futterkiste', 'Obere Str. 57', 'Berlin', NULL, '12209', 'Germany'),
(11012, 'FRANK', 1, '1998-04-09 00:00:00', '1998-04-23 00:00:00', '1998-04-17 00:00:00', 3, '242.9500', 'Frankenversand', 'Berliner Platz 43', 'Mnchen', NULL, '80805', 'Germany'),
(11013, 'ROMEY', 2, '1998-04-09 00:00:00', '1998-05-07 00:00:00', '1998-04-10 00:00:00', 1, '32.9900', 'Romero y tomillo', 'Gran Va, 1', 'Madrid', NULL, '28001', 'Spain'),
(11014, 'LINOD', 2, '1998-04-10 00:00:00', '1998-05-08 00:00:00', '1998-04-15 00:00:00', 3, '23.6000', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(11015, 'SANTG', 2, '1998-04-10 00:00:00', '1998-04-24 00:00:00', '1998-04-20 00:00:00', 2, '4.6200', 'Sant Gourmet', 'Erling Skakkes gate 78', 'Stavern', NULL, '4110', 'Norway'),
(11016, 'AROUT', 9, '1998-04-10 00:00:00', '1998-05-08 00:00:00', '1998-04-13 00:00:00', 2, '33.8000', 'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'),
(11017, 'ERNSH', 9, '1998-04-13 00:00:00', '1998-05-11 00:00:00', '1998-04-20 00:00:00', 2, '754.2600', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(11018, 'LONEP', 4, '1998-04-13 00:00:00', '1998-05-11 00:00:00', '1998-04-16 00:00:00', 2, '11.6500', 'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'),
(11019, 'RANCH', 6, '1998-04-13 00:00:00', '1998-05-11 00:00:00', NULL, 3, '3.1700', 'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires', NULL, '1010', 'Argentina'),
(11020, 'OTTIK', 2, '1998-04-14 00:00:00', '1998-05-12 00:00:00', '1998-04-16 00:00:00', 2, '43.3000', 'Ottilies Kseladen', 'Mehrheimerstr. 369', 'Kln', NULL, '50739', 'Germany'),
(11021, 'QUICK', 3, '1998-04-14 00:00:00', '1998-05-12 00:00:00', '1998-04-21 00:00:00', 1, '297.1800', 'QUICK-Stop', 'Taucherstrae 10', 'Cunewalde', NULL, '1307', 'Germany'),
(11022, 'HANAR', 9, '1998-04-14 00:00:00', '1998-05-12 00:00:00', '1998-05-04 00:00:00', 2, '6.2700', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(11023, 'BSBEV', 1, '1998-04-14 00:00:00', '1998-04-28 00:00:00', '1998-04-24 00:00:00', 2, '123.8300', 'B-s Beverages', 'Fauntleroy Circus', 'London', NULL, 'EC2 5NT', 'UK'),
(11024, 'EASTC', 4, '1998-04-15 00:00:00', '1998-05-13 00:00:00', '1998-04-20 00:00:00', 1, '74.3600', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(11025, 'WARTH', 6, '1998-04-15 00:00:00', '1998-05-13 00:00:00', '1998-04-24 00:00:00', 3, '29.1700', 'Wartian Herkku', 'Torikatu 38', 'Oulu', NULL, '90110', 'Finland'),
(11026, 'FRANS', 4, '1998-04-15 00:00:00', '1998-05-13 00:00:00', '1998-04-28 00:00:00', 1, '47.0900', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(11027, 'BOTTM', 1, '1998-04-16 00:00:00', '1998-05-14 00:00:00', '1998-04-20 00:00:00', 1, '52.5200', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(11028, 'KOENE', 2, '1998-04-16 00:00:00', '1998-05-14 00:00:00', '1998-04-22 00:00:00', 1, '29.5900', 'Kniglich Essen', 'Maubelstr. 90', 'Brandenburg', NULL, '14776', 'Germany'),
(11029, 'CHOPS', 4, '1998-04-16 00:00:00', '1998-05-14 00:00:00', '1998-04-27 00:00:00', 1, '47.8400', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(11030, 'SAVEA', 7, '1998-04-17 00:00:00', '1998-05-15 00:00:00', '1998-04-27 00:00:00', 2, '830.7500', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(11031, 'SAVEA', 6, '1998-04-17 00:00:00', '1998-05-15 00:00:00', '1998-04-24 00:00:00', 2, '227.2200', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(11032, 'WHITC', 2, '1998-04-17 00:00:00', '1998-05-15 00:00:00', '1998-04-23 00:00:00', 3, '606.1900', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(11033, 'RICSU', 7, '1998-04-17 00:00:00', '1998-05-15 00:00:00', '1998-04-23 00:00:00', 3, '84.7400', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(11034, 'OLDWO', 8, '1998-04-20 00:00:00', '1998-06-01 00:00:00', '1998-04-27 00:00:00', 1, '40.3200', 'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'),
(11035, 'SUPRD', 2, '1998-04-20 00:00:00', '1998-05-18 00:00:00', '1998-04-24 00:00:00', 2, '0.1700', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(11036, 'DRACD', 8, '1998-04-20 00:00:00', '1998-05-18 00:00:00', '1998-04-22 00:00:00', 3, '149.4700', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(11037, 'GODOS', 7, '1998-04-21 00:00:00', '1998-05-19 00:00:00', '1998-04-27 00:00:00', 1, '3.2000', 'Godos Cocina Tpica', 'C/ Romero, 33', 'Sevilla', NULL, '41101', 'Spain'),
(11038, 'SUPRD', 1, '1998-04-21 00:00:00', '1998-05-19 00:00:00', '1998-04-30 00:00:00', 2, '29.5900', 'Suprmes dlices', 'Boulevard Tirou, 255', 'Charleroi', NULL, 'B-6000', 'Belgium'),
(11039, 'LINOD', 1, '1998-04-21 00:00:00', '1998-05-19 00:00:00', NULL, 2, '65.0000', 'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'),
(11040, 'GREAL', 4, '1998-04-22 00:00:00', '1998-05-20 00:00:00', NULL, 3, '18.8400', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(11041, 'CHOPS', 3, '1998-04-22 00:00:00', '1998-05-20 00:00:00', '1998-04-28 00:00:00', 2, '48.2200', 'Chop-suey Chinese', 'Hauptstr. 31', 'Bern', NULL, '3012', 'Switzerland'),
(11042, 'COMMI', 2, '1998-04-22 00:00:00', '1998-05-06 00:00:00', '1998-05-01 00:00:00', 1, '29.9900', 'Comrcio Mineiro', 'Av. dos Lusadas, 23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'),
(11043, 'SPECD', 5, '1998-04-22 00:00:00', '1998-05-20 00:00:00', '1998-04-29 00:00:00', 2, '8.8000', 'Spcialits du monde', '25, rue Lauriston', 'Paris', NULL, '75016', 'France'),
(11044, 'WOLZA', 4, '1998-04-23 00:00:00', '1998-05-21 00:00:00', '1998-05-01 00:00:00', 1, '8.7200', 'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa', NULL, '01-012', 'Poland'),
(11045, 'BOTTM', 6, '1998-04-23 00:00:00', '1998-05-21 00:00:00', NULL, 2, '70.5800', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(11046, 'WANDK', 8, '1998-04-23 00:00:00', '1998-05-21 00:00:00', '1998-04-24 00:00:00', 2, '71.6400', 'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart', NULL, '70563', 'Germany'),
(11047, 'EASTC', 7, '1998-04-24 00:00:00', '1998-05-22 00:00:00', '1998-05-01 00:00:00', 3, '46.6200', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(11048, 'BOTTM', 7, '1998-04-24 00:00:00', '1998-05-22 00:00:00', '1998-04-30 00:00:00', 3, '24.1200', 'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'),
(11049, 'GOURL', 3, '1998-04-24 00:00:00', '1998-05-22 00:00:00', '1998-05-04 00:00:00', 1, '8.3400', 'Gourmet Lanchonetes', 'Av. Brasil, 442', 'Campinas', 'SP', '04876-786', 'Brazil'),
(11050, 'FOLKO', 8, '1998-04-27 00:00:00', '1998-05-25 00:00:00', '1998-05-05 00:00:00', 2, '59.4100', 'Folk och f HB', 'kergatan 24', 'Brcke', NULL, 'S-844 67', 'Sweden'),
(11051, 'LAMAI', 7, '1998-04-27 00:00:00', '1998-05-25 00:00:00', NULL, 3, '2.7900', 'La maison d-Asie', '1 rue Alsace-Lorraine', 'Toulouse', NULL, '31000', 'France'),
(11052, 'HANAR', 3, '1998-04-27 00:00:00', '1998-05-25 00:00:00', '1998-05-01 00:00:00', 1, '67.2600', 'Hanari Carnes', 'Rua do Pao, 67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'),
(11053, 'PICCO', 2, '1998-04-27 00:00:00', '1998-05-25 00:00:00', '1998-04-29 00:00:00', 2, '53.0500', 'Piccolo und mehr', 'Geislweg 14', 'Salzburg', NULL, '5020', 'Austria'),
(11054, 'CACTU', 8, '1998-04-28 00:00:00', '1998-05-26 00:00:00', NULL, 1, '0.3300', 'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires', NULL, '1010', 'Argentina'),
(11055, 'HILAA', 7, '1998-04-28 00:00:00', '1998-05-26 00:00:00', '1998-05-05 00:00:00', 2, '120.9200', 'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristbal', 'Tchira', '5022', 'Venezuela'),
(11056, 'EASTC', 8, '1998-04-28 00:00:00', '1998-05-12 00:00:00', '1998-05-01 00:00:00', 2, '278.9600', 'Eastern Connection', '35 King George', 'London', NULL, 'WX3 6FW', 'UK'),
(11057, 'NORTS', 3, '1998-04-29 00:00:00', '1998-05-27 00:00:00', '1998-05-01 00:00:00', 3, '4.1300', 'North/South', 'South House 300 Queensbridge', 'London', NULL, 'SW7 1RZ', 'UK'),
(11058, 'BLAUS', 9, '1998-04-29 00:00:00', '1998-05-27 00:00:00', NULL, 3, '31.1400', 'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim', NULL, '68306', 'Germany'),
(11059, 'RICAR', 2, '1998-04-29 00:00:00', '1998-06-10 00:00:00', NULL, 2, '85.8000', 'Ricardo Adocicados', 'Av. Copacabana, 267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'),
(11060, 'FRANS', 2, '1998-04-30 00:00:00', '1998-05-28 00:00:00', '1998-05-04 00:00:00', 2, '10.9800', 'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino', NULL, '10100', 'Italy'),
(11061, 'GREAL', 4, '1998-04-30 00:00:00', '1998-06-11 00:00:00', NULL, 3, '14.0100', 'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'),
(11062, 'REGGC', 4, '1998-04-30 00:00:00', '1998-05-28 00:00:00', NULL, 2, '29.9300', 'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia', NULL, '42100', 'Italy');
INSERT INTO `orders` (`OrderID`, `CustomerID`, `EmployeeID`, `OrderDate`, `RequiredDate`, `ShippedDate`, `ShipVia`, `Freight`, `ShipName`, `ShipAddress`, `ShipCity`, `ShipRegion`, `ShipPostalCode`, `ShipCountry`) VALUES
(11063, 'HUNGO', 3, '1998-04-30 00:00:00', '1998-05-28 00:00:00', '1998-05-06 00:00:00', 2, '81.7300', 'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork', NULL, 'Ireland'),
(11064, 'SAVEA', 1, '1998-05-01 00:00:00', '1998-05-29 00:00:00', '1998-05-04 00:00:00', 1, '30.0900', 'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'),
(11065, 'LILAS', 8, '1998-05-01 00:00:00', '1998-05-29 00:00:00', NULL, 1, '12.9100', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(11066, 'WHITC', 7, '1998-05-01 00:00:00', '1998-05-29 00:00:00', '1998-05-04 00:00:00', 2, '44.7200', 'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'),
(11067, 'DRACD', 1, '1998-05-04 00:00:00', '1998-05-18 00:00:00', '1998-05-06 00:00:00', 2, '7.9800', 'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen', NULL, '52066', 'Germany'),
(11068, 'QUEEN', 8, '1998-05-04 00:00:00', '1998-06-01 00:00:00', NULL, 2, '81.7500', 'Queen Cozinha', 'Alameda dos Canrios, 891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'),
(11069, 'TORTU', 1, '1998-05-04 00:00:00', '1998-06-01 00:00:00', '1998-05-06 00:00:00', 2, '15.6700', 'Tortuga Restaurante', 'Avda. Azteca 123', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(11070, 'LEHMS', 2, '1998-05-05 00:00:00', '1998-06-02 00:00:00', NULL, 1, '136.0000', 'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.', NULL, '60528', 'Germany'),
(11071, 'LILAS', 1, '1998-05-05 00:00:00', '1998-06-02 00:00:00', NULL, 1, '0.9300', 'LILA-Supermercado', 'Carrera 52 con Ave. Bolvar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'),
(11072, 'ERNSH', 4, '1998-05-05 00:00:00', '1998-06-02 00:00:00', NULL, 2, '258.6400', 'Ernst Handel', 'Kirchgasse 6', 'Graz', NULL, '8010', 'Austria'),
(11073, 'PERIC', 2, '1998-05-05 00:00:00', '1998-06-02 00:00:00', NULL, 2, '24.9500', 'Pericles Comidas clsicas', 'Calle Dr. Jorge Cash 321', 'Mxico D.F.', NULL, '5033', 'Mexico'),
(11074, 'SIMOB', 7, '1998-05-06 00:00:00', '1998-06-03 00:00:00', NULL, 2, '18.4400', 'Simons bistro', 'Vinbltet 34', 'Kobenhavn', NULL, '1734', 'Denmark'),
(11075, 'RICSU', 8, '1998-05-06 00:00:00', '1998-06-03 00:00:00', NULL, 2, '6.1900', 'Richter Supermarkt', 'Starenweg 5', 'Genve', NULL, '1204', 'Switzerland'),
(11076, 'BONAP', 4, '1998-05-06 00:00:00', '1998-06-03 00:00:00', NULL, 2, '38.2800', 'Bon app-', '12, rue des Bouchers', 'Marseille', NULL, '13008', 'France'),
(11077, 'RATTC', 1, '1998-05-06 00:00:00', '1998-06-03 00:00:00', NULL, 2, '8.5300', 'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA');

-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(40) NOT NULL,
  `SupplierID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `QuantityPerUnit` varchar(20) DEFAULT NULL,
  `UnitPrice` decimal(10,4) DEFAULT '0.0000',
  `UnitsInStock` smallint(2) DEFAULT '0',
  `UnitsOnOrder` smallint(2) DEFAULT '0',
  `ReorderLevel` smallint(2) DEFAULT '0',
  `Discontinued` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `SupplierID`, `CategoryID`, `QuantityPerUnit`, `UnitPrice`, `UnitsInStock`, `UnitsOnOrder`, `ReorderLevel`, `Discontinued`) VALUES
(1, 'Chai', 1, 1, '10 boxes x 20 bags', '18.0000', 39, 0, 10, b'0'),
(2, 'Chang', 1, 1, '24 - 12 oz bottles', '19.0000', 17, 40, 25, b'0'),
(3, 'Aniseed Syrup', 1, 2, '12 - 550 ml bottles', '10.0000', 13, 70, 25, b'0'),
(4, 'Chef Anton\'s Cajun Seasoning', 2, 2, '48 - 6 oz jars', '22.0000', 53, 0, 0, b'0'),
(5, 'Chef Anton\'s Gumbo Mix', 2, 2, '36 boxes', '21.3500', 0, 0, 0, b'1'),
(6, 'Grandma\'s Boysenberry Spread', 3, 2, '12 - 8 oz jars', '25.0000', 120, 0, 25, b'0'),
(7, 'Uncle Bob\'s Organic Dried Pears', 3, 7, '12 - 1 lb pkgs.', '30.0000', 15, 0, 10, b'0'),
(8, 'Northwoods Cranberry Sauce', 3, 2, '12 - 12 oz jars', '40.0000', 6, 0, 0, b'0'),
(9, 'Mishi Kobe Niku', 4, 6, '18 - 500 g pkgs.', '97.0000', 29, 0, 0, b'1'),
(10, 'Ikura', 4, 8, '12 - 200 ml jars', '31.0000', 31, 0, 0, b'0'),
(11, 'Queso Cabrales', 5, 4, '1 kg pkg.', '21.0000', 22, 30, 30, b'0'),
(12, 'Queso Manchego La Pastora', 5, 4, '10 - 500 g pkgs.', '38.0000', 86, 0, 0, b'0'),
(13, 'Konbu', 6, 8, '2 kg box', '6.0000', 24, 0, 5, b'0'),
(14, 'Tofu', 6, 7, '40 - 100 g pkgs.', '23.2500', 35, 0, 0, b'0'),
(15, 'Genen Shouyu', 6, 2, '24 - 250 ml bottles', '15.5000', 39, 0, 5, b'0'),
(16, 'Pavlova', 7, 3, '32 - 500 g boxes', '17.4500', 29, 0, 10, b'0'),
(17, 'Alice Mutton', 7, 6, '20 - 1 kg tins', '39.0000', 0, 0, 0, b'1'),
(18, 'Carnarvon Tigers', 7, 8, '16 kg pkg.', '62.5000', 42, 0, 0, b'0'),
(19, 'Teatime Chocolate Biscuits', 8, 3, '10 boxes x 12 pieces', '9.2000', 25, 0, 5, b'0'),
(20, 'Sir Rodney\'s Marmalade', 8, 3, '30 gift boxes', '81.0000', 40, 0, 0, b'0'),
(21, 'Sir Rodney\'s Scones', 8, 3, '24 pkgs. x 4 pieces', '10.0000', 3, 40, 5, b'0'),
(22, 'Gustaf\'s Knckebrd', 9, 5, '24 - 500 g pkgs.', '21.0000', 104, 0, 25, b'0'),
(23, 'Tunnbrd', 9, 5, '12 - 250 g pkgs.', '9.0000', 61, 0, 25, b'0'),
(24, 'Guaran Fantstica', 10, 1, '12 - 355 ml cans', '4.5000', 20, 0, 0, b'1'),
(25, 'NuNuCa Nu-Nougat-Creme', 11, 3, '20 - 450 g glasses', '14.0000', 76, 0, 30, b'0'),
(26, 'Gumbr Gummibrchen', 11, 3, '100 - 250 g bags', '31.2300', 15, 0, 0, b'0'),
(27, 'Schoggi Schokolade', 11, 3, '100 - 100 g pieces', '43.9000', 49, 0, 30, b'0'),
(28, 'Rssle Sauerkraut', 12, 7, '25 - 825 g cans', '45.6000', 26, 0, 0, b'1'),
(29, 'Thringer Rostbratwurst', 12, 6, '50 bags x 30 sausgs.', '123.7900', 0, 0, 0, b'1'),
(30, 'Nord-Ost Matjeshering', 13, 8, '10 - 200 g glasses', '25.8900', 10, 0, 15, b'0'),
(31, 'Gorgonzola Telino', 14, 4, '12 - 100 g pkgs', '12.5000', 0, 70, 20, b'0'),
(32, 'Mascarpone Fabioli', 14, 4, '24 - 200 g pkgs.', '32.0000', 9, 40, 25, b'0'),
(33, 'Geitost', 15, 4, '500 g', '2.5000', 112, 0, 20, b'0'),
(34, 'Sasquatch Ale', 16, 1, '24 - 12 oz bottles', '14.0000', 111, 0, 15, b'0'),
(35, 'Steeleye Stout', 16, 1, '24 - 12 oz bottles', '18.0000', 20, 0, 15, b'0'),
(36, 'Inlagd Sill', 17, 8, '24 - 250 g  jars', '19.0000', 112, 0, 20, b'0'),
(37, 'Gravad lax', 17, 8, '12 - 500 g pkgs.', '26.0000', 11, 50, 25, b'0'),
(38, 'Cte de Blaye', 18, 1, '12 - 75 cl bottles', '263.5000', 17, 0, 15, b'0'),
(39, 'Chartreuse verte', 18, 1, '750 cc per bottle', '18.0000', 69, 0, 5, b'0'),
(40, 'Boston Crab Meat', 19, 8, '24 - 4 oz tins', '18.4000', 123, 0, 30, b'0'),
(41, 'Jack\'s New England Clam Chowder', 19, 8, '12 - 12 oz cans', '9.6500', 85, 0, 10, b'0'),
(42, 'Singaporean Hokkien Fried Mee', 20, 5, '32 - 1 kg pkgs.', '14.0000', 26, 0, 0, b'1'),
(43, 'Ipoh Coffee', 20, 1, '16 - 500 g tins', '46.0000', 17, 10, 25, b'0'),
(44, 'Gula Malacca', 20, 2, '20 - 2 kg bags', '19.4500', 27, 0, 15, b'0'),
(45, 'Rogede sild', 21, 8, '1k pkg.', '9.5000', 5, 70, 15, b'0'),
(46, 'Spegesild', 21, 8, '4 - 450 g glasses', '12.0000', 95, 0, 0, b'0'),
(47, 'Zaanse koeken', 22, 3, '10 - 4 oz boxes', '9.5000', 36, 0, 0, b'0'),
(48, 'Chocolade', 22, 3, '10 pkgs.', '12.7500', 15, 70, 25, b'0'),
(49, 'Maxilaku', 23, 3, '24 - 50 g pkgs.', '20.0000', 10, 60, 15, b'0'),
(50, 'Valkoinen suklaa', 23, 3, '12 - 100 g bars', '16.2500', 65, 0, 30, b'0'),
(51, 'Manjimup Dried Apples', 24, 7, '50 - 300 g pkgs.', '53.0000', 20, 0, 10, b'0'),
(52, 'Filo Mix', 24, 5, '16 - 2 kg boxes', '7.0000', 38, 0, 25, b'0'),
(53, 'Perth Pasties', 24, 6, '48 pieces', '32.8000', 0, 0, 0, b'1'),
(54, 'Tourtire', 25, 6, '16 pies', '7.4500', 21, 0, 10, b'0'),
(55, 'Pt chinois', 25, 6, '24 boxes x 2 pies', '24.0000', 115, 0, 20, b'0'),
(56, 'Gnocchi di nonna Alice', 26, 5, '24 - 250 g pkgs.', '38.0000', 21, 10, 30, b'0'),
(57, 'Ravioli Angelo', 26, 5, '24 - 250 g pkgs.', '19.5000', 36, 0, 20, b'0'),
(58, 'Escargots de Bourgogne', 27, 8, '24 pieces', '13.2500', 62, 0, 20, b'0'),
(59, 'Raclette Courdavault', 28, 4, '5 kg pkg.', '55.0000', 79, 0, 0, b'0'),
(60, 'Camembert Pierrot', 28, 4, '15 - 300 g rounds', '34.0000', 19, 0, 0, b'0'),
(61, 'Sirop d\'rable', 29, 2, '24 - 500 ml bottles', '28.5000', 113, 0, 25, b'0'),
(62, 'Tarte au sucre', 29, 3, '48 pies', '49.3000', 17, 0, 0, b'0'),
(63, 'Vegie-spread', 7, 2, '15 - 625 g jars', '43.9000', 24, 0, 5, b'0'),
(64, 'Wimmers gute Semmelkndel', 12, 5, '20 bags x 4 pieces', '33.2500', 22, 80, 30, b'0'),
(65, 'Louisiana Fiery Hot Pepper Sauce', 2, 2, '32 - 8 oz bottles', '21.0500', 76, 0, 0, b'0'),
(66, 'Louisiana Hot Spiced Okra', 2, 2, '24 - 8 oz jars', '17.0000', 4, 100, 20, b'0'),
(67, 'Laughing Lumberjack Lager', 16, 1, '24 - 12 oz bottles', '14.0000', 52, 0, 10, b'0'),
(68, 'Scottish Longbreads', 8, 3, '10 boxes x 8 pieces', '12.5000', 6, 10, 15, b'0'),
(69, 'Gudbrandsdalsost', 15, 4, '10 kg pkg.', '36.0000', 26, 0, 15, b'0'),
(70, 'Outback Lager', 7, 1, '24 - 355 ml bottles', '15.0000', 15, 10, 30, b'0'),
(71, 'Flotemysost', 15, 4, '10 - 500 g pkgs.', '21.5000', 26, 0, 0, b'0'),
(72, 'Mozzarella di Giovanni', 14, 4, '24 - 200 g pkgs.', '34.8000', 14, 0, 0, b'0'),
(73, 'Rd Kaviar', 17, 8, '24 - 150 g jars', '15.0000', 101, 0, 5, b'0'),
(74, 'Longlife Tofu', 4, 7, '5 kg pkg.', '10.0000', 4, 20, 5, b'0'),
(75, 'Rhnbru Klosterbier', 12, 1, '24 - 0.5 l bottles', '7.7500', 125, 0, 25, b'0'),
(76, 'Lakkalikri', 23, 1, '500 ml', '18.0000', 57, 0, 20, b'0'),
(77, 'Original Frankfurter grne Soe', 12, 2, '12 boxes', '13.0000', 32, 0, 15, b'0');

-- --------------------------------------------------------

--
-- 資料表結構 `shippers`
--

CREATE TABLE `shippers` (
  `ShipperID` int(11) NOT NULL,
  `CompanyName` varchar(40) NOT NULL,
  `Phone` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `shippers`
--

INSERT INTO `shippers` (`ShipperID`, `CompanyName`, `Phone`) VALUES
(1, 'Speedy Express', '(503) 555-9831'),
(2, 'United Package', '(503) 555-3199'),
(3, 'Federal Shipping', '(503) 555-9931');

-- --------------------------------------------------------

--
-- 資料表結構 `suppliers`
--

CREATE TABLE `suppliers` (
  `SupplierID` int(11) NOT NULL,
  `CompanyName` varchar(40) NOT NULL,
  `ContactName` varchar(30) DEFAULT NULL,
  `ContactTitle` varchar(30) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(15) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(15) DEFAULT NULL,
  `Phone` varchar(24) DEFAULT NULL,
  `Fax` varchar(24) DEFAULT NULL,
  `HomePage` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `suppliers`
--

INSERT INTO `suppliers` (`SupplierID`, `CompanyName`, `ContactName`, `ContactTitle`, `Address`, `City`, `Region`, `PostalCode`, `Country`, `Phone`, `Fax`, `HomePage`) VALUES
(1, 'Exotic Liquids', 'Charlotte Cooper', 'Purchasing Manager', '49 Gilbert St.', 'London', NULL, 'EC1 4SD', 'UK', '(171) 555-2222', NULL, NULL),
(2, 'New Orleans Cajun Delights', 'Shelley Burke', 'Order Administrator', 'P.O. Box 78934', 'New Orleans', 'LA', '70117', 'USA', '(100) 555-4822', NULL, '#CAJUN.HTM#'),
(3, 'Grandma Kelly\'s Homestead', 'Regina Murphy', 'Sales Representative', '707 Oxford Rd.', 'Ann Arbor', 'MI', '48104', 'USA', '(313) 555-5735', '(313) 555-3349', NULL),
(4, 'Tokyo Traders', 'Yoshi Nagase', 'Marketing Manager', '9-8 Sekimai\r\nMusashino-shi', 'Tokyo', NULL, '100', 'Japan', '(03) 3555-5011', NULL, NULL),
(5, 'Cooperativa de Quesos \'Las Cabras\'', 'Antonio del Valle Saavedra ', 'Export Administrator', 'Calle del Rosal 4', 'Oviedo', 'Asturias', '33007', 'Spain', '(98) 598 76 54', NULL, NULL),
(6, 'Mayumi\'s', 'Mayumi Ohno', 'Marketing Representative', '92 Setsuko\r\nChuo-ku', 'Osaka', NULL, '545', 'Japan', '(06) 431-7877', NULL, 'Mayumi\'s (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/mayumi.htm#'),
(7, 'Pavlova, Ltd.', 'Ian Devling', 'Marketing Manager', '74 Rose St.\r\nMoonie Ponds', 'Melbourne', 'Victoria', '3058', 'Australia', '(03) 444-2343', '(03) 444-6588', NULL),
(8, 'Specialty Biscuits, Ltd.', 'Peter Wilson', 'Sales Representative', '29 King\'s Way', 'Manchester', NULL, 'M14 GSD', 'UK', '(161) 555-4448', NULL, NULL),
(9, 'PB Knckebrd AB', 'Lars Peterson', 'Sales Agent', 'Kaloadagatan 13', 'Gteborg', NULL, 'S-345 67', 'Sweden ', '031-987 65 43', '031-987 65 91', NULL),
(10, 'Refrescos Americanas LTDA', 'Carlos Diaz', 'Marketing Manager', 'Av. das Americanas 12.890', 'So Paulo', NULL, '5442', 'Brazil', '(11) 555 4640', NULL, NULL),
(11, 'Heli Swaren GmbH & Co. KG', 'Petra Winkler', 'Sales Manager', 'Tiergartenstrae 5', 'Berlin', NULL, '10785', 'Germany', '(010) 9984510', NULL, NULL),
(12, 'Plutzer Lebensmittelgromrkte AG', 'Martin Bein', 'International Marketing Mgr.', 'Bogenallee 51', 'Frankfurt', NULL, '60439', 'Germany', '(069) 992755', NULL, 'Plutzer (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/plutzer.htm#'),
(13, 'Nord-Ost-Fisch Handelsgesellschaft mbH', 'Sven Petersen', 'Coordinator Foreign Markets', 'Frahmredder 112a', 'Cuxhaven', NULL, '27478', 'Germany', '(04721) 8713', '(04721) 8714', NULL),
(14, 'Formaggi Fortini s.r.l.', 'Elio Rossi', 'Sales Representative', 'Viale Dante, 75', 'Ravenna', NULL, '48100', 'Italy', '(0544) 60323', '(0544) 60603', '#FORMAGGI.HTM#'),
(15, 'Norske Meierier', 'Beate Vileid', 'Marketing Manager', 'Hatlevegen 5', 'Sandvika', NULL, '1320', 'Norway', '(0)2-953010', NULL, NULL),
(16, 'Bigfoot Breweries', 'Cheryl Saylor', 'Regional Account Rep.', '3400 - 8th Avenue\r\nSuite 210', 'Bend', 'OR', '97101', 'USA', '(503) 555-9931', NULL, NULL),
(17, 'Svensk Sjfda AB', 'Michael Bjrn', 'Sales Representative', 'Brovallavgen 231', 'Stockholm', NULL, 'S-123 45', 'Sweden', '08-123 45 67', NULL, NULL),
(18, 'Aux joyeux ecclsiastiques', 'Guylne Nodier', 'Sales Manager', '203, Rue des Francs-Bourgeois', 'Paris', NULL, '75004', 'France', '(1) 03.83.00.68', '(1) 03.83.00.62', NULL),
(19, 'New England Seafood Cannery', 'Robb Merchant', 'Wholesale Account Agent', 'Order Processing Dept.\r\n2100 Paul Revere Blvd.', 'Boston', 'MA', '02134', 'USA', '(617) 555-3267', '(617) 555-3389', NULL),
(20, 'Leka Trading', 'Chandra Leka', 'Owner', '471 Serangoon Loop, Suite #402', 'Singapore', NULL, '0512', 'Singapore', '555-8787', NULL, NULL),
(21, 'Lyngbysild', 'Niels Petersen', 'Sales Manager', 'Lyngbysild\r\nFiskebakken 10', 'Lyngby', NULL, '2800', 'Denmark', '43844108', '43844115', NULL),
(22, 'Zaanse Snoepfabriek', 'Dirk Luchte', 'Accounting Manager', 'Verkoop\r\nRijnweg 22', 'Zaandam', NULL, '9999 ZZ', 'Netherlands', '(12345) 1212', '(12345) 1210', NULL),
(23, 'Karkki Oy', 'Anne Heikkonen', 'Product Manager', 'Valtakatu 12', 'Lappeenranta', NULL, '53120', 'Finland', '(953) 10956', NULL, NULL),
(24, 'G\'day, Mate', 'Wendy Mackenzie', 'Sales Representative', '170 Prince Edward Parade\r\nHunter\'s Hill', 'Sydney', 'NSW', '2042', 'Australia', '(02) 555-5914', '(02) 555-4873', 'G\'day Mate (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/gdaymate.htm#'),
(25, 'Ma Maison', 'Jean-Guy Lauzon', 'Marketing Manager', '2960 Rue St. Laurent', 'Montral', 'Qubec', 'H1J 1C3', 'Canada', '(514) 555-9022', NULL, NULL),
(26, 'Pasta Buttini s.r.l.', 'Giovanni Giudici', 'Order Administrator', 'Via dei Gelsomini, 153', 'Salerno', NULL, '84100', 'Italy', '(089) 6547665', '(089) 6547667', NULL),
(27, 'Escargots Nouveaux', 'Marie Delamare', 'Sales Manager', '22, rue H. Voiron', 'Montceau', NULL, '71300', 'France', '85.57.00.07', NULL, NULL),
(28, 'Gai pturage', 'Eliane Noz', 'Sales Representative', 'Bat. B\r\n3, rue des Alpes', 'Annecy', NULL, '74000', 'France', '38.76.98.06', '38.76.98.58', NULL),
(29, 'Forts d\'rables', 'Chantal Goulet', 'Accounting Manager', '148 rue Chasseur', 'Ste-Hyacinthe', 'Qubec', 'J2S 7S8', 'Canada', '(514) 555-2955', '(514) 555-2921', NULL);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CategoryID`),
  ADD KEY `CategoryName` (`CategoryName`);

--
-- 資料表索引 `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD KEY `City` (`City`),
  ADD KEY `CompanyName` (`CompanyName`),
  ADD KEY `PostalCode` (`PostalCode`),
  ADD KEY `Region` (`Region`);

--
-- 資料表索引 `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmployeeID`),
  ADD KEY `LastName` (`LastName`),
  ADD KEY `PostalCode` (`PostalCode`),
  ADD KEY `FK_Employees_Employees` (`ReportsTo`);

--
-- 資料表索引 `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderID`,`ProductID`),
  ADD KEY `FK_Order_Details_Products` (`ProductID`);

--
-- 資料表索引 `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `OrderDate` (`OrderDate`),
  ADD KEY `ShippedDate` (`ShippedDate`),
  ADD KEY `ShipPostalCode` (`ShipPostalCode`),
  ADD KEY `FK_Orders_Customers` (`CustomerID`),
  ADD KEY `FK_Orders_Employees` (`EmployeeID`),
  ADD KEY `FK_Orders_Shippers` (`ShipVia`);

--
-- 資料表索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `ProductName` (`ProductName`),
  ADD KEY `FK_Products_Categories` (`CategoryID`),
  ADD KEY `FK_Products_Suppliers` (`SupplierID`);

--
-- 資料表索引 `shippers`
--
ALTER TABLE `shippers`
  ADD PRIMARY KEY (`ShipperID`);

--
-- 資料表索引 `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`SupplierID`),
  ADD KEY `CompanyName` (`CompanyName`),
  ADD KEY `PostalCode` (`PostalCode`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `categories`
--
ALTER TABLE `categories`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `employees`
--
ALTER TABLE `employees`
  MODIFY `EmployeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11078;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `shippers`
--
ALTER TABLE `shippers`
  MODIFY `ShipperID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `SupplierID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `FK_Employees_Employees` FOREIGN KEY (`ReportsTo`) REFERENCES `employees` (`EmployeeID`);

--
-- 資料表的限制式 `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `FK_Order_Details_Orders` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  ADD CONSTRAINT `FK_Order_Details_Products` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- 資料表的限制式 `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `FK_Orders_Customers` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  ADD CONSTRAINT `FK_Orders_Employees` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`),
  ADD CONSTRAINT `FK_Orders_Shippers` FOREIGN KEY (`ShipVia`) REFERENCES `shippers` (`ShipperID`);

--
-- 資料表的限制式 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_Products_Categories` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`CategoryID`),
  ADD CONSTRAINT `FK_Products_Suppliers` FOREIGN KEY (`SupplierID`) REFERENCES `suppliers` (`SupplierID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
